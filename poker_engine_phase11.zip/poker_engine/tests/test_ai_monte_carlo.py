from poker_engine.ai.game_state import GameStateView, build_game_state_view
from poker_engine.ai.monte_carlo_ai import MonteCarloAI
from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.round import LegalActions
from poker_engine.cards import Card, Rank, Suit
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem


def full_deck():
    return [Card(r, s) for r in Rank for s in Suit]


def cards(text):
    return [Card.from_str(t) for t in text.split()]


def make_game(n=2, stack=1000, seed=1):
    table = Table(table_id="t1", max_seats=4)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", stack)
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    return game


def manual_state(hole_cards, board, *, pot_size=100, to_call=50, stack=1000):
    legal = LegalActions(
        to_call=to_call,
        can_fold=to_call > 0,
        can_check=to_call == 0,
        can_call=to_call > 0,
        can_bet=to_call == 0,
        can_raise=to_call > 0,
        bet_min=10 if to_call == 0 else None,
        bet_max=stack if to_call == 0 else None,
        raise_min=to_call * 2 if to_call > 0 else None,
        raise_max=stack if to_call > 0 else None,
    )
    return GameStateView(
        player_id="hero",
        legal_actions=legal,
        hole_cards=tuple(hole_cards),
        board=tuple(board),
        up_cards={},
        pot_size=pot_size,
        stack=stack,
        to_call=to_call,
        num_players_in_hand=2,
    )


def test_monte_carlo_ai_plays_full_hands_across_many_seeds():
    for seed in range(5):
        game = make_game(seed=seed)
        ais = {f"p{i}": MonteCarloAI(full_deck(), num_simulations=50, seed=seed) for i in range(2)}
        steps = 0
        while not game.is_hand_complete and steps < 100:
            pid = game.current_player
            state = build_game_state_view(game, pid)
            decision = ais[pid].choose_action(state)
            game.apply_action(pid, decision.action_type, decision.amount)
            steps += 1
        assert game.is_hand_complete
        game.settle()
        assert game.outcome is not None


def test_monte_carlo_ai_uses_preflop_heuristic_before_the_flop():
    game = make_game(n=2)
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert state.board == ()
    ai = MonteCarloAI(full_deck(), num_simulations=50, seed=1)
    decision = ai.choose_action(state)
    assert decision.action_type in (
        ActionType.FOLD,
        ActionType.CHECK,
        ActionType.CALL,
        ActionType.BET,
        ActionType.RAISE,
    )


def test_monte_carlo_ai_does_not_fold_the_effective_nuts():
    # Quad aces on a dry board: about as strong as postflop poker gets.
    board = cards("Ac Kd 2h")
    hole = cards("Ah As")
    remaining = [c for c in full_deck() if c not in hole and c not in board]
    state = manual_state(hole, board, pot_size=100, to_call=50, stack=1000)
    ai = MonteCarloAI(remaining, num_simulations=150, raise_equity_threshold=0.6, seed=1)
    decision = ai.choose_action(state)
    assert decision.action_type != ActionType.FOLD


def test_monte_carlo_ai_folds_a_hopeless_hand_facing_a_huge_bet():
    # Worst possible hand (7-2 offsuit) on a scary board, facing a bet
    # bigger than the pot -- pot odds this bad should be an easy fold
    # even against a random range.
    board = cards("Ac Kd Qh")
    hole = cards("7c 2d")
    remaining = [c for c in full_deck() if c not in hole and c not in board]
    state = manual_state(hole, board, pot_size=50, to_call=500, stack=1000)
    ai = MonteCarloAI(remaining, num_simulations=150, seed=1)
    decision = ai.choose_action(state)
    assert decision.action_type == ActionType.FOLD


def test_monte_carlo_ai_uses_evaluator_parameter():
    # Just confirm a non-default evaluator can be passed through without error.
    from poker_engine.simulation.equity import omaha_evaluator

    board = cards("Ac Kd 2h")
    hole = cards("Ah As 2c 3c")
    remaining = [c for c in full_deck() if c not in hole and c not in board]
    state = manual_state(hole, board, pot_size=100, to_call=50, stack=1000)
    ai = MonteCarloAI(remaining, num_simulations=100, evaluator=omaha_evaluator, seed=1)
    decision = ai.choose_action(state)
    assert decision.action_type in (
        ActionType.FOLD,
        ActionType.CHECK,
        ActionType.CALL,
        ActionType.BET,
        ActionType.RAISE,
    )
