import pytest

from poker_engine.cards import Card, Rank, Suit
from poker_engine.simulation import HandRange, HandRangeError


def full_deck():
    return [Card(r, s) for r in Rank for s in Suit]


def test_specific_range_from_explicit_hands():
    hands = [[Card.from_str("Ah"), Card.from_str("Kh")], [Card.from_str("2c"), Card.from_str("3c")]]
    r = HandRange.specific(hands)
    assert len(r.combos) == 2
    assert r.hole_card_count == 2


def test_random_range_enumerates_all_combos():
    deck = full_deck()[:6]  # small deck for a manageable combo count
    r = HandRange.random(deck, 2)
    from itertools import combinations

    assert len(r.combos) == len(list(combinations(deck, 2)))


def test_random_range_excludes_nothing_not_in_deck():
    deck = full_deck()
    r = HandRange.random(deck, 2)
    all_cards_used = {c for combo in r.combos for c in combo}
    assert all_cards_used <= set(deck)


def test_range_rejects_empty_combos():
    with pytest.raises(HandRangeError):
        HandRange(combos=())


def test_range_rejects_mismatched_combo_sizes():
    with pytest.raises(HandRangeError):
        HandRange(combos=((Card.from_str("Ah"), Card.from_str("Kh")), (Card.from_str("2c"),)))


def test_random_rejects_non_positive_hole_card_count():
    with pytest.raises(HandRangeError):
        HandRange.random(full_deck(), 0)


def test_random_rejects_deck_too_small():
    with pytest.raises(HandRangeError):
        HandRange.random([Card.from_str("Ah")], 2)
