import pytest

from poker_engine.ai.base_ai import AIError
from poker_engine.ai.game_state import GameStateView, build_game_state_view
from poker_engine.ai.pluggable import (
    CallableModelAI,
    PolicyTableAI,
    default_information_set_key,
    state_to_features,
)
from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.round import LegalActions
from poker_engine.cards import Card
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem


def make_game(n=2, stack=1000, seed=1):
    table = Table(table_id="t1", max_seats=4)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", stack)
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    return game


def manual_state(to_call=50, pot_size=100, stack=1000):
    legal = LegalActions(
        to_call=to_call,
        can_fold=to_call > 0,
        can_check=to_call == 0,
        can_call=to_call > 0,
        can_bet=to_call == 0,
        can_raise=to_call > 0,
        bet_min=10 if to_call == 0 else None,
        bet_max=stack if to_call == 0 else None,
        raise_min=to_call * 2 if to_call > 0 else None,
        raise_max=stack if to_call > 0 else None,
    )
    return GameStateView(
        player_id="hero",
        legal_actions=legal,
        hole_cards=(Card.from_str("Ah"), Card.from_str("Kh")),
        board=(),
        up_cards={},
        pot_size=pot_size,
        stack=stack,
        to_call=to_call,
        num_players_in_hand=2,
    )


# ---------------------------------------------------------------------------
# PolicyTableAI
# ---------------------------------------------------------------------------

def test_policy_table_ai_samples_from_distribution():
    state = manual_state(to_call=50)

    def always_fold(_state):
        return {ActionType.FOLD: 1.0}

    ai = PolicyTableAI(always_fold, seed=1)
    decision = ai.choose_action(state)
    assert decision.action_type == ActionType.FOLD


def test_policy_table_ai_filters_to_legal_actions_only():
    state = manual_state(to_call=0)  # can't fold when to_call == 0

    def wants_to_fold_or_check(_state):
        return {ActionType.FOLD: 0.9, ActionType.CHECK: 0.1}

    ai = PolicyTableAI(wants_to_fold_or_check, seed=1)
    for _ in range(10):
        decision = ai.choose_action(state)
        assert decision.action_type == ActionType.CHECK


def test_policy_table_ai_raises_when_no_legal_action_has_positive_probability():
    state = manual_state(to_call=0)

    def only_fold(_state):
        return {ActionType.FOLD: 1.0}

    ai = PolicyTableAI(only_fold, seed=1)
    with pytest.raises(AIError):
        ai.choose_action(state)


def test_policy_table_ai_sizes_bets_within_legal_range():
    state = manual_state(to_call=0, pot_size=100, stack=1000)

    def wants_to_bet(_state):
        return {ActionType.BET: 1.0}

    ai = PolicyTableAI(wants_to_bet, bet_sizing_fraction=0.75, seed=1)
    decision = ai.choose_action(state)
    assert decision.action_type == ActionType.BET
    assert state.legal_actions.bet_min <= decision.amount <= state.legal_actions.bet_max


def test_policy_table_ai_plays_full_hands_with_real_game():
    def uniform_policy(state):
        legal = state.legal_actions
        dist = {}
        if legal.can_check:
            dist[ActionType.CHECK] = 1.0
        if legal.can_call:
            dist[ActionType.CALL] = 1.0
        if legal.can_fold:
            dist[ActionType.FOLD] = 0.3
        if legal.can_raise:
            dist[ActionType.RAISE] = 0.3
        return dist

    for seed in range(10):
        game = make_game(seed=seed)
        ais = {f"p{i}": PolicyTableAI(uniform_policy, seed=seed) for i in range(2)}
        steps = 0
        while not game.is_hand_complete and steps < 100:
            pid = game.current_player
            state = build_game_state_view(game, pid)
            decision = ais[pid].choose_action(state)
            game.apply_action(pid, decision.action_type, decision.amount)
            steps += 1
        assert game.is_hand_complete
        game.settle()


def test_default_information_set_key_is_deterministic():
    state = manual_state(to_call=50)
    key1 = default_information_set_key(state)
    key2 = default_information_set_key(state)
    assert key1 == key2
    assert isinstance(key1, str)


# ---------------------------------------------------------------------------
# CallableModelAI
# ---------------------------------------------------------------------------

def test_callable_model_ai_deterministic_picks_argmax():
    state = manual_state(to_call=50)

    def model(features):
        return {ActionType.FOLD: 1.0, ActionType.CALL: 10.0, ActionType.RAISE: 2.0}

    ai = CallableModelAI(model, deterministic=True)
    decision = ai.choose_action(state)
    assert decision.action_type == ActionType.CALL


def test_callable_model_ai_filters_illegal_actions():
    state = manual_state(to_call=0)  # CHECK/BET legal, not FOLD/CALL

    def model(features):
        return {ActionType.FOLD: 100.0, ActionType.CHECK: 1.0}

    ai = CallableModelAI(model, deterministic=True)
    decision = ai.choose_action(state)
    assert decision.action_type == ActionType.CHECK


def test_callable_model_ai_raises_when_no_legal_action_scored():
    state = manual_state(to_call=0)

    def model(features):
        return {ActionType.FOLD: 1.0}

    ai = CallableModelAI(model)
    with pytest.raises(AIError):
        ai.choose_action(state)


def test_state_to_features_returns_fixed_length_numeric_vector():
    state = manual_state(to_call=50)
    features = state_to_features(state)
    assert all(isinstance(f, float) for f in features)
    assert len(features) > 0
    features2 = state_to_features(state)
    assert len(features) == len(features2)


def test_callable_model_ai_plays_full_hands_with_real_game():
    def simple_model(features):
        strength = features[0]
        return {
            ActionType.FOLD: 1.0 - strength,
            ActionType.CHECK: 0.5,
            ActionType.CALL: strength,
            ActionType.BET: strength,
            ActionType.RAISE: strength,
        }

    for seed in range(10):
        game = make_game(seed=seed)
        ais = {f"p{i}": CallableModelAI(simple_model, seed=seed) for i in range(2)}
        steps = 0
        while not game.is_hand_complete and steps < 100:
            pid = game.current_player
            state = build_game_state_view(game, pid)
            decision = ais[pid].choose_action(state)
            game.apply_action(pid, decision.action_type, decision.amount)
            steps += 1
        assert game.is_hand_complete
        game.settle()
