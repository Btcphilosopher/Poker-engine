"""
Property-based tests for the AI framework: randomized matchups between
rule-based archetypes across variants must terminate and conserve chips,
the same standard every earlier phase's property tests held games to.
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.ai.archetypes import (
    CallingStation,
    LooseAggressive,
    LoosePassive,
    RandomPlayer,
    TightAggressive,
    TightPassive,
)
from poker_engine.ai.game_state import build_game_state_view
from poker_engine.ai.profiles import CashGameAI, TournamentAI
from poker_engine.betting import BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import FiveCardDraw, Omaha, TexasHoldem

ARCHETYPES = [
    RandomPlayer,
    CallingStation,
    TightPassive,
    LoosePassive,
    TightAggressive,
    LooseAggressive,
    TournamentAI,
    CashGameAI,
]

FLOP_VARIANTS = [TexasHoldem, Omaha]


def _make_ai(cls, seed):
    if cls is RandomPlayer:
        return cls(seed=seed)
    return cls()


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=6),
    variant=st.sampled_from(FLOP_VARIANTS),
    structure=st.sampled_from([BettingStructure.NO_LIMIT, BettingStructure.POT_LIMIT]),
)
@settings(max_examples=60, deadline=None)
def test_random_archetype_matchups_terminate_and_conserve_chips(seed, n_players, variant, structure):
    rng = random.Random(seed)
    table = Table(table_id="t1", max_seats=9)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, 1000)

    ai_by_player = {pid: _make_ai(rng.choice(ARCHETYPES), seed=rng.randint(0, 2**31 - 1)) for pid in ids}

    total_before = sum(p.stack for p in table.occupied_seats())
    deck = Deck()
    deck.shuffle(seed=rng.randint(0, 2**31 - 1))
    game = variant(table, structure, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()

    steps = 0
    while not game.is_hand_complete and steps < 400:
        pid = game.current_player
        state = build_game_state_view(game, pid)
        decision = ai_by_player[pid].choose_action(state)
        game.apply_action(pid, decision.action_type, decision.amount)
        steps += 1

    assert game.is_hand_complete
    assert steps < 400
    game.settle()
    total_after = sum(p.stack for p in table.occupied_seats())
    assert total_after == total_before


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=5),
)
@settings(max_examples=30, deadline=None)
def test_random_archetype_matchups_in_draw_games(seed, n_players):
    rng = random.Random(seed)
    table = Table(table_id="t1", max_seats=9)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, 1000)

    ai_by_player = {pid: _make_ai(rng.choice(ARCHETYPES), seed=rng.randint(0, 2**31 - 1)) for pid in ids}

    total_before = sum(p.stack for p in table.occupied_seats())
    deck = Deck()
    deck.shuffle(seed=rng.randint(0, 2**31 - 1))
    game = FiveCardDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()

    steps = 0
    while not game.is_hand_complete and steps < 400:
        if game.awaiting_draw:
            pid = game.current_player
            hand = game.hole_cards[pid]
            discard = rng.sample(hand, rng.randint(0, len(hand)))
            game.draw(pid, discard)
            steps += 1
            continue
        pid = game.current_player
        state = build_game_state_view(game, pid)
        decision = ai_by_player[pid].choose_action(state)
        game.apply_action(pid, decision.action_type, decision.amount)
        steps += 1

    assert game.is_hand_complete
    game.settle()
    total_after = sum(p.stack for p in table.occupied_seats())
    assert total_after == total_before


@given(seed=st.integers(min_value=0, max_value=2**31 - 1))
@settings(max_examples=20, deadline=None)
def test_random_heads_up_archetype_matchups(seed):
    rng = random.Random(seed)
    table = Table(table_id="t1", max_seats=4)
    table.sit_down("a", "a", 1000)
    table.sit_down("b", "b", 1000)
    ai_by_player = {
        "a": _make_ai(rng.choice(ARCHETYPES), seed=rng.randint(0, 2**31 - 1)),
        "b": _make_ai(rng.choice(ARCHETYPES), seed=rng.randint(0, 2**31 - 1)),
    }

    total_before = sum(p.stack for p in table.occupied_seats())
    deck = Deck()
    deck.shuffle(seed=rng.randint(0, 2**31 - 1))
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()

    steps = 0
    while not game.is_hand_complete and steps < 300:
        pid = game.current_player
        state = build_game_state_view(game, pid)
        decision = ai_by_player[pid].choose_action(state)
        game.apply_action(pid, decision.action_type, decision.amount)
        steps += 1

    assert game.is_hand_complete
    game.settle()
    total_after = sum(p.stack for p in table.occupied_seats())
    assert total_after == total_before
