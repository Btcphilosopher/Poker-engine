import pytest

from poker_engine.ai.game_state import GameStateError, build_game_state_view
from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.structures import StudStakes
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import FiveCardDraw, SevenCardStud, TexasHoldem


def make_holdem(n=3, stack=1000, seed=1):
    table = Table(table_id="t1", max_seats=6)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", stack)
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    return game


def test_build_state_for_current_player():
    game = make_holdem()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert state.player_id == pid
    assert len(state.hole_cards) == 2


def test_build_state_rejects_wrong_players_turn():
    game = make_holdem()
    pid = game.current_player
    other = next(p for p in ["p0", "p1", "p2"] if p != pid)
    with pytest.raises(GameStateError):
        build_game_state_view(game, other)


def test_state_reflects_pot_size():
    game = make_holdem()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert state.pot_size == game.pot_size


def test_state_reflects_legal_actions():
    game = make_holdem()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert state.legal_actions == game.legal_actions(pid)


def test_state_board_empty_preflop():
    game = make_holdem()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert state.board == ()


def test_state_board_populated_after_flop():
    game = make_holdem(n=2)
    while not game.is_hand_complete and not game.board:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    if not game.is_hand_complete:
        pid = game.current_player
        state = build_game_state_view(game, pid)
        assert len(state.board) == 3


def test_state_up_cards_empty_for_flop_game():
    game = make_holdem()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert state.up_cards == {}


def test_state_up_cards_populated_for_stud():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    deck = Deck()
    deck.shuffle(seed=1)
    game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes, deck=deck)
    game.start_hand()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert len(state.up_cards) == 2
    assert state.board == ()


def test_state_num_players_in_hand_decreases_after_fold():
    game = make_holdem(n=3)
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    next_pid = game.current_player
    state = build_game_state_view(game, next_pid)
    assert state.num_players_in_hand == 2


def test_state_to_call_matches_legal_actions():
    game = make_holdem()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert state.to_call == state.legal_actions.to_call


def test_state_for_draw_game():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    deck = Deck()
    deck.shuffle(seed=1)
    game = FiveCardDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    assert len(state.hole_cards) == 5
    assert state.board == ()
