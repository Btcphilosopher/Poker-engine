import pytest

from poker_engine.ai.archetypes import (
    CallingStation,
    LooseAggressive,
    LoosePassive,
    RandomPlayer,
    TightAggressive,
    TightPassive,
)
from poker_engine.ai.game_state import build_game_state_view
from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem


def make_game(n=3, stack=1000, seed=1):
    table = Table(table_id="t1", max_seats=6)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", stack)
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    return game


def play_full_hand_with_ai(ai_by_player, seed=1, n=3, stack=1000):
    game = make_game(n=n, stack=stack, seed=seed)
    steps = 0
    while not game.is_hand_complete and steps < 200:
        pid = game.current_player
        state = build_game_state_view(game, pid)
        decision = ai_by_player[pid].choose_action(state)
        game.apply_action(pid, decision.action_type, decision.amount)
        steps += 1
    assert game.is_hand_complete
    game.settle()
    return game


ARCHETYPE_FACTORIES = {
    "random": lambda: RandomPlayer(seed=1),
    "calling_station": CallingStation,
    "tight_passive": TightPassive,
    "loose_passive": LoosePassive,
    "tight_aggressive": TightAggressive,
    "loose_aggressive": LooseAggressive,
}


@pytest.mark.parametrize("name", ARCHETYPE_FACTORIES.keys())
def test_archetype_produces_only_legal_actions_across_many_hands(name):
    factory = ARCHETYPE_FACTORIES[name]
    for seed in range(20):
        ai_by_player = {f"p{i}": factory() for i in range(3)}
        game = play_full_hand_with_ai(ai_by_player, seed=seed)
        assert game.outcome is not None


def test_calling_station_never_raises():
    game = make_game(n=2)
    ai = CallingStation()
    for _ in range(20):
        if game.is_hand_complete:
            break
        pid = game.current_player
        state = build_game_state_view(game, pid)
        decision = ai.choose_action(state)
        assert decision.action_type in (ActionType.CHECK, ActionType.CALL, ActionType.FOLD)
        game.apply_action(pid, decision.action_type, decision.amount)


def test_calling_station_checks_when_free():
    game = make_game(n=2)
    ai = CallingStation()
    pid = game.current_player
    state = build_game_state_view(game, pid)
    if state.legal_actions.can_check:
        decision = ai.choose_action(state)
        assert decision.action_type == ActionType.CHECK


def test_random_player_is_seed_reproducible():
    game1 = make_game(n=2, seed=5)
    game2 = make_game(n=2, seed=5)
    ai1 = RandomPlayer(seed=42)
    ai2 = RandomPlayer(seed=42)

    pid1 = game1.current_player
    state1 = build_game_state_view(game1, pid1)
    decision1 = ai1.choose_action(state1)

    pid2 = game2.current_player
    state2 = build_game_state_view(game2, pid2)
    decision2 = ai2.choose_action(state2)

    assert decision1 == decision2


def test_tight_passive_folds_more_often_than_loose_passive_over_many_hands():
    fold_counts = {"tight": 0, "loose": 0}
    for seed in range(30):
        for label, cls in [("tight", TightPassive), ("loose", LoosePassive)]:
            game = make_game(n=2, seed=seed)
            pid = game.current_player
            state = build_game_state_view(game, pid)
            if state.legal_actions.to_call > 0:
                decision = cls().choose_action(state)
                if decision.action_type == ActionType.FOLD:
                    fold_counts[label] += 1
    assert fold_counts["tight"] >= fold_counts["loose"]


def test_loose_aggressive_raises_more_often_than_tight_aggressive_over_many_hands():
    raise_counts = {"tight": 0, "loose": 0}
    for seed in range(30):
        for label, cls in [("tight", TightAggressive), ("loose", LooseAggressive)]:
            game = make_game(n=2, seed=seed)
            pid = game.current_player
            state = build_game_state_view(game, pid)
            decision = cls().choose_action(state)
            if decision.action_type in (ActionType.BET, ActionType.RAISE):
                raise_counts[label] += 1
    assert raise_counts["loose"] >= raise_counts["tight"]


def test_random_player_never_errors_across_many_hands():
    for seed in range(10):
        ai_by_player = {f"p{i}": RandomPlayer(seed=seed) for i in range(3)}
        play_full_hand_with_ai(ai_by_player, seed=seed)  # should not raise


# ---------------------------------------------------------------------------
# direct unit tests for specific decision branches
# ---------------------------------------------------------------------------

def _manual_state(*, to_call, pot_size=100, stack=1000, strength_cards=None):
    from poker_engine.ai.game_state import GameStateView
    from poker_engine.betting.round import LegalActions
    from poker_engine.cards import Card

    legal = LegalActions(
        to_call=to_call,
        can_fold=to_call > 0,
        can_check=to_call == 0,
        can_call=to_call > 0,
        can_bet=to_call == 0,
        can_raise=to_call > 0,
        bet_min=10 if to_call == 0 else None,
        bet_max=stack if to_call == 0 else None,
        raise_min=to_call * 2 if to_call > 0 else None,
        raise_max=stack if to_call > 0 else None,
    )
    hole = strength_cards or (Card.from_str("2h"), Card.from_str("3d"))
    return GameStateView(
        player_id="hero",
        legal_actions=legal,
        hole_cards=tuple(hole),
        board=(),
        up_cards={},
        pot_size=pot_size,
        stack=stack,
        to_call=to_call,
        num_players_in_hand=2,
    )


def test_check_or_call_falls_back_to_fold_when_neither_available():
    from poker_engine.ai.archetypes import check_or_call
    from poker_engine.betting.round import LegalActions

    state = _manual_state(to_call=50)
    # Force a scenario where neither check nor call is legal (e.g. already
    # covered elsewhere) by constructing LegalActions directly.
    forced = LegalActions(to_call=50, can_fold=True, can_check=False, can_call=False, can_bet=False, can_raise=False)
    from dataclasses import replace

    state = replace(state, legal_actions=forced)
    decision = check_or_call(state)
    assert decision.action_type == ActionType.FOLD


def test_bet_or_raise_falls_back_to_check_or_call_when_neither_available():
    from dataclasses import replace

    from poker_engine.ai.archetypes import bet_or_raise
    from poker_engine.betting.round import LegalActions

    state = _manual_state(to_call=0)
    forced = LegalActions(to_call=0, can_fold=False, can_check=True, can_call=False, can_bet=False, can_raise=False)
    state = replace(state, legal_actions=forced)
    decision = bet_or_raise(state)
    assert decision.action_type == ActionType.CHECK


def test_random_player_raises_when_no_legal_actions_at_all():
    from dataclasses import replace

    from poker_engine.betting.round import LegalActions

    state = _manual_state(to_call=0)
    forced = LegalActions(
        to_call=0, can_fold=False, can_check=False, can_call=False, can_bet=False, can_raise=False
    )
    state = replace(state, legal_actions=forced)
    ai = RandomPlayer(seed=1)
    with pytest.raises(RuntimeError):
        ai.choose_action(state)


def test_loose_passive_raises_a_monster_hand_when_checking_is_free():
    from poker_engine.cards import Card
    from poker_engine.evaluation.hand_category import HandCategory, HandResult

    ai = LoosePassive()
    # Strength >= 0.95 requires an actual made hand at that tier; use a
    # board that gives a guaranteed straight flush so estimate_hand_strength
    # returns 1.0.
    state = _manual_state(to_call=0, pot_size=100)
    from dataclasses import replace

    board = (
        Card.from_str("4h"),
        Card.from_str("5h"),
        Card.from_str("6h"),
        Card.from_str("7h"),
        Card.from_str("8h"),
    )
    state = replace(state, board=board, hole_cards=(Card.from_str("2c"), Card.from_str("3c")))
    decision = ai.choose_action(state)
    assert decision.action_type in (ActionType.BET, ActionType.RAISE)


def test_loose_passive_folds_a_truly_hopeless_hand_facing_a_bet():
    from dataclasses import replace

    from poker_engine.cards import Card

    ai = LoosePassive()
    state = _manual_state(to_call=50, pot_size=100)
    # Weakest possible unpaired preflop holding.
    state = replace(state, hole_cards=(Card.from_str("2c"), Card.from_str("3d")))
    decision = ai.choose_action(state)
    assert decision.action_type in (ActionType.FOLD, ActionType.CALL)
