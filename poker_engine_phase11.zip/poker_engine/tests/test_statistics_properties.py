"""
Property-based tests for hand history + statistics: randomized full hands
across variants must always produce a chip-conserving, replayable
HandHistory, and stats accumulated from many random hands must stay
within their defined bounds.
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.statistics import PlayerStatsTracker, begin_hand_history, replay_hand_history
from poker_engine.tables import Table
from poker_engine.variants import Omaha, TexasHoldem

VARIANTS = [TexasHoldem, Omaha]


def _play_random_hand_with_history(seed, n_players, variant, structure):
    rng = random.Random(seed)
    table = Table(table_id="t1", max_seats=9)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}

    deck = Deck()
    deck.shuffle(seed=rng.randint(0, 2**31 - 1))
    game = variant(table, structure, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)

    steps = 0
    while not game.is_hand_complete and steps < 300:
        pid = game.current_player
        legal = game.legal_actions(pid)
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        weights = {ActionType.CHECK: 5, ActionType.CALL: 5, ActionType.FOLD: 2, ActionType.RAISE: 2}
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
        if chosen is ActionType.RAISE:
            game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
        else:
            game.apply_action(pid, chosen)
        steps += 1
    assert game.is_hand_complete
    game.settle()
    return builder.finalize("h", starting)


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=6),
    variant=st.sampled_from(VARIANTS),
    structure=st.sampled_from([BettingStructure.NO_LIMIT, BettingStructure.POT_LIMIT]),
)
@settings(max_examples=60, deadline=None)
def test_random_hand_histories_conserve_chips_and_replay_cleanly(seed, n_players, variant, structure):
    history = _play_random_hand_with_history(seed, n_players, variant, structure)

    assert sum(history.starting_stacks.values()) == sum(history.final_stacks.values())
    assert sum(history.winners.values()) <= sum(history.starting_stacks.values())

    steps = replay_hand_history(history)
    assert len(steps) == len(history.actions)
    pots = [a.pot_after for a in history.actions]
    assert pots == sorted(pots)  # pot never decreases across recorded actions

    # Every action must be attributable to a seated player.
    assert all(a.player_id in history.starting_stacks for a in history.actions)


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=5),
)
@settings(max_examples=30, deadline=None)
def test_random_stats_accumulation_stays_within_bounds(seed, n_players):
    rng = random.Random(seed)
    tracker = PlayerStatsTracker()
    for _ in range(5):
        history = _play_random_hand_with_history(
            rng.randint(0, 2**31 - 1), n_players, TexasHoldem, BettingStructure.NO_LIMIT
        )
        pid = rng.choice(list(history.starting_stacks.keys()))
        tracker.record_hand(history, pid)

    assert 0.0 <= tracker.vpip_pct <= 1.0
    assert 0.0 <= tracker.pfr_pct <= 1.0
    assert 0.0 <= tracker.three_bet_pct <= 1.0
    assert tracker.aggression_factor >= 0.0
    assert tracker.hands_tracked == 5
