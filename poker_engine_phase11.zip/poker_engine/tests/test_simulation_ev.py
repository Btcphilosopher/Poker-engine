import pytest

from poker_engine.simulation import ExpectedValueError, expected_value_of_bet, expected_value_of_call, pot_odds


def test_pot_odds_basic():
    assert abs(pot_odds(100, 50) - (50 / 150)) < 1e-9


def test_pot_odds_zero_to_call_needs_no_equity():
    assert pot_odds(100, 0) == 0.0


def test_pot_odds_rejects_negative_inputs():
    with pytest.raises(ExpectedValueError):
        pot_odds(-1, 50)
    with pytest.raises(ExpectedValueError):
        pot_odds(100, -1)


def test_ev_of_call_positive_above_breakeven():
    assert expected_value_of_call(100, 50, 0.5) == 25.0


def test_ev_of_call_at_breakeven_is_zero():
    equity = pot_odds(100, 50)
    assert abs(expected_value_of_call(100, 50, equity)) < 1e-9


def test_ev_of_call_negative_below_breakeven():
    equity = pot_odds(100, 50) - 0.05
    assert expected_value_of_call(100, 50, equity) < 0


def test_ev_of_call_zero_equity_loses_the_call():
    assert expected_value_of_call(100, 50, 0.0) == -50.0


def test_ev_of_call_full_equity_wins_the_whole_pot_plus_call():
    assert expected_value_of_call(100, 50, 1.0) == 100.0


def test_ev_of_call_rejects_negative_inputs():
    with pytest.raises(ExpectedValueError):
        expected_value_of_call(-1, 50, 0.5)
    with pytest.raises(ExpectedValueError):
        expected_value_of_call(100, -1, 0.5)


def test_ev_of_call_rejects_invalid_equity():
    with pytest.raises(ExpectedValueError):
        expected_value_of_call(100, 50, 1.5)
    with pytest.raises(ExpectedValueError):
        expected_value_of_call(100, 50, -0.1)


def test_ev_of_bet_pure_bluff_always_folded_wins_the_pot():
    assert expected_value_of_bet(100, 50, fold_equity=1.0, equity_if_called=0.0) == 100.0


def test_ev_of_bet_never_folded_reduces_to_call_ev_style_formula():
    ev = expected_value_of_bet(100, 50, fold_equity=0.0, equity_if_called=0.6)
    expected = 0.6 * (100 + 2 * 50) - 50
    assert abs(ev - expected) < 1e-9


def test_ev_of_bet_rejects_negative_inputs():
    with pytest.raises(ExpectedValueError):
        expected_value_of_bet(-1, 50, 0.5, 0.5)
    with pytest.raises(ExpectedValueError):
        expected_value_of_bet(100, -1, 0.5, 0.5)


def test_ev_of_bet_rejects_invalid_probabilities():
    with pytest.raises(ExpectedValueError):
        expected_value_of_bet(100, 50, fold_equity=1.5, equity_if_called=0.5)
    with pytest.raises(ExpectedValueError):
        expected_value_of_bet(100, 50, fold_equity=0.5, equity_if_called=-0.1)
