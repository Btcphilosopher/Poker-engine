from poker_engine.ai.hand_strength import (
    estimate_hand_strength,
    estimate_made_hand_strength,
    estimate_preflop_strength,
)
from poker_engine.cards import Card
from poker_engine.evaluation.evaluator import evaluate_best_of


def cards(text):
    return [Card.from_str(t) for t in text.split()]


# ---------------------------------------------------------------------------
# preflop heuristic
# ---------------------------------------------------------------------------

def test_preflop_pocket_aces_is_the_strongest():
    aa = estimate_preflop_strength(cards("Ah Ad"))
    kk = estimate_preflop_strength(cards("Kh Kd"))
    assert aa > kk
    assert aa == 1.0


def test_preflop_pair_beats_weak_unpaired_holdings():
    pair = estimate_preflop_strength(cards("2h 2d"))
    weak_unpaired = estimate_preflop_strength(cards("7h 2d"))
    assert pair > weak_unpaired


def test_preflop_suited_beats_otherwise_identical_offsuit():
    suited = estimate_preflop_strength(cards("Ah Kh"))
    offsuit = estimate_preflop_strength(cards("Ah Kd"))
    assert suited > offsuit


def test_preflop_high_cards_beat_low_cards():
    high = estimate_preflop_strength(cards("Ah Kd"))
    low = estimate_preflop_strength(cards("3h 2d"))
    assert high > low


def test_preflop_strength_bounded_zero_to_one():
    for hole in [cards("Ah Ad"), cards("2h 3d"), cards("7c 2s")]:
        s = estimate_preflop_strength(hole)
        assert 0.0 <= s <= 1.0


# ---------------------------------------------------------------------------
# made hand heuristic
# ---------------------------------------------------------------------------

def test_made_hand_strength_ordering_matches_category_ordering():
    high_card = evaluate_best_of(cards("2h 5d 9c Jh Ks Ac 3d"))
    pair = evaluate_best_of(cards("2h 2d 9c Jh Ks Ac 3d"))
    two_pair = evaluate_best_of(cards("2h 2d 9c 9h Ks Ac 3d"))
    trips = evaluate_best_of(cards("2h 2d 2c 9h Ks Ac 3d"))
    straight = evaluate_best_of(cards("4h 5d 6c 7h 8s Ac 3d"))
    flush = evaluate_best_of(cards("2h 5h 9h Jh Kh Ac 3d"))
    full_house = evaluate_best_of(cards("2h 2d 2c 9h 9s Ac 3d"))
    quads = evaluate_best_of(cards("2h 2d 2c 2s 9h Ac 3d"))
    straight_flush = evaluate_best_of(cards("4h 5h 6h 7h 8h Ac 3d"))

    hands_worst_to_best = [high_card, pair, two_pair, trips, straight, flush, full_house, quads, straight_flush]
    strengths = [estimate_made_hand_strength(h) for h in hands_worst_to_best]
    assert strengths == sorted(strengths)


def test_made_hand_strength_bounded_zero_to_one():
    result = evaluate_best_of(cards("4h 5h 6h 7h 8h Ac 3d"))
    assert 0.0 <= estimate_made_hand_strength(result) <= 1.0


def test_made_hand_strength_higher_kicker_scores_higher_within_category():
    high_pair = evaluate_best_of(cards("Ah Ad 9c 5h Ks 2c 3d"))
    low_pair = evaluate_best_of(cards("2h 2d 9c 5h Ks Ac 3d"))
    assert estimate_made_hand_strength(high_pair) > estimate_made_hand_strength(low_pair)


# ---------------------------------------------------------------------------
# dispatcher
# ---------------------------------------------------------------------------

def test_estimate_hand_strength_falls_back_to_preflop_with_no_board():
    hole = cards("Ah Ad")
    assert estimate_hand_strength(hole, []) == estimate_preflop_strength(hole)


def test_estimate_hand_strength_falls_back_when_fewer_than_five_total_cards():
    hole = cards("Ah Ad")
    board = cards("2c 3d")
    assert estimate_hand_strength(hole, board) == estimate_preflop_strength(hole)


def test_estimate_hand_strength_evaluates_made_hand_with_enough_cards():
    hole = cards("Ah Ad")
    board = cards("Ac 2d 3h")  # trips
    strength = estimate_hand_strength(hole, board)
    result = evaluate_best_of(hole + board)
    assert strength == estimate_made_hand_strength(result)


def test_estimate_hand_strength_strong_beats_weak_postflop():
    board = cards("Ac Kd 2h 3s 9c")
    strong = estimate_hand_strength(cards("Ah As"), board)  # trip aces
    weak = estimate_hand_strength(cards("5h 6d"), board)  # nothing
    assert strong > weak
