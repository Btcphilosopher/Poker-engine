import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.statistics import PlayerStatsTracker, StatisticsError, begin_hand_history, calculate_roi
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem


def make_hand(n=2, stack=1000, seed=1):
    table = Table(table_id="t1", max_seats=6)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", stack)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    return game, starting


def finish_with_checks_and_calls(game, builder, starting, hand_id):
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    return builder.finalize(hand_id, starting)


# ---------------------------------------------------------------------------
# basic accumulation
# ---------------------------------------------------------------------------

def test_record_hand_increments_hands_tracked():
    game, starting = make_hand(seed=1)
    builder = begin_hand_history(game)
    history = finish_with_checks_and_calls(game, builder, starting, "h1")

    tracker = PlayerStatsTracker()
    tracker.record_hand(history, "p0")
    assert tracker.hands_tracked == 1
    tracker.record_hand(history, "p0")  # a second (contrived) hand -- just checking accumulation
    assert tracker.hands_tracked == 2


def test_record_hand_unknown_player_raises():
    game, starting = make_hand(seed=1)
    builder = begin_hand_history(game)
    history = finish_with_checks_and_calls(game, builder, starting, "h1")

    tracker = PlayerStatsTracker()
    with pytest.raises(StatisticsError):
        tracker.record_hand(history, "ghost")


def test_empty_tracker_stats_are_zero_not_errors():
    tracker = PlayerStatsTracker()
    assert tracker.vpip_pct == 0.0
    assert tracker.pfr_pct == 0.0
    assert tracker.three_bet_pct == 0.0
    assert tracker.aggression_factor == 0.0
    assert tracker.bb_per_100 == 0.0


# ---------------------------------------------------------------------------
# VPIP / PFR / 3-bet -- controlled scenario
# ---------------------------------------------------------------------------

def _play_controlled_3bet_hand(seed=1):
    table = Table(table_id="t1", max_seats=5)
    for pid in ["a", "b", "c", "d"]:
        table.sit_down(pid, pid, 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)

    first = game.current_player
    legal = game.legal_actions(first)
    game.apply_action(first, ActionType.RAISE, legal.raise_min)  # PFR (the "2-bet")

    declined = game.current_player
    game.apply_action(declined, ActionType.CALL)  # faced exactly 1 raise, a 3-bet opportunity -- declined (called)

    three_bettor = game.current_player
    legal = game.legal_actions(three_bettor)
    game.apply_action(three_bettor, ActionType.RAISE, legal.raise_min)  # faced exactly 1 raise -- takes it (3-bets)

    fourth = game.current_player
    game.apply_action(fourth, ActionType.FOLD)  # faces 2 raises now -- a 4-bet decision, NOT a 3-bet opportunity

    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    history = builder.finalize("h1", starting)
    return history, first, declined, three_bettor, fourth


def test_pfr_only_credited_to_first_raiser():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, first)
    assert tracker.pfr_hands == 1


def test_pfr_not_credited_to_three_bettor():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, three_bettor)
    assert tracker.pfr_hands == 0


def test_three_bet_credited_to_three_bettor_only():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker_first = PlayerStatsTracker()
    tracker_first.record_hand(history, first)
    assert tracker_first.three_bet_hands == 0

    tracker_three_bettor = PlayerStatsTracker()
    tracker_three_bettor.record_hand(history, three_bettor)
    assert tracker_three_bettor.three_bet_hands == 1


def test_three_bet_opportunity_credited_to_player_who_declined_it():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, declined)
    assert tracker.three_bet_opportunities == 1
    assert tracker.three_bet_hands == 0  # they called, didn't 3-bet


def test_three_bet_opportunity_also_credited_to_the_player_who_took_it():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, three_bettor)
    assert tracker.three_bet_opportunities == 1
    assert tracker.three_bet_hands == 1


def test_player_facing_two_raises_does_not_get_a_three_bet_opportunity():
    # `fourth` faces the ALREADY-made 3-bet -- a 4-bet decision, not a
    # 3-bet opportunity (nobody was ever offered exactly one raise to
    # respond to in that specific seat this hand).
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, fourth)
    assert tracker.three_bet_opportunities == 0


def test_first_raiser_does_not_get_a_three_bet_opportunity_from_their_own_raise():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, first)
    assert tracker.three_bet_opportunities == 0


def test_vpip_true_for_voluntary_raiser_and_caller():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, first)
    assert tracker.vpip_hands == 1


def test_vpip_false_for_player_who_folds_without_voluntary_action():
    history, first, declined, three_bettor, fourth = _play_controlled_3bet_hand()
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, fourth)
    assert tracker.vpip_hands == 0


# ---------------------------------------------------------------------------
# aggression factor
# ---------------------------------------------------------------------------

def test_aggression_factor_pure_calling_is_zero():
    game, starting = make_hand(n=2, seed=1)
    builder = begin_hand_history(game)
    history = finish_with_checks_and_calls(game, builder, starting, "h1")
    tracker = PlayerStatsTracker()
    # find a player who only ever checked/called this hand
    for pid in starting:
        t = PlayerStatsTracker()
        t.record_hand(history, pid)
        assert t.aggression_factor == 0.0  # nobody bet in this all-check/call hand


def test_aggression_factor_infinite_when_only_aggression_no_calls():
    from poker_engine.statistics.hand_history import HandHistory, HandHistoryAction

    history = HandHistory(
        hand_id="h1",
        variant_name="TexasHoldem",
        structure="no_limit",
        table_id="t1",
        seat_order=("a", "b"),
        starting_stacks={"a": 1000, "b": 1000},
        hole_cards={},
        board=(),
        up_cards={},
        actions=(
            HandHistoryAction(player_id="a", action_type=ActionType.BET, amount=50, street_label="flop", pot_after=100),
        ),
        winners={"a": 100},
        final_stacks={"a": 1050, "b": 950},
        big_blind_equivalent=20,
    )
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, "a")
    assert tracker.aggression_factor == float("inf")


def test_aggression_factor_ignores_preflop_actions():
    from poker_engine.statistics.hand_history import HandHistory, HandHistoryAction

    history = HandHistory(
        hand_id="h1",
        variant_name="TexasHoldem",
        structure="no_limit",
        table_id="t1",
        seat_order=("a", "b"),
        starting_stacks={"a": 1000, "b": 1000},
        hole_cards={},
        board=(),
        up_cards={},
        actions=(
            HandHistoryAction(player_id="a", action_type=ActionType.RAISE, amount=50, street_label="preflop", pot_after=100),
            HandHistoryAction(player_id="a", action_type=ActionType.CALL, amount=20, street_label="flop", pot_after=120),
        ),
        winners={"a": 120},
        final_stacks={"a": 1050, "b": 950},
        big_blind_equivalent=20,
    )
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, "a")
    # only the flop CALL counts; preflop RAISE is excluded from AF
    assert tracker.postflop_aggressive_actions == 0
    assert tracker.postflop_calls == 1
    assert tracker.aggression_factor == 0.0


# ---------------------------------------------------------------------------
# bb_per_100
# ---------------------------------------------------------------------------

def test_bb_per_100_positive_for_net_winner():
    from poker_engine.statistics.hand_history import HandHistory

    history = HandHistory(
        hand_id="h1",
        variant_name="TexasHoldem",
        structure="no_limit",
        table_id="t1",
        seat_order=("a", "b"),
        starting_stacks={"a": 1000, "b": 1000},
        hole_cards={},
        board=(),
        up_cards={},
        actions=(),
        winners={"a": 40},
        final_stacks={"a": 1040, "b": 960},
        big_blind_equivalent=20,
    )
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, "a")
    # profit = +40, / bb(20) = +2 bb this hand; over 1 hand, bb/100 = 2 * 100 = 200
    assert tracker.bb_per_100 == 200.0


def test_bb_per_100_zero_without_big_blind_equivalent():
    from poker_engine.statistics.hand_history import HandHistory

    history = HandHistory(
        hand_id="h1",
        variant_name="TexasHoldem",
        structure="no_limit",
        table_id="t1",
        seat_order=("a", "b"),
        starting_stacks={"a": 1000, "b": 1000},
        hole_cards={},
        board=(),
        up_cards={},
        actions=(),
        winners={"a": 40},
        final_stacks={"a": 1040, "b": 960},
        big_blind_equivalent=None,
    )
    tracker = PlayerStatsTracker()
    tracker.record_hand(history, "a")
    assert tracker.bb_per_100 == 0.0
    assert tracker.total_profit == 40  # profit is still tracked even without a bb reference


# ---------------------------------------------------------------------------
# ROI
# ---------------------------------------------------------------------------

def test_roi_profit():
    assert calculate_roi(100, 150) == 0.5


def test_roi_breakeven():
    assert calculate_roi(100, 100) == 0.0


def test_roi_total_loss():
    assert calculate_roi(100, 0) == -1.0


def test_roi_rejects_non_positive_buy_ins():
    with pytest.raises(StatisticsError):
        calculate_roi(0, 100)
    with pytest.raises(StatisticsError):
        calculate_roi(-10, 100)
