"""
Full AI integration test: several different archetypes seated at the same
table, playing real hands across multiple variants, exactly the pattern
every earlier phase's capstone integration test used -- proving the
pieces work together, not just in isolation.
"""

from poker_engine.ai.archetypes import (
    CallingStation,
    LooseAggressive,
    LoosePassive,
    RandomPlayer,
    TightAggressive,
    TightPassive,
)
from poker_engine.ai.game_state import build_game_state_view
from poker_engine.ai.monte_carlo_ai import MonteCarloAI
from poker_engine.ai.profiles import CashGameAI, TournamentAI
from poker_engine.betting import BettingStructure, BlindLevel
from poker_engine.cards import Card, Rank, Suit
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import Omaha, ShortDeckHoldem, TexasHoldem


def full_deck():
    return [Card(r, s) for r in Rank for s in Suit]


def play_hand_to_completion(game, ai_by_player, max_steps=300):
    steps = 0
    while not game.is_hand_complete and steps < max_steps:
        pid = game.current_player
        state = build_game_state_view(game, pid)
        decision = ai_by_player[pid].choose_action(state)
        game.apply_action(pid, decision.action_type, decision.amount)
        steps += 1
    assert game.is_hand_complete
    return game


def test_six_different_archetypes_play_a_full_holdem_hand():
    table = Table(table_id="t1", max_seats=6)
    ids = ["random", "station", "tp", "lp", "tag", "lag"]
    for pid in ids:
        table.sit_down(pid, pid, 1000)

    ai_by_player = {
        "random": RandomPlayer(seed=1),
        "station": CallingStation(),
        "tp": TightPassive(),
        "lp": LoosePassive(),
        "tag": TightAggressive(),
        "lag": LooseAggressive(),
    }

    total_before = sum(p.stack for p in table.occupied_seats())
    deck = Deck()
    deck.shuffle(seed=1)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    play_hand_to_completion(game, ai_by_player)
    game.settle()
    total_after = sum(p.stack for p in table.occupied_seats())
    assert total_after == total_before


def test_monte_carlo_ai_and_tournament_ai_play_together_across_many_hands():
    table = Table(table_id="t1", max_seats=4)
    table.sit_down("mc", "mc", 1000)
    table.sit_down("tourney", "tourney", 1000)
    ai_by_player = {
        "mc": MonteCarloAI(full_deck(), num_simulations=50, seed=1),
        "tourney": TournamentAI(),
    }

    total_before = sum(p.stack for p in table.occupied_seats())
    hands_played = 0
    for seed in range(8):
        if len(table.active_player_ids()) < 2:
            break
        deck = Deck()
        deck.shuffle(seed=seed)
        game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
        game.start_hand()
        play_hand_to_completion(game, ai_by_player)
        game.settle()
        hands_played += 1

    total_after = sum(p.stack for p in table.occupied_seats())
    assert hands_played > 0
    assert total_after == total_before


def test_ai_archetypes_play_across_multiple_variants():
    # Omaha
    table1 = Table(table_id="t1", max_seats=4)
    table1.sit_down("a", "a", 1000)
    table1.sit_down("b", "b", 1000)
    ai_by_player = {"a": TightAggressive(), "b": LooseAggressive()}
    deck = Deck()
    deck.shuffle(seed=1)
    game1 = Omaha(table1, BettingStructure.POT_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game1.start_hand()
    play_hand_to_completion(game1, ai_by_player)
    game1.settle()
    assert game1.outcome is not None

    # Short Deck -- builds its own 36-card deck internally
    table2 = Table(table_id="t2", max_seats=4)
    table2.sit_down("c", "c", 1000)
    table2.sit_down("d", "d", 1000)
    ai_by_player2 = {"c": CallingStation(), "d": CashGameAI()}
    game2 = ShortDeckHoldem(table2, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
    game2.start_hand()
    play_hand_to_completion(game2, ai_by_player2)
    game2.settle()
    assert game2.outcome is not None
