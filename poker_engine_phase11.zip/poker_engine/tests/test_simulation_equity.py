import pytest

from poker_engine.cards import Card, Rank, Suit
from poker_engine.simulation import (
    EquityError,
    HandRange,
    calculate_equity,
    hand_strength_vs_random,
    omaha_evaluator,
)


def full_deck():
    return [Card(r, s) for r in Rank for s in Suit]


def cards(text):
    return [Card.from_str(t) for t in text.split()]


# ---------------------------------------------------------------------------
# EquityResult
# ---------------------------------------------------------------------------

def test_equity_result_lose_derived_from_win_and_tie():
    from poker_engine.simulation.equity import EquityResult

    r = EquityResult(win=0.6, tie=0.1)
    assert abs(r.lose - 0.3) < 1e-9
    assert abs(r.equity - 0.7) < 1e-9


def test_equity_result_lose_never_negative():
    from poker_engine.simulation.equity import EquityResult

    r = EquityResult(win=0.6, tie=0.6)  # deliberately overlapping/rounding edge case
    assert r.lose == 0.0


# ---------------------------------------------------------------------------
# calculate_equity: basic correctness
# ---------------------------------------------------------------------------

def test_dominant_hand_wins_almost_always():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    board = cards("Ac As 2h")  # quads already made for AA
    remaining = [c for c in full_deck() if c not in aa + kk + board]
    results = calculate_equity([aa, kk], board, remaining, num_simulations=500, seed=1)
    assert results[0].win > 0.99


def test_equal_hands_split_evenly():
    a = cards("2h 3h")
    b = cards("2d 3d")
    board = cards("Ac Kc Qc Jc Tc")  # royal flush on board -- everyone plays the board
    remaining = [c for c in full_deck() if c not in a + b + board]
    results = calculate_equity([a, b], board, remaining, num_simulations=200, seed=1)
    # .tie is the average FRACTIONAL SHARE won via ties (already divided by
    # the number of tied players), not how often a tie happens -- a
    # guaranteed 2-way chop means each player's equity is exactly 0.5.
    assert abs(results[0].tie - 0.5) < 1e-9
    assert abs(results[1].tie - 0.5) < 1e-9
    assert abs(results[0].equity - 0.5) < 1e-9
    assert results[0].win == 0.0


def test_probabilities_sum_to_one_per_player_set():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    remaining = [c for c in full_deck() if c not in aa + kk]
    results = calculate_equity([aa, kk], [], remaining, num_simulations=500, seed=1)
    total_win = sum(r.win for r in results)
    total_tie = sum(r.tie for r in results)
    assert abs(total_win + total_tie - 1.0) < 1e-6


def test_three_way_equity_sums_correctly():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    qq = cards("Qh Qd")
    remaining = [c for c in full_deck() if c not in aa + kk + qq]
    results = calculate_equity([aa, kk, qq], [], remaining, num_simulations=500, seed=1)
    assert len(results) == 3
    total = sum(r.win + r.tie for r in results)
    assert abs(total - 1.0) < 1e-6


def test_full_board_no_further_cards_needed():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    board = cards("2c 3c 4c 5c 9h")
    remaining = [c for c in full_deck() if c not in aa + kk + board]
    results = calculate_equity([aa, kk], board, remaining, num_simulations=100, seed=1)
    assert results[0].win in (0.0, 1.0) or results[0].tie == 1.0


# ---------------------------------------------------------------------------
# range vs range
# ---------------------------------------------------------------------------

def test_specific_hand_vs_random_range():
    aa = cards("Ah Ad")
    remaining = [c for c in full_deck() if c not in aa]
    opp_range = HandRange.random(remaining, 2)
    results = calculate_equity([aa, opp_range], [], full_deck(), num_simulations=800, seed=1)
    assert 0.75 < results[0].equity < 0.95


def test_range_vs_range():
    deck = full_deck()
    tight_hands = [cards("Ah Ad"), cards("Kh Kd"), cards("Qh Qd")]
    tight_range = HandRange.specific(tight_hands)
    wide_range = HandRange.random(deck, 2)
    results = calculate_equity([tight_range, wide_range], [], deck, num_simulations=800, seed=1)
    assert results[0].equity > results[1].equity


# ---------------------------------------------------------------------------
# validation
# ---------------------------------------------------------------------------

def test_calculate_equity_rejects_empty_hole_specs():
    with pytest.raises(EquityError):
        calculate_equity([], [], full_deck())


def test_calculate_equity_rejects_non_positive_num_simulations():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    with pytest.raises(EquityError):
        calculate_equity([aa, kk], [], full_deck(), num_simulations=0)


def test_calculate_equity_rejects_non_positive_num_workers():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    with pytest.raises(EquityError):
        calculate_equity([aa, kk], [], full_deck(), num_simulations=10, num_workers=0)


def test_calculate_equity_rejects_board_too_large():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    board = cards("2c 3c 4c 5c 6c 7c")
    with pytest.raises(EquityError):
        calculate_equity([aa, kk], board, full_deck(), num_simulations=10)


def test_calculate_equity_seed_is_reproducible():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    remaining = [c for c in full_deck() if c not in aa + kk]
    r1 = calculate_equity([aa, kk], [], remaining, num_simulations=500, seed=42)
    r2 = calculate_equity([aa, kk], [], remaining, num_simulations=500, seed=42)
    assert r1 == r2


# ---------------------------------------------------------------------------
# multi-threaded execution
# ---------------------------------------------------------------------------

def test_multiple_workers_produces_consistent_results():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    remaining = [c for c in full_deck() if c not in aa + kk]
    results = calculate_equity([aa, kk], [], remaining, num_simulations=1000, num_workers=4, seed=1)
    assert 0.7 < results[0].win < 0.95


def test_num_workers_exceeding_num_simulations_still_works():
    aa = cards("Ah Ad")
    kk = cards("Kh Kd")
    remaining = [c for c in full_deck() if c not in aa + kk]
    results = calculate_equity([aa, kk], [], remaining, num_simulations=3, num_workers=10, seed=1)
    assert len(results) == 2


# ---------------------------------------------------------------------------
# hand_strength_vs_random
# ---------------------------------------------------------------------------

def test_hand_strength_vs_random_strong_hand():
    aa = cards("Ah Ad")
    result = hand_strength_vs_random(aa, [], full_deck(), num_simulations=500, seed=1)
    assert result.equity > 0.75


def test_hand_strength_vs_random_weak_hand():
    weak = cards("7c 2d")
    result = hand_strength_vs_random(weak, [], full_deck(), num_simulations=500, seed=1)
    assert result.equity < 0.6


# ---------------------------------------------------------------------------
# omaha evaluator
# ---------------------------------------------------------------------------

def test_omaha_evaluator_used_when_specified():
    hole = cards("Ah Ad 2c 3c")
    opp = cards("Kh Kd 4c 5c")
    board = cards("Qc Jc Tc")
    remaining = [c for c in full_deck() if c not in hole + opp + board]
    results = calculate_equity(
        [hole, opp], board, remaining, num_simulations=300, evaluator=omaha_evaluator, seed=1
    )
    assert len(results) == 2
    assert abs(sum(r.win + r.tie for r in results) - 1.0) < 1e-6
