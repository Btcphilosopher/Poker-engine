from poker_engine.ai.game_state import build_game_state_view
from poker_engine.ai.profiles import CashGameAI, TournamentAI
from poker_engine.betting import BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem


def make_game(stack_a=1000, stack_b=1000, seed=1):
    table = Table(table_id="t1", max_seats=4)
    table.sit_down("a", "a", stack_a)
    table.sit_down("b", "b", stack_b)
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    return game


def play_full_hand(ai_by_player, seed=1, stack_a=1000, stack_b=1000):
    game = make_game(stack_a, stack_b, seed)
    steps = 0
    while not game.is_hand_complete and steps < 100:
        pid = game.current_player
        state = build_game_state_view(game, pid)
        decision = ai_by_player[pid].choose_action(state)
        game.apply_action(pid, decision.action_type, decision.amount)
        steps += 1
    assert game.is_hand_complete
    game.settle()
    return game


def test_tournament_ai_plays_full_hands_across_many_seeds():
    for seed in range(20):
        ais = {"a": TournamentAI(), "b": TournamentAI()}
        game = play_full_hand(ais, seed=seed)
        assert game.outcome is not None


def test_cash_game_ai_plays_full_hands_across_many_seeds():
    for seed in range(20):
        ais = {"a": CashGameAI(), "b": CashGameAI()}
        game = play_full_hand(ais, seed=seed)
        assert game.outcome is not None


def test_tournament_ai_and_cash_game_ai_play_together():
    for seed in range(20):
        ais = {"a": TournamentAI(), "b": CashGameAI()}
        game = play_full_hand(ais, seed=seed)
        assert game.outcome is not None


def test_tournament_ai_loosens_thresholds_when_short_stacked():
    ai = TournamentAI(fold_threshold=0.35, raise_threshold=0.55, short_stack_pot_ratio=3.0)
    game_short = make_game(stack_a=40, stack_b=1000, seed=1)
    pid = game_short.current_player
    state_short = build_game_state_view(game_short, pid)

    if state_short.pot_size > 0 and state_short.stack / state_short.pot_size < 3.0:
        assert ai._fold_threshold * 0.5 < ai._fold_threshold
        assert ai._raise_threshold * 0.8 < ai._raise_threshold


def test_cash_game_ai_thresholds_never_change_with_stack_size():
    ai = CashGameAI(fold_threshold=0.35, raise_threshold=0.55)
    assert ai._fold_threshold == 0.35
    assert ai._raise_threshold == 0.55
    play_full_hand({"a": ai, "b": CashGameAI()}, seed=1, stack_a=30, stack_b=1000)
    assert ai._fold_threshold == 0.35
    assert ai._raise_threshold == 0.55
