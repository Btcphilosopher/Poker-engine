from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.structures import StudStakes
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import FiveCardDraw, SevenCardStud, TexasHoldem


def test_flop_game_pot_size_reflects_blinds_before_any_action():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b", "c"]:
        table.sit_down(pid, pid, 1000)
    deck = Deck()
    deck.shuffle(seed=1)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    assert game.pot_size == 30


def test_flop_game_pot_size_grows_with_bets():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    deck = Deck()
    deck.shuffle(seed=1)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    before = game.pot_size
    pid = game.current_player
    legal = game.legal_actions(pid)
    if legal.can_raise:
        game.apply_action(pid, ActionType.RAISE, legal.raise_min)
        assert game.pot_size > before


def test_flop_game_pot_size_after_settle_reflects_total_contributed():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    deck = Deck()
    deck.shuffle(seed=2)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    pot_before_settle = game.pot_size
    game.settle()
    assert game.pot_size == pot_before_settle


def test_stud_game_pot_size_reflects_antes_and_bring_in():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b", "c"]:
        table.sit_down(pid, pid, 1000)
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    deck = Deck()
    deck.shuffle(seed=1)
    game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes, deck=deck)
    game.start_hand()
    assert game.pot_size == 3 * 1 + 3  # 3 antes + the bring-in


def test_draw_game_pot_size_reflects_blinds():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    deck = Deck()
    deck.shuffle(seed=1)
    game = FiveCardDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    assert game.pot_size == 30
