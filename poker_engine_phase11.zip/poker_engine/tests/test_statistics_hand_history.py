import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.structures import StudStakes
from poker_engine.deck import Deck
from poker_engine.statistics import HandHistoryError, begin_hand_history
from poker_engine.tables import Table
from poker_engine.variants import FiveCardDraw, SevenCardStud, TexasHoldem


def make_holdem(n=2, stack=1000, seed=1):
    table = Table(table_id="t1", max_seats=6)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", stack)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    deck = Deck()
    deck.shuffle(seed=seed)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    return game, starting


def play_to_completion(game):
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()


def test_finalize_before_hand_complete_raises():
    game, starting = make_holdem()
    builder = begin_hand_history(game)
    with pytest.raises(HandHistoryError):
        builder.finalize("h1", starting)


def test_basic_fields_populated_correctly():
    game, starting = make_holdem(n=3, seed=2)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("hand-abc", starting)

    assert history.hand_id == "hand-abc"
    assert history.variant_name == "TexasHoldem"
    assert history.structure == "no_limit"
    assert history.table_id == "t1"
    assert set(history.seat_order) == {"p0", "p1", "p2"}
    assert history.starting_stacks == starting
    assert history.big_blind_equivalent == 20


def test_final_stacks_and_winners_are_consistent_with_conservation():
    game, starting = make_holdem(n=3, seed=3)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)

    total_start = sum(history.starting_stacks.values())
    total_final = sum(history.final_stacks.values())
    assert total_start == total_final


def test_pot_after_increases_monotonically():
    game, starting = make_holdem(n=2, seed=4)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)

    pots = [a.pot_after for a in history.actions]
    non_zero_amount_pots = [a.pot_after for a in history.actions if a.amount > 0]
    # pot never decreases as actions accumulate
    assert pots == sorted(pots)


def test_first_actions_pot_after_reflects_blinds_plus_amount():
    game, starting = make_holdem(n=2, seed=1)
    initial_pot = game.pot_size  # 30 (blinds already posted)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)

    first_action = history.actions[0]
    assert first_action.pot_after == initial_pot + first_action.amount


def test_street_labels_present_for_flop_game():
    game, starting = make_holdem(n=2, seed=1)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)

    labels = {a.street_label for a in history.actions}
    assert labels <= {"preflop", "flop", "turn", "river"}
    assert "preflop" in labels


def test_hole_cards_recorded_for_every_player():
    game, starting = make_holdem(n=3, seed=5)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)

    for pid in ["p0", "p1", "p2"]:
        assert len(history.hole_cards[pid]) == 2


def test_board_recorded_with_five_cards():
    game, starting = make_holdem(n=2, seed=1)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)
    assert len(history.board) == 5


def test_up_cards_empty_for_flop_game():
    game, starting = make_holdem(n=2, seed=1)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)
    assert history.up_cards == {}


def test_winners_sum_matches_pot():
    game, starting = make_holdem(n=3, seed=6)
    builder = begin_hand_history(game)
    play_to_completion(game)
    history = builder.finalize("h1", starting)
    assert sum(history.winners.values()) == game.outcome.total_awarded


def test_stud_hand_history_street_labels():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    deck = Deck()
    deck.shuffle(seed=1)
    game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes, deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    history = builder.finalize("h1", starting)

    labels = {a.street_label for a in history.actions}
    assert labels <= {"third", "fourth", "fifth", "sixth", "seventh"}
    assert history.big_blind_equivalent == 20  # StudStakes.big_bet
    assert len(history.up_cards["a"]) == 4
    assert history.board == ()


def test_draw_game_hand_history_street_labels():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    deck = Deck()
    deck.shuffle(seed=1)
    game = FiveCardDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)
    while not game.is_hand_complete:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, [])
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    history = builder.finalize("h1", starting)

    labels = {a.street_label for a in history.actions}
    assert "predraw" in labels
    assert history.board == ()
    assert history.up_cards == {}
