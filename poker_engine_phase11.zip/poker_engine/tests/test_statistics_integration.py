"""
Full statistics integration test: many hands played by real AI archetypes
(Phase 10), each one recorded as a HandHistory and fed into
PlayerStatsTracker -- exactly the workflow suggested at the end of Phase
10's roadmap notes. Proves hand history recording, statistics
accumulation, and replay all work together across a realistic session,
not just in isolation.
"""

import random

from poker_engine.ai.archetypes import CallingStation, TightAggressive
from poker_engine.ai.game_state import build_game_state_view
from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.statistics import PlayerStatsTracker, begin_hand_history, replay_hand_history
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem


def test_many_hands_with_real_ai_feed_the_stats_tracker():
    rng = random.Random(1)
    table = Table(table_id="t1", max_seats=4)
    table.sit_down("tag", "tag", 1000)
    table.sit_down("station", "station", 1000)

    ai_by_player = {"tag": TightAggressive(), "station": CallingStation()}
    tracker_tag = PlayerStatsTracker()
    tracker_station = PlayerStatsTracker()

    histories = []
    for i in range(15):
        starting = {p.player_id: p.stack for p in table.occupied_seats()}
        deck = Deck()
        deck.shuffle(seed=rng.randint(0, 2**31 - 1))
        game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
        game.start_hand()
        builder = begin_hand_history(game)

        while not game.is_hand_complete:
            pid = game.current_player
            state = build_game_state_view(game, pid)
            decision = ai_by_player[pid].choose_action(state)
            game.apply_action(pid, decision.action_type, decision.amount)
        game.settle()

        history = builder.finalize(f"hand-{i}", starting)
        histories.append(history)
        tracker_tag.record_hand(history, "tag")
        tracker_station.record_hand(history, "station")

        # Reset stacks between hands so nobody busts mid-test (this test
        # is about statistics accumulation, not tournament dynamics).
        for p in table.occupied_seats():
            p.stack = 1000

    assert tracker_tag.hands_tracked == 15
    assert tracker_station.hands_tracked == 15

    # CallingStation never raises -- its PFR and 3-bet% must be exactly 0.
    assert tracker_station.pfr_hands == 0
    assert tracker_station.three_bet_hands == 0
    assert tracker_station.aggression_factor == 0.0

    # TightAggressive should show SOME aggression across 15 hands (not a
    # strict guarantee for any single hand, but overwhelmingly likely
    # across 15 with these thresholds).
    assert tracker_tag.pfr_hands + tracker_tag.postflop_aggressive_actions > 0

    # Every recorded hand history must also be replayable without error.
    for history in histories:
        steps = replay_hand_history(history)
        assert len(steps) == len(history.actions)


def test_stats_and_hand_history_agree_on_chip_conservation_across_a_session():
    rng = random.Random(2)
    table = Table(table_id="t1", max_seats=4)
    table.sit_down("a", "a", 1000)
    table.sit_down("b", "b", 1000)
    ai_by_player = {"a": TightAggressive(), "b": TightAggressive()}

    for i in range(10):
        starting = {p.player_id: p.stack for p in table.occupied_seats()}
        deck = Deck()
        deck.shuffle(seed=rng.randint(0, 2**31 - 1))
        game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
        game.start_hand()
        builder = begin_hand_history(game)

        while not game.is_hand_complete:
            pid = game.current_player
            state = build_game_state_view(game, pid)
            decision = ai_by_player[pid].choose_action(state)
            game.apply_action(pid, decision.action_type, decision.amount)
        game.settle()

        history = builder.finalize(f"hand-{i}", starting)
        assert sum(history.starting_stacks.values()) == sum(history.final_stacks.values())

        if min(p.stack for p in table.occupied_seats()) < 20:
            break
