from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.structures import StudStakes
from poker_engine.deck import Deck
from poker_engine.statistics import begin_hand_history, replay_hand_history
from poker_engine.tables import Table
from poker_engine.variants import FiveCardDraw, Omaha, SevenCardStud, TexasHoldem


def _play_flop_game_to_completion(cls, n=2, seed=1, structure=BettingStructure.NO_LIMIT):
    table = Table(table_id="t1", max_seats=6)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    deck = Deck()
    deck.shuffle(seed=seed)
    game = cls(table, structure, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    return builder.finalize("h1", starting)


def test_replay_step_count_matches_action_count():
    history = _play_flop_game_to_completion(TexasHoldem)
    steps = replay_hand_history(history)
    assert len(steps) == len(history.actions)


def test_replay_step_indices_are_sequential():
    history = _play_flop_game_to_completion(TexasHoldem)
    steps = replay_hand_history(history)
    assert [s.step_index for s in steps] == list(range(len(steps)))


def test_replay_board_empty_preflop():
    history = _play_flop_game_to_completion(TexasHoldem, seed=1)
    steps = replay_hand_history(history)
    preflop_steps = [s for s in steps if s.action.street_label == "preflop"]
    assert all(s.board_visible == () for s in preflop_steps)


def test_replay_board_grows_with_street():
    history = _play_flop_game_to_completion(TexasHoldem, seed=1)
    steps = replay_hand_history(history)
    for s in steps:
        expected_size = {"preflop": 0, "flop": 3, "turn": 4, "river": 5}[s.action.street_label]
        assert len(s.board_visible) == expected_size


def test_replay_board_visible_is_prefix_of_final_board():
    history = _play_flop_game_to_completion(TexasHoldem, seed=1)
    steps = replay_hand_history(history)
    for s in steps:
        assert s.board_visible == history.board[: len(s.board_visible)]


def test_replay_up_cards_empty_for_flop_game():
    history = _play_flop_game_to_completion(TexasHoldem, seed=1)
    steps = replay_hand_history(history)
    assert all(s.up_cards_visible == {} for s in steps)


def test_replay_works_for_omaha():
    history = _play_flop_game_to_completion(Omaha, seed=1, structure=BettingStructure.POT_LIMIT)
    steps = replay_hand_history(history)
    assert len(steps) == len(history.actions)
    river_steps = [s for s in steps if s.action.street_label == "river"]
    assert all(len(s.board_visible) == 5 for s in river_steps)


def test_replay_stud_up_cards_grow_by_street():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    deck = Deck()
    deck.shuffle(seed=1)
    game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes, deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    history = builder.finalize("h1", starting)

    steps = replay_hand_history(history)
    expected_counts = {"third": 1, "fourth": 2, "fifth": 3, "sixth": 4, "seventh": 4}
    for s in steps:
        expected = expected_counts[s.action.street_label]
        for pid, cards in s.up_cards_visible.items():
            assert len(cards) == expected


def test_replay_stud_board_always_empty():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    deck = Deck()
    deck.shuffle(seed=1)
    game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes, deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    history = builder.finalize("h1", starting)

    steps = replay_hand_history(history)
    assert all(s.board_visible == () for s in steps)


def test_replay_draw_game_has_no_incremental_reveal():
    table = Table(table_id="t1", max_seats=4)
    for pid in ["a", "b"]:
        table.sit_down(pid, pid, 1000)
    starting = {p.player_id: p.stack for p in table.occupied_seats()}
    deck = Deck()
    deck.shuffle(seed=1)
    game = FiveCardDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()
    builder = begin_hand_history(game)
    while not game.is_hand_complete:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, [])
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    game.settle()
    history = builder.finalize("h1", starting)

    steps = replay_hand_history(history)
    # documented limitation: Draw-family hands get no incremental reveal
    assert all(s.board_visible == () and s.up_cards_visible == {} for s in steps)
