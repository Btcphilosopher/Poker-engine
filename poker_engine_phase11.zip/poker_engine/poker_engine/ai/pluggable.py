"""
Pluggable extension points: PolicyTableAI (CFR-ready) and
CallableModelAI (neural-network-ready).

These are NOT trained strategies -- training a real CFR solver or neural
network is a large undertaking entirely outside this engine's scope
(this is a rules engine, not an ML research project). What belongs here,
and what "future reinforcement learning should plug in without rewriting
the engine" actually requires, is the SEAM: proof that an external
strategy -- however it was produced -- can drive `choose_action` through
nothing but the standard AIPlayer interface, with no engine changes.

PolicyTableAI demonstrates the CFR shape: real CFR training produces a
strategy as a table of action PROBABILITIES keyed by an "information set"
(a bucketed summary of the state a player can observe). PolicyTableAI
takes that exact shape -- a `state -> {ActionType: probability}` function
-- and samples from it. Feed it a real CFR-trained table and it becomes a
real CFR-driven AI without any change to this class.

CallableModelAI demonstrates the neural-network shape: a model that
consumes a numeric feature vector and outputs per-action scores.
`state_to_features` converts GameStateView into a fixed-size, model-ready
vector using nothing but Python floats (no hard dependency on numpy/torch
introduced here); `predict_fn` is the model itself, expected to have the
same `features -> {ActionType: score}` shape whether it's a lookup table,
a hand-written heuristic, or an actual trained network.
"""

from __future__ import annotations

import random
from typing import Callable, Dict, List, Optional

from poker_engine.ai.base_ai import AIDecision, AIError, AIPlayer
from poker_engine.ai.game_state import GameStateView
from poker_engine.ai.hand_strength import estimate_hand_strength
from poker_engine.betting.actions import ActionType

InformationSetKey = str
PolicyFn = Callable[[GameStateView], Dict[ActionType, float]]


def default_information_set_key(state: GameStateView) -> InformationSetKey:
    """
    A reasonable default "information set" bucketing: hand-strength decile
    plus which actions are legal plus the pot-odds bucket. Real CFR
    training defines its own information sets; this is just something
    concrete PolicyTableAI can use out of the box.
    """
    strength = estimate_hand_strength(state.hole_cards, state.board)
    strength_bucket = min(9, int(strength * 10))
    to_call_bucket = 0 if state.to_call == 0 else (1 if state.to_call < state.pot_size else 2)
    return f"s{strength_bucket}_c{to_call_bucket}"


class PolicyTableAI(AIPlayer):
    """
    Samples an action from a probability distribution returned by
    `policy_fn(state) -> {ActionType: probability}` -- the shape a
    CFR-trained strategy table naturally has. `bet_sizing_fraction`
    controls sizing when the sampled action is BET/RAISE (CFR strategies
    are usually trained over a small fixed set of bet sizes; picking one
    fraction here keeps this demonstration simple without pretending to
    reproduce a full bet-sizing abstraction).
    """

    def __init__(self, policy_fn: PolicyFn, *, bet_sizing_fraction: float = 0.75, seed: Optional[int] = None) -> None:
        self._policy_fn = policy_fn
        self._bet_sizing_fraction = bet_sizing_fraction
        self._rng = random.Random(seed)

    def choose_action(self, state: GameStateView) -> AIDecision:
        distribution = self._policy_fn(state)
        legal = state.legal_actions
        legal_types = set()
        if legal.can_fold:
            legal_types.add(ActionType.FOLD)
        if legal.can_check:
            legal_types.add(ActionType.CHECK)
        if legal.can_call:
            legal_types.add(ActionType.CALL)
        if legal.can_bet:
            legal_types.add(ActionType.BET)
        if legal.can_raise:
            legal_types.add(ActionType.RAISE)

        filtered = {a: p for a, p in distribution.items() if a in legal_types and p > 0}
        if not filtered:
            raise AIError("policy_fn returned no legal action with positive probability")

        total = sum(filtered.values())
        actions: List[ActionType] = list(filtered.keys())
        weights = [p / total for p in filtered.values()]
        chosen = self._rng.choices(actions, weights=weights, k=1)[0]

        if chosen is ActionType.BET:
            target = max(1, int(state.pot_size * self._bet_sizing_fraction))
            amount = min(max(legal.bet_min, target), legal.bet_max)
            return AIDecision(ActionType.BET, amount)
        if chosen is ActionType.RAISE:
            target = max(1, int(state.pot_size * self._bet_sizing_fraction))
            amount = min(max(legal.raise_min, target), legal.raise_max)
            return AIDecision(ActionType.RAISE, amount)
        return AIDecision(chosen)


FeatureVector = List[float]
ModelPredictFn = Callable[[FeatureVector], Dict[ActionType, float]]


def state_to_features(state: GameStateView) -> FeatureVector:
    """
    Convert a GameStateView into a fixed-size numeric feature vector: a
    reasonable, deliberately simple default a real model could be trained
    against. Uses plain Python floats -- no numpy/torch dependency
    introduced by this engine; callers integrating a real framework
    convert this list into whatever tensor type their model expects.
    """
    strength = estimate_hand_strength(state.hole_cards, state.board)
    legal = state.legal_actions
    pot_odds_value = 0.0 if state.to_call == 0 else state.to_call / (state.pot_size + state.to_call)
    return [
        strength,
        float(state.pot_size),
        float(state.stack),
        float(state.to_call),
        pot_odds_value,
        float(state.num_players_in_hand),
        float(len(state.board)),
        1.0 if legal.can_check else 0.0,
        1.0 if legal.can_bet else 0.0,
        1.0 if legal.can_raise else 0.0,
    ]


class CallableModelAI(AIPlayer):
    """
    Wraps any `predict_fn(features) -> {ActionType: score}` callable --
    the shape a trained model naturally has. Scores are used exactly like
    PolicyTableAI's probabilities (normalized over legal actions, then
    sampled) rather than always taking the argmax, so a model doesn't need
    to be perfectly calibrated to produce sensible-looking play; pass
    `deterministic=True` to always take the highest-scoring legal action
    instead.
    """

    def __init__(
        self,
        predict_fn: ModelPredictFn,
        *,
        deterministic: bool = False,
        bet_sizing_fraction: float = 0.75,
        seed: Optional[int] = None,
    ) -> None:
        self._predict_fn = predict_fn
        self._deterministic = deterministic
        self._bet_sizing_fraction = bet_sizing_fraction
        self._rng = random.Random(seed)

    def choose_action(self, state: GameStateView) -> AIDecision:
        features = state_to_features(state)
        scores = self._predict_fn(features)

        legal = state.legal_actions
        legal_types = set()
        if legal.can_fold:
            legal_types.add(ActionType.FOLD)
        if legal.can_check:
            legal_types.add(ActionType.CHECK)
        if legal.can_call:
            legal_types.add(ActionType.CALL)
        if legal.can_bet:
            legal_types.add(ActionType.BET)
        if legal.can_raise:
            legal_types.add(ActionType.RAISE)

        filtered = {a: s for a, s in scores.items() if a in legal_types}
        if not filtered:
            raise AIError("predict_fn returned no legal action")

        if self._deterministic:
            chosen = max(filtered, key=filtered.get)
        else:
            min_score = min(filtered.values())
            shifted = {a: (s - min_score) + 1e-9 for a, s in filtered.items()}
            total = sum(shifted.values())
            actions = list(shifted.keys())
            weights = [w / total for w in shifted.values()]
            chosen = self._rng.choices(actions, weights=weights, k=1)[0]

        if chosen is ActionType.BET:
            target = max(1, int(state.pot_size * self._bet_sizing_fraction))
            amount = min(max(legal.bet_min, target), legal.bet_max)
            return AIDecision(ActionType.BET, amount)
        if chosen is ActionType.RAISE:
            target = max(1, int(state.pot_size * self._bet_sizing_fraction))
            amount = min(max(legal.raise_min, target), legal.raise_max)
            return AIDecision(ActionType.RAISE, amount)
        return AIDecision(chosen)
