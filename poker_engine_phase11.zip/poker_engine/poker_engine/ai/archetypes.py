"""
Rule-based AI archetypes.

Each uses the fast heuristic hand-strength estimate (poker_engine.ai.
hand_strength), not the Monte Carlo equity calculator -- these are meant
to be cheap enough to drive thousands of simulated hands (as every
earlier phase's property tests effectively already were, informally).
See MonteCarloAI (poker_engine.ai.monte_carlo_ai) for the archetype that
uses real simulation instead.

"Tight"/"loose" controls how wide a range folds (a hand-strength
threshold below which the AI folds to a bet); "passive"/"aggressive"
controls how it responds to a strong hand (calling vs. raising it).
"""

from __future__ import annotations

import random
from typing import Optional

from poker_engine.ai.base_ai import AIDecision, AIPlayer
from poker_engine.ai.game_state import GameStateView
from poker_engine.ai.hand_strength import estimate_hand_strength
from poker_engine.betting.actions import ActionType


def check_or_call(state: GameStateView) -> AIDecision:
    legal = state.legal_actions
    if legal.can_check:
        return AIDecision(ActionType.CHECK)
    if legal.can_call:
        return AIDecision(ActionType.CALL)
    return AIDecision(ActionType.FOLD)


def bet_or_raise(state: GameStateView, sizing_fraction: float = 0.75) -> AIDecision:
    """Bet/raise roughly `sizing_fraction` of the pot, clamped to the legal range."""
    legal = state.legal_actions
    target = max(1, int(state.pot_size * sizing_fraction))
    if legal.can_bet:
        amount = min(max(legal.bet_min, target), legal.bet_max)
        return AIDecision(ActionType.BET, amount)
    if legal.can_raise:
        amount = min(max(legal.raise_min, target), legal.raise_max)
        return AIDecision(ActionType.RAISE, amount)
    return check_or_call(state)


class RandomPlayer(AIPlayer):
    """Picks uniformly at random among every legal action; random sizing when betting/raising."""

    def __init__(self, seed: Optional[int] = None) -> None:
        self._rng = random.Random(seed)

    def choose_action(self, state: GameStateView) -> AIDecision:
        legal = state.legal_actions
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_bet:
            options.append(ActionType.BET)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        if not options:
            raise RuntimeError("No legal actions available")

        chosen = self._rng.choice(options)
        if chosen is ActionType.BET:
            return AIDecision(ActionType.BET, self._rng.randint(legal.bet_min, legal.bet_max))
        if chosen is ActionType.RAISE:
            return AIDecision(ActionType.RAISE, self._rng.randint(legal.raise_min, legal.raise_max))
        return AIDecision(chosen)


class CallingStation(AIPlayer):
    """Checks when free, calls anything else, never raises, never voluntarily folds."""

    def choose_action(self, state: GameStateView) -> AIDecision:
        return check_or_call(state)


class TightPassive(AIPlayer):
    """Folds most hands; calls decent ones; almost never raises even strong ones."""

    FOLD_THRESHOLD = 0.35
    RAISE_THRESHOLD = 0.90

    def choose_action(self, state: GameStateView) -> AIDecision:
        strength = estimate_hand_strength(state.hole_cards, state.board)
        legal = state.legal_actions
        if legal.can_check:
            if strength >= self.RAISE_THRESHOLD and (legal.can_bet or legal.can_raise):
                return bet_or_raise(state, sizing_fraction=0.5)
            return AIDecision(ActionType.CHECK)
        if strength < self.FOLD_THRESHOLD:
            return AIDecision(ActionType.FOLD) if legal.can_fold else check_or_call(state)
        if strength >= self.RAISE_THRESHOLD and (legal.can_bet or legal.can_raise):
            return bet_or_raise(state, sizing_fraction=0.5)
        return check_or_call(state)


class LoosePassive(AIPlayer):
    """Folds rarely (plays a wide range); still almost never raises."""

    FOLD_THRESHOLD = 0.15
    RAISE_THRESHOLD = 0.95

    def choose_action(self, state: GameStateView) -> AIDecision:
        strength = estimate_hand_strength(state.hole_cards, state.board)
        legal = state.legal_actions
        if legal.can_check:
            if strength >= self.RAISE_THRESHOLD and (legal.can_bet or legal.can_raise):
                return bet_or_raise(state, sizing_fraction=0.5)
            return AIDecision(ActionType.CHECK)
        if strength < self.FOLD_THRESHOLD:
            return AIDecision(ActionType.FOLD) if legal.can_fold else check_or_call(state)
        return check_or_call(state)


class TightAggressive(AIPlayer):
    """TAG: folds most hands, but bets/raises the ones it plays rather than just calling."""

    FOLD_THRESHOLD = 0.35
    RAISE_THRESHOLD = 0.55

    def choose_action(self, state: GameStateView) -> AIDecision:
        strength = estimate_hand_strength(state.hole_cards, state.board)
        legal = state.legal_actions
        if strength < self.FOLD_THRESHOLD and legal.to_call > 0:
            return AIDecision(ActionType.FOLD) if legal.can_fold else check_or_call(state)
        if strength >= self.RAISE_THRESHOLD and (legal.can_bet or legal.can_raise):
            return bet_or_raise(state, sizing_fraction=0.75)
        return check_or_call(state)


class LooseAggressive(AIPlayer):
    """LAG: plays a wide range (rarely folds) AND raises aggressively within it."""

    FOLD_THRESHOLD = 0.10
    RAISE_THRESHOLD = 0.40

    def choose_action(self, state: GameStateView) -> AIDecision:
        strength = estimate_hand_strength(state.hole_cards, state.board)
        legal = state.legal_actions
        if strength < self.FOLD_THRESHOLD and legal.to_call > 0:
            return AIDecision(ActionType.FOLD) if legal.can_fold else check_or_call(state)
        if strength >= self.RAISE_THRESHOLD and (legal.can_bet or legal.can_raise):
            return bet_or_raise(state, sizing_fraction=1.0)
        return check_or_call(state)
