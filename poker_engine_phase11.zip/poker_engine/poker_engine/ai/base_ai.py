"""
AIPlayer -- the pluggable AI interface.

Every AI strategy, from the simplest random player to a future
reinforcement-learning agent, implements exactly one method:

    choose_action(state: GameStateView) -> AIDecision

choose_action never sees or touches the live Game object -- only the
read-only GameStateView snapshot -- and never mutates anything itself.
The caller (whatever's driving the hand) is responsible for actually
applying the decision via game.apply_action(player_id, decision.action_type,
decision.amount), exactly the same way a human player's UI input would
be applied. This is the seam "future reinforcement learning should plug
in without rewriting the engine" is about: nothing below AIPlayer needs
to know or care what's on the other side of it.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from poker_engine.ai.game_state import GameStateView
from poker_engine.betting.actions import ActionType


class AIError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class AIDecision:
    action_type: ActionType
    amount: int = 0


class AIPlayer(ABC):
    """Common interface every AI strategy implements."""

    @abstractmethod
    def choose_action(self, state: GameStateView) -> AIDecision:
        """Return the action to take given `state`. Must return a LEGAL action per `state.legal_actions`."""
        raise NotImplementedError
