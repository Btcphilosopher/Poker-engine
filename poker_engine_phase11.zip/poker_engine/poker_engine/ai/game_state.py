"""
GameStateView -- a read-only, variant-agnostic snapshot of what an AI
needs to decide an action.

Every AI archetype's choose_action() takes one of these, never the live
Game object: it's a stable, minimal interface that works identically
whether the underlying hand is a FlopGame, StudGame, or DrawGame, so AI
code never needs a branch for which concrete Game subclass it's looking
at. Built via build_game_state_view(game, player_id).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

from poker_engine.betting.round import LegalActions
from poker_engine.cards.card import Card
from poker_engine.variants.base_game import BaseGame


class GameStateError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class GameStateView:
    player_id: str
    legal_actions: LegalActions
    hole_cards: Tuple[Card, ...]
    board: Tuple[Card, ...]  # community cards; empty for Stud/Draw
    up_cards: Dict[str, Tuple[Card, ...]]  # exposed cards by player; empty outside Stud
    pot_size: int
    stack: int
    to_call: int
    num_players_in_hand: int


def build_game_state_view(game: BaseGame, player_id: str) -> GameStateView:
    """
    Construct a GameStateView by reading whichever attributes `game`
    actually exposes, defaulting sensibly for the ones a given variant
    doesn't have (e.g. board is empty for Stud/Draw, up_cards is empty
    for Flop/Draw).
    """
    if game.current_player != player_id:
        raise GameStateError(f"It is not {player_id}'s turn to act")

    legal = game.legal_actions(player_id)
    hole_cards = tuple(game.hole_cards.get(player_id, ())) if hasattr(game, "hole_cards") else ()
    board = tuple(getattr(game, "board", ()))
    raw_up_cards = getattr(game, "up_cards", {})
    up_cards = {pid: tuple(cards) for pid, cards in raw_up_cards.items()}

    betting_state = game._betting_states.get(player_id)
    stack = betting_state.stack if betting_state is not None else 0
    num_in_hand = sum(1 for bs in game._betting_states.values() if not bs.is_folded)

    return GameStateView(
        player_id=player_id,
        legal_actions=legal,
        hole_cards=hole_cards,
        board=board,
        up_cards=up_cards,
        pot_size=game.pot_size,
        stack=stack,
        to_call=legal.to_call,
        num_players_in_hand=num_in_hand,
    )
