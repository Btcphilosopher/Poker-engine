"""
Fast, heuristic hand-strength estimation for AI decision-making.

This is NOT the Monte Carlo equity calculator (see poker_engine.simulation
for that) -- it's a cheap, deterministic proxy the rule-based AI
archetypes (TightPassive, TAG, LAG, ...) use to make a fold/call/raise
decision in microseconds rather than running thousands of simulations per
action. MonteCarloAI uses the real equity calculator instead, trading
speed for accuracy -- the tradeoff the spec's simpler style-based
archetypes and its separate "Monte Carlo AI" archetype are meant to
represent.

Deliberately approximate: estimate_hand_strength evaluates hole+board
together with the permissive evaluate_best_of for every variant,
including Omaha (which technically requires exactly 2 hole + 3 board) --
correct enough to rank a hand's rough strength for AI behaviour, not
precise enough to determine a pot outcome (that's what the dealer's real
per-variant evaluators are for).
"""

from __future__ import annotations

from typing import Sequence

from poker_engine.cards.card import Card
from poker_engine.evaluation.evaluator import evaluate_best_of
from poker_engine.evaluation.hand_category import HandCategory, HandResult

_CATEGORY_BASE_STRENGTH = {
    HandCategory.HIGH_CARD: 0.10,
    HandCategory.PAIR: 0.25,
    HandCategory.TWO_PAIR: 0.40,
    HandCategory.THREE_OF_A_KIND: 0.55,
    HandCategory.STRAIGHT: 0.65,
    HandCategory.FLUSH: 0.75,
    HandCategory.FULL_HOUSE: 0.85,
    HandCategory.FOUR_OF_A_KIND: 0.95,
    HandCategory.STRAIGHT_FLUSH: 1.0,
}


def estimate_made_hand_strength(result: HandResult) -> float:
    """
    Map a made hand's category + top tiebreaker to a rough [0, 1]
    strength score: mostly the hand category, nudged up to +0.08 within a
    tier by how high the primary tiebreaker card is (Ace-high top pair
    rates higher than 2-high top pair) without needing a full equity run.
    """
    base = _CATEGORY_BASE_STRENGTH[result.category]
    nudge = 0.08 * ((result.tiebreakers[0] - 2) / 12.0) if result.tiebreakers else 0.0
    return min(1.0, base + nudge)


def estimate_preflop_strength(hole_cards: Sequence[Card]) -> float:
    """
    Cheap starting-hand heuristic for hole cards before any community
    cards are known (or too few total cards to evaluate a made hand):
    rewards high cards, pairs, and suitedness. Deliberately simple -- a
    real preflop equity table is a much bigger undertaking than this
    phase's AI archetypes need, and this is explicitly a fast proxy, not
    a claim of strategic accuracy.
    """
    ranks = sorted((c.rank.value for c in hole_cards), reverse=True)
    top_two = ranks[:2] if len(ranks) >= 2 else ranks
    score = 0.85 * (sum(top_two) / 28.0)  # normalize against AA (14+14=28), leaving room for bonuses below
    if len(ranks) >= 2 and ranks[0] == ranks[1]:
        score += 0.20  # any pair should reliably outrank weak unpaired holdings
    suits = {c.suit for c in hole_cards}
    if len(hole_cards) >= 2 and len(suits) < len(hole_cards):
        score += 0.05
    return min(1.0, score)


def estimate_hand_strength(hole_cards: Sequence[Card], board: Sequence[Card]) -> float:
    """
    Estimate this hand's rough strength in [0, 1]. Falls back to the
    preflop heuristic whenever there aren't at least 5 known cards to
    evaluate a made hand from (preflop, or early Stud streets).
    """
    combined = list(hole_cards) + list(board)
    if len(combined) < 5:
        return estimate_preflop_strength(hole_cards)
    result = evaluate_best_of(combined)
    return estimate_made_hand_strength(result)
