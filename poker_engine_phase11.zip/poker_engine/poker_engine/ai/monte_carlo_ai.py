"""
MonteCarloAI -- decides using the real equity calculator
(poker_engine.simulation) rather than the fast heuristic every other
rule-based archetype uses. Trades speed for accuracy: estimates this
hand's equity against a random opponent range via actual simulation, then
compares that equity to pot odds (call/fold) and a fixed threshold
(bet/raise), rather than a cheap category-based lookup.

Only meaningful for variants with a shared community board (Hold'em,
Omaha, Short Deck, the Pineapple family) -- see
poker_engine.simulation.equity's docstring for why Stud/Draw don't fit
this model. Falls back to the fast heuristic before the flop (or before
enough Stud/Draw information exists), since simulating a board that
hasn't been dealt yet doesn't reduce variance meaningfully over the
preflop heuristic and costs far more.
"""

from __future__ import annotations

from typing import Optional, Sequence

from poker_engine.ai.archetypes import bet_or_raise, check_or_call
from poker_engine.ai.base_ai import AIDecision, AIPlayer
from poker_engine.ai.game_state import GameStateView
from poker_engine.ai.hand_strength import estimate_preflop_strength
from poker_engine.betting.actions import ActionType
from poker_engine.cards.card import Card
from poker_engine.simulation.equity import Evaluator, hand_strength_vs_random, holdem_evaluator
from poker_engine.simulation.ev import expected_value_of_call


class MonteCarloAI(AIPlayer):
    """Decides using real Monte Carlo equity against a random opponent range."""

    def __init__(
        self,
        full_deck: Sequence[Card],
        *,
        num_simulations: int = 500,
        evaluator: Evaluator = holdem_evaluator,
        raise_equity_threshold: float = 0.65,
        preflop_fold_threshold: float = 0.30,
        seed: Optional[int] = None,
    ) -> None:
        self._full_deck = list(full_deck)
        self._num_simulations = num_simulations
        self._evaluator = evaluator
        self._raise_equity_threshold = raise_equity_threshold
        self._preflop_fold_threshold = preflop_fold_threshold
        self._seed = seed

    def choose_action(self, state: GameStateView) -> AIDecision:
        legal = state.legal_actions

        if not state.board:
            # No board yet: simulating a board that hasn't been dealt adds
            # cost without meaningfully reducing variance over the cheap
            # preflop heuristic -- use that instead, same fallback logic
            # estimate_hand_strength itself uses.
            strength = estimate_preflop_strength(state.hole_cards)
            if strength < self._preflop_fold_threshold and legal.to_call > 0:
                return AIDecision(ActionType.FOLD) if legal.can_fold else check_or_call(state)
            if strength >= self._raise_equity_threshold and (legal.can_bet or legal.can_raise):
                return bet_or_raise(state, sizing_fraction=0.75)
            return check_or_call(state)

        equity_result = hand_strength_vs_random(
            state.hole_cards,
            state.board,
            self._full_deck,
            num_simulations=self._num_simulations,
            evaluator=self._evaluator,
            seed=self._seed,
        )
        equity = equity_result.equity

        if legal.to_call > 0:
            ev_call = expected_value_of_call(state.pot_size, legal.to_call, equity)
            if ev_call < 0 and legal.can_fold:
                return AIDecision(ActionType.FOLD)
        if equity >= self._raise_equity_threshold and (legal.can_bet or legal.can_raise):
            return bet_or_raise(state, sizing_fraction=0.75)
        return check_or_call(state)
