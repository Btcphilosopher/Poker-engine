"""
TournamentAI and CashGameAI.

Both are TightAggressive-style (fold weak, raise strong) decision logic,
parameterized directly rather than wrapping another AIPlayer instance and
mutating its thresholds -- that would work for a single sequential
turn-based caller, but it's a needless state-mutation risk for zero
benefit over just parameterizing the thresholds directly.

TournamentAI loosens its thresholds as the stack-to-pot ratio shrinks --
a simple proxy for tournament stack-pressure dynamics (the shorter you
are, the more marginal hands become correct to play), without
implementing a full push/fold chart. CashGameAI applies no such
adjustment: a cash-game stack can always be topped back up, so there's no
elimination pressure creating a rational reason to widen up as it shrinks.
"""

from __future__ import annotations

from poker_engine.ai.archetypes import bet_or_raise, check_or_call
from poker_engine.ai.base_ai import AIDecision, AIPlayer
from poker_engine.ai.game_state import GameStateView
from poker_engine.ai.hand_strength import estimate_hand_strength
from poker_engine.betting.actions import ActionType


class TournamentAI(AIPlayer):
    """TightAggressive-style, but plays progressively wider as the stack-to-pot ratio shrinks."""

    def __init__(
        self,
        *,
        fold_threshold: float = 0.35,
        raise_threshold: float = 0.55,
        short_stack_pot_ratio: float = 3.0,
    ) -> None:
        self._fold_threshold = fold_threshold
        self._raise_threshold = raise_threshold
        self._short_stack_pot_ratio = short_stack_pot_ratio

    def choose_action(self, state: GameStateView) -> AIDecision:
        fold_threshold, raise_threshold = self._fold_threshold, self._raise_threshold
        if state.pot_size > 0 and state.stack / state.pot_size < self._short_stack_pot_ratio:
            fold_threshold *= 0.5
            raise_threshold *= 0.8

        strength = estimate_hand_strength(state.hole_cards, state.board)
        legal = state.legal_actions
        if strength < fold_threshold and legal.to_call > 0:
            return AIDecision(ActionType.FOLD) if legal.can_fold else check_or_call(state)
        if strength >= raise_threshold and (legal.can_bet or legal.can_raise):
            return bet_or_raise(state, sizing_fraction=0.75)
        return check_or_call(state)


class CashGameAI(AIPlayer):
    """TightAggressive-style with fixed thresholds -- the standard default profile for ring-game play."""

    def __init__(self, *, fold_threshold: float = 0.35, raise_threshold: float = 0.55) -> None:
        self._fold_threshold = fold_threshold
        self._raise_threshold = raise_threshold

    def choose_action(self, state: GameStateView) -> AIDecision:
        strength = estimate_hand_strength(state.hole_cards, state.board)
        legal = state.legal_actions
        if strength < self._fold_threshold and legal.to_call > 0:
            return AIDecision(ActionType.FOLD) if legal.can_fold else check_or_call(state)
        if strength >= self._raise_threshold and (legal.can_bet or legal.can_raise):
            return bet_or_raise(state, sizing_fraction=0.75)
        return check_or_call(state)
