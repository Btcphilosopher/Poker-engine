"""
Hand history recording.

A HandHistory is a complete, self-contained, exportable record of one
hand: starting stacks, every action with its street and the running pot,
cards, and the final outcome. Built without touching the core game
engine at all -- entirely from state every Game class already exposes
publicly (action_log, hole_cards, board/up_cards, outcome, pot_size),
the same "sits entirely on top of existing state" relationship Phase 8's
Tournament and Phase 9's CashGame both have with Table.

Building one is a two-step, caller-driven process (matching this
engine's "no magic, no hidden hooks" pattern used everywhere else):

    builder = begin_hand_history(game)   # call right after game.start_hand()
    ... play the hand ...
    history = builder.finalize(hand_id, starting_stacks)   # call after it's over

Two steps because the STARTING pot (blinds/antes already posted) is only
observable right after start_hand() -- by the time the hand is complete,
that information is gone, folded into a final pot_size that no longer
distinguishes "posted before any action" from "bet during the hand."
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from poker_engine.betting.actions import ActionType
from poker_engine.cards.card import Card
from poker_engine.variants.base_game import BaseGame


class HandHistoryError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class HandHistoryAction:
    player_id: str
    action_type: ActionType
    amount: int
    street_label: str
    pot_after: int


@dataclass(frozen=True, slots=True)
class HandHistory:
    hand_id: str
    variant_name: str
    structure: str
    table_id: str
    seat_order: Tuple[str, ...]
    starting_stacks: Dict[str, int]
    hole_cards: Dict[str, Tuple[Card, ...]]
    board: Tuple[Card, ...]
    up_cards: Dict[str, Tuple[Card, ...]]
    actions: Tuple[HandHistoryAction, ...]
    winners: Dict[str, int]
    final_stacks: Dict[str, int]
    big_blind_equivalent: Optional[int]  # BlindLevel.big_blind, or StudStakes.big_bet -- None if neither applies


def _street_label(entry: object) -> str:
    street = getattr(entry, "street", None)
    if street is not None:
        return street.value
    round_index = getattr(entry, "round_index", None)
    if round_index is not None:
        return "predraw" if round_index == 0 else f"draw_{round_index}"
    raise HandHistoryError(f"Unrecognized action-log entry type: {type(entry)!r}")


def _big_blind_equivalent(game: BaseGame) -> Optional[int]:
    blind_level = getattr(game, "blind_level", None)
    if blind_level is not None:
        return blind_level.big_blind
    stakes = getattr(game, "stakes", None)
    if stakes is not None:
        return stakes.big_bet
    return None


class HandHistoryBuilder:
    def __init__(self, game: BaseGame) -> None:
        self._game = game
        self._initial_pot = game.pot_size
        self._seat_order = tuple(p.player_id for p in game.table.occupied_seats())

    def finalize(self, hand_id: str, starting_stacks: Dict[str, int]) -> HandHistory:
        game = self._game
        if not game.is_hand_complete:
            raise HandHistoryError("Cannot finalize a hand history before the hand is complete")
        if game.outcome is None:
            raise HandHistoryError("Game has no outcome to record")

        actions: List[HandHistoryAction] = []
        running_pot = self._initial_pot
        for entry in game.action_log:
            action = entry.action
            running_pot += action.amount
            actions.append(
                HandHistoryAction(
                    player_id=action.player_id,
                    action_type=action.action_type,
                    amount=action.amount,
                    street_label=_street_label(entry),
                    pot_after=running_pot,
                )
            )

        hole_cards = {pid: tuple(cards) for pid, cards in getattr(game, "hole_cards", {}).items()}
        board = tuple(getattr(game, "board", ()))
        up_cards = {pid: tuple(cards) for pid, cards in getattr(game, "up_cards", {}).items()}

        final_stacks = {p.player_id: p.stack for p in game.table.occupied_seats()}

        return HandHistory(
            hand_id=hand_id,
            variant_name=type(game).__name__,
            structure=game.structure.value,
            table_id=game.table.table_id,
            seat_order=self._seat_order,
            starting_stacks=dict(starting_stacks),
            hole_cards=hole_cards,
            board=board,
            up_cards=up_cards,
            actions=tuple(actions),
            winners=dict(game.outcome.total_payouts),
            final_stacks=final_stacks,
            big_blind_equivalent=_big_blind_equivalent(game),
        )


def begin_hand_history(game: BaseGame) -> HandHistoryBuilder:
    """Call immediately after `game.start_hand()` to snapshot the pre-action state."""
    return HandHistoryBuilder(game)
