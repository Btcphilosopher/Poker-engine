"""
Player statistics, computed from a stream of HandHistory records.

VPIP, PFR, and 3-bet% are Hold'em/Omaha-style concepts (blinds, a
"preflop" street, a well-defined betting sequence to be first/second to
raise) -- they only accumulate from hands whose action log has a
"preflop" street label, i.e. FlopGame-family hands. Stud and Draw hands
still contribute to hands_tracked, profit, and bb_per_100 (which
generalize fine across every variant), just not to those three.

Aggression Factor and BB/100 are the two genuinely universal stats here.
AF is computed POSTFLOP only (any street label other than "preflop"),
matching the standard tracker convention -- preflop calling the big
blind is structurally routine in a way that would dilute AF's signal if
included.

ROI is NOT computed from HandHistory at all -- it's a per-TOURNAMENT
concept (buy-ins and payouts), not a per-hand one. See calculate_roi,
which takes tournament-level totals directly (e.g. from
poker_engine.tournaments.Tournament).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence, Tuple

from poker_engine.betting.actions import ActionType
from poker_engine.statistics.hand_history import HandHistory, HandHistoryAction

_AGGRESSIVE = (ActionType.BET, ActionType.RAISE)
_VOLUNTARY = (ActionType.CALL, ActionType.BET, ActionType.RAISE)


class StatisticsError(Exception):
    pass


def _analyze_preflop(preflop_actions: Sequence[HandHistoryAction], player_id: str) -> Tuple[bool, bool, bool, bool]:
    """
    Walk one hand's preflop actions IN ORDER and return
    (vpip, pfr, three_bet_opportunity, three_bet_made) for `player_id`.
    The first raise of the hand is the "2-bet" (PFR); the next one is the
    3-bet -- the standard simplified convention, not a claim this
    handles every edge case (cold 4-bets, multi-way squeezes, etc.) with
    full nuance.
    """
    vpip = False
    pfr = False
    three_bet_opportunity = False
    three_bet_made = False
    raises_so_far = 0

    for action in preflop_actions:
        is_this_player = action.player_id == player_id

        if is_this_player:
            if action.action_type in _VOLUNTARY:
                vpip = True
            if action.action_type in _AGGRESSIVE:
                if raises_so_far == 0:
                    pfr = True
                elif raises_so_far == 1:
                    three_bet_opportunity = True
                    three_bet_made = True
            elif raises_so_far == 1 and action.action_type in (ActionType.FOLD, ActionType.CALL):
                three_bet_opportunity = True

        if action.action_type in _AGGRESSIVE:
            raises_so_far += 1

    return vpip, pfr, three_bet_opportunity, three_bet_made


@dataclass
class PlayerStatsTracker:
    """
    Accumulates raw counts hand-by-hand via record_hand(); every stat is a
    property computed on demand from those counts, so a snapshot taken
    mid-accumulation is always internally consistent.
    """

    hands_tracked: int = 0
    vpip_hands: int = 0
    pfr_hands: int = 0
    three_bet_hands: int = 0
    three_bet_opportunities: int = 0
    postflop_aggressive_actions: int = 0
    postflop_calls: int = 0
    total_profit: int = 0
    total_bb_won: float = 0.0

    def record_hand(self, history: HandHistory, player_id: str) -> None:
        if player_id not in history.starting_stacks:
            raise StatisticsError(f"{player_id} was not part of hand {history.hand_id}")

        self.hands_tracked += 1

        starting_stack = history.starting_stacks[player_id]
        final_stack = history.final_stacks.get(player_id, starting_stack)
        profit = final_stack - starting_stack
        self.total_profit += profit
        if history.big_blind_equivalent:
            self.total_bb_won += profit / history.big_blind_equivalent

        preflop_actions = [a for a in history.actions if a.street_label == "preflop"]
        if preflop_actions:
            vpip, pfr, opp, made = _analyze_preflop(preflop_actions, player_id)
            if vpip:
                self.vpip_hands += 1
            if pfr:
                self.pfr_hands += 1
            if opp:
                self.three_bet_opportunities += 1
            if made:
                self.three_bet_hands += 1

        for a in history.actions:
            if a.player_id != player_id or a.street_label == "preflop":
                continue
            if a.action_type in _AGGRESSIVE:
                self.postflop_aggressive_actions += 1
            elif a.action_type == ActionType.CALL:
                self.postflop_calls += 1

    @property
    def vpip_pct(self) -> float:
        return self.vpip_hands / self.hands_tracked if self.hands_tracked else 0.0

    @property
    def pfr_pct(self) -> float:
        return self.pfr_hands / self.hands_tracked if self.hands_tracked else 0.0

    @property
    def three_bet_pct(self) -> float:
        return self.three_bet_hands / self.three_bet_opportunities if self.three_bet_opportunities else 0.0

    @property
    def aggression_factor(self) -> float:
        if self.postflop_calls == 0:
            return float("inf") if self.postflop_aggressive_actions > 0 else 0.0
        return self.postflop_aggressive_actions / self.postflop_calls

    @property
    def bb_per_100(self) -> float:
        return (self.total_bb_won / self.hands_tracked) * 100 if self.hands_tracked else 0.0


def calculate_roi(total_buy_ins: int, total_winnings: int) -> float:
    """
    Return on investment across a set of tournaments (or any buy-in/payout
    pair): (winnings - buy_ins) / buy_ins, as a fraction (0.5 = +50% ROI,
    -1.0 = total loss). A per-TOURNAMENT concept, not a per-hand one --
    takes totals directly rather than HandHistory records.
    """
    if total_buy_ins <= 0:
        raise StatisticsError("total_buy_ins must be positive")
    return (total_winnings - total_buy_ins) / total_buy_ins
