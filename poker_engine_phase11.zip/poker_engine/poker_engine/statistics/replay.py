"""
Replay engine.

Reconstructs a step-by-step walkthrough of a HandHistory: what was
visible on the board (or up-cards) at the moment each action happened,
alongside the action itself and the running pot.

FlopGame-family hands (street labels preflop/flop/turn/river) reconstruct
board visibility exactly, from the standard 0/3/4/5-card reveal
convention -- no extra data needed beyond the final board plus each
action's street label. StudGame-family hands (third/fourth/.../seventh)
reconstruct up-card visibility the same way (1/2/3/4 up-cards revealed by
street; seventh deals a final DOWN card, so up-card count doesn't grow
again there).

DrawGame-family hands (predraw/draw_N) are NOT reconstructed card-by-card:
a HandHistory only stores the FINAL hole cards, and a draw round replaces
cards rather than revealing more of them, so there's no way to derive
what was held at an earlier point from the final hand alone. Replaying a
Draw hand shows the final hand throughout every step -- a documented
limitation, not a silent inaccuracy. A future phase wanting full Draw
replay fidelity would need HandHistory to record a hole-card snapshot per
round, which today's HandHistory deliberately doesn't (see its own
docstring on why it stays a lean, derived-from-existing-state record).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

from poker_engine.cards.card import Card
from poker_engine.statistics.hand_history import HandHistory, HandHistoryAction

_FLOP_STREET_BOARD_SIZE = {"preflop": 0, "flop": 3, "turn": 4, "river": 5}
_STUD_STREET_UP_COUNT = {"third": 1, "fourth": 2, "fifth": 3, "sixth": 4, "seventh": 4}


@dataclass(frozen=True, slots=True)
class ReplayStep:
    step_index: int
    action: HandHistoryAction
    board_visible: Tuple[Card, ...]
    up_cards_visible: Dict[str, Tuple[Card, ...]]


def replay_hand_history(history: HandHistory) -> List[ReplayStep]:
    steps: List[ReplayStep] = []
    for i, action in enumerate(history.actions):
        board_visible: Tuple[Card, ...] = ()
        up_cards_visible: Dict[str, Tuple[Card, ...]] = {}

        if action.street_label in _FLOP_STREET_BOARD_SIZE:
            board_visible = tuple(history.board[: _FLOP_STREET_BOARD_SIZE[action.street_label]])
        elif action.street_label in _STUD_STREET_UP_COUNT:
            count = _STUD_STREET_UP_COUNT[action.street_label]
            up_cards_visible = {pid: tuple(cards[:count]) for pid, cards in history.up_cards.items()}
        # else: Draw-family ("predraw"/"draw_N") -- no incremental reveal to reconstruct.

        steps.append(
            ReplayStep(
                step_index=i,
                action=action,
                board_visible=board_visible,
                up_cards_visible=up_cards_visible,
            )
        )
    return steps
