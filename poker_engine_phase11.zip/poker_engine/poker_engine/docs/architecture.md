# Architecture — Phase 1 (Foundation)

## Design principles carried through from here on

- **Immutability where it's free.** `Card` is a frozen, slotted dataclass —
  hashable, safe to share across threads, cheap to compare. This matters
  later for the multi-threaded Monte Carlo engine (Phase 10), which will
  pass cards between worker threads without locking.
- **Rank values ARE poker values.** `Rank.ACE.value == 14`. Evaluation code
  never needs a translation table between "what the enum says" and "what the
  hand ranking needs" — that's a common source of off-by-one bugs in poker
  engines and it's designed out from the start.
- **Comparison keys, not comparison functions.** Both `HandResult` and
  `LowHandResult` reduce to a plain tuple (`sort_key` / `rank_key`) such that
  Python's built-in tuple comparison produces the correct poker ranking.
  This means `max()`, `sorted()`, `min()` and the `<`/`>` operators all just
  work, including across combinatorial search (`evaluate_best_of`).
- **Display values and comparison keys are kept separate.** `LowHandResult`
  had a real bug caught during Phase 1 testing: the internal comparison key
  for Ace-to-5 low hands (which must be shape-prefixed — see below) is *not*
  the same as the actual card ranks you'd want to show a user. The dataclass
  now carries both `values` (display) and `rank_key` (comparison) explicitly
  rather than overloading one field for both purposes.

## Hand evaluation algorithm

`evaluate_5` classifies a 5-card hand by:
1. Sorting ranks descending and counting duplicates (`Counter`).
2. Checking flush (all one suit) and straight (5 consecutive distinct ranks,
   with the wheel A-2-3-4-5 as a special case where the Ace plays low).
3. Mapping the rank-count "pattern" (e.g. `(4,1)`, `(3,2)`, `(2,2,1)`) plus
   the flush/straight flags to one of the 9 `HandCategory` values.
4. Building an ordered tiebreaker tuple specific to that category (e.g. for
   two pair: `(high_pair, low_pair, kicker)`), so any two hands of the same
   category compare correctly including full kicker resolution.

`evaluate_best_of` (7-card hold'em/stud) and `evaluate_omaha` (Omaha's
"exactly 2 hole + 3 board" restriction) are built on top of `evaluate_5` via
`itertools.combinations` — correct by construction, since they're just
"evaluate every legal 5-card hand and take the best." This is the right
starting point for correctness; see the roadmap for the planned lookup-table
optimisation once the full rule engine depends on this API and a stable
before/after benchmark is meaningful.

## Ace-to-5 low evaluation

This is the one place in Phase 1 where the "obvious" implementation is
actually wrong, and it's worth documenting why.

A tempting shortcut for low-hand comparison is: sort each hand's ace-low
values descending, then compare the two tuples lexicographically (lower
tuple wins). This is correct for *unpaired* hands, but breaks the moment a
pair is involved:

```
7-5-4-3-2 (no pair)  vs  6-6-4-3-2 (pair of sixes)
```

Naive lexicographic comparison checks the highest card first (7 vs 6) and
would call the paired 6-6-4-3-2 hand better — which is wrong. In real
Ace-to-5 low (used by Razz, and for resolving the low side of Hi-Lo split
pots when a qualifier is disabled), **hand shape dominates first**, exactly
like a standard high hand: five-distinct-ranks beats one-pair beats two-pair
beats trips beats full house beats quads, *regardless* of what the actual
ranks are. Only within the same shape do lower ranks win.

`_low_sort_key` builds a `(shape_rank, *ordered_ranks)` tuple that encodes
this correctly, and `LowHandResult.rank_key` is what all comparisons go
through. `LowHandResult.values` is a separate, plain-English field (actual
ace-low ranks, sorted descending) kept purely for display and hand-history
export.

## What's deliberately not here yet

- **Badugi evaluation** — structurally different (suit-uniqueness based
  rather than rank-counting) and belongs with the Draw-games phase where
  it'll be built alongside the game rules that actually use it.
- **2-7 (Deuce-to-Seven) lowball** — straights/flushes count *against* the
  hand and Ace plays high-only, the opposite of Ace-to-5. Deferred to the
  Triple Draw implementation.
- **Lookup-table hand evaluation** — the current combinatorial approach is
  correct and already fast enough for turn-based gameplay (~100K hands/sec
  for `evaluate_5`); a perfect-hash table is planned once the full rule
  engine exists and Monte Carlo simulation volume actually demands it.

---

# Phase 2 — Betting Engine

## Why BettingRound is street-scoped, not hand-scoped

`BettingRound` handles exactly one street. `PlayerBettingState` is the
object that persists across the whole hand — the dealer phase is expected
to build a fresh `BettingRound` per street, passing the *same*
`PlayerBettingState` instances through each one, calling
`start_new_street()` between them. This mirrors how the money actually
behaves: `street_contributed` is street-scoped (what you owe/have put in
*this round*), `total_contributed` is hand-scoped (what side-pot
computation needs). Trying to make one object handle all streets would
mean either resetting internal state mid-object (fragile) or duplicating
the street/hand distinction that already exists naturally in the two
contribution fields.

## The minimum-raise / incomplete-raise rule

This is the single trickiest rule in the whole betting engine, so it gets
its own section (also documented inline in `round.py`).

A raise must increase the current bet by at least the size of the previous
full bet or raise. A player going all-in for less than that is still
allowed — but it does NOT let players who already called the previous bet
level re-raise; they may only call the extra amount or fold. Meanwhile, a
player who *hasn't* acted yet at the current level keeps full options
(including raising) even after an incomplete raise, since they never used
up their chance to respond to a legitimate full bet.

The implementation tracks this with a single set, `_acted_since_full_raise`,
cleared only on a COMPLETE bet/raise:
- Any action (fold/check/call/bet/raise) adds the actor to the set.
- A COMPLETE bet/raise clears the set and starts it over with just the
  actor — reopening full options for everyone else.
- An INCOMPLETE (short all-in) raise does NOT clear the set — the raiser
  is added to it, but everyone already in the set stays restricted to
  call/fold when `legal_actions` is asked for their options next.

Getting this right mattered enough that three of the test file's scenarios
(`test_incomplete_raise_*`) exist purely to pin down each side of this
rule with a worked example, rather than trusting the general logic alone.

## Bugs caught while writing Phase 2's own tests

Two are worth recording because they're the kind of bug that looks
plausible until you write the test that specifically targets it:

1. **Short-stacked "raise" below the current bet.** The first version of
   `legal_actions` computed a raise range for *any* player with `stack > 0`
   facing a bet, without checking whether their stack could actually
   exceed the current bet. A player with less in their stack than the
   current bet (e.g. facing a bet of 100 with only 30 chips) was offered a
   legal "raise" to 30 — which is less than the current bet, i.e. not a
   raise at all, just a disguised short call. Fixed by requiring
   `max_reachable() > current_bet` before offering RAISE; see
   `test_very_short_stack_cannot_raise_only_call_all_in_or_fold`.

2. **Pot-limit sizing fallback could balloon to full stack.** The original
   pot-limit `bet_max`/`raise_max` computed the structural cap and the
   stack-based floor *independently*, then patched disagreements with a
   fallback that set both to the player's full stack. In a degenerate
   (but code-reachable) case — a pot-limit street with nothing at all in
   the pot yet — this let a player with a million-chip stack "open" for
   their entire stack, ignoring the pot-limit cap entirely. Fixed by
   deriving the minimum from the already-correctly-capped maximum
   (`bet_min = min(self.min_bet, bet_max)`) instead of computing both
   independently; see
   `test_pot_limit_with_truly_empty_pot_disallows_betting_rather_than_ballooning_to_full_stack`.

Both were caught by deliberately writing a test for the exact edge case
the logic needed to handle, not by generic fuzzing — a reminder that the
property-based tests (which caught neither of these) are a complement to
targeted edge-case tests, not a replacement for them.

## `is_betting_complete()` vs. "the hand should end"

`BettingRound.is_betting_complete()` answers a narrow, mechanical question:
has every live player matched the current bet and had a turn this street?
It deliberately does NOT check "does only one non-folded player remain" —
that's a hand-level decision (award the pot immediately, don't even ask
the survivor to act) that belongs to the dealer/orchestrator in Phase 3,
which has visibility across the whole hand rather than one street. Mixing
that concern into `BettingRound` would couple street-mechanics to
hand-lifecycle decisions that differ per variant (e.g. running it twice in
some cash-game "run it twice" rules). See
`tests/test_betting_integration.py::test_uncontested_pot_when_everyone_but_one_folds`
for a worked example of the distinction.

## Pot construction: why layering by contribution level works

`compute_pots` doesn't track *when* side pots formed during play — it
recomputes them from scratch at the end from each player's
`total_contributed` and `is_folded` status. This is simpler and less
bug-prone than trying to maintain pot state incrementally as all-ins
happen mid-hand: sort the distinct contribution levels, and each layer
between two consecutive levels is a pot of `layer_size * contributors`,
eligible to whoever in that layer didn't fold. Adjacent pots that happen to
share an identical eligible set get merged for display — this changes
nothing about payouts (whoever wins between the same set of players wins
the combined amount either way) but avoids showing a poker room three
identically-eligible "pots" when there's no practical difference between
them.

---

# Phase 3 — Dealer + Table Management

## Player vs. PlayerBettingState: two objects, two lifetimes

It would be tempting to have one "Player" object carry both a persistent
stack and the per-hand betting fields (`street_contributed`,
`total_contributed`, `is_folded`, `is_all_in`). Phase 3 deliberately keeps
them as two separate objects instead:

- `Player` (this phase) lives at the table across many hands: name, seat,
  status (active / sitting out / waiting / eliminated), and the stack size
  that persists between hands.
- `PlayerBettingState` (Phase 2) lives for exactly one hand: it's built
  fresh from `Player.to_betting_state()` at the start of a hand and
  discarded once `Table.settle_hand()` folds its result back into `Player`.

The alternative — one long-lived object — would need to either reset a
pile of per-hand fields at the start of every hand (easy to forget one) or
carry hand-scoped noise (`is_folded`, `is_all_in`) that's meaningless
between hands. Two objects with two clear lifetimes is less code overall
once you account for the bugs the alternative invites.

## Deriving action order instead of hard-coding seat positions

`Table.preflop_action_order()` / `postflop_action_order()` don't store "who
is UTG" anywhere — they derive it fresh from `seats_from_button()` every
time, filtered to active players. This matters because the alternative
(tracking named positions like "UTG", "MP", "CO" as table state) has to be
kept in sync with every seating change, elimination, and button move; a
derived function can't drift out of sync with reality because there's
nothing to keep in sync — it just re-reads the current seat layout.

The one piece of real logic worth calling out is the 3-handed pre-flop
case: with exactly button+SB+BB and nobody else, the player *after* the
BB, who acts first pre-flop, is the button themselves (action wraps all
the way around). `order[3:] + order[:3]` on a 3-element list naturally
produces `[] + [button, SB, BB]` — the same order, which is correct — so
no special-casing was needed once the general slicing formula was right;
see `test_three_handed_action_order` for this worked out explicitly, since
it's easy to eyeball as a bug when it isn't one.

## The `advance_to_next_street` footgun (and why it's now an API, not a habit)

While writing Phase 3's own end-to-end integration test, a scratch version
of the dealer loop did this, in this order:

```python
for player in players_bs.values():
    player.start_new_street()          # resets street_contributed to 0

flop_round = BettingRound(
    ..., carried_pot=preflop.total_pot()   # <-- reads street_contributed AFTER it was reset
)
```

`BettingRound.total_pot()` is a live computation
(`carried_pot + sum(p.street_contributed for p in players)`), not a value
captured when the street ended. Resetting `street_contributed` before
reading it silently produces `0` for what should have been the entire pot
so far — no exception, no warning, just a hand that plays out for a pot
that's quietly stopped existing. This is exactly the kind of bug that's
invisible in a quick test (the code runs, nothing crashes) and only shows
up as "why did everyone's chip count come out wrong."

The fix wasn't "remember to call these in the right order" — that's not a
fix, it's a hope. `dealer.dealing.advance_to_next_street(round_)` captures
`total_pot()` and resets every player's street state as a single atomic
operation, so the two steps can no longer be reordered by a caller. Every
street-transition in the codebase (including the integration test that
found the bug) goes through it now.

## Table balancing: greedy nearest-pair, not a global optimum

`balance_tables` repeatedly moves one player from the currently-fullest
table to the currently-emptiest table until no two tables differ by more
than one. This is a greedy heuristic, not a proof-optimal minimum-move
solution — but table balancing doesn't need optimality, it needs to
converge to "within one player" quickly and deterministically, which the
greedy approach does in at most `O(total players)` moves. `find_table_to_break`
/ `plan_table_break` are kept as a separate, explicit two-step process
(decide whether a table *should* break, then plan where its players go)
rather than folded into `balance_tables` directly, since "should we
reduce the number of tables" is a judgment call a tournament director
makes deliberately, not something that should happen as a side effect of
routine rebalancing.

## resolve_showdown's scope: single-ranking pots only, on purpose

`resolve_showdown` picks one winning group per pot (the best hand among
eligible players, split evenly among exact ties). This covers Hold'em,
Omaha (high), Stud, and Draw games — everything Phase 4-6 needs before
Hi-Lo variants exist. It deliberately does NOT attempt to guess at a
Hi-Lo-shaped API now (e.g. "high_hand_results" and "low_hand_results"
parameters) — building that against no concrete variant to validate it
against would mean guessing at requirements Phase 5 (Omaha Hi-Lo) hasn't
surfaced yet. The natural extension when that phase arrives is calling pot
resolution twice (once against high hands, once against qualifying low
hands, each for half the pot) rather than a redesign, since `compute_pots`
already doesn't care what "winning" means — it just needs a comparison.

---

# Phase 4 — Texas Hold'em (First Playable Variant)

## One Game instance = one hand

`TexasHoldem.start_hand()` can only be called once per instance — playing
a second hand means constructing a new `TexasHoldem(table, ...)`. This
mirrors the `PlayerBettingState` design from Phase 2 (rebuilt fresh per
hand from `Player.stack`) rather than fighting it with reset logic. The
alternative — a `TexasHoldem` that can play hand after hand via some
`next_hand()` method — would need to carefully reset a dozen internal
fields (`_board`, `_hole_cards`, `_action_log`, `_outcome`, `_round`,
`_street`, ...) and get every one of them right, every time. A fresh
object per hand makes forgetting to reset something structurally
impossible: there's nothing left over from the last hand because there
*is* no last hand in this object.

The `Table` is what actually persists across hands (seating, stacks,
button position) — exactly the split Phase 3 set up on purpose.

## The state machine: one method decides everything

Every action funnels through `apply_action()` → `_advance_if_needed()`,
which asks exactly two questions, in this order:

1. **Is only one non-folded player left?** If so, the hand ends
   immediately and uncontested — no more cards get dealt, because a real
   dealer wouldn't deal cards nobody's going to see. This is the exact
   rule Phase 3 documented as explicitly out of scope for
   `BettingRound.is_betting_complete()` (see that docstring) — it lives
   here instead, at the hand-orchestration layer, because "should the hand
   end" is a decision that needs visibility across the whole hand, not
   just the current street.

2. **Is the current street's betting complete?** If not, nothing happens
   yet — wait for more actions. If so, advance: carry the pot forward
   (via `advance_to_next_street`, the Phase 3 API that exists specifically
   to prevent the pot-zeroing footgun), deal the next street's cards, and
   open a new `BettingRound` — *unless* fewer than two players have any
   chips left to bet with, in which case every remaining street gets
   dealt in one go and the hand jumps straight to showdown. This is the
   "everyone's all-in, run it out" case, and it's the same code path
   whether it happens on the flop, the turn, or even mid-preflop — the
   check runs after every single street transition, so it doesn't matter
   which street triggered it.

Nothing else in the class needs to know about hand-ending conditions —
every other method just does its one job (deal cards, run a betting round,
compute a showdown) and trusts `_advance_if_needed` to have decided
correctly that it's time to call it.

## Why structure-specific behaviour lives in one method, not three classes

`NoLimitHoldem`, `LimitHoldem`, and `PotLimitHoldem` could have been three
separate classes. They're one class (`TexasHoldem(structure=...)`)
because, looked at closely, exactly two things differ between them:

1. **Bet sizing.** `BettingRound` (Phase 2) already fully owns this — it
   takes a `BettingStructure` and computes legal ranges correctly for all
   three. `TexasHoldem` doesn't reimplement any of that; it just picks the
   right `min_bet` per street (`_min_bet_for_street()`: big blind for
   NL/PL, small_bet/big_bet for Limit depending on which street).
2. **The raise cap.** Fixed-limit games cap the number of raises per
   street (traditionally 4); NL/PL don't. This is a single `cap_raises`
   value computed once at `start_hand()` and passed through to every
   street's `BettingRound`.

Neither of these affects *how a hand is dealt, when streets advance, how
showdown is resolved, or how pots are split* — all of which is 100%
identical across the three structures. Three subclasses would mean three
copies of that identical logic (or an inheritance hierarchy built solely
to avoid duplicating two small computations), for zero behavioural
benefit. The property tests
(`test_random_full_games_terminate_and_conserve_chips`) run all three
structures through the exact same test body for exactly this reason: they
*are* the same game with different money rules, not three different games.

---

# Phase 5 — Other Flop Games

## Extracting FlopGame: waiting for three examples paid off

Phase 4's roadmap notes said extracting a shared base class was "worth
doing once there are 2-3 concrete variants to generalize from — deferred
rather than guessed at now." With Omaha, Omaha Hi-Lo, Short Deck,
Pineapple, Crazy Pineapple, and Irish all needing to exist this phase, that
moment arrived — and having six real examples on hand (not just Hold'em)
made the actual shape of the abstraction obvious rather than guessed:
almost the ENTIRE street-progression state machine (blinds, dealing,
betting-round-to-street sequencing, run-it-out, uncontested-pot detection,
settlement) turned out to be identical across every one of them. What
differs fits in five class attributes:

```python
HOLE_CARDS_DEALT: int       # how many hole cards a player starts with
HOLE_CARDS_FINAL: int       # how many they're evaluated with at showdown
DISCARD_AFTER_STREET: ...   # if set, a discard phase happens once this street's betting completes
SHORT_DECK: bool            # 36-card deck + flush-beats-full-house ranking
EVALUATION_MODE: str        # "best_of" | "omaha" | "omaha_hi_lo"
```

`TexasHoldem` — which had ~230 lines of its own state machine in Phase 4 —
is now two lines: a class statement and a docstring, because FlopGame's
defaults already are Hold'em's configuration. This was verified rather
than assumed: all 292 pre-existing Phase 1-4 tests pass unchanged against
the refactored class.

The lesson generalizes: the "don't build the abstraction before you have
three examples" discipline isn't just about avoiding wasted work on a
guess that turns out wrong — it also means that when you DO build the
abstraction, its shape comes from what several real cases actually needed,
which tends to produce a smaller, more confident design than reasoning
about it in the abstract would have.

## The discard mechanic: a pause button on street advancement, not a new state machine

Pineapple, Crazy Pineapple, and Irish all deal extra hole cards that get
discarded down mid-hand. Rather than model this as a special multi-street
sub-flow, it's implemented as a single interruption point:
`_advance_if_needed()` checks, right after a street's betting completes,
whether `self._street is self.DISCARD_AFTER_STREET` and nothing has been
discarded yet — if so, it populates a discard queue and *returns* instead
of dealing the next street. `current_player`, `legal_actions`, and
`apply_action` all check `_awaiting_discard` first and redirect callers to
`discard()`. Once the last player discards, the exact same
"deal next street, open next betting round" code that would have run
immediately just runs now instead, from `discard()`'s tail end.

The one genuinely tricky interaction: what happens if everyone goes all-in
on a street immediately before a scheduled discard? The "run it out"
fast-forward path (`_open_next_betting_round`, when fewer than two players
have chips left to act with) loops dealing remaining streets — that loop
now also checks for a pending, not-yet-done discard on each iteration and
pauses there too, exactly like the normal path does. Getting this right
mattered enough to write a dedicated test for it
(`test_pineapple_discard_pauses_run_it_out_when_all_in_preflop`) rather
than trusting that the two code paths (normal advancement vs. run-it-out)
would naturally agree — they're separate branches of the code, so nothing
guarantees they handle a new feature the same way unless it's checked in
both.

## Short Deck: a ranking swap, not a new evaluator

Short Deck's only two real differences from standard poker are the deck
(36 cards) and treating flush as better than full house. Both are handled
without touching the core evaluator at all: `Deck(short_deck=True)`
already existed (Phase 1 built deck-size flexibility in from the start),
and `evaluation/short_deck.py` just provides an alternate SORT KEY —
`evaluate_5`'s category *detection* logic (what makes something a flush,
what makes something a straight) doesn't know or care about deck size or
category ordering, so it's reused as-is.

Getting `resolve_showdown` to respect this ranking needed one small,
backward-compatible addition: an optional `key` parameter (default: the
`HandResult`'s own natural ordering), rather than a parallel
"resolve_showdown_short_deck" function or hard-coding standard ranking
into the resolver. Every pre-existing call site keeps working unchanged;
Short Deck just passes `short_deck_sort_key` instead of trusting the
default.

While writing the tests for this, a genuinely interesting fact fell out
that's worth knowing if you're ever tempted to "obviously" test it with 7
constructed cards: a full house and a flush can **never** both be
achievable from exactly 7 cards (2 hole + 5 board) — the math is in
`short_deck.py`'s docstring — so the ranking swap can never change which 5
cards a single player's own best hand is made of. It only ever matters
when comparing BETWEEN two different players' hands at showdown, which is
exactly the situation it exists to handle correctly.

## Omaha Hi-Lo: splitting a pot is splitting a pot, twice

`resolve_showdown_hi_lo` doesn't reimplement pot-splitting — it calls the
existing `distribute_pot` (Phase 2) twice per contested pot, once against
a half-sized "high" sub-pot and once against a half-sized "low" sub-pot,
built via `dataclasses.replace(pot, amount=half)`. This means the standard
odd-chip-to-first-winner-left-of-button rule Phase 2 already got right
automatically applies correctly to EACH half independently, with no new
odd-chip logic to write or test — only one new rule was actually needed:
when the total pot itself doesn't split evenly in two, the extra chip goes
to the high half (the standard convention), which is a single
`(pot.amount + 1) // 2` computation.

---

# Phase 6 — Stud + Draw Games

## Three independent state machines, not a forced hierarchy

`FlopGame`, `StudGame`, and `DrawGame` all implement `BaseGame`, and they
do share real *shape*: something that owns a `BettingRound` and a
turn-queue, a "run it out when everyone's all-in" fast-forward, an
"end immediately when only one player's left" check, and a `settle()`.
But `StudGame` isn't a `FlopGame` subclass, and neither is `DrawGame` —
each is built independently. The differences are structural, not
cosmetic: Stud has no button or blinds at all (antes + a bring-in instead,
and action order recalculated from scratch every street based on what
cards are showing, not a static seat rotation); Draw games have no
community cards and no up/down card distinction, just a discard-and-redraw
mechanic that fundamentally replaces cards rather than revealing shared
ones. Forcing three genuinely different domain models through one
inheritance hierarchy to save a few hundred lines of admittedly-similar
plumbing would trade a small amount of duplication for a much larger
amount of conditional complexity inside a single class. Phase 5's
`FlopGame` extraction worked because six concrete variants turned out to
share almost everything; Stud and Draw don't get that same benefit of the
doubt without evidence, so they don't get force-fit into it.

## The bring-in completion rule needed a real BettingRound extension

Stud's 3rd street opens with a bring-in: a small forced bet from whoever
has the worst-looking up-card. The next player can call it, fold, or
"complete" it — raise it up to the table's full small bet. This sounds
like an ordinary raise, but the arithmetic doesn't fit standard raise
sizing: if the bring-in is $3 and the small bet is $10, completing costs
only a $7 increment over the bring-in — smaller than a normal $10 raise —
yet every raise *after* the completion must jump back to a full $10.
Standard poker's "minimum raise = size of the previous bet or raise"
logic, unmodified, would either let someone complete for less than $10 or
demand raises smaller than a full small bet forever after.

`BettingRound` gained `min_bet_after_first_raise` for exactly this: pass
`min_bet=(small_bet - bring_in)` so the completion's arithmetic lands on
exactly `small_bet`, and `min_bet_after_first_raise=small_bet` so the
*next* raise (and every one after) reverts to a full small-bet increment
rather than inheriting the completion's smaller one. Getting this right
took two passes — see the bug below — but the result is a single,
narrowly-scoped, backward-compatible parameter (every existing caller
passes `None` and gets identical behaviour to before) rather than a
Stud-specific fork of the betting engine.

The bug: the first version of this fix updated `last_raise_size` correctly
in `_apply_wager`'s bookkeeping, but `legal_actions()`'s `FIXED_LIMIT`
branch computed the actual raise range from `self.min_bet` directly,
bypassing that bookkeeping entirely — because in every OTHER fixed-limit
game, a raise is always exactly `min_bet`, so there was never a reason for
that branch to consult anything else. It took direct verification with
concrete expected numbers ($3 → $10 → $20 → $30) to catch that the fix
was necessary-but-not-sufficient, rather than trusting that "the
bookkeeping is right" meant "the legal range is right" — they turned out
to be two different pieces of code that both needed to agree.

## Reshuffling discards back in: a real (not contrived) deck-exhaustion bug

Property testing surfaced something worth trusting the tests over
intuition on: a 52-card deck can genuinely run out mid-hand in Draw poker.
Six players in 5-Card Draw, each discarding several cards in the single
draw round, can need more replacement cards than remain after the initial
deal — this isn't an edge case invented to stress the code, it's an
arithmetic inevitability once enough players discard enough cards against
one deck.

The fix (`Deck.replenish()`, reshuffling previously-dealt cards back into
the draw pile) went through two iterations. The first mirrored the live-
casino convention of only reusing discards from *completed* rounds, never
the round in progress — the reasoning being that live players shouldn't
see what a table-mate just mucked seconds ago. That fixed Triple Draw (which
has three rounds to draw completed-round discards from) but did nothing
for 5-Card Draw, which has exactly one round and therefore no completed
round to reuse from when it runs short *within* that same round. The
second iteration dropped the completed-vs-current distinction entirely:
reshuffle in any card discarded so far this hand, the instant it's needed,
regardless of which round it came from. The live-casino protocol concern
this convention protects against — a player visually noticing what a
tablemate just mucked — has no equivalent in a headless rules engine with
no visual table; keeping the stricter rule would have been protecting
against a category of problem this engine doesn't have, at the cost of a
hand crashing that didn't need to.

---

# Phase 7 — Badugi + Mixed Games

## Badugi validated DrawGame's abstraction against a fourth example

`DrawGame` was built in Phase 6 from exactly two concrete cases (5-Card
Draw, 2-7 Triple Draw). Badugi is the first real test of whether that
generalized correctly or just happened to fit two examples: it needs a
4-card hand (not 5), the same 3-draw-round cadence as Triple Draw, and a
structurally different evaluator. The result required zero changes to
`DrawGame` itself beyond adding one more branch to
`_resolve_showdown()`'s evaluation-mode dispatch (`"badugi"` alongside
`"high"` and `"deuce_to_seven"`) — `CARDS_PER_PLAYER`, the discard/draw
mechanic, the betting-round cadence, and the all-in "still draw, just
don't bet" logic were all already generic enough. That's a meaningfully
stronger signal than Phase 6's original two examples: two data points can
always be explained by an abstraction that's merely convenient for those
two; a third holding up without modification is evidence the shape is
actually right.

## BadugiResult's `.sort_key` was designed to be a drop-in, not coincidence

`resolve_showdown`'s default comparison is `lambda hr: hr.sort_key` —
written that way in Phase 3 because `HandResult` exposed a `.sort_key`
property, and kept general (duck-typed, not type-checked) rather than
hard-coded to `HandResult` specifically. `BadugiResult` was built to
expose the identical property name with the identical "higher = better"
convention on purpose, specifically so it could be handed to
`resolve_showdown` with no `key=` argument at all — unlike Short Deck
(needed a custom key because it *inverts part of* the standard ordering)
or Razz (needed a custom key because `LowHandResult`'s own convention is
"lower = better," the opposite direction). This is worth calling out
because it's easy to mistake for luck rather than design: the module
docstring says outright that this compatibility is deliberate, and
`test_sort_key_is_directly_compatible_with_resolve_showdown_default`
exists specifically to keep it true if either side ever changes.

## The mixed-rotation button bug: correct pieces, wrong whole

Every individual button decision in this engine was already correct in
isolation before Phase 7: `StudGame` rightly never advances the button
(Stud's action order doesn't depend on it), and `FlopGame`/`DrawGame`
rightly always do (their action order does). The bug only exists at the
level where hands from different variants share one `Table` across a
session — something no single-variant test could have caught, because
within any one variant, "does the button move exactly once per hand"
was already true.

The fix is deliberately narrow: `MixedGameRotation.start_next_hand()`
advances the button itself, but only when checking `issubclass(leg.
game_class, StudGame)` — i.e., only for the one family of variant that
doesn't already do it internally. This was verified with a test that
plays two CONSECUTIVE Stud legs and asserts the button position differs
after each `start_next_hand()` call, specifically because that's the
scenario where a bug (button not moving at all across a Stud-only
stretch) would otherwise go unnoticed by a test that only checked
"does the button eventually differ from where the session started."

---

# Phase 8 — Tournament Engine

## One class, configuration-driven, not a class per tournament type

The spec's tournament list reads like a menu of distinct products: Sit &
Go, Freezeout, Rebuy, Knockout, Progressive Knockout, Satellite,
Multi-table. `Tournament` is one class for all of them, because none of
those differences turn out to be differences in ALGORITHM — they're
differences in DATA:

- Freezeout vs. Rebuy: whether `TournamentConfig.rebuy_policy` is `None`.
- Knockout vs. Progressive Knockout vs. neither: `bounty_config` absent,
  present with `progressive=False`, or present with `progressive=True`.
- Standard vs. Satellite: `is_satellite` + `num_seats`, which changes
  exactly two things — when `is_finished` triggers, and how `finalize()`
  splits the pool (flat instead of top-heavy).
- SNG vs. MTT: not a config field at all. A "Sit & Go" is just a
  `Tournament` where the caller happens to call `start()` once
  registration reaches some target size, on one table; an MTT is the same
  class with more registrants, more tables, and `rebalance_tables()`
  actually having work to do. There is no meaningful algorithmic
  difference to encode.

This mirrors the exact reasoning that kept `TexasHoldem` as one class
across No-Limit/Limit/Pot-Limit back in Phase 4 rather than three: when
the "different products" turn out to differ only in a handful of
parameters, one configurable class is more honest about the actual shape
of the problem than an inheritance hierarchy would be — and it's the kind
of thing that's only obvious once you sit down and check whether the
differences are really algorithmic before assuming they need separate
code paths.

## Prize pool: dollars in, not entries counted

The first version of `Tournament` tracked a single `_entry_count` and
computed `prize_pool = _entry_count * config.buy_in`. This is correct
exactly as long as every rebuy costs the same as the original buy-in —
true often enough in simple examples to pass a first round of testing,
false in plenty of real structures (a $100 buy-in tournament with $50
rebuys is completely ordinary). The fix separates two different
questions that had been conflated into one counter: "how many places
should be paid" (`total_entrants`, a count, used for
`standard_paid_places` sizing) and "how much money is actually in the
pool" (`prize_pool`, now `_prize_pool_contributions`, incremented by the
ACTUAL amount — `buy_in`, `rebuy_cost`, or `addon_cost` — at each event
that adds money). A count and a dollar total look interchangeable right
up until the price-per-unit isn't constant, which is exactly the case a
bare "entries × buy_in" formula can't represent.

## Satellites: know when to stop

`is_finished` and `finalize()` both needed to become satellite-aware
rather than assuming a single eventual winner. The insight that made this
the right fix rather than a workaround: a satellite's payout is ALREADY
flat (every seat is worth the same, by design — see `satellite_payouts`),
so playing past the point where the field size equals the seat count
produces zero additional information that the payout will ever reflect.
Stopping there isn't a shortcut that trades accuracy for speed; it's
recognizing that the "correct" answer and the "stop early" answer are
identical, because nothing about who specifically ends up 1st vs. 2nd
vs. 3rd among the survivors changes what any of them are paid.

## The stuck-hand bug: the most important one this phase found

Every earlier phase's property tests ran hundreds of full hands and
found real bugs. This phase's found something a different kind of
important: not a miscalculation, but a hand that could simply never
finish. Late in a long, realistic simulation — many hands played, blinds
growing every level, exactly the conditions a real tournament clock
creates — two short stacks in a heads-up match both went all-in from
posting forced blinds alone, before either player got a turn. Every
variant's state machine relies on a simple contract: after any action,
check whether the hand needs to advance (run the board out, go to
showdown, whatever). That contract has an unstated assumption baked into
it — that at least one action will eventually happen. When blinds exceed
both remaining stacks, that assumption breaks: nobody CAN act, so nothing
ever calls the code that would notice the hand is already over.

This is the kind of bug that's specifically resistant to hand-written
tests, because writing a test for it requires already suspecting it could
happen — four phases of variant-building, dozens of hand-picked all-in
and short-stack scenarios, never hit it, because nobody constructed a
test where BOTH players were already too short for the blinds before
either could act. It took a property test running a genuinely long
tournament under realistic (not adversarially-designed) conditions for
the scenario to occur on its own. The fix is one line in each of the
three base game classes — call the existing advancement check once,
unconditionally, right after the first betting round is constructed —
but the reason it's worth dwelling on isn't the size of the fix, it's
that no amount of additional hand-picked test cases would have been
likely to find it; only running enough realistic games for the world to
produce the scenario did.

---

# Phase 9 — Cash Games

## Where this content lives, and why

The original scaffold's directory list doesn't have an exact slot for
"cash game session orchestration" — `tables/` exists, but it's `Table`'s
home: seat mechanics, buy-in range enforcement, button rotation, action
order. Those are data-structure-and-mechanics concerns. `CashGame` is an
orchestrator — it decides WHEN a seat opens up gets filled and BY WHOM,
tracks a waiting list and reservation expiry across many hands, and calls
`Table` rather than being part of it — the same relationship `Tournament`
has with `Table`, which already lives in its own `tournaments/` package
rather than inside `tables/`. Phase 9's cash-game content follows that
same split: `poker_engine/cash_games/` for the orchestrator and its
supporting policies (`WaitingList`, `SeatReservationManager`,
`AutoTopUpPolicy`), `Table.top_up()` for the one piece of genuinely
low-level seat mechanics cash games needed that `Table` didn't already
have. This is the identical judgment call already made for `hands/` vs.
`variants/` back in Phase 5 — the original scaffold's directory names are
a reasonable starting guide, not a constraint that should force
orchestration logic into a module built for something structurally
different, and both deviations are documented here rather than made
silently.

## The reactivation bug: duplicating logic instead of calling it

`Table.top_up()`'s first version read as obviously correct: find the
player, compute how much room is left under `max_buyin`, add that many
chips to `player.stack`. And the arithmetic WAS correct. What it missed
wasn't a calculation — it was a piece of STATE that Phase 3's `Player`
class had already solved correctly, sitting one method away.
`Player.apply_hand_result()` marks a player `ELIMINATED` the instant a
hand leaves them at exactly 0 chips. `Player.rebuy()` already knew about
this and reactivates `ELIMINATED` back to `ACTIVE` as part of adding
chips. `top_up()` needed that exact same reactivation — a top-up and a
rebuy are the same operation from a status-tracking point of view, chips
added to a seated player — but its first version reimplemented "add
chips to stack" from scratch instead of calling `rebuy()`, and in doing
so silently left out the half of `rebuy()`'s job it didn't know to
re-derive.

The failure mode this produces is unusually quiet: nothing raises, no
exception, no wrong number anywhere obviously visible. A player who busts
and gets auto-topped-up ends up sitting at the table, seat occupied,
stack full — and then simply never gets dealt into another hand, because
`start_hand()`'s `active_player_ids()` filters on `is_active`
(`status == ACTIVE and stack > 0`), and their status never moved off
`ELIMINATED`. Every one of `top_up()`'s own unit tests passed, because
every one of them tested a player who was `ACTIVE` before AND after the
top-up — none of them constructed the specific prior state (`ELIMINATED`,
stack exactly 0) that the bug depended on, because writing that test
requires already knowing status-tracking is a thing that could go wrong
in this specific method. The `CashGame` integration test found it for a
mundane reason: it played real hands, real players actually busted to
exactly 0 (not a contrived setup), and the auto top-up policy that's the
whole point of Phase 9 topped them back up exactly the way a real ring
game would — and the very next hand quietly had one less player than it
should have.

The fix — `top_up()` now calls `player.rebuy(amount)` for the actual
chip addition rather than setting `.stack` directly — is small, but the
general shape of the bug is worth naming plainly: a method that
reimplements what another method already does, instead of calling it,
doesn't just risk drifting out of sync with it LATER. It can start out
already incomplete, missing whatever the original method handled that
its author didn't think to re-derive from scratch. This is the same
family of bug as Phase 8's stuck-hand issue in a different guise: both
were places where an existing piece of correct logic (the "run it out"
advancement check; `rebuy()`'s reactivation) had an implicit precondition
("something will eventually call this") that a new code path violated
by construction, not by a calculation error anywhere in the new code
itself.

---

# Phase 10 — AI Framework + Monte Carlo Simulation

## Two hand-strength functions, deliberately, not one

`poker_engine/ai/hand_strength.py` and `poker_engine/simulation/equity.py`
both answer some version of "how good is this hand" — it would be easy to
read that as duplication that should be collapsed into one function. It
isn't, because the two answer genuinely different questions under
genuinely different constraints. The heuristic is a category lookup with
a small kicker nudge: it runs in microseconds and needs to, because the
rule-based archetypes (and, more importantly, anything simulating
thousands of hands to validate them — this phase's own property tests,
Phase 11's likely statistics validation) call it on every single
decision. The Monte Carlo version runs an actual simulation against a
sampled opponent range: it's slower by a factor of hundreds, and buys
real accuracy in exchange. `MonteCarloAI` is the one archetype in this
phase built to spend that budget; every other archetype is built not to.
Keeping these as two separate, clearly-named functions with docstrings
that point at each other is the design decision — collapsing them into
one "smart" function that decides internally how much effort to spend
would hide that tradeoff instead of making it visible and controllable
by the caller.

## The preflop heuristic's two-pass recalibration

`estimate_preflop_strength` is explicitly documented as "deliberately
simple... not a claim of strategic accuracy" — and it still needed fixing
twice, because "approximate" and "wrong in an obvious way" are different
standards. The first version normalized against AA's maximum score and
added flat bonuses for pairs and suitedness; the bonuses pushed both AA
and AKs to the same capped value of `1.0`, erasing a distinction any
poker player would consider basic. Rebalancing that (scaling the base
score down to leave headroom for the bonuses) fixed AA-vs-AKs but
surfaced a second, worse problem on the next pass of testing: a bare pair
of deuces scored *below* unsuited 7-2 — statistically one of the worst
possible starting hands — because the pair bonus, sized to leave room
under the new cap, was too small to compensate for two mediocre unpaired
ranks. Both problems were caught the same way: by writing the specific,
obvious test a domain expert would ask first ("does AA beat AKs", "does
any pair beat garbage unpaired cards") rather than only checking that the
function stays inside `[0, 1]`. Range-boundedness is easy to get right by
construction; ORDERING between specific hands is where an approximation
actually earns or loses trust, and it needs a test that names the hands,
not a property test that only samples random ones — a random sample over
1,326 starting hands is unlikely to happen to compare AA against AKs
specifically, or 22 against 72o specifically, the exact pairs where this
heuristic's weaknesses lived.

## A design smell caught before it shipped, not after

`TournamentAI`'s first draft composed a `TightAggressive` instance and
adjusted its behavior for short stacks by temporarily overwriting its
`FOLD_THRESHOLD`/`RAISE_THRESHOLD` class attributes, restoring them in a
`finally` block after each decision. Nothing about this was actually
broken for how this engine drives hands — one decision at a time,
sequentially, no concurrent access to the same AI instance — so it would
have passed every test written against it. It's included here anyway
because it's worth being honest that not every improvement in this
project came from a failing test; this one came from re-reading the code
before writing tests against it and recognizing that "mutate a shared
object's state to fake per-call parameterization" is a pattern that looks
fine right up until something changes the assumptions that made it safe
(concurrent access, the wrapped instance being shared elsewhere, a future
refactor that makes the mutation observable mid-decision). The fix —
parameterizing the thresholds directly instead of wrapping and mutating
another `AIPlayer` — removes the state-mutation risk entirely rather than
managing it carefully, which is the better trade whenever the two options
cost about the same to write.

---

# Phase 11 — Statistics + Hand History + Replay

## A whole phase built without touching anything below it

Every prior phase that added a layer on top of the core engine —
`Tournament` on `Table`, `CashGame` on `Table`, `AIPlayer` on
`legal_actions()`/`apply_action()` — needed at least one small addition
to what the layer below exposed (`Table.top_up()`, `pot_size`). Phase 11
needed none. `HandHistory` is built entirely from `action_log`,
`hole_cards`, `board`/`up_cards`, `outcome`, and `pot_size` — five things
every `BaseGame` subclass was already exposing publicly, several of them
(`action_log` particularly) carrying a comment left back in Phase 6
noting they were "the basic unit Phase 11's hand-history export will
eventually consume." That comment turned out to be exactly right, which
is worth noting not as a coincidence but as a consequence of a pattern
held consistently since Phase 1: expose state as data (dataclasses,
public attributes, read-only properties) rather than only as behavior,
and a use nobody explicitly designed for — hand history export, five
phases later — becomes possible for free instead of requiring new hooks
threaded back through the engine.

## Reconstructing pot progression instead of tracking it

`action_log` entries never recorded "the pot size at this point" — only
the action itself. Adding that would have meant touching `BettingRound`
or every `Game` class's `apply_action()`, which is exactly the kind of
change Phase 11 was trying to avoid needing. Instead, `HandHistoryBuilder`
captures ONE number — `game.pot_size` immediately after `start_hand()`,
before any voluntary action — and reconstructs the running pot for every
later action purely by accumulating `action.amount` in order. This works
because `Action.amount` already means "the amount actually put into the
pot by this action" (documented on `Action` since Phase 2) for every
action type that moves money, and folds/checks contribute zero — the pot
progression was always fully determined by information already being
recorded, it just hadn't been extracted into that shape yet.

## Two off-by-one poker concepts, and why 3-bet% needs a real denominator

VPIP and PFR are single true/false facts per hand — did the player ever
voluntarily put money in preflop; were they the very first to raise. 3-bet%
is different: it's a percentage of OPPORTUNITIES, not a percentage of
hands, and getting the denominator right requires modeling something
subtler than "did a raise happen" — specifically, EXACTLY one prior raise,
no more. A player who folds facing a single raise had a 3-bet opportunity
and declined it. A player who folds facing an already-made 3-bet is
making a 4-bet decision — a real thing, just not the same thing, and
counting it as a missed 3-bet would inflate the denominator with
situations that were never actually 3-bet decisions at all. This is the
exact distinction Phase 11's own first-draft test got wrong (see the
roadmap's "what this phase's own tests caught" — the fix there was to
the TEST, not `PlayerStatsTracker`, which had the right logic from the
start), and it's worth stating plainly as a design principle: a
percentage stat is only as meaningful as its denominator, and a
denominator that's slightly too broad ("anyone who could have raised
again") produces a number that looks like 3-bet% but silently isn't.

## Replay's honest boundary at Draw games

`replay_hand_history` reconstructs board and up-card visibility for
FlopGame- and StudGame-family hands with full fidelity, from nothing more
than the final `HandHistory` plus the fixed, universal reveal convention
each family follows (0/3/4/5 board cards; 1/2/3/4 up-cards). Draw-family
hands get no such reconstruction, and the reason is structural, not a
missing feature: a draw round REPLACES cards, it doesn't reveal more of
an existing hand, so a `HandHistory` that only stores the FINAL hole
cards has genuinely lost the information needed to show what was held
before a draw — there's nothing to derive it from, the same way you
can't recover an overwritten variable's old value from its new one. The
honest fix would be recording a hole-card snapshot per draw round, which
would work but which `HandHistory` deliberately doesn't do, to stay a
lean record built from what the engine already exposes rather than
growing new per-round tracking specifically to serve one downstream
feature. Documenting the boundary clearly (a player looking at a
Draw-game replay sees the final hand throughout, not "cards TBD" or a
wrong reconstruction) was the deciding factor in leaving it as a
documented limitation rather than adding the tracking now on
speculation that some future phase will need it.
