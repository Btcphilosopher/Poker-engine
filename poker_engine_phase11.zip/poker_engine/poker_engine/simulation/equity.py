"""
Monte Carlo equity calculator.

Estimates win/tie/lose probability for each player in a hand by dealing
out the remaining unknown cards (board runouts, and hole cards for anyone
given a range instead of a specific hand) many times and evaluating who'd
win each time. This is the general "equity calculator" / "range vs range
simulation" the spec asks for -- Hold'em/Omaha-style, one SHARED community
board dealt out to 5 cards. Stud and Draw variants don't have a shared
board to run out; their hand-strength needs are served by
poker_engine.ai.hand_strength's faster heuristic instead (see that
module's docstring for the distinction).

Multi-threaded execution: num_workers splits num_simulations into
chunks run via concurrent.futures. Pure-Python CPU-bound work doesn't
get a linear speedup from threads because of the GIL -- pass
executor_factory=concurrent.futures.ProcessPoolExecutor for genuine
parallelism across cores (this module's worker function is a plain
top-level function specifically so it's picklable for that); threads
remain the default because they need no such consideration and this
module's actual bottleneck (card evaluation) is proportionally small next
to card shuffling/dealing overhead at realistic simulation counts.
"""

from __future__ import annotations

import random
from concurrent.futures import Executor, ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable, List, Optional, Sequence, Tuple, Union

from poker_engine.cards.card import Card
from poker_engine.evaluation.evaluator import evaluate_best_of, evaluate_omaha
from poker_engine.simulation.ranges import HandRange

HoleCardSpec = Union[Sequence[Card], HandRange]
Evaluator = Callable[[Sequence[Card], Sequence[Card]], object]


class EquityError(Exception):
    pass


def holdem_evaluator(hole: Sequence[Card], board: Sequence[Card]) -> object:
    """Default evaluator: best 5 of hole+board (Hold'em/Short-Deck/Draw-family style)."""
    return evaluate_best_of(list(hole) + list(board))


def omaha_evaluator(hole: Sequence[Card], board: Sequence[Card]) -> object:
    """Omaha-restricted evaluator: exactly 2 hole + 3 board."""
    return evaluate_omaha(hole, board)


@dataclass(frozen=True, slots=True)
class EquityResult:
    win: float
    tie: float

    @property
    def lose(self) -> float:
        return max(0.0, 1.0 - self.win - self.tie)

    @property
    def equity(self) -> float:
        """Expected fractional share of the pot: outright wins plus a fair share of ties."""
        return self.win + self.tie


def _resolve_trial_hands(
    hole_specs: Sequence[HoleCardSpec], board: Sequence[Card], full_deck: Sequence[Card], rng: random.Random
) -> Optional[Tuple[List[Tuple[Card, ...]], List[Card]]]:
    """One attempt at a non-conflicting deal for this trial, or None if ranges collided too many times."""
    for _ in range(50):
        used = set(board)
        resolved: List[Tuple[Card, ...]] = []
        ok = True
        for spec in hole_specs:
            if isinstance(spec, HandRange):
                candidates = [c for c in spec.combos if not (set(c) & used)]
                if not candidates:
                    ok = False
                    break
                combo = rng.choice(candidates)
                resolved.append(combo)
                used.update(combo)
            else:
                combo = tuple(spec)
                resolved.append(combo)
                used.update(combo)
        if not ok:
            continue

        remaining = [c for c in full_deck if c not in used]
        needed = 5 - len(board)
        if needed < 0:
            raise EquityError("board already has more than 5 cards")
        if needed > len(remaining):
            return None
        extra_board = rng.sample(remaining, needed) if needed > 0 else []
        return resolved, list(board) + extra_board
    return None


def _simulate_chunk(
    hole_specs: Sequence[HoleCardSpec],
    board: Sequence[Card],
    full_deck: Sequence[Card],
    evaluator: Evaluator,
    num_trials: int,
    seed: Optional[int],
) -> Tuple[List[int], List[float], int]:
    """
    Run num_trials independent deals. Returns (win_counts, tie_shares,
    completed_trials) -- one entry per player in hole_specs. A top-level
    function (not a closure) so it's usable with ProcessPoolExecutor, not
    just ThreadPoolExecutor.
    """
    rng = random.Random(seed)
    n = len(hole_specs)
    wins = [0] * n
    tie_shares = [0.0] * n
    completed = 0

    for _ in range(num_trials):
        resolved = _resolve_trial_hands(hole_specs, board, full_deck, rng)
        if resolved is None:
            continue
        hands, full_board = resolved
        results = [evaluator(hand, full_board) for hand in hands]
        best = max(results)
        winners = [i for i, r in enumerate(results) if r == best]
        if len(winners) == 1:
            wins[winners[0]] += 1
        else:
            share = 1.0 / len(winners)
            for i in winners:
                tie_shares[i] += share
        completed += 1

    return wins, tie_shares, completed


def calculate_equity(
    hole_specs: Sequence[HoleCardSpec],
    board: Sequence[Card],
    full_deck: Sequence[Card],
    *,
    num_simulations: int = 10_000,
    evaluator: Evaluator = holdem_evaluator,
    num_workers: int = 1,
    executor_factory: Optional[Callable[[int], Executor]] = None,
    seed: Optional[int] = None,
) -> List[EquityResult]:
    """
    Estimate win/tie probability for each player in hole_specs (each
    either a specific hand or a HandRange) given the cards already on
    board (0-5 known community cards; the rest are dealt randomly each
    trial from full_deck, which should contain every card NOT already
    assigned to a specific hand or the board).

    num_workers > 1 splits the simulation across that many workers via
    executor_factory (default ThreadPoolExecutor) -- see this module's
    docstring for the GIL caveat and how to get genuine parallelism.
    """
    if len(hole_specs) < 1:
        raise EquityError("hole_specs must not be empty")
    if num_simulations < 1:
        raise EquityError("num_simulations must be at least 1")
    if num_workers < 1:
        raise EquityError("num_workers must be at least 1")
    if len(board) > 5:
        raise EquityError("board cannot have more than 5 cards")

    factory = executor_factory or ThreadPoolExecutor
    n = len(hole_specs)

    base_seed = seed if seed is not None else random.SystemRandom().randrange(2**31 - 1)
    chunk_size = num_simulations // num_workers
    remainder = num_simulations % num_workers
    chunk_sizes = [chunk_size + (1 if i < remainder else 0) for i in range(num_workers)]
    chunk_sizes = [c for c in chunk_sizes if c > 0]

    total_wins = [0] * n
    total_tie_shares = [0.0] * n
    total_completed = 0

    if num_workers == 1 or len(chunk_sizes) == 1:
        wins, tie_shares, completed = _simulate_chunk(
            hole_specs, board, full_deck, evaluator, num_simulations, base_seed
        )
        total_wins, total_tie_shares, total_completed = wins, tie_shares, completed
    else:
        with factory(len(chunk_sizes)) as executor:
            futures = [
                executor.submit(_simulate_chunk, hole_specs, board, full_deck, evaluator, size, base_seed + i)
                for i, size in enumerate(chunk_sizes)
            ]
            for future in futures:
                wins, tie_shares, completed = future.result()
                for i in range(n):
                    total_wins[i] += wins[i]
                    total_tie_shares[i] += tie_shares[i]
                total_completed += completed

    if total_completed == 0:
        raise EquityError("No valid deals could be resolved -- check for conflicting/impossible hole_specs")

    return [
        EquityResult(win=total_wins[i] / total_completed, tie=total_tie_shares[i] / total_completed)
        for i in range(n)
    ]


def hand_strength_vs_random(
    hole_cards: Sequence[Card],
    board: Sequence[Card],
    full_deck: Sequence[Card],
    *,
    num_simulations: int = 5_000,
    evaluator: Evaluator = holdem_evaluator,
    seed: Optional[int] = None,
) -> EquityResult:
    """
    Convenience wrapper: this hand's equity against ONE random opponent
    hand (i.e. HandRange.random). The "true", simulation-based hand
    strength -- see poker_engine.ai.hand_strength for the fast heuristic
    version used by the simpler rule-based AI archetypes.
    """
    opponent_deck = [c for c in full_deck if c not in set(hole_cards) and c not in set(board)]
    opponent_range = HandRange.random(opponent_deck, len(hole_cards))
    results = calculate_equity(
        [tuple(hole_cards), opponent_range],
        board,
        full_deck,
        num_simulations=num_simulations,
        evaluator=evaluator,
        seed=seed,
    )
    return results[0]
