"""
Hand ranges for equity simulation.

A player's cards in an equity calculation are either a SPECIFIC known hand
(a fixed tuple of cards) or a RANGE — a set of possible combinations they
might hold, sampled from during simulation. "Range vs range" equity just
means every player in the calculation has a HandRange instead of a fixed
hand.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Sequence, Tuple

from poker_engine.cards.card import Card


class HandRangeError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class HandRange:
    """A set of equally-weighted possible hole-card combinations."""

    combos: Tuple[Tuple[Card, ...], ...]

    def __post_init__(self) -> None:
        if not self.combos:
            raise HandRangeError("combos must not be empty")
        sizes = {len(c) for c in self.combos}
        if len(sizes) != 1:
            raise HandRangeError("every combo in a range must have the same number of cards")

    @property
    def hole_card_count(self) -> int:
        return len(self.combos[0])

    @staticmethod
    def random(deck: Sequence[Card], hole_card_count: int) -> "HandRange":
        """
        The full "any N cards" range: every possible combination of
        `hole_card_count` cards from `deck` (typically the cards NOT
        already known to be in play — someone's hole cards or the board).
        """
        if hole_card_count < 1:
            raise HandRangeError("hole_card_count must be at least 1")
        combos = tuple(combinations(deck, hole_card_count))
        if not combos:
            raise HandRangeError("deck does not contain enough cards for this hole_card_count")
        return HandRange(combos=combos)

    @staticmethod
    def specific(hands: Sequence[Sequence[Card]]) -> "HandRange":
        """An explicit, equally-weighted list of possible hands."""
        return HandRange(combos=tuple(tuple(h) for h in hands))
