"""Expected value and pot odds calculations."""

from __future__ import annotations


class ExpectedValueError(Exception):
    pass


def pot_odds(pot_size: int, to_call: int) -> float:
    """
    The equity needed to break even calling to_call into a pot of
    pot_size (not counting the call itself): to_call / (pot_size + to_call).
    """
    if pot_size < 0 or to_call < 0:
        raise ExpectedValueError("pot_size and to_call cannot be negative")
    if to_call == 0:
        return 0.0
    return to_call / (pot_size + to_call)


def expected_value_of_call(pot_size: int, to_call: int, equity: float) -> float:
    """
    EV of calling: the standard formula equity * (pot after call) - cost,
    i.e. equity * (pot_size + to_call) - to_call. Positive means calling
    profits in expectation at this equity; negative means it doesn't.
    """
    if pot_size < 0 or to_call < 0:
        raise ExpectedValueError("pot_size and to_call cannot be negative")
    if not (0.0 <= equity <= 1.0):
        raise ExpectedValueError("equity must be between 0.0 and 1.0")
    return equity * (pot_size + to_call) - to_call


def expected_value_of_bet(pot_size: int, bet_size: int, fold_equity: float, equity_if_called: float) -> float:
    """
    EV of betting bet_size into pot_size, given the probability the bet
    gets folded to (fold_equity) and this hand's equity in the (larger)
    pot on the times it gets called.

    EV = fold_equity * pot_size
       + (1 - fold_equity) * (equity_if_called * (pot_size + 2 * bet_size) - bet_size)
    """
    if pot_size < 0 or bet_size < 0:
        raise ExpectedValueError("pot_size and bet_size cannot be negative")
    if not (0.0 <= fold_equity <= 1.0):
        raise ExpectedValueError("fold_equity must be between 0.0 and 1.0")
    if not (0.0 <= equity_if_called <= 1.0):
        raise ExpectedValueError("equity_if_called must be between 0.0 and 1.0")

    win_on_fold = fold_equity * pot_size
    called_pot = pot_size + 2 * bet_size
    win_on_call = (1 - fold_equity) * (equity_if_called * called_pot - bet_size)
    return win_on_fold + win_on_call
