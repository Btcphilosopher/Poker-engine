# Roadmap

Status legend: ✅ done · 🔜 next · ⬜ not started

| Phase | Scope | Status |
|---|---|---|
| 1 | **Foundation** — cards, deck, hand evaluation (5-card, best-of-N, Omaha, Ace-to-5 low) | ✅ |
| 2 | **Betting engine** — blinds, antes, bring-in, pot manager with side pots, limit/pot-limit/no-limit raise rules, all-in handling | ✅ |
| 3 | **Dealer + table management** — shuffle/deal orchestration, street progression, pot distribution, table balancing | ✅ |
| 4 | **Texas Hold'em (NL / Limit / Pot-Limit) end-to-end** — first fully playable variant | ✅ |
| 5 | **Other flop games** — Omaha, Omaha Hi-Lo, Short Deck (6+), Pineapple, Crazy Pineapple, Irish | ✅ |
| 6 | **Stud games** (7-Stud, Stud Hi-Lo, Razz) **+ Draw games** (5-Card Draw, 2-7 Triple Draw) | ✅ |
| 7 | **Badugi + Mixed games** — HORSE rotation, general mixed-game framework | ✅ |
| 8 | Tournament engine — SNG, freezeout, rebuy, KO/PKO, satellite, MTT, blind/break schedules, prize calculation, table balancing/merging | 🔜 |
| 9 | Cash games — ring games, buy-ins, seat reservations, waiting lists, auto top-up, table limits | ⬜ |
| 10 | AI framework (rule-based styles, Monte Carlo AI, CFR/NN interfaces) + Monte Carlo simulation engine (equity, range vs range, multi-threaded) | ⬜ |
| 11 | Statistics engine (VPIP/PFR/3-bet/aggression/BB-100/ROI/...) + hand history export + replay engine | ⬜ |
| 12 | Networking layer + REST API + WebSocket architecture | ⬜ |
| 13 | Hardening — full-suite coverage push, Docker, CI/CD, complete developer/API docs | ⬜ |

## Phase 1 deliverables

- `poker_engine/cards/` — `Card`, `Rank`, `Suit`
- `poker_engine/deck/` — `Deck` (standard/short/multi-deck, 3 shuffle modes)
- `poker_engine/evaluation/` — `evaluate_5`, `evaluate_best_of`,
  `evaluate_omaha`, `evaluate_low_5`, `evaluate_low_best_of`,
  `evaluate_omaha_low`, plus a throughput benchmark script
- 79 tests (unit + edge-case + property-based), 97% coverage
- Full package scaffold for every module named in the original spec, each
  stub documenting which phase will implement it

## Phase 2 deliverables

- `poker_engine/betting/structures.py` — `BettingStructure` (NL/PL/FL),
  `BlindLevel`
- `poker_engine/betting/actions.py` — `ActionType`, `Action` (hand-history
  log entry)
- `poker_engine/betting/player_state.py` — `PlayerBettingState`
- `poker_engine/betting/pot.py` — `compute_pots` (main + side pots via
  contribution layering), `distribute_pot` (split-pot chip division with
  the standard odd-chip-to-first-winner-left-of-button rule)
- `poker_engine/betting/round.py` — `BettingRound`, the core street state
  machine: turn order, legal-action computation, minimum-raise tracking,
  the "incomplete all-in raise doesn't reopen action" rule, pot-limit
  sizing, fixed-limit exact-size + raise-cap enforcement
- `poker_engine/betting/blinds.py` — blind/ante/bring-in/dead-blind
  posting, blind assignment (incl. heads-up), stud bring-in determination
- `poker_engine/betting/button.py` — dealer button rotation across seats
  (skipping empty seats)
- 105 new tests (unit, edge-case, property-based via Hypothesis, and a
  full multi-street integration test), bringing the suite to 184 tests /
  95%+ overall coverage

Real bugs caught and fixed during Phase 2's own test-writing (see
architecture.md for details): a short-stacked player could incorrectly be
offered "raise" for less than the current bet; a pot-limit sizing fallback
could balloon the legal max bet to a player's entire stack in a degenerate
zero-pot edge case.

## Phase 3 deliverables

- `poker_engine/players/player.py` — `Player` (persistent, across-hands
  state: name, seat, status, stack) and `PlayerStatus`, distinct from
  `PlayerBettingState` (ephemeral, per-hand)
- `poker_engine/tables/table.py` — `Table`: seating, buy-in range
  enforcement, dealer button rotation, and correct pre-flop/post-flop
  action-order derivation (including 3-handed and heads-up special cases)
- `poker_engine/tables/balancing.py` — `balance_tables` (keep multi-table
  player counts within one of each other), `find_table_to_break` /
  `plan_table_break` (standard tournament table consolidation)
- `poker_engine/dealer/dealing.py` — `deal_hole_cards` (round-robin),
  `deal_community_cards` (flop/turn/river with burns), `deal_stud_street`,
  `draw_replacement_cards`, and `advance_to_next_street` (see the footgun
  it prevents, below)
- `poker_engine/dealer/showdown.py` — `resolve_showdown` (pots → winners →
  payouts, single-ranking games), `determine_reveal_order`,
  `last_aggressor_of`
- 80 new tests (unit, edge-case, property-based, and a full end-to-end
  hand played through the real public API from seating to settlement),
  bringing the suite to 264 tests / 96% overall coverage

A real bug was caught while building Phase 3's own integration test: a
scratch script called `player.start_new_street()` (resetting
`street_contributed`) *before* reading `BettingRound.total_pot()` to carry
forward as the next street's pot — silently zeroing the carried pot with
no error, because `total_pot()` is a live computation over mutable state,
not a snapshot. Fixed at the API level with `advance_to_next_street()`,
which captures the pot and resets state as one atomic operation, so this
mistake isn't available to make. See architecture.md for the full story.

## Phase 4 deliverables

- `poker_engine/variants/base_game.py` — `BaseGame` (ABC every variant
  implements: `start_hand`, `legal_actions`, `apply_action`,
  `current_player`, `is_hand_complete`, `outcome`), `Street` enum for
  flop-based games
- `poker_engine/variants/texas_holdem.py` — `TexasHoldem`, one class
  parametrized by `BettingStructure` covering all three required variants
  (NL / Limit / Pot-Limit Hold'em). Fully self-contained state machine:
  blinds/antes → deal → four betting rounds with automatic street
  progression → automatic "run it out" when everyone's all-in →
  automatic uncontested-pot detection when folds leave one player →
  showdown → settlement
- 25 unit/edge-case tests plus property-based tests driving 300+
  fully-randomized complete games (every structure, 2-6 players, uneven
  stacks, heads-up) through the real public API, all verified to
  terminate and conserve chips exactly
- 292 tests total, 96% overall coverage

Phase 4 is where the "only one live player left -> end the hand
immediately" rule that Phase 3 explicitly deferred (see
`BettingRound.is_betting_complete()`'s docstring) finally gets
implemented, in `TexasHoldem._advance_if_needed()` — it's checked before
every other street-advancement logic, exactly as promised.

## Phase 5 deliverables

- `poker_engine/variants/flop_game.py` — `FlopGame`, extracted from Phase
  4's `TexasHoldem` once there were enough concrete variants to generalize
  from correctly. Every flop-based variant is now mostly class-attribute
  configuration (`HOLE_CARDS_DEALT`, `HOLE_CARDS_FINAL`,
  `DISCARD_AFTER_STREET`, `SHORT_DECK`, `EVALUATION_MODE`) rather than
  reimplemented street-progression logic. Also adds a full discard-phase
  mechanic (`discard()`, `awaiting_discard`) for the Pineapple family,
  including correctly pausing mid-"run it out" when an all-in happens
  before a pending discard.
- `poker_engine/variants/texas_holdem.py` — refactored to a 2-line
  `FlopGame` subclass with zero behaviour change (verified: all 292
  pre-existing tests pass unchanged).
- `poker_engine/variants/omaha.py` — `Omaha` (4 hole cards, exactly-2+3
  evaluation) and `OmahaHiLo` (same, pot split between qualifying high
  and low via the new `resolve_showdown_hi_lo`).
- `poker_engine/variants/short_deck_holdem.py` — `ShortDeckHoldem` (36-card
  deck, flush beats full house).
- `poker_engine/variants/pineapple.py` — `Pineapple`, `CrazyPineapple`,
  `Irish` (3 or 4 hole cards, discard down to 2 at different points,
  standard Hold'em evaluation once discarded).
- `poker_engine/evaluation/short_deck.py` — `short_deck_sort_key`,
  `evaluate_best_of_short_deck` (swaps flush/full-house ranking; see
  architecture.md for why this can never matter for a single player's own
  best-hand selection with exactly 7 cards, only for comparing between
  players).
- `poker_engine/dealer/showdown.py` — `resolve_showdown` gained an
  optional `key` parameter (Short Deck's hook); `resolve_showdown_hi_lo`
  is new (Omaha Hi-Lo's pot-splitting, with the standard "odd chip to the
  high half" rule) — this is the Hi-Lo capability Phase 3 and 4 both
  deliberately deferred until there was a concrete consumer to design it
  against.
- 52 new tests (unit, edge-case, and property-based — ~440 randomized full
  games across all 7 flop-based variants, every structure, random discard
  choices), bringing the suite to 344 tests / 97% overall coverage

## Phase 6 deliverables

- `poker_engine/evaluation/deuce_to_seven.py` — 2-7 lowball evaluation,
  deferred since Phase 1. Reuses `evaluate_5` via a new `allow_wheel`
  parameter (default `True`, fully backward-compatible) rather than
  duplicating category-detection logic.
- `poker_engine/evaluation/exposed.py` — `best_exposed_player`,
  `exposed_hand_key`: determining Stud action order from partial up-cards,
  which is explicitly NOT a poker hand evaluation (no straights/flushes
  possible with 2-4 cards showing).
- `poker_engine/betting/structures.py` — `StudStakes` (ante/bring-in/
  small-bet/big-bet).
- `poker_engine/betting/round.py` — `BettingRound` gained an optional
  `min_bet_after_first_raise` parameter, built specifically for Stud's
  bring-in "completion" rule (a small forced bet that the next player can
  complete to a full bet, after which normal-sized raises resume) — see
  the bug story below.
- `poker_engine/variants/stud_game.py` — `StudGame`: antes + bring-in
  instead of blinds, action order recalculated fresh every street from
  exposed cards, 5 betting rounds (3rd-7th street).
- `poker_engine/variants/seven_card_stud.py` — `SevenCardStud`,
  `StudHiLo` (reuses `resolve_showdown_hi_lo` directly — no new pot logic
  needed), `Razz` (`LOWBALL=True` flips both bring-in and action-order
  direction).
- `poker_engine/variants/draw_game.py` — `DrawGame`: reuses FlopGame's
  blind/button machinery, but replaces community-card streets with
  discard-and-redraw rounds. Kept separate from `FlopGame` (different
  discard semantics: full redraw vs. one-time narrowing) and separate from
  `StudGame` (blinds vs. antes+bring-in) — three independent state
  machines under `BaseGame`, not a forced hierarchy.
- `poker_engine/variants/five_card_draw.py` — `FiveCardDraw`,
  `TripleDraw` (2-7 lowball, 3 draw rounds).
- `poker_engine/deck/deck.py` — `Deck.replenish()`, new: reshuffles
  previously-dealt cards back into the draw pile. Built to fix a real bug
  (below), not speculatively.
- 90 new tests (unit, edge-case, and property-based — ~600 additional
  randomized full games across all 5 new variants), bringing the suite to
  434 tests / 98% overall coverage

### Three real bugs caught during Phase 6

1. **Bring-in completion sizing.** Stud's bring-in "completion" (a player
   raising a small forced bet up to a full small-bet) doesn't fit standard
   raise math — completing to *exactly* small_bet is a smaller increment
   than the bring-in itself, but every raise *after* that must jump back
   to a full small-bet increment. Fixed via `min_bet_after_first_raise`.
   The first version of the fix only updated `BettingRound`'s internal
   bookkeeping (`last_raise_size`), which turned out to be necessary but
   not sufficient: `FIXED_LIMIT`'s `legal_actions()` computed its raise
   range directly from `self.min_bet`, completely bypassing that
   bookkeeping (fixed-limit raises are normally a constant size, so it
   never needed to consult it before). Caught by direct verification with
   exact expected numbers ($3 bring-in → completes to $10 → next raise to
   $20 → $30) before trusting the design, not by assuming the first fix
   was sufficient.
2. **Bring-in action order.** The first implementation put the bring-in
   poster FIRST in the next street's action order — but they already
   acted (via the forced bet); the player AFTER them should act first,
   with the bring-in poster acting LAST (mirroring how the big blind acts
   last pre-flop in flop games). Caught immediately by a test that simply
   tried to fold the first-to-act player and got "nothing to call,"
   because the engine had them facing their own bring-in.
3. **Deck exhaustion in Draw games.** Property testing found that several
   players discarding heavily across multiple rounds (or even within a
   single round, for 5-Card Draw specifically, which only gets one) can
   genuinely exhaust a 52-card deck — not a contrived case, a real
   consequence of "many players, aggressive discarding, one deck." Fixed
   with `Deck.replenish()`: reshuffle previously-discarded cards back into
   the draw pile rather than crashing the hand. The first version of this
   fix only reused discards from *completed* rounds (mirroring the live-
   casino convention of never reusing the current round's own discards, to
   avoid players seeing what was just mucked) — which fixed Triple Draw
   but couldn't help 5-Card Draw at all, since it only has one round and
   therefore no "completed" round to draw from. Simplified to reshuffle in
   *any* prior discard, including from earlier in the same round, once it
   was clear the live-casino protocol concern (players watching what gets
   mucked) doesn't apply to a headless rules engine — documented as a
   deliberate simplification, not an oversight.

## Phase 7 deliverables

- `poker_engine/evaluation/badugi.py` — Badugi evaluation, deferred since
  Phase 1: best-qualifying-subset search over a 4-card hand (no duplicate
  rank, no duplicate suit, Ace low only), with a `.sort_key` property
  deliberately shaped to match `HandResult`/`LowHandResult`'s convention
  — `resolve_showdown`'s *default* key function works on `BadugiResult`
  objects with no custom `key` override needed, purely because the
  attribute name and "higher = better" direction match.
- `poker_engine/variants/badugi.py` — `Badugi`, a `DrawGame` subclass
  (4 cards, 3 draw rounds, `EVALUATION_MODE="badugi"`) — the fourth
  concrete `DrawGame` example, and it required zero changes to `DrawGame`
  itself beyond the one new evaluation-mode branch, confirming the
  abstraction generalizes rather than just happening to fit three
  examples.
- `poker_engine/variants/mixed_games.py` — `RotationLeg`, `MixedGameRotation`
  (the general mixed-game framework), and `horse_rotation()` (the classic
  5-game HORSE cycle built from it). Each hand is still a fresh Game
  instance per the "one instance = one hand" pattern every variant
  already follows; the rotation just knows which class and stakes object
  go with each leg.
- 65 new tests (unit, edge-case, and property-based — including a
  12-hands-deep randomized rotation test that switches game types every
  hand while verifying chip conservation across the whole sequence),
  bringing the suite to 480 tests / 98% overall coverage

### The button-fairness bug in mixed rotations

`StudGame` deliberately never touches the table's dealer button (it's
irrelevant to Stud's own action order, which is recalculated from exposed
cards every street). That's correct in isolation, but surfaced a real gap
once hands from different variants share a table: `FlopGame`/`DrawGame`
subclasses already advance the button themselves in `start_hand()`, so
if `MixedGameRotation` did nothing extra, a player could sit on the button
through an entire run of Stud hands and *still* be on it when the rotation
returned to a blind-based game — several hands of unfair positioning
compressed into what should have been one button-move each. Fixed by
having `MixedGameRotation.start_next_hand()` advance the button itself,
but *only* when the upcoming leg is a `StudGame` subclass — advancing it
unconditionally would double-advance for every blind-based leg, which
already does it internally. Verified directly: button position must
differ before vs. after `start_next_hand()` even across two consecutive
Stud legs, where neither game class touches it on its own.

## Notes for the next session

- Phase 8 (Tournament engine) is next: SNG, freezeout, rebuy, KO/PKO,
  satellite, MTT structures, blind/break schedules, prize calculation,
  and table balancing/merging (`poker_engine.tables.balancing`, built in
  Phase 3, has been sitting unused by anything above the `Table` layer
  until now — this is where it finally gets a caller).
- `MixedGameRotation` becomes directly relevant to Phase 8: mixed-game
  tournaments (e.g. HORSE tournaments) are a real, common structure, so
  the tournament engine should be able to wrap a `MixedGameRotation` the
  same way it wraps a single variant, rather than assuming one game type
  per tournament.
- Every variant built so far assumes a single, stable `Table`. Phase 8's
  multi-table tournaments will be the first real stress test of whether
  `Table.settle_hand()` and the `Player`/`PlayerBettingState` split (Phase
  3) hold up when players move between tables mid-tournament via
  `tables.balancing` — worth watching for rather than assuming it "just
  works" because the pieces exist independently.
