"""
StudGame — the shared state machine behind 7-Card Stud, Stud Hi-Lo, and
Razz. Deliberately NOT a FlopGame subclass (see Phase 5's roadmap notes):
Stud has no button/blinds (antes + bring-in instead), no community cards
(each player has their own up/down cards), and action order is
recalculated fresh every street from what's showing rather than a static
seat rotation — different enough in every dimension that forcing it into
FlopGame's shape would cost more than it saved.

Streets: 3rd (2 down + 1 up, bring-in), 4th/5th/6th (1 up each), 7th
(1 down, "the river card"). Betting order: 3rd street starts with the
bring-in (lowest/highest up-card — see determine_bring_in); 4th street
onward starts with whoever's exposed cards look best/worst (see
best_exposed_player), and proceeds around the table from there.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional

from poker_engine.betting.actions import Action, ActionType
from poker_engine.betting.round import BettingRound, LegalActions
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.betting.structures import BettingStructure, StudStakes
from poker_engine.betting.blinds import determine_bring_in, post_ante, post_bring_in
from poker_engine.cards.card import Card
from poker_engine.dealer.dealing import advance_to_next_street
from poker_engine.dealer.showdown import HandOutcome, resolve_showdown, resolve_showdown_hi_lo
from poker_engine.deck.deck import Deck
from poker_engine.evaluation.evaluator import evaluate_best_of, evaluate_low_best_of
from poker_engine.evaluation.exposed import best_exposed_player
from poker_engine.tables.table import Table
from poker_engine.variants.base_game import BaseGame, GameError


class StudStreet(Enum):
    THIRD = "third"
    FOURTH = "fourth"
    FIFTH = "fifth"
    SIXTH = "sixth"
    SEVENTH = "seventh"
    SHOWDOWN = "showdown"
    COMPLETE = "complete"


_STREET_ORDER = [
    StudStreet.THIRD,
    StudStreet.FOURTH,
    StudStreet.FIFTH,
    StudStreet.SIXTH,
    StudStreet.SEVENTH,
]


@dataclass(frozen=True, slots=True)
class StudStreetAction:
    street: StudStreet
    action: Action


class StudGame(BaseGame):
    # -- variant configuration (override in subclasses) ----------------------------------------------------------
    CARDS_PER_PLAYER: int = 7
    EVALUATION_MODE: str = "high"  # "high" | "low" | "hi_lo"
    LOW_QUALIFIER: Optional[int] = 8  # only consulted when EVALUATION_MODE in ("low", "hi_lo"); None = no qualifier (Razz)
    LOWBALL: bool = False  # Razz=True: highest up-card brings in, worst exposed hand acts first

    def __init__(
        self,
        table: Table,
        structure: BettingStructure,
        stakes: StudStakes,
        *,
        deck: Optional[Deck] = None,
        fixed_limit_raise_cap: int = 4,
    ) -> None:
        self.table = table
        self.structure = structure
        self.stakes = stakes
        self.fixed_limit_raise_cap = fixed_limit_raise_cap

        self._deck = deck if deck is not None else self._build_deck()
        self._betting_states: Dict[str, PlayerBettingState] = {}
        self._round: Optional[BettingRound] = None
        self._street: StudStreet = StudStreet.THIRD
        self._hole_cards: Dict[str, List[Card]] = {}
        self._up_cards: Dict[str, List[Card]] = {}
        self._action_log: List[StudStreetAction] = []
        self._outcome: Optional[HandOutcome] = None
        self._cap_raises: Optional[int] = None
        self._seat_order: List[str] = []
        self._started = False

    def _build_deck(self) -> Deck:
        deck = Deck()
        deck.shuffle(secure=True)
        return deck

    # -- BaseGame interface ----------------------------------------------------------

    def start_hand(self) -> None:
        if self._started:
            raise GameError("start_hand() may only be called once per Game instance")
        self._started = True

        active_ids = self.table.active_player_ids()
        if len(active_ids) < 2:
            raise GameError("Need at least 2 active players to start a hand")
        # Stud has no button/blinds, but we still need SOME fixed seating
        # order to deal in and to rotate action from; table seating order
        # works regardless of where the (irrelevant, for stud) button is.
        self._seat_order = self.table.active_seats_from_button()

        self._betting_states = {pid: self.table.find_player(pid).to_betting_state() for pid in active_ids}
        heads_up = len(active_ids) == 2
        self._cap_raises = self.fixed_limit_raise_cap if not heads_up else None

        ante_total = 0
        for pid in active_ids:
            ante_total += post_ante(self._betting_states[pid], self.stakes.ante).amount

        self._hole_cards = {pid: [] for pid in self._seat_order}
        self._up_cards = {pid: [] for pid in self._seat_order}
        for _ in range(2):
            for pid in self._seat_order:
                self._hole_cards[pid].append(self._deck.deal_one())
        for pid in self._seat_order:
            card = self._deck.deal_one()
            self._hole_cards[pid].append(card)
            self._up_cards[pid].append(card)

        up_card_map = {pid: self._up_cards[pid][0] for pid in self._seat_order}
        bring_in_id = determine_bring_in(up_card_map, low_brings_in=not self.LOWBALL)
        post_bring_in(self._betting_states[bring_in_id], self.stakes.bring_in)

        # The bring-in poster already "acted" via the forced bet -- action
        # starts with the NEXT player, and the bring-in poster acts last.
        rotated = self._rotate_from(bring_in_id)
        order = rotated[1:] + rotated[:1]
        self._round = BettingRound(
            [self._betting_states[pid] for pid in order],
            self.structure,
            self.stakes.small_bet - self.stakes.bring_in,
            carried_pot=ante_total,
            cap_raises=self._cap_raises,
            min_bet_after_first_raise=self.stakes.small_bet,
        )

    def legal_actions(self, player_id: str) -> LegalActions:
        if self._round is None:
            raise GameError("No betting round is currently open")
        return self._round.legal_actions(player_id)

    def apply_action(self, player_id: str, action_type: ActionType, amount: int = 0) -> Action:
        if self.is_hand_complete:
            raise GameError("This hand is already complete")
        if self._round is None:
            raise GameError("No betting round is currently open")

        action = self._round.apply(player_id, action_type, amount)
        self._action_log.append(StudStreetAction(street=self._street, action=action))
        self._advance_if_needed()
        return action

    @property
    def current_player(self) -> Optional[str]:
        return self._round.next_to_act() if self._round is not None else None

    @property
    def is_hand_complete(self) -> bool:
        return self._street is StudStreet.COMPLETE

    @property
    def outcome(self) -> Optional[HandOutcome]:
        return self._outcome

    # -- read-only hand state ----------------------------------------------------------

    @property
    def street(self) -> StudStreet:
        return self._street

    @property
    def hole_cards(self) -> Dict[str, List[Card]]:
        return {pid: list(cards) for pid, cards in self._hole_cards.items()}

    @property
    def up_cards(self) -> Dict[str, List[Card]]:
        return {pid: list(cards) for pid, cards in self._up_cards.items()}

    @property
    def action_log(self) -> List[StudStreetAction]:
        return list(self._action_log)

    def settle(self) -> None:
        if not self.is_hand_complete or self._outcome is None:
            raise GameError("Cannot settle a hand that isn't complete yet")
        self.table.settle_hand(self._betting_states, self._outcome.total_payouts)

    # -- internals ----------------------------------------------------------

    def _min_bet_for_street(self) -> int:
        return self.stakes.small_bet if self._street in (StudStreet.THIRD, StudStreet.FOURTH) else self.stakes.big_bet

    def _live_player_ids(self) -> List[str]:
        return [pid for pid in self._seat_order if not self._betting_states[pid].is_folded]

    def _contestable_player_ids(self) -> List[str]:
        return [
            pid
            for pid in self._seat_order
            if not self._betting_states[pid].is_folded and not self._betting_states[pid].is_all_in
        ]

    def _rotate_from(self, start_pid: str) -> List[str]:
        idx = self._seat_order.index(start_pid)
        return self._seat_order[idx:] + self._seat_order[:idx]

    def _advance_if_needed(self) -> None:
        if len(self._live_player_ids()) <= 1:
            self._finish_uncontested()
            return
        if self._round is not None and not self._round.is_betting_complete():
            return

        carried_pot = advance_to_next_street(self._round)
        if self._street is StudStreet.SEVENTH:
            self._go_to_showdown()
            return

        self._deal_next_street()
        self._open_next_betting_round(carried_pot)

    def _deal_next_street(self) -> None:
        next_index = _STREET_ORDER.index(self._street) + 1
        self._street = _STREET_ORDER[next_index]
        live = self._live_player_ids()
        if self._street is StudStreet.SEVENTH:
            for pid in live:
                self._hole_cards[pid].append(self._deck.deal_one())  # face down, no new up-card
        else:
            for pid in live:
                card = self._deck.deal_one()
                self._hole_cards[pid].append(card)
                self._up_cards[pid].append(card)

    def _open_next_betting_round(self, carried_pot: int) -> None:
        contestable = set(self._contestable_player_ids())
        if len(contestable) < 2:
            self._round = None
            while self._street is not StudStreet.SEVENTH:
                self._deal_next_street()
            self._go_to_showdown()
            return

        leader = best_exposed_player(
            {pid: self._up_cards[pid] for pid in contestable}, low_hand=self.LOWBALL
        )
        order = [pid for pid in self._rotate_from(leader) if pid in contestable]
        self._round = BettingRound(
            [self._betting_states[pid] for pid in order],
            self.structure,
            self._min_bet_for_street(),
            carried_pot=carried_pot,
            cap_raises=self._cap_raises,
        )

    def _go_to_showdown(self) -> None:
        self._street = StudStreet.SHOWDOWN
        self._round = None
        self._outcome = self._resolve_showdown()
        self._street = StudStreet.COMPLETE

    def _finish_uncontested(self) -> None:
        self._round = None
        self._outcome = self._resolve_showdown()
        self._street = StudStreet.COMPLETE

    def _resolve_showdown(self) -> HandOutcome:
        live = self._live_player_ids()
        order = self._seat_order

        if self.EVALUATION_MODE == "hi_lo":
            high_results = {}
            low_results = {}
            if len(live) > 1:
                for pid in live:
                    hand = self._hole_cards[pid]
                    high_results[pid] = evaluate_best_of(hand)
                    low_results[pid] = evaluate_low_best_of(hand, qualifier=self.LOW_QUALIFIER)
            return resolve_showdown_hi_lo(list(self._betting_states.values()), high_results, low_results, order)

        if self.EVALUATION_MODE == "low":
            hand_results = {}
            if len(live) > 1:
                for pid in live:
                    hand_results[pid] = evaluate_low_best_of(self._hole_cards[pid], qualifier=self.LOW_QUALIFIER)
            return resolve_showdown(
                list(self._betting_states.values()),
                hand_results,
                order,
                key=lambda lr: tuple(-v for v in lr.rank_key),
            )

        hand_results = {}
        if len(live) > 1:
            for pid in live:
                hand_results[pid] = evaluate_best_of(self._hole_cards[pid])
        return resolve_showdown(list(self._betting_states.values()), hand_results, order)
