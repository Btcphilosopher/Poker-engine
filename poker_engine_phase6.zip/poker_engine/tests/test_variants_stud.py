import pytest

from poker_engine.betting import ActionType, BettingStructure
from poker_engine.betting.structures import StudStakes
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import GameError, Razz, SevenCardStud, StudHiLo, StudStreet


def make_table(n_players=3, stack=1000):
    table = Table(table_id="t1", max_seats=8)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, stack)
    return table, ids


def seeded(cls, table, seed, structure=BettingStructure.FIXED_LIMIT, stakes=None):
    deck = Deck()
    deck.shuffle(seed=seed)
    stakes = stakes or StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    return cls(table, structure, stakes, deck=deck)


def play_to_completion(game):
    steps = 0
    while not game.is_hand_complete and steps < 200:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete
    return steps


# ---------------------------------------------------------------------------
# setup / dealing
# ---------------------------------------------------------------------------

def test_deals_two_down_one_up_on_third_street():
    table, ids = make_table(3)
    game = seeded(SevenCardStud, table, seed=1)
    game.start_hand()
    assert all(len(cards) == 3 for cards in game.hole_cards.values())
    assert all(len(cards) == 1 for cards in game.up_cards.values())


def test_razz_bring_in_posted_by_highest_up_card():
    table, ids = make_table(3)
    game = seeded(Razz, table, seed=1)
    game.start_hand()
    # Just confirm the hand proceeds without error; exact bring-in
    # correctness is covered directly in test_evaluation_exposed.py and
    # test_betting_blinds.py's determine_bring_in tests.
    assert game.street is StudStreet.THIRD


def test_start_hand_requires_at_least_two_active_players():
    table, ids = make_table(1)
    game = seeded(SevenCardStud, table, seed=1)
    with pytest.raises(GameError):
        game.start_hand()


def test_start_hand_can_only_be_called_once():
    table, ids = make_table(3)
    game = seeded(SevenCardStud, table, seed=1)
    game.start_hand()
    with pytest.raises(GameError):
        game.start_hand()


def test_legal_actions_before_start_hand_raises():
    table, ids = make_table(3)
    game = seeded(SevenCardStud, table, seed=1)
    with pytest.raises(GameError):
        game.legal_actions("p0")


def test_apply_action_before_start_hand_raises():
    table, ids = make_table(3)
    game = seeded(SevenCardStud, table, seed=1)
    with pytest.raises(GameError):
        game.apply_action("p0", ActionType.CHECK)


def test_apply_action_after_hand_complete_raises():
    table, ids = make_table(3, stack=1000)
    game = seeded(SevenCardStud, table, seed=5)
    game.start_hand()
    play_to_completion(game)
    with pytest.raises(GameError):
        game.apply_action(ids[0], ActionType.CHECK)


def test_settle_before_hand_complete_raises():
    table, ids = make_table(3)
    game = seeded(SevenCardStud, table, seed=1)
    game.start_hand()
    with pytest.raises(GameError):
        game.settle()


def test_start_hand_creates_own_securely_shuffled_deck_if_none_provided():
    table, ids = make_table(3)
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes)  # no deck passed
    game.start_hand()
    dealt = [c for cards in game.hole_cards.values() for c in cards]
    assert len(dealt) == len(set(dealt))


def test_action_log_records_actions():
    table, ids = make_table(3, stack=1000)
    game = seeded(SevenCardStud, table, seed=5)
    game.start_hand()
    play_to_completion(game)
    assert len(game.action_log) > 0


# ---------------------------------------------------------------------------
# full hand flow
# ---------------------------------------------------------------------------

def test_seven_card_stud_full_hand_deals_seven_cards_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(SevenCardStud, table, seed=5)
    game.start_hand()
    play_to_completion(game)
    assert all(len(cards) == 7 for cards in game.hole_cards.values())
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_five_betting_rounds_occur_across_a_full_hand():
    table, ids = make_table(3, stack=1000)
    game = seeded(SevenCardStud, table, seed=5)
    game.start_hand()
    play_to_completion(game)
    streets_seen = {sa.street for sa in game.action_log}
    assert streets_seen == {
        StudStreet.THIRD,
        StudStreet.FOURTH,
        StudStreet.FIFTH,
        StudStreet.SIXTH,
        StudStreet.SEVENTH,
    }


def test_seventh_street_deals_face_down_with_no_new_up_card():
    table, ids = make_table(3, stack=1000)
    game = seeded(SevenCardStud, table, seed=5)
    game.start_hand()
    play_to_completion(game)
    for pid in ids:
        assert len(game.hole_cards[pid]) == 7
        assert len(game.up_cards[pid]) == 4  # 3rd, 4th, 5th, 6th street only


def test_razz_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(Razz, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_stud_hi_lo_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(StudHiLo, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_stud_hi_lo_can_produce_a_split_pot():
    found = False
    for seed in range(1, 40):
        table, ids = make_table(3, stack=1000)
        game = seeded(StudHiLo, table, seed=seed)
        game.start_hand()
        play_to_completion(game)
        for po in game.outcome.pot_outcomes:
            if len(po.winners) > 1:
                found = True
                assert po.pot.amount == sum(po.payouts.values())
        if found:
            break
    assert found, "expected at least one split pot within the sampled seeds"


def test_uncontested_pot_when_all_but_one_fold():
    table, ids = make_table(3, stack=1000)
    game = seeded(SevenCardStud, table, seed=1)
    game.start_hand()
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    assert game.is_hand_complete
    assert len(game.outcome.pot_outcomes[0].winners) == 1


def test_all_in_runs_remaining_streets_automatically():
    table = Table(table_id="t1", max_seats=8)
    table.sit_down("short", "short", 20)
    table.sit_down("big", "big", 1000)
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    deck = Deck()
    deck.shuffle(seed=2)
    game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes, deck=deck)
    game.start_hand()

    steps = 0
    while not game.is_hand_complete and steps < 20:
        pid = game.current_player
        legal = game.legal_actions(pid)
        if legal.can_raise:
            game.apply_action(pid, ActionType.RAISE, legal.raise_max)
        else:
            action = ActionType.CHECK if legal.can_check else ActionType.CALL
            game.apply_action(pid, action)
        steps += 1

    assert game.is_hand_complete
    assert all(len(cards) == 7 for cards in game.hole_cards.values())


# ---------------------------------------------------------------------------
# heads-up (no raise cap)
# ---------------------------------------------------------------------------

def test_heads_up_hand_completes():
    table, ids = make_table(2, stack=1000)
    game = seeded(SevenCardStud, table, seed=3)
    game.start_hand()
    play_to_completion(game)
    assert game.outcome is not None
