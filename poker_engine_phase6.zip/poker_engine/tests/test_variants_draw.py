import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import FiveCardDraw, GameError, TripleDraw


def make_table(n_players=3, stack=1000):
    table = Table(table_id="t1", max_seats=6)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, stack)
    return table, ids


def seeded(cls, table, seed, structure=BettingStructure.NO_LIMIT, blind_level=None):
    deck = Deck()
    deck.shuffle(seed=seed)
    blind_level = blind_level or BlindLevel(small_blind=10, big_blind=20)
    return cls(table, structure, blind_level, deck=deck)


def bet_to_draw_phase(game):
    while not game.awaiting_draw and not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)


def play_to_completion(game):
    steps = 0
    while not game.is_hand_complete and steps < 300:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, game.hole_cards[pid][:1])  # always discard exactly one
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete


# ---------------------------------------------------------------------------
# Five Card Draw
# ---------------------------------------------------------------------------

def test_deals_five_hole_cards():
    table, ids = make_table(3)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    assert all(len(cards) == 5 for cards in game.hole_cards.values())


def test_one_draw_round_total():
    game_cls = FiveCardDraw
    assert game_cls.NUM_DRAW_ROUNDS == 1


def test_legal_actions_before_start_hand_raises():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    with pytest.raises(GameError):
        game.legal_actions("p0")


def test_apply_action_before_start_hand_raises():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    with pytest.raises(GameError):
        game.apply_action("p0", ActionType.CHECK)


def test_apply_action_after_hand_complete_raises():
    table, ids = make_table(3, stack=1000)
    game = seeded(FiveCardDraw, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    with pytest.raises(GameError):
        game.apply_action(ids[0], ActionType.CHECK)


def test_start_hand_requires_at_least_two_active_players():
    table, ids = make_table(1)
    game = seeded(FiveCardDraw, table, seed=1)
    with pytest.raises(GameError):
        game.start_hand()


def test_start_hand_can_only_be_called_once():
    table, ids = make_table(3)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    with pytest.raises(GameError):
        game.start_hand()


def test_draw_phase_begins_after_preflop_betting():
    table, ids = make_table(3)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    assert game.awaiting_draw
    assert game.round_index == 0


def test_draw_replaces_discarded_cards_and_keeps_hand_size():
    table, ids = make_table(3)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    pid = game.current_player
    original = game.hole_cards[pid]
    discard = original[:3]
    game.draw(pid, discard)
    new_hand = game.hole_cards[pid]
    assert len(new_hand) == 5
    assert all(c not in new_hand for c in discard)
    kept = [c for c in original if c not in discard]
    assert all(c in new_hand for c in kept)


def test_stand_pat_discard_zero_cards():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    pid = game.current_player
    original = game.hole_cards[pid]
    game.draw(pid, [])
    assert game.hole_cards[pid] == original


def test_draw_rejects_too_many_cards():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    pid = game.current_player
    with pytest.raises(GameError):
        game.draw(pid, game.hole_cards[pid] + [game.hole_cards[pid][0]])  # 6 cards, > hand size


def test_draw_rejects_duplicate_cards_in_discard():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    pid = game.current_player
    card = game.hole_cards[pid][0]
    with pytest.raises(GameError):
        game.draw(pid, [card, card])


def test_draw_rejects_cards_not_in_hand():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    pid = game.current_player
    other_pid = [p for p in ids if p != pid][0]
    with pytest.raises(GameError):
        game.draw(pid, game.hole_cards[other_pid][:2])


def test_draw_from_a_player_not_in_the_queue_raises():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    pid = game.current_player
    game.draw(pid, [])  # first player draws, leaving the queue
    with pytest.raises(GameError):
        game.draw(pid, [])  # trying again should fail: no longer in queue


def test_action_log_records_actions():
    table, ids = make_table(3, stack=1000)
    game = seeded(FiveCardDraw, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    assert len(game.action_log) > 0


def test_settle_before_hand_complete_raises():
    table, ids = make_table(3)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    with pytest.raises(GameError):
        game.settle()


def test_cannot_draw_when_not_awaiting():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    pid = game.current_player
    with pytest.raises(GameError):
        game.draw(pid, [])


def test_legal_actions_blocked_during_draw():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    with pytest.raises(GameError):
        game.legal_actions(game.current_player)


def test_apply_action_blocked_during_draw():
    table, ids = make_table(2)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    bet_to_draw_phase(game)
    with pytest.raises(GameError):
        game.apply_action(game.current_player, ActionType.CHECK)


def test_five_card_draw_full_hand_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(FiveCardDraw, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_uncontested_pot_when_all_but_one_fold():
    table, ids = make_table(3, stack=1000)
    game = seeded(FiveCardDraw, table, seed=1)
    game.start_hand()
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    assert game.is_hand_complete
    assert len(game.outcome.pot_outcomes[0].winners) == 1


# ---------------------------------------------------------------------------
# 2-7 Triple Draw
# ---------------------------------------------------------------------------

def test_triple_draw_has_three_draw_rounds():
    assert TripleDraw.NUM_DRAW_ROUNDS == 3


def test_triple_draw_full_hand_goes_through_three_draws():
    table, ids = make_table(2, stack=1000)
    game = seeded(TripleDraw, table, seed=1)
    game.start_hand()
    play_to_completion(game)
    assert game.draws_completed == 3


def test_triple_draw_full_hand_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(TripleDraw, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_triple_draw_uses_deuce_to_seven_ranking():
    assert TripleDraw.EVALUATION_MODE == "deuce_to_seven"


def test_all_in_before_first_draw_still_completes_all_three_draw_rounds():
    table = Table(table_id="t2", max_seats=6)
    table.sit_down("short", "short", 50)
    table.sit_down("big", "big", 1000)
    game = seeded(TripleDraw, table, seed=1)
    game.start_hand()

    pid = game.current_player
    legal = game.legal_actions(pid)
    game.apply_action(pid, ActionType.RAISE, legal.raise_max)
    game.apply_action(game.current_player, ActionType.CALL)

    assert game.awaiting_draw
    assert not game.is_hand_complete

    draws_taken = 0
    while not game.is_hand_complete:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, [])
            draws_taken += 1
        else:
            break

    assert draws_taken == 6  # 3 rounds x 2 players, all-in players still draw
    assert game.is_hand_complete
    assert game.draws_completed == 3


def test_fixed_limit_uses_small_bet_on_first_half_of_rounds():
    table, ids = make_table(2, stack=2000)
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = seeded(TripleDraw, table, seed=1, structure=BettingStructure.FIXED_LIMIT, blind_level=blind_level)
    game.start_hand()
    assert game._min_bet_for_round() == 20  # round_index 0 (pre-draw): small_bet


def test_fixed_limit_uses_big_bet_on_second_half_of_rounds():
    table, ids = make_table(2, stack=2000)
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = seeded(TripleDraw, table, seed=1, structure=BettingStructure.FIXED_LIMIT, blind_level=blind_level)
    game.start_hand()
    game._round_index = 2  # simulate having completed 2 of 4 rounds
    assert game._min_bet_for_round() == 40


def test_full_no_limit_pot_limit_and_fixed_limit_complete():
    for structure in (BettingStructure.NO_LIMIT, BettingStructure.POT_LIMIT, BettingStructure.FIXED_LIMIT):
        table, ids = make_table(3, stack=2000)
        blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
        game = seeded(TripleDraw, table, seed=11, structure=structure, blind_level=blind_level)
        game.start_hand()
        play_to_completion(game)
        assert game.outcome is not None


def test_heavy_discarding_across_rounds_replenishes_deck_from_discard_pile():
    # 3 players discarding their entire hand every round: round 3 cannot be
    # covered by what's left in a single 52-card deck alone (this is a real
    # scenario a Triple Draw engine must handle, not a contrived one -- see
    # docs/architecture.md). The deck must reshuffle in earlier rounds'
    # discards rather than raising DeckExhaustedError.
    table, ids = make_table(3, stack=1000)
    deck = Deck()
    deck.shuffle(seed=1)
    game = TripleDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()

    while not game.is_hand_complete:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, game.hole_cards[pid])  # discard everything, every round
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)

    assert game.is_hand_complete
    assert game.outcome is not None


def test_heavy_discarding_never_produces_duplicate_cards():
    # General card-integrity sanity check under the same heavy-discard,
    # replenish-triggering conditions as the test above: no two players
    # (and no player's own hand) should ever end up holding the same card.
    table, ids = make_table(3, stack=1000)
    deck = Deck()
    deck.shuffle(seed=1)
    game = TripleDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
    game.start_hand()

    while not game.is_hand_complete:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, game.hole_cards[pid])
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        game.apply_action(pid, ActionType.CHECK if legal.can_check else ActionType.CALL)

    all_final_cards = [c for cards in game.hole_cards.values() for c in cards]
    assert len(all_final_cards) == len(set(all_final_cards))


# ---------------------------------------------------------------------------
# heads-up
# ---------------------------------------------------------------------------

def test_start_hand_creates_own_securely_shuffled_deck_if_none_provided():
    table, ids = make_table(3)
    game = FiveCardDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))  # no deck
    game.start_hand()
    dealt = [c for cards in game.hole_cards.values() for c in cards]
    assert len(dealt) == len(set(dealt))


def test_antes_are_collected_into_the_preflop_pot():
    table, ids = make_table(3, stack=1000)
    blind_level = BlindLevel(small_blind=10, big_blind=20, ante=5)
    game = seeded(FiveCardDraw, table, seed=1, blind_level=blind_level)
    game.start_hand()
    # 3 players x 5 ante = 15, plus blinds 10+20 = 30 -> pot starts at 45
    assert game._round.total_pot() == 45


def test_heads_up_hand_completes():
    table, ids = make_table(2, stack=1000)
    game = seeded(FiveCardDraw, table, seed=42)
    game.start_hand()
    play_to_completion(game)
    assert game.outcome is not None
