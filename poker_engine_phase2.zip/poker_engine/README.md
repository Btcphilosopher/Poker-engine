# Poker Engine

A production-grade, multi-variant poker engine core, built in phases. This
repository currently contains **Phase 1: Foundation** and **Phase 2: Betting
Engine** — the card/hand-evaluation core and the full betting state machine
that every later phase (dealer, variants, tournaments, AI, simulation, API)
will build on.

See [`docs/roadmap.md`](docs/roadmap.md) for the full 13-phase build plan and
current status, and [`docs/architecture.md`](docs/architecture.md) for design
notes — including two real bugs caught and fixed during Phase 2's own
test-writing, documented in detail because they're instructive.

## What's implemented

**Phase 1 — Foundation**
- **Cards** (`poker_engine.cards`) — immutable `Card`, `Rank`, `Suit`, with
  string parsing/formatting (`Card.from_str("Ah")`, `str(card)`).
- **Deck** (`poker_engine.deck`) — standard 52-card and short (6+) 36-card
  decks, multi-deck support, three shuffle strategies (secure/CSPRNG, seeded/
  deterministic, standard), deal, burn, reset.
- **Evaluation** (`poker_engine.evaluation`) — full 5-card hand evaluation
  (all 9 categories, complete tie-breaking), best-of-N (7-card hold'em/stud),
  Omaha-restricted evaluation (exactly 2 hole + 3 board), and Ace-to-5 low
  evaluation (Razz / Hi-Lo split, with configurable qualifier).

**Phase 2 — Betting Engine**
- **`BettingRound`** (`poker_engine.betting`) — the core street state
  machine: turn order, legal-action computation, correct minimum-raise
  tracking (including the "incomplete all-in raise doesn't reopen the
  action" rule), pot-limit sizing, fixed-limit exact sizing + raise cap,
  all-in handling.
- **Pots** — `compute_pots` builds main + side pots from contributions
  (handles any number of simultaneous all-ins at different stack depths);
  `distribute_pot` splits a pot evenly with the standard odd-chip rule.
- **Forced bets** — blinds, antes, bring-in, dead blinds, blind assignment
  (including heads-up), stud bring-in determination (low or high card).
- **Button** — dealer button rotation across seats, skipping empty ones.

184 tests total, 95%+ coverage (unit, edge-case, and property-based via
Hypothesis, plus a full multi-street integration test). See `tests/`.

## Quickstart

```bash
pip install -e ".[dev]"
pytest
```

```python
from poker_engine.cards import Card
from poker_engine.deck import Deck
from poker_engine.evaluation import evaluate_5, evaluate_best_of, evaluate_omaha
from poker_engine.betting import (
    PlayerBettingState, BettingRound, BettingStructure, ActionType,
    post_small_blind, post_big_blind, compute_pots, distribute_pot,
)

# Deal a hand
deck = Deck()
deck.shuffle(seed=42)  # deterministic, for reproducible tests/replays
hand = deck.deal(5)
print(evaluate_5(hand))  # e.g. "Pair [Kc Kd 9h 4s 2c]"

# Run a betting round
sb = PlayerBettingState("sb", stack=1000)
bb = PlayerBettingState("bb", stack=1000)
utg = PlayerBettingState("utg", stack=1000)
post_small_blind(sb, 10)
post_big_blind(bb, 20)

round1 = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
round1.apply("utg", ActionType.RAISE, 60)
round1.apply("sb", ActionType.FOLD)
round1.apply("bb", ActionType.CALL)
print(round1.is_betting_complete(), round1.street_pot())  # True 130

# Build pots (handles side pots automatically) and split them
pots = compute_pots([utg, sb, bb])
payouts = distribute_pot(pots[0], ["utg"], order_from_button=["sb", "bb", "utg"])
```

## Benchmark

```bash
python3 -m poker_engine.evaluation.benchmark
```

Current throughput (single-threaded, no lookup-table optimisation yet):
~100K hands/sec for `evaluate_5`, ~5K hands/sec for `evaluate_best_of` on
7 cards (brute-force over the 21 five-card combinations). A perfect-hash
lookup table is planned as a hardening pass — see the roadmap.

## Project layout

```
poker_engine/
    cards/        implemented — Card, Rank, Suit
    deck/         implemented — Deck
    evaluation/   implemented — evaluators + benchmark
    betting/      implemented — BettingRound, pots, blinds, button
    players/      scaffolded — Phase 2-3
    dealer/       scaffolded — Phase 3
    tables/       scaffolded — Phase 3, 9
    hands/        scaffolded — Phase 4-6
    variants/     scaffolded — Phase 4-6
    tournaments/  scaffolded — Phase 8
    ai/           scaffolded — Phase 10
    simulation/   scaffolded — Phase 10
    statistics/   scaffolded — Phase 11
    network/      scaffolded — Phase 12
    api/          scaffolded — Phase 12
tests/
```

Every scaffolded module has a docstring in its `__init__.py` naming which
phase will fill it in.
