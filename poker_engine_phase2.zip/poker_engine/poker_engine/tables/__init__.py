"""
tables — not yet implemented.

Phase 3, 9 — table/seat management, buy-ins, waiting lists, auto top-up.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
