"""
dealer — not yet implemented.

Phase 3 — shuffle/deal orchestration, burn cards, street progression, pot distribution, table balancing.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
