"""
poker_engine — a production-grade, multi-variant poker engine.

Phase 1 (Foundation) and Phase 2 (Betting Engine) are implemented.
See docs/roadmap.md for the full build plan and current status.
"""

from poker_engine.cards import Card, Rank, Suit
from poker_engine.deck import Deck, DeckExhaustedError
from poker_engine.evaluation import (
    HandCategory,
    HandResult,
    LowHandResult,
    evaluate_5,
    evaluate_best_of,
    evaluate_omaha,
    evaluate_low_5,
    evaluate_low_best_of,
    evaluate_omaha_low,
)
from poker_engine.betting import (
    Action,
    ActionType,
    BettingError,
    BettingRound,
    BettingStructure,
    BlindLevel,
    IllegalActionError,
    LegalActions,
    NotPlayersTurnError,
    PlayerBettingState,
    Pot,
    PotError,
    compute_pots,
    distribute_pot,
    ForcedBetError,
    assign_blinds,
    determine_bring_in,
    post_ante,
    post_big_blind,
    post_bring_in,
    post_dead_blind,
    post_small_blind,
    ButtonError,
    advance_button,
    next_occupied_seat,
    seats_from_button,
)

__version__ = "0.2.0"

__all__ = [
    "Card",
    "Rank",
    "Suit",
    "Deck",
    "DeckExhaustedError",
    "HandCategory",
    "HandResult",
    "LowHandResult",
    "evaluate_5",
    "evaluate_best_of",
    "evaluate_omaha",
    "evaluate_low_5",
    "evaluate_low_best_of",
    "evaluate_omaha_low",
    "Action",
    "ActionType",
    "BettingError",
    "BettingRound",
    "BettingStructure",
    "BlindLevel",
    "IllegalActionError",
    "LegalActions",
    "NotPlayersTurnError",
    "PlayerBettingState",
    "Pot",
    "PotError",
    "compute_pots",
    "distribute_pot",
    "ForcedBetError",
    "assign_blinds",
    "determine_bring_in",
    "post_ante",
    "post_big_blind",
    "post_bring_in",
    "post_dead_blind",
    "post_small_blind",
    "ButtonError",
    "advance_button",
    "next_occupied_seat",
    "seats_from_button",
]
