# Architecture — Phase 1 (Foundation)

## Design principles carried through from here on

- **Immutability where it's free.** `Card` is a frozen, slotted dataclass —
  hashable, safe to share across threads, cheap to compare. This matters
  later for the multi-threaded Monte Carlo engine (Phase 10), which will
  pass cards between worker threads without locking.
- **Rank values ARE poker values.** `Rank.ACE.value == 14`. Evaluation code
  never needs a translation table between "what the enum says" and "what the
  hand ranking needs" — that's a common source of off-by-one bugs in poker
  engines and it's designed out from the start.
- **Comparison keys, not comparison functions.** Both `HandResult` and
  `LowHandResult` reduce to a plain tuple (`sort_key` / `rank_key`) such that
  Python's built-in tuple comparison produces the correct poker ranking.
  This means `max()`, `sorted()`, `min()` and the `<`/`>` operators all just
  work, including across combinatorial search (`evaluate_best_of`).
- **Display values and comparison keys are kept separate.** `LowHandResult`
  had a real bug caught during Phase 1 testing: the internal comparison key
  for Ace-to-5 low hands (which must be shape-prefixed — see below) is *not*
  the same as the actual card ranks you'd want to show a user. The dataclass
  now carries both `values` (display) and `rank_key` (comparison) explicitly
  rather than overloading one field for both purposes.

## Hand evaluation algorithm

`evaluate_5` classifies a 5-card hand by:
1. Sorting ranks descending and counting duplicates (`Counter`).
2. Checking flush (all one suit) and straight (5 consecutive distinct ranks,
   with the wheel A-2-3-4-5 as a special case where the Ace plays low).
3. Mapping the rank-count "pattern" (e.g. `(4,1)`, `(3,2)`, `(2,2,1)`) plus
   the flush/straight flags to one of the 9 `HandCategory` values.
4. Building an ordered tiebreaker tuple specific to that category (e.g. for
   two pair: `(high_pair, low_pair, kicker)`), so any two hands of the same
   category compare correctly including full kicker resolution.

`evaluate_best_of` (7-card hold'em/stud) and `evaluate_omaha` (Omaha's
"exactly 2 hole + 3 board" restriction) are built on top of `evaluate_5` via
`itertools.combinations` — correct by construction, since they're just
"evaluate every legal 5-card hand and take the best." This is the right
starting point for correctness; see the roadmap for the planned lookup-table
optimisation once the full rule engine depends on this API and a stable
before/after benchmark is meaningful.

## Ace-to-5 low evaluation

This is the one place in Phase 1 where the "obvious" implementation is
actually wrong, and it's worth documenting why.

A tempting shortcut for low-hand comparison is: sort each hand's ace-low
values descending, then compare the two tuples lexicographically (lower
tuple wins). This is correct for *unpaired* hands, but breaks the moment a
pair is involved:

```
7-5-4-3-2 (no pair)  vs  6-6-4-3-2 (pair of sixes)
```

Naive lexicographic comparison checks the highest card first (7 vs 6) and
would call the paired 6-6-4-3-2 hand better — which is wrong. In real
Ace-to-5 low (used by Razz, and for resolving the low side of Hi-Lo split
pots when a qualifier is disabled), **hand shape dominates first**, exactly
like a standard high hand: five-distinct-ranks beats one-pair beats two-pair
beats trips beats full house beats quads, *regardless* of what the actual
ranks are. Only within the same shape do lower ranks win.

`_low_sort_key` builds a `(shape_rank, *ordered_ranks)` tuple that encodes
this correctly, and `LowHandResult.rank_key` is what all comparisons go
through. `LowHandResult.values` is a separate, plain-English field (actual
ace-low ranks, sorted descending) kept purely for display and hand-history
export.

## What's deliberately not here yet

- **Badugi evaluation** — structurally different (suit-uniqueness based
  rather than rank-counting) and belongs with the Draw-games phase where
  it'll be built alongside the game rules that actually use it.
- **2-7 (Deuce-to-Seven) lowball** — straights/flushes count *against* the
  hand and Ace plays high-only, the opposite of Ace-to-5. Deferred to the
  Triple Draw implementation.
- **Lookup-table hand evaluation** — the current combinatorial approach is
  correct and already fast enough for turn-based gameplay (~100K hands/sec
  for `evaluate_5`); a perfect-hash table is planned once the full rule
  engine exists and Monte Carlo simulation volume actually demands it.

---

# Phase 2 — Betting Engine

## Why BettingRound is street-scoped, not hand-scoped

`BettingRound` handles exactly one street. `PlayerBettingState` is the
object that persists across the whole hand — the dealer phase is expected
to build a fresh `BettingRound` per street, passing the *same*
`PlayerBettingState` instances through each one, calling
`start_new_street()` between them. This mirrors how the money actually
behaves: `street_contributed` is street-scoped (what you owe/have put in
*this round*), `total_contributed` is hand-scoped (what side-pot
computation needs). Trying to make one object handle all streets would
mean either resetting internal state mid-object (fragile) or duplicating
the street/hand distinction that already exists naturally in the two
contribution fields.

## The minimum-raise / incomplete-raise rule

This is the single trickiest rule in the whole betting engine, so it gets
its own section (also documented inline in `round.py`).

A raise must increase the current bet by at least the size of the previous
full bet or raise. A player going all-in for less than that is still
allowed — but it does NOT let players who already called the previous bet
level re-raise; they may only call the extra amount or fold. Meanwhile, a
player who *hasn't* acted yet at the current level keeps full options
(including raising) even after an incomplete raise, since they never used
up their chance to respond to a legitimate full bet.

The implementation tracks this with a single set, `_acted_since_full_raise`,
cleared only on a COMPLETE bet/raise:
- Any action (fold/check/call/bet/raise) adds the actor to the set.
- A COMPLETE bet/raise clears the set and starts it over with just the
  actor — reopening full options for everyone else.
- An INCOMPLETE (short all-in) raise does NOT clear the set — the raiser
  is added to it, but everyone already in the set stays restricted to
  call/fold when `legal_actions` is asked for their options next.

Getting this right mattered enough that three of the test file's scenarios
(`test_incomplete_raise_*`) exist purely to pin down each side of this
rule with a worked example, rather than trusting the general logic alone.

## Bugs caught while writing Phase 2's own tests

Two are worth recording because they're the kind of bug that looks
plausible until you write the test that specifically targets it:

1. **Short-stacked "raise" below the current bet.** The first version of
   `legal_actions` computed a raise range for *any* player with `stack > 0`
   facing a bet, without checking whether their stack could actually
   exceed the current bet. A player with less in their stack than the
   current bet (e.g. facing a bet of 100 with only 30 chips) was offered a
   legal "raise" to 30 — which is less than the current bet, i.e. not a
   raise at all, just a disguised short call. Fixed by requiring
   `max_reachable() > current_bet` before offering RAISE; see
   `test_very_short_stack_cannot_raise_only_call_all_in_or_fold`.

2. **Pot-limit sizing fallback could balloon to full stack.** The original
   pot-limit `bet_max`/`raise_max` computed the structural cap and the
   stack-based floor *independently*, then patched disagreements with a
   fallback that set both to the player's full stack. In a degenerate
   (but code-reachable) case — a pot-limit street with nothing at all in
   the pot yet — this let a player with a million-chip stack "open" for
   their entire stack, ignoring the pot-limit cap entirely. Fixed by
   deriving the minimum from the already-correctly-capped maximum
   (`bet_min = min(self.min_bet, bet_max)`) instead of computing both
   independently; see
   `test_pot_limit_with_truly_empty_pot_disallows_betting_rather_than_ballooning_to_full_stack`.

Both were caught by deliberately writing a test for the exact edge case
the logic needed to handle, not by generic fuzzing — a reminder that the
property-based tests (which caught neither of these) are a complement to
targeted edge-case tests, not a replacement for them.

## `is_betting_complete()` vs. "the hand should end"

`BettingRound.is_betting_complete()` answers a narrow, mechanical question:
has every live player matched the current bet and had a turn this street?
It deliberately does NOT check "does only one non-folded player remain" —
that's a hand-level decision (award the pot immediately, don't even ask
the survivor to act) that belongs to the dealer/orchestrator in Phase 3,
which has visibility across the whole hand rather than one street. Mixing
that concern into `BettingRound` would couple street-mechanics to
hand-lifecycle decisions that differ per variant (e.g. running it twice in
some cash-game "run it twice" rules). See
`tests/test_betting_integration.py::test_uncontested_pot_when_everyone_but_one_folds`
for a worked example of the distinction.

## Pot construction: why layering by contribution level works

`compute_pots` doesn't track *when* side pots formed during play — it
recomputes them from scratch at the end from each player's
`total_contributed` and `is_folded` status. This is simpler and less
bug-prone than trying to maintain pot state incrementally as all-ins
happen mid-hand: sort the distinct contribution levels, and each layer
between two consecutive levels is a pot of `layer_size * contributors`,
eligible to whoever in that layer didn't fold. Adjacent pots that happen to
share an identical eligible set get merged for display — this changes
nothing about payouts (whoever wins between the same set of players wins
the combined amount either way) but avoids showing a poker room three
identically-eligible "pots" when there's no practical difference between
them.
