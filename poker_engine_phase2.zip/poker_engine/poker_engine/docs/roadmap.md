# Roadmap

Status legend: ✅ done · 🔜 next · ⬜ not started

| Phase | Scope | Status |
|---|---|---|
| 1 | **Foundation** — cards, deck, hand evaluation (5-card, best-of-N, Omaha, Ace-to-5 low) | ✅ |
| 2 | **Betting engine** — blinds, antes, bring-in, pot manager with side pots, limit/pot-limit/no-limit raise rules, all-in handling | ✅ |
| 3 | Dealer + table management — shuffle/deal orchestration, street progression, pot distribution, table balancing | 🔜 |
| 4 | Texas Hold'em (NL / Limit / Pot-Limit) end-to-end — first fully playable variant | ⬜ |
| 5 | Other flop games — Omaha, Omaha Hi-Lo, Short Deck (6+), Pineapple, Crazy Pineapple, Irish | ⬜ |
| 6 | Stud games (7-Stud, Stud Hi-Lo, Razz) + Draw games (5-Card Draw, 2-7 Triple Draw, Badugi) | ⬜ |
| 7 | Mixed games — HORSE rotation, general mixed-game framework | ⬜ |
| 8 | Tournament engine — SNG, freezeout, rebuy, KO/PKO, satellite, MTT, blind/break schedules, prize calculation, table balancing/merging | ⬜ |
| 9 | Cash games — ring games, buy-ins, seat reservations, waiting lists, auto top-up, table limits | ⬜ |
| 10 | AI framework (rule-based styles, Monte Carlo AI, CFR/NN interfaces) + Monte Carlo simulation engine (equity, range vs range, multi-threaded) | ⬜ |
| 11 | Statistics engine (VPIP/PFR/3-bet/aggression/BB-100/ROI/...) + hand history export + replay engine | ⬜ |
| 12 | Networking layer + REST API + WebSocket architecture | ⬜ |
| 13 | Hardening — full-suite coverage push, Docker, CI/CD, complete developer/API docs | ⬜ |

## Phase 1 deliverables

- `poker_engine/cards/` — `Card`, `Rank`, `Suit`
- `poker_engine/deck/` — `Deck` (standard/short/multi-deck, 3 shuffle modes)
- `poker_engine/evaluation/` — `evaluate_5`, `evaluate_best_of`,
  `evaluate_omaha`, `evaluate_low_5`, `evaluate_low_best_of`,
  `evaluate_omaha_low`, plus a throughput benchmark script
- 79 tests (unit + edge-case + property-based), 97% coverage
- Full package scaffold for every module named in the original spec, each
  stub documenting which phase will implement it

## Phase 2 deliverables

- `poker_engine/betting/structures.py` — `BettingStructure` (NL/PL/FL),
  `BlindLevel`
- `poker_engine/betting/actions.py` — `ActionType`, `Action` (hand-history
  log entry)
- `poker_engine/betting/player_state.py` — `PlayerBettingState`
- `poker_engine/betting/pot.py` — `compute_pots` (main + side pots via
  contribution layering), `distribute_pot` (split-pot chip division with
  the standard odd-chip-to-first-winner-left-of-button rule)
- `poker_engine/betting/round.py` — `BettingRound`, the core street state
  machine: turn order, legal-action computation, minimum-raise tracking,
  the "incomplete all-in raise doesn't reopen action" rule, pot-limit
  sizing, fixed-limit exact-size + raise-cap enforcement
- `poker_engine/betting/blinds.py` — blind/ante/bring-in/dead-blind
  posting, blind assignment (incl. heads-up), stud bring-in determination
- `poker_engine/betting/button.py` — dealer button rotation across seats
  (skipping empty seats)
- 105 new tests (unit, edge-case, property-based via Hypothesis, and a
  full multi-street integration test), bringing the suite to 184 tests /
  95%+ overall coverage

Real bugs caught and fixed during Phase 2's own test-writing (see
architecture.md for details): a short-stacked player could incorrectly be
offered "raise" for less than the current bet; a pot-limit sizing fallback
could balloon the legal max bet to a player's entire stack in a degenerate
zero-pot edge case.

## Notes for the next session

- Phase 3 (dealer + table) is the natural next step: it consumes
  `BettingRound` + `PlayerBettingState` + `Deck` directly, and is where the
  "only one live player left -> end the hand immediately" rule (explicitly
  NOT handled by `BettingRound.is_betting_complete()` — see its docstring)
  needs to be implemented.
- The 7-card evaluator's lookup-table optimisation (see architecture.md) is
  still deferred, for the same reason as before: better to benchmark it
  against real gameplay load once Phase 4 exists.
- `poker_engine/betting/round.py`'s `BettingRound` is deliberately
  street-scoped (one instance per street) rather than whole-hand-scoped;
  the dealer phase is expected to construct a fresh one per street, call
  `player.start_new_street()` between them, and use `PlayerBettingState`
  as the persistent (whole-hand) object threaded through all of them —
  see `tests/test_betting_integration.py` for a worked example of this
  pattern across a full 3-player hand with a side pot.
