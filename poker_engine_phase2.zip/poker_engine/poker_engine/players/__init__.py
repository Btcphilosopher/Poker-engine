"""
players — not yet implemented.

Phase 2-3 — player/seat state, stacks, hole-card holding, action state machine.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
