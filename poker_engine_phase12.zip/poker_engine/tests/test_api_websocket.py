import pytest
from fastapi.testclient import TestClient

from poker_engine.network import create_app


@pytest.fixture
def client():
    app = create_app()
    return TestClient(app)


def _setup_table_and_hand(client, table_id="t1"):
    client.post("/tables", json={"table_id": table_id, "max_seats": 6, "min_buyin": 100, "max_buyin": 1000})
    client.post("/tables/" + table_id + "/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 500})
    client.post("/tables/" + table_id + "/join", json={"player_id": "bob", "display_name": "Bob", "buyin": 500})
    client.post(
        "/tables/" + table_id + "/hands",
        json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20},
    )


def _issue_token(client, player_id):
    return client.post("/auth/token", json={"player_id": player_id}).json()["token"]


def test_player_connection_receives_initial_state(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/play/alice") as ws:
        message = ws.receive_json()
        assert message["type"] == "hand_state"
        assert message["your_hole_cards"] is not None
        assert len(message["your_hole_cards"]) == 2


def test_spectator_connection_receives_initial_state_without_hole_cards(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/watch") as ws:
        message = ws.receive_json()
        assert message["type"] == "hand_state"
        assert message["your_hole_cards"] is None


def test_player_never_sees_another_players_hole_cards(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/play/alice") as ws_alice:
        alice_msg = ws_alice.receive_json()
        alice_cards = alice_msg["your_hole_cards"]

    with client.websocket_connect("/ws/tables/t1/play/bob") as ws_bob:
        bob_msg = ws_bob.receive_json()
        bob_cards = bob_msg["your_hole_cards"]

    # Different players' hole cards must never overlap.
    alice_set = {(c["rank"], c["suit"]) for c in alice_cards}
    bob_set = {(c["rank"], c["suit"]) for c in bob_cards}
    assert alice_set.isdisjoint(bob_set)


def test_action_via_rest_pushes_update_to_connected_player(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/play/alice") as ws_alice:
        ws_alice.receive_json()  # initial push

        state = client.get("/tables/t1/hands/current").json()
        acting = state["current_player"]
        token = _issue_token(client, acting)
        action = "check" if state["legal_actions"]["can_check"] else "call"
        client.post(
            "/tables/t1/hands/current/actions",
            json={"player_id": acting, "action_type": action},
            headers={"Authorization": f"Bearer {token}"},
        )

        update = ws_alice.receive_json()
        assert update["type"] == "hand_state"


def test_action_via_rest_pushes_update_to_spectator_without_hole_cards(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/watch") as ws_spectator:
        ws_spectator.receive_json()  # initial push

        state = client.get("/tables/t1/hands/current").json()
        acting = state["current_player"]
        token = _issue_token(client, acting)
        action = "check" if state["legal_actions"]["can_check"] else "call"
        client.post(
            "/tables/t1/hands/current/actions",
            json={"player_id": acting, "action_type": action},
            headers={"Authorization": f"Bearer {token}"},
        )

        update = ws_spectator.receive_json()
        assert update["your_hole_cards"] is None


def test_chat_broadcast_reaches_other_connections(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/play/alice") as ws_alice:
        ws_alice.receive_json()  # initial push
        with client.websocket_connect("/ws/tables/t1/watch") as ws_spectator:
            ws_spectator.receive_json()  # initial push

            ws_alice.send_json({"type": "chat", "text": "hello!"})

            chat_msg = ws_spectator.receive_json()
            assert chat_msg == {"type": "chat", "sender_id": "alice", "text": "hello!"}


def test_reconnect_replaces_old_player_connection(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/play/alice") as ws_old:
        ws_old.receive_json()  # initial push

        with client.websocket_connect("/ws/tables/t1/play/alice") as ws_new:
            ws_new.receive_json()  # initial push for the reconnect

            state = client.get("/tables/t1/hands/current").json()
            acting = state["current_player"]
            token = _issue_token(client, acting)
            action = "check" if state["legal_actions"]["can_check"] else "call"
            client.post(
                "/tables/t1/hands/current/actions",
                json={"player_id": acting, "action_type": action},
                headers={"Authorization": f"Bearer {token}"},
            )

            # Only the NEW connection should get the live update.
            update = ws_new.receive_json()
            assert update["type"] == "hand_state"


def test_full_hand_over_websocket_and_rest_together(client):
    _setup_table_and_hand(client)
    with client.websocket_connect("/ws/tables/t1/play/alice") as ws_alice, client.websocket_connect(
        "/ws/tables/t1/play/bob"
    ) as ws_bob:
        ws_alice.receive_json()
        ws_bob.receive_json()

        state = client.get("/tables/t1/hands/current").json()
        steps = 0
        while not state["is_complete"] and steps < 100:
            acting = state["current_player"]
            token = _issue_token(client, acting)
            action = "check" if state["legal_actions"]["can_check"] else "call"
            r = client.post(
                "/tables/t1/hands/current/actions",
                json={"player_id": acting, "action_type": action},
                headers={"Authorization": f"Bearer {token}"},
            )
            state = r.json()
            ws_alice.receive_json()
            ws_bob.receive_json()
            steps += 1

        assert state["is_complete"] is True
