import pytest

from poker_engine.network.connection_manager import ConnectionManager


class FakeWebSocket:
    """Minimal stand-in for a FastAPI WebSocket, recording what was sent/accepted."""

    def __init__(self):
        self.accepted = False
        self.sent: list = []

    async def accept(self):
        self.accepted = True

    async def send_json(self, message):
        self.sent.append(message)


@pytest.mark.asyncio
async def test_connect_player_accepts_and_registers():
    cm = ConnectionManager()
    ws = FakeWebSocket()
    await cm.connect_player("t1", "alice", ws)
    assert ws.accepted
    assert cm.is_player_connected("t1", "alice")


@pytest.mark.asyncio
async def test_connect_spectator_accepts_and_registers():
    cm = ConnectionManager()
    ws = FakeWebSocket()
    await cm.connect_spectator("t1", ws)
    assert ws.accepted
    assert cm.spectator_count("t1") == 1


@pytest.mark.asyncio
async def test_reconnect_replaces_old_connection():
    cm = ConnectionManager()
    ws_old = FakeWebSocket()
    ws_new = FakeWebSocket()
    await cm.connect_player("t1", "alice", ws_old)
    await cm.connect_player("t1", "alice", ws_new)
    assert cm.is_player_connected("t1", "alice")

    await cm.send_private("t1", "alice", {"hello": "world"})
    assert ws_new.sent == [{"hello": "world"}]
    assert ws_old.sent == []  # old connection no longer receives anything


@pytest.mark.asyncio
async def test_disconnect_player_removes_registration():
    cm = ConnectionManager()
    ws = FakeWebSocket()
    await cm.connect_player("t1", "alice", ws)
    cm.disconnect_player("t1", "alice")
    assert not cm.is_player_connected("t1", "alice")


@pytest.mark.asyncio
async def test_disconnect_spectator_removes_registration():
    cm = ConnectionManager()
    ws = FakeWebSocket()
    await cm.connect_spectator("t1", ws)
    cm.disconnect_spectator("t1", ws)
    assert cm.spectator_count("t1") == 0


def test_disconnect_unknown_player_is_a_no_op():
    cm = ConnectionManager()
    cm.disconnect_player("t1", "ghost")  # should not raise


def test_disconnect_unknown_spectator_is_a_no_op():
    cm = ConnectionManager()
    ws = FakeWebSocket()
    cm.disconnect_spectator("t1", ws)  # should not raise


def test_is_player_connected_false_when_never_connected():
    cm = ConnectionManager()
    assert not cm.is_player_connected("t1", "alice")


def test_spectator_count_zero_when_none_connected():
    cm = ConnectionManager()
    assert cm.spectator_count("t1") == 0


@pytest.mark.asyncio
async def test_send_private_to_unconnected_player_is_a_no_op():
    cm = ConnectionManager()
    await cm.send_private("t1", "ghost", {"x": 1})  # should not raise


@pytest.mark.asyncio
async def test_broadcast_public_reaches_players_and_spectators():
    cm = ConnectionManager()
    ws_player = FakeWebSocket()
    ws_spectator = FakeWebSocket()
    await cm.connect_player("t1", "alice", ws_player)
    await cm.connect_spectator("t1", ws_spectator)

    await cm.broadcast_public("t1", {"event": "update"})
    assert ws_player.sent == [{"event": "update"}]
    assert ws_spectator.sent == [{"event": "update"}]


@pytest.mark.asyncio
async def test_broadcast_public_can_exclude_a_specific_player():
    cm = ConnectionManager()
    ws_alice = FakeWebSocket()
    ws_bob = FakeWebSocket()
    await cm.connect_player("t1", "alice", ws_alice)
    await cm.connect_player("t1", "bob", ws_bob)

    await cm.broadcast_public("t1", {"event": "update"}, exclude_player="alice")
    assert ws_alice.sent == []
    assert ws_bob.sent == [{"event": "update"}]


@pytest.mark.asyncio
async def test_broadcast_to_spectators_never_reaches_players():
    cm = ConnectionManager()
    ws_player = FakeWebSocket()
    ws_spectator = FakeWebSocket()
    await cm.connect_player("t1", "alice", ws_player)
    await cm.connect_spectator("t1", ws_spectator)

    await cm.broadcast_to_spectators("t1", {"event": "public-only"})
    assert ws_player.sent == []
    assert ws_spectator.sent == [{"event": "public-only"}]


@pytest.mark.asyncio
async def test_broadcast_chat_wraps_message_correctly():
    cm = ConnectionManager()
    ws_spectator = FakeWebSocket()
    await cm.connect_spectator("t1", ws_spectator)

    await cm.broadcast_chat("t1", "alice", "hello table")
    assert ws_spectator.sent == [{"type": "chat", "sender_id": "alice", "text": "hello table"}]


@pytest.mark.asyncio
async def test_connections_are_isolated_per_table():
    cm = ConnectionManager()
    ws_t1 = FakeWebSocket()
    ws_t2 = FakeWebSocket()
    await cm.connect_spectator("t1", ws_t1)
    await cm.connect_spectator("t2", ws_t2)

    await cm.broadcast_to_spectators("t1", {"only": "t1"})
    assert ws_t1.sent == [{"only": "t1"}]
    assert ws_t2.sent == []
