import pytest

from poker_engine.network.auth import AuthError, TokenAuth


def test_issue_returns_a_token():
    auth = TokenAuth()
    token = auth.issue("alice")
    assert isinstance(token, str)
    assert len(token) > 10


def test_validate_returns_the_correct_player_id():
    auth = TokenAuth()
    token = auth.issue("alice")
    assert auth.validate(token) == "alice"


def test_validate_unknown_token_raises():
    auth = TokenAuth()
    with pytest.raises(AuthError):
        auth.validate("not-a-real-token")


def test_revoke_invalidates_the_token():
    auth = TokenAuth()
    token = auth.issue("alice")
    auth.revoke(token)
    with pytest.raises(AuthError):
        auth.validate(token)


def test_revoke_unknown_token_is_a_no_op():
    auth = TokenAuth()
    auth.revoke("never-issued")  # should not raise


def test_issuing_multiple_tokens_for_same_player_both_work():
    auth = TokenAuth()
    token1 = auth.issue("alice")
    token2 = auth.issue("alice")
    assert token1 != token2
    assert auth.validate(token1) == "alice"
    assert auth.validate(token2) == "alice"


def test_tokens_are_unique_across_different_players():
    auth = TokenAuth()
    token_a = auth.issue("alice")
    token_b = auth.issue("bob")
    assert token_a != token_b
    assert auth.validate(token_a) == "alice"
    assert auth.validate(token_b) == "bob"
