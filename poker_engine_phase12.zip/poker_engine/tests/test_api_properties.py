"""
Property-based tests for the REST API: randomized multi-player sessions
driven entirely through HTTP requests must always conserve chips exactly,
regardless of variant, structure, or player count -- the same standard
every earlier phase's property tests held the engine to, now proven at
the HTTP boundary rather than purely in-process.
"""

import random

from fastapi.testclient import TestClient
from hypothesis import given, settings, strategies as st

from poker_engine.network import create_app

VARIANTS = ["TexasHoldem", "Omaha"]
STRUCTURES = ["no_limit", "pot_limit"]


def _issue_token(client, player_id):
    return client.post("/auth/token", json={"player_id": player_id}).json()["token"]


def _play_random_hand_via_rest(seed, n_players, variant, structure):
    rng = random.Random(seed)
    app = create_app()
    client = TestClient(app)

    client.post("/tables", json={"table_id": "t1", "max_seats": 9, "min_buyin": 100, "max_buyin": 2000})
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        client.post("/tables/t1/join", json={"player_id": pid, "display_name": pid, "buyin": 1000})

    r = client.post(
        "/tables/t1/hands", json={"variant": variant, "structure": structure, "small_blind": 10, "big_blind": 20}
    )
    assert r.status_code == 200
    state = r.json()

    steps = 0
    while not state["is_complete"] and steps < 300:
        acting = state["current_player"]
        legal = state["legal_actions"]
        options = []
        if legal["can_check"]:
            options.append("check")
        if legal["can_call"]:
            options.append("call")
        if legal["can_fold"]:
            options.append("fold")
        if legal["can_raise"]:
            options.append("raise")
        weights = {"check": 5, "call": 5, "fold": 2, "raise": 2}
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]

        token = _issue_token(client, acting)
        body = {"player_id": acting, "action_type": chosen}
        if chosen == "raise":
            body["amount"] = rng.randint(legal["raise_min"], legal["raise_max"])

        r = client.post(
            "/tables/t1/hands/current/actions", json=body, headers={"Authorization": f"Bearer {token}"}
        )
        assert r.status_code == 200
        state = r.json()
        steps += 1

    assert state["is_complete"]
    assert steps < 300
    return client, state


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=6),
    variant=st.sampled_from(VARIANTS),
    structure=st.sampled_from(STRUCTURES),
)
@settings(max_examples=40, deadline=None)
def test_random_rest_driven_hands_conserve_chips(seed, n_players, variant, structure):
    client, state = _play_random_hand_via_rest(seed, n_players, variant, structure)

    table_state = client.get("/tables/t1").json()
    assert table_state["occupied_seats"] == n_players

    hand_history = client.get(f"/hands/{state['hand_id']}").json()
    assert sum(hand_history["starting_stacks"].values()) == sum(hand_history["final_stacks"].values())
    assert sum(hand_history["winners"].values()) == state["pot_size"]


@given(seed=st.integers(min_value=0, max_value=2**31 - 1))
@settings(max_examples=15, deadline=None)
def test_random_heads_up_hands_via_rest(seed):
    client, state = _play_random_hand_via_rest(seed, 2, "TexasHoldem", "no_limit")
    assert state["is_complete"]
