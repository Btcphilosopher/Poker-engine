"""
Full API integration test: a realistic multi-hand session driven entirely
through the REST API and observed live through WebSocket connections --
the same "prove the pieces work together" pattern every earlier phase's
capstone integration test used, now at the network boundary instead of
purely in-process.
"""

from fastapi.testclient import TestClient

from poker_engine.network import create_app


def _issue_token(client, player_id):
    return client.post("/auth/token", json={"player_id": player_id}).json()["token"]


def test_multi_hand_session_via_rest_conserves_chips_and_records_stats():
    app = create_app()
    client = TestClient(app)

    client.post("/tables", json={"table_id": "t1", "max_seats": 4, "min_buyin": 100, "max_buyin": 2000})
    for pid in ["alice", "bob", "carol"]:
        client.post("/tables/t1/join", json={"player_id": pid, "display_name": pid, "buyin": 500})

    hands_played = 0
    for _ in range(5):
        r = client.post(
            "/tables/t1/hands",
            json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20},
        )
        assert r.status_code == 200
        state = r.json()
        steps = 0
        while not state["is_complete"] and steps < 100:
            acting = state["current_player"]
            token = _issue_token(client, acting)
            action = "check" if state["legal_actions"]["can_check"] else "call"
            r = client.post(
                "/tables/t1/hands/current/actions",
                json={"player_id": acting, "action_type": action},
                headers={"Authorization": f"Bearer {token}"},
            )
            state = r.json()
            steps += 1
        assert state["is_complete"]
        hands_played += 1

    assert hands_played == 5

    table_state = client.get("/tables/t1").json()
    assert table_state["occupied_seats"] == 3

    for pid in ["alice", "bob", "carol"]:
        stats = client.get(f"/players/{pid}/stats").json()
        assert stats["hands_tracked"] == 5

    leaderboard = client.get("/leaderboard", params={"limit": 10}).json()
    assert len(leaderboard["entries"]) == 3


def test_tournament_lifecycle_via_rest():
    app = create_app()
    client = TestClient(app)

    client.post(
        "/tournaments",
        json={"tournament_id": "sng1", "buy_in": 50, "starting_stack": 1000, "small_blind": 10, "big_blind": 20},
    )
    for pid in ["a", "b", "c"]:
        r = client.post("/tournaments/sng1/register", json={"player_id": pid, "display_name": pid})
        assert r.status_code == 200

    r = client.post("/tournaments/sng1/start")
    assert r.status_code == 200
    assert r.json()["is_started"] is True
    assert r.json()["prize_pool"] == 150


def test_cash_game_lifecycle_via_rest_with_waiting_list():
    app = create_app()
    client = TestClient(app)

    client.post("/cash-games", json={"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000, "max_seats": 2})
    client.post("/cash-games/ring1/join", json={"player_id": "a", "display_name": "a", "buyin": 500})
    client.post("/cash-games/ring1/join", json={"player_id": "b", "display_name": "b", "buyin": 500})
    r = client.post("/cash-games/ring1/join", json={"player_id": "c", "display_name": "c", "buyin": 500})
    assert r.json()["waiting_list_length"] == 1

    r = client.post("/cash-games/ring1/leave/a")
    assert r.json()["occupied_seats"] == 2  # c auto-seated from the waiting list
    assert r.json()["waiting_list_length"] == 0


def test_spectator_watches_a_hand_end_to_end_via_websocket():
    app = create_app()
    client = TestClient(app)

    client.post("/tables", json={"table_id": "t1", "max_seats": 4, "min_buyin": 100, "max_buyin": 1000})
    client.post("/tables/t1/join", json={"player_id": "alice", "display_name": "alice", "buyin": 500})
    client.post("/tables/t1/join", json={"player_id": "bob", "display_name": "bob", "buyin": 500})

    with client.websocket_connect("/ws/tables/t1/watch") as ws:
        r = client.post(
            "/tables/t1/hands",
            json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20},
        )
        initial = ws.receive_json()
        assert initial["your_hole_cards"] is None

        state = r.json()
        message_count = 0
        while not state["is_complete"] and message_count < 100:
            acting = state["current_player"]
            token = _issue_token(client, acting)
            action = "check" if state["legal_actions"]["can_check"] else "call"
            r = client.post(
                "/tables/t1/hands/current/actions",
                json={"player_id": acting, "action_type": action},
                headers={"Authorization": f"Bearer {token}"},
            )
            state = r.json()
            update = ws.receive_json()
            assert update["your_hole_cards"] is None  # spectator NEVER sees hole cards
            message_count += 1

        assert state["is_complete"]
