import pytest
from fastapi.testclient import TestClient

from poker_engine.network import create_app


@pytest.fixture
def client():
    app = create_app()
    return TestClient(app)


def _create_table_with_two_players(client, table_id="t1"):
    client.post("/tables", json={"table_id": table_id, "max_seats": 6, "min_buyin": 100, "max_buyin": 1000})
    client.post("/tables/" + table_id + "/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 500})
    client.post("/tables/" + table_id + "/join", json={"player_id": "bob", "display_name": "Bob", "buyin": 500})


def _issue_token(client, player_id):
    r = client.post("/auth/token", json={"player_id": player_id})
    return r.json()["token"]


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------

def test_issue_token_returns_matching_player_id(client):
    r = client.post("/auth/token", json={"player_id": "alice"})
    assert r.status_code == 200
    assert r.json()["player_id"] == "alice"


# ---------------------------------------------------------------------------
# tables
# ---------------------------------------------------------------------------

def test_create_table(client):
    r = client.post("/tables", json={"table_id": "t1", "max_seats": 6})
    assert r.status_code == 200
    assert r.json()["table_id"] == "t1"
    assert r.json()["occupied_seats"] == 0


def test_create_duplicate_table_returns_400(client):
    client.post("/tables", json={"table_id": "t1"})
    r = client.post("/tables", json={"table_id": "t1"})
    assert r.status_code == 400


def test_get_table_not_found_returns_404(client):
    r = client.get("/tables/ghost")
    assert r.status_code == 404


def test_join_table(client):
    client.post("/tables", json={"table_id": "t1", "min_buyin": 100, "max_buyin": 1000})
    r = client.post("/tables/t1/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 500})
    assert r.status_code == 200
    assert "alice" in r.json()["player_ids"]


def test_join_table_below_min_buyin_returns_400(client):
    client.post("/tables", json={"table_id": "t1", "min_buyin": 100, "max_buyin": 1000})
    r = client.post("/tables/t1/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 50})
    assert r.status_code == 400


def test_join_unknown_table_returns_404(client):
    r = client.post("/tables/ghost/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 500})
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# hands
# ---------------------------------------------------------------------------

def test_start_hand(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    assert r.status_code == 200
    body = r.json()
    assert body["is_complete"] is False
    assert body["current_player"] is not None
    assert body["pot_size"] == 30


def test_start_hand_unknown_variant_returns_400(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "NotAVariant", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    assert r.status_code == 400


def test_start_hand_twice_returns_400(client):
    _create_table_with_two_players(client)
    client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    assert r.status_code == 400


def test_get_current_hand_no_viewer_hides_hole_cards(client):
    _create_table_with_two_players(client)
    client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    r = client.get("/tables/t1/hands/current")
    assert r.status_code == 200
    assert r.json()["your_hole_cards"] is None


def test_get_current_hand_with_viewer_shows_only_their_own_cards(client):
    _create_table_with_two_players(client)
    client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    r = client.get("/tables/t1/hands/current", params={"viewer": "alice"})
    assert r.status_code == 200
    assert r.json()["your_hole_cards"] is not None
    assert len(r.json()["your_hole_cards"]) == 2


def test_get_current_hand_unknown_table_returns_404(client):
    r = client.get("/tables/ghost/hands/current")
    assert r.status_code == 404


def test_apply_action_without_token_returns_401(client):
    _create_table_with_two_players(client)
    client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    r = client.post("/tables/t1/hands/current/actions", json={"player_id": "bob", "action_type": "call"})
    assert r.status_code == 401


def test_apply_action_with_wrong_players_token_returns_403(client):
    _create_table_with_two_players(client)
    client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    alice_token = _issue_token(client, "alice")
    r = client.post(
        "/tables/t1/hands/current/actions",
        json={"player_id": "bob", "action_type": "call"},
        headers={"Authorization": f"Bearer {alice_token}"},
    )
    assert r.status_code == 403


def test_apply_action_with_correct_token_succeeds(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    acting_player = r.json()["current_player"]
    token = _issue_token(client, acting_player)
    r2 = client.post(
        "/tables/t1/hands/current/actions",
        json={"player_id": acting_player, "action_type": "call"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r2.status_code == 200
    assert r2.json()["current_player"] != acting_player


def test_apply_action_unknown_action_type_returns_400(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    acting_player = r.json()["current_player"]
    token = _issue_token(client, acting_player)
    r2 = client.post(
        "/tables/t1/hands/current/actions",
        json={"player_id": acting_player, "action_type": "not_a_real_action"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r2.status_code == 400


def test_full_hand_via_rest_conserves_chips(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    steps = 0
    while not r.json()["is_complete"] and steps < 100:
        state = r.json()
        acting = state["current_player"]
        token = _issue_token(client, acting)
        action = "check" if state["legal_actions"]["can_check"] else "call"
        r = client.post(
            "/tables/t1/hands/current/actions",
            json={"player_id": acting, "action_type": action},
            headers={"Authorization": f"Bearer {token}"},
        )
        steps += 1
    assert r.json()["is_complete"] is True

    table_state = client.get("/tables/t1").json()
    assert table_state["occupied_seats"] == 2


# ---------------------------------------------------------------------------
# hand history
# ---------------------------------------------------------------------------

def test_get_hand_history_after_completion(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    while not r.json()["is_complete"]:
        state = r.json()
        acting = state["current_player"]
        token = _issue_token(client, acting)
        action = "check" if state["legal_actions"]["can_check"] else "call"
        r = client.post(
            "/tables/t1/hands/current/actions",
            json={"player_id": acting, "action_type": action},
            headers={"Authorization": f"Bearer {token}"},
        )
    hand_id = r.json()["hand_id"]
    history_response = client.get(f"/hands/{hand_id}")
    assert history_response.status_code == 200
    assert history_response.json()["hand_id"] == hand_id
    assert len(history_response.json()["board"]) == 5


def test_get_hand_history_unknown_id_returns_404(client):
    r = client.get("/hands/ghost")
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# stats + leaderboard
# ---------------------------------------------------------------------------

def test_get_player_stats_before_any_hands(client):
    r = client.get("/players/never-played/stats")
    assert r.status_code == 200
    assert r.json()["hands_tracked"] == 0


def test_get_player_stats_after_a_hand(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    while not r.json()["is_complete"]:
        state = r.json()
        acting = state["current_player"]
        token = _issue_token(client, acting)
        action = "check" if state["legal_actions"]["can_check"] else "call"
        r = client.post(
            "/tables/t1/hands/current/actions",
            json={"player_id": acting, "action_type": action},
            headers={"Authorization": f"Bearer {token}"},
        )
    stats = client.get("/players/alice/stats").json()
    assert stats["hands_tracked"] == 1


def test_leaderboard_empty_initially(client):
    r = client.get("/leaderboard")
    assert r.status_code == 200
    assert r.json()["entries"] == []


def test_leaderboard_respects_limit(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    while not r.json()["is_complete"]:
        state = r.json()
        acting = state["current_player"]
        token = _issue_token(client, acting)
        action = "check" if state["legal_actions"]["can_check"] else "call"
        r = client.post(
            "/tables/t1/hands/current/actions",
            json={"player_id": acting, "action_type": action},
            headers={"Authorization": f"Bearer {token}"},
        )
    r = client.get("/leaderboard", params={"limit": 1})
    assert len(r.json()["entries"]) == 1


# ---------------------------------------------------------------------------
# tournaments
# ---------------------------------------------------------------------------

def test_create_tournament(client):
    r = client.post(
        "/tournaments",
        json={"tournament_id": "main", "buy_in": 100, "starting_stack": 1000, "small_blind": 10, "big_blind": 20},
    )
    assert r.status_code == 200
    assert r.json()["is_started"] is False


def test_register_for_tournament(client):
    client.post(
        "/tournaments",
        json={"tournament_id": "main", "buy_in": 100, "starting_stack": 1000, "small_blind": 10, "big_blind": 20},
    )
    r = client.post("/tournaments/main/register", json={"player_id": "alice", "display_name": "Alice"})
    assert r.status_code == 200
    assert "alice" in r.json()["registered_player_ids"]


def test_register_for_unknown_tournament_returns_404(client):
    r = client.post("/tournaments/ghost/register", json={"player_id": "alice", "display_name": "Alice"})
    assert r.status_code == 404


def test_start_tournament_with_enough_players(client):
    client.post(
        "/tournaments",
        json={"tournament_id": "main", "buy_in": 100, "starting_stack": 1000, "small_blind": 10, "big_blind": 20},
    )
    client.post("/tournaments/main/register", json={"player_id": "alice", "display_name": "Alice"})
    client.post("/tournaments/main/register", json={"player_id": "bob", "display_name": "Bob"})
    r = client.post("/tournaments/main/start")
    assert r.status_code == 200
    assert r.json()["is_started"] is True
    assert r.json()["num_tables"] == 1


def test_start_tournament_without_enough_players_returns_400(client):
    client.post(
        "/tournaments",
        json={"tournament_id": "main", "buy_in": 100, "starting_stack": 1000, "small_blind": 10, "big_blind": 20},
    )
    client.post("/tournaments/main/register", json={"player_id": "alice", "display_name": "Alice"})
    r = client.post("/tournaments/main/start")
    assert r.status_code == 400


def test_get_tournament_status(client):
    client.post(
        "/tournaments",
        json={"tournament_id": "main", "buy_in": 100, "starting_stack": 1000, "small_blind": 10, "big_blind": 20},
    )
    r = client.get("/tournaments/main")
    assert r.status_code == 200
    assert r.json()["prize_pool"] == 0


# ---------------------------------------------------------------------------
# cash games
# ---------------------------------------------------------------------------

def test_create_cash_game(client):
    r = client.post("/cash-games", json={"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000})
    assert r.status_code == 200
    assert r.json()["occupied_seats"] == 0


def test_join_cash_game(client):
    client.post("/cash-games", json={"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000})
    r = client.post("/cash-games/ring1/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 500})
    assert r.status_code == 200
    assert r.json()["occupied_seats"] == 1


def test_leave_cash_game(client):
    client.post("/cash-games", json={"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000})
    client.post("/cash-games/ring1/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 500})
    r = client.post("/cash-games/ring1/leave/alice")
    assert r.status_code == 200
    assert r.json()["occupied_seats"] == 0


def test_join_cash_game_waitlisted_when_full(client):
    client.post("/cash-games", json={"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000, "max_seats": 2})
    client.post("/cash-games/ring1/join", json={"player_id": "a", "display_name": "a", "buyin": 500})
    client.post("/cash-games/ring1/join", json={"player_id": "b", "display_name": "b", "buyin": 500})
    r = client.post("/cash-games/ring1/join", json={"player_id": "c", "display_name": "c", "buyin": 500})
    assert r.status_code == 200
    assert r.json()["waiting_list_length"] == 1


# ---------------------------------------------------------------------------
# additional error-path coverage
# ---------------------------------------------------------------------------

def test_auth_header_without_bearer_prefix_still_works(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    acting = r.json()["current_player"]
    token = _issue_token(client, acting)
    r2 = client.post(
        "/tables/t1/hands/current/actions",
        json={"player_id": acting, "action_type": "call"},
        headers={"Authorization": token},  # no "Bearer " prefix
    )
    assert r2.status_code == 200


def test_apply_action_with_invalid_token_returns_401(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    acting = r.json()["current_player"]
    r2 = client.post(
        "/tables/t1/hands/current/actions",
        json={"player_id": acting, "action_type": "call"},
        headers={"Authorization": "Bearer not-a-real-token"},
    )
    assert r2.status_code == 401


def test_start_hand_unknown_structure_returns_400(client):
    _create_table_with_two_players(client)
    r = client.post(
        "/tables/t1/hands",
        json={"variant": "TexasHoldem", "structure": "not_a_structure", "small_blind": 10, "big_blind": 20},
    )
    assert r.status_code == 400


def test_start_hand_unknown_table_returns_400(client):
    r = client.post(
        "/tables/ghost/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    assert r.status_code == 400


def test_start_hand_too_few_players_returns_400(client):
    client.post("/tables", json={"table_id": "t1", "min_buyin": 100, "max_buyin": 1000})
    client.post("/tables/t1/join", json={"player_id": "alice", "display_name": "Alice", "buyin": 500})
    r = client.post(
        "/tables/t1/hands", json={"variant": "TexasHoldem", "structure": "no_limit", "small_blind": 10, "big_blind": 20}
    )
    assert r.status_code == 400


def test_apply_action_unknown_table_returns_404(client):
    token = _issue_token(client, "alice")
    r = client.post(
        "/tables/ghost/hands/current/actions",
        json={"player_id": "alice", "action_type": "call"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 404


def test_register_tournament_with_duplicate_player_returns_400(client):
    client.post(
        "/tournaments",
        json={"tournament_id": "main", "buy_in": 100, "starting_stack": 1000, "small_blind": 10, "big_blind": 20},
    )
    client.post("/tournaments/main/register", json={"player_id": "alice", "display_name": "Alice"})
    r = client.post("/tournaments/main/register", json={"player_id": "alice", "display_name": "Alice"})
    assert r.status_code == 400


def test_start_tournament_unknown_id_returns_404(client):
    r = client.post("/tournaments/ghost/start")
    assert r.status_code == 404


def test_create_duplicate_tournament_returns_400(client):
    payload = {"tournament_id": "main", "buy_in": 100, "starting_stack": 1000, "small_blind": 10, "big_blind": 20}
    client.post("/tournaments", json=payload)
    r = client.post("/tournaments", json=payload)
    assert r.status_code == 400


def test_get_unknown_tournament_returns_404(client):
    r = client.get("/tournaments/ghost")
    assert r.status_code == 404


def test_create_duplicate_cash_game_returns_400(client):
    payload = {"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000}
    client.post("/cash-games", json=payload)
    r = client.post("/cash-games", json=payload)
    assert r.status_code == 400


def test_join_unknown_cash_game_returns_404(client):
    r = client.post("/cash-games/ghost/join", json={"player_id": "a", "display_name": "a", "buyin": 500})
    assert r.status_code == 404


def test_join_cash_game_below_min_buyin_returns_400(client):
    client.post("/cash-games", json={"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000})
    r = client.post("/cash-games/ring1/join", json={"player_id": "a", "display_name": "a", "buyin": 10})
    assert r.status_code == 400


def test_leave_unknown_cash_game_returns_404(client):
    r = client.post("/cash-games/ghost/leave/alice")
    assert r.status_code == 404


def test_leave_cash_game_unseated_player_returns_400(client):
    client.post("/cash-games", json={"cash_game_id": "ring1", "min_buyin": 100, "max_buyin": 1000})
    r = client.post("/cash-games/ring1/leave/never-joined")
    assert r.status_code == 400


def test_get_unknown_cash_game_returns_404(client):
    r = client.get("/cash-games/ghost")
    assert r.status_code == 404
