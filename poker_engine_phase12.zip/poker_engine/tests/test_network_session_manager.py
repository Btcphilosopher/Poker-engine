import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.cash_games.cash_game import CashGameConfig
from poker_engine.network.session_manager import SessionManager, SessionManagerError
from poker_engine.tournaments.blind_schedule import BlindSchedule
from poker_engine.tournaments.tournament import TournamentConfig
from poker_engine.variants import TexasHoldem


def make_sm_with_table(n=2, stack=500):
    sm = SessionManager()
    table = sm.create_table("t1", max_seats=6, min_buyin=100, max_buyin=1000)
    for i in range(n):
        table.sit_down(f"p{i}", f"p{i}", stack)
    return sm, table


def play_to_completion(sm, table_id):
    game = sm.get_active_hand(table_id)
    while not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game = sm.apply_action(table_id, pid, action)
    return game


# ---------------------------------------------------------------------------
# tables
# ---------------------------------------------------------------------------

def test_create_table_and_get_table():
    sm = SessionManager()
    table = sm.create_table("t1", max_seats=6)
    assert sm.get_table("t1") is table


def test_create_duplicate_table_raises():
    sm = SessionManager()
    sm.create_table("t1")
    with pytest.raises(SessionManagerError):
        sm.create_table("t1")


def test_get_unknown_table_raises():
    sm = SessionManager()
    with pytest.raises(SessionManagerError):
        sm.get_table("ghost")


# ---------------------------------------------------------------------------
# hands
# ---------------------------------------------------------------------------

def test_start_hand_returns_unique_hand_ids():
    sm, table = make_sm_with_table()
    hand_id1 = sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
    play_to_completion(sm, "t1")
    hand_id2 = sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
    assert hand_id1 != hand_id2


def test_start_hand_at_unknown_table_raises():
    sm = SessionManager()
    with pytest.raises(SessionManagerError):
        sm.start_hand("ghost", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))


def test_start_hand_while_one_in_progress_raises():
    sm, table = make_sm_with_table()
    sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
    with pytest.raises(SessionManagerError):
        sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))


def test_start_hand_after_previous_completes_succeeds():
    sm, table = make_sm_with_table()
    sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
    play_to_completion(sm, "t1")
    # should not raise
    sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))


def test_apply_action_at_unknown_table_raises():
    sm = SessionManager()
    with pytest.raises(SessionManagerError):
        sm.apply_action("ghost", "p0", ActionType.CHECK)


def test_get_active_hand_before_any_hand_raises():
    sm, table = make_sm_with_table()
    with pytest.raises(SessionManagerError):
        sm.get_active_hand("t1")


def test_get_current_hand_id_before_any_hand_raises():
    sm, table = make_sm_with_table()
    with pytest.raises(SessionManagerError):
        sm.get_current_hand_id("t1")


def test_get_current_hand_id_persists_after_completion():
    sm, table = make_sm_with_table()
    hand_id = sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
    play_to_completion(sm, "t1")
    assert sm.get_current_hand_id("t1") == hand_id


def test_hand_completion_records_history_and_stats():
    sm, table = make_sm_with_table(n=2)
    hand_id = sm.start_hand("t1", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
    play_to_completion(sm, "t1")

    history = sm.get_hand_history(hand_id)
    assert history.hand_id == hand_id

    for pid in ["p0", "p1"]:
        stats = sm.get_player_stats(pid)
        assert stats.hands_tracked == 1


def test_get_hand_history_unknown_id_raises():
    sm = SessionManager()
    with pytest.raises(SessionManagerError):
        sm.get_hand_history("ghost")


def test_get_player_stats_creates_empty_tracker_for_unknown_player():
    sm = SessionManager()
    stats = sm.get_player_stats("never-played")
    assert stats.hands_tracked == 0


def test_immediate_all_in_from_blinds_still_records_a_hand():
    # Regression-style check: Phase 8's stuck-hand fix means start_hand()
    # can complete a hand immediately if blinds exceed both stacks.
    # SessionManager must still finalize and record it correctly.
    sm = SessionManager()
    table = sm.create_table("t2", max_seats=4)
    table.sit_down("a", "a", 1)
    table.sit_down("b", "b", 1)
    hand_id = sm.start_hand("t2", TexasHoldem, BettingStructure.NO_LIMIT, BlindLevel(small_blind=100, big_blind=200))
    game = sm.get_active_hand("t2")
    assert game.is_hand_complete
    history = sm.get_hand_history(hand_id)
    assert history.hand_id == hand_id


# ---------------------------------------------------------------------------
# tournaments
# ---------------------------------------------------------------------------

def test_create_and_get_tournament():
    sm = SessionManager()
    schedule = BlindSchedule.standard_flop_schedule(10, num_levels=5)
    config = TournamentConfig(buy_in=100, starting_stack=1000, blind_schedule=schedule)
    tournament = sm.create_tournament("main-event", config)
    assert sm.get_tournament("main-event") is tournament


def test_create_duplicate_tournament_raises():
    sm = SessionManager()
    schedule = BlindSchedule.standard_flop_schedule(10, num_levels=5)
    config = TournamentConfig(buy_in=100, starting_stack=1000, blind_schedule=schedule)
    sm.create_tournament("t1", config)
    with pytest.raises(SessionManagerError):
        sm.create_tournament("t1", config)


def test_get_unknown_tournament_raises():
    sm = SessionManager()
    with pytest.raises(SessionManagerError):
        sm.get_tournament("ghost")


# ---------------------------------------------------------------------------
# cash games
# ---------------------------------------------------------------------------

def test_create_and_get_cash_game():
    sm = SessionManager()
    config = CashGameConfig(min_buyin=100, max_buyin=1000)
    cash_game = sm.create_cash_game("main-ring", config)
    assert sm.get_cash_game("main-ring") is cash_game


def test_create_duplicate_cash_game_raises():
    sm = SessionManager()
    config = CashGameConfig(min_buyin=100, max_buyin=1000)
    sm.create_cash_game("c1", config)
    with pytest.raises(SessionManagerError):
        sm.create_cash_game("c1", config)


def test_get_unknown_cash_game_raises():
    sm = SessionManager()
    with pytest.raises(SessionManagerError):
        sm.get_cash_game("ghost")
