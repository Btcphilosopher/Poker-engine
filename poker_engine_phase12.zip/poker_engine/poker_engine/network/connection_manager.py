"""
ConnectionManager -- tracks active WebSocket connections per table.

Two kinds of connection: PLAYERS (seated, get their own private info
like hole cards, exactly one live connection per player per table) and
SPECTATORS (any number, public info only -- never sent another player's
hole cards). Reconnect is just "a new connection for a player_id that
already has one" -- the old connection is dropped in favor of the new
one rather than treated as an error, since a dropped WebSocket (a
flaky network, a phone switching from wifi to cellular) is the normal
case a real client needs to recover from, not an exceptional one.
"""

from __future__ import annotations

from typing import Dict, Optional, Set

from fastapi import WebSocket


class ConnectionManagerError(Exception):
    pass


class ConnectionManager:
    def __init__(self) -> None:
        self._player_connections: Dict[str, Dict[str, WebSocket]] = {}  # table_id -> {player_id: ws}
        self._spectator_connections: Dict[str, Set[WebSocket]] = {}  # table_id -> {ws, ...}

    async def connect_player(self, table_id: str, player_id: str, websocket: WebSocket) -> None:
        await websocket.accept()
        table_conns = self._player_connections.setdefault(table_id, {})
        # Reconnect: a new connection for a player_id that already has one
        # simply replaces it -- the old socket is presumed stale/dead.
        table_conns[player_id] = websocket

    async def connect_spectator(self, table_id: str, websocket: WebSocket) -> None:
        await websocket.accept()
        self._spectator_connections.setdefault(table_id, set()).add(websocket)

    def disconnect_player(self, table_id: str, player_id: str) -> None:
        table_conns = self._player_connections.get(table_id)
        if table_conns is not None:
            table_conns.pop(player_id, None)
            if not table_conns:
                self._player_connections.pop(table_id, None)

    def disconnect_spectator(self, table_id: str, websocket: WebSocket) -> None:
        spectators = self._spectator_connections.get(table_id)
        if spectators is not None:
            spectators.discard(websocket)
            if not spectators:
                self._spectator_connections.pop(table_id, None)

    def is_player_connected(self, table_id: str, player_id: str) -> bool:
        return player_id in self._player_connections.get(table_id, {})

    def spectator_count(self, table_id: str) -> int:
        return len(self._spectator_connections.get(table_id, set()))

    async def send_private(self, table_id: str, player_id: str, message: dict) -> None:
        ws = self._player_connections.get(table_id, {}).get(player_id)
        if ws is not None:
            await ws.send_json(message)

    async def broadcast_public(self, table_id: str, message: dict, *, exclude_player: Optional[str] = None) -> None:
        for player_id, ws in list(self._player_connections.get(table_id, {}).items()):
            if player_id == exclude_player:
                continue
            await ws.send_json(message)
        for ws in list(self._spectator_connections.get(table_id, set())):
            await ws.send_json(message)

    async def broadcast_to_spectators(self, table_id: str, message: dict) -> None:
        for ws in list(self._spectator_connections.get(table_id, set())):
            await ws.send_json(message)

    async def broadcast_chat(self, table_id: str, sender_id: str, text: str) -> None:
        await self.broadcast_public(table_id, {"type": "chat", "sender_id": sender_id, "text": text})
