"""
WebSocket endpoints: live state push for players and spectators watching
a table, plus chat.

Two connection routes per table:
  /ws/tables/{table_id}/play/{player_id}   -- a seated player's live feed
  /ws/tables/{table_id}/watch               -- a spectator's live feed

On connect, each client immediately receives the CURRENT hand state (if
any hand is in progress) so a client doesn't have to wait for the next
action to see where things stand -- important for the exact case this
layer is built around: reconnect. A player whose connection drops and
reconnects gets caught back up immediately rather than staring at stale
state until something happens to trigger a fresh push.

Actual actions still go through the REST API (POST .../actions) -- the
WebSocket here is push-only (state changes, chat), not a second channel
for submitting actions. Keeping "how do I ACT" (REST, one clear path,
easy to test synchronously) and "how do I FIND OUT something changed"
(WebSocket, inherently async/live) separate avoids the two channels ever
disagreeing about which one is authoritative.
"""

from __future__ import annotations

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from poker_engine.api.serializers import build_hand_state_response
from poker_engine.network.connection_manager import ConnectionManager
from poker_engine.network.session_manager import SessionManager, SessionManagerError


def create_websocket_router(session_manager: SessionManager, connections: ConnectionManager) -> APIRouter:
    router = APIRouter()

    async def _push_current_state(table_id: str, websocket: WebSocket, viewer_player_id: str = None) -> None:
        try:
            game = session_manager.get_active_hand(table_id)
            hand_id = session_manager.get_current_hand_id(table_id)
        except SessionManagerError:
            return
        response = build_hand_state_response(game, hand_id, table_id, viewer_player_id=viewer_player_id)
        await websocket.send_json({"type": "hand_state", **response.model_dump()})

    @router.websocket("/ws/tables/{table_id}/play/{player_id}")
    async def play(websocket: WebSocket, table_id: str, player_id: str) -> None:
        await connections.connect_player(table_id, player_id, websocket)
        await _push_current_state(table_id, websocket, viewer_player_id=player_id)
        try:
            while True:
                message = await websocket.receive_json()
                if message.get("type") == "chat":
                    await connections.broadcast_chat(table_id, player_id, message.get("text", ""))
        except WebSocketDisconnect:
            connections.disconnect_player(table_id, player_id)

    @router.websocket("/ws/tables/{table_id}/watch")
    async def watch(websocket: WebSocket, table_id: str) -> None:
        await connections.connect_spectator(table_id, websocket)
        await _push_current_state(table_id, websocket, viewer_player_id=None)
        try:
            while True:
                await websocket.receive_json()  # spectators can send chat too; no action rights
        except WebSocketDisconnect:
            connections.disconnect_spectator(table_id, websocket)

    return router


async def broadcast_hand_state(
    session_manager: SessionManager, connections: ConnectionManager, table_id: str
) -> None:
    """
    Push the current hand state to every connection watching `table_id` --
    each seated player gets their OWN private view (their hole cards
    included), spectators get the public view only. Call this after every
    action applied through the REST API so live viewers stay in sync
    without polling. Each connection receives exactly one message.
    """
    try:
        game = session_manager.get_active_hand(table_id)
        hand_id = session_manager.get_current_hand_id(table_id)
    except SessionManagerError:
        return

    for player_id in list(getattr(game, "hole_cards", {}).keys()):
        if connections.is_player_connected(table_id, player_id):
            private_response = build_hand_state_response(game, hand_id, table_id, viewer_player_id=player_id)
            await connections.send_private(table_id, player_id, {"type": "hand_state", **private_response.model_dump()})

    if connections.spectator_count(table_id) > 0:
        public_response = build_hand_state_response(game, hand_id, table_id, viewer_player_id=None)
        await connections.broadcast_to_spectators(table_id, {"type": "hand_state", **public_response.model_dump()})
