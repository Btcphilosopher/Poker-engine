"""
create_app() -- builds one FastAPI application combining the REST API
(poker_engine.api.rest_api) and the WebSocket endpoints
(poker_engine.network.websocket_api), all sharing one SessionManager,
TokenAuth, and ConnectionManager instance.

A factory function, not a module-level app instance, so tests (and any
real deployment running more than one independent game server in the
same process) get a fresh, isolated set of shared state per call rather
than accidentally sharing tables/tournaments/tokens across unrelated
app instances -- the same reason Table/Tournament/CashGame are all
constructed explicitly rather than reached for as global singletons
throughout this engine.
"""

from __future__ import annotations

from fastapi import FastAPI

import poker_engine
from poker_engine.network.auth import TokenAuth
from poker_engine.network.connection_manager import ConnectionManager
from poker_engine.network.session_manager import SessionManager
from poker_engine.network.websocket_api import create_websocket_router


def create_app() -> FastAPI:
    # Deferred import: api.rest_api itself imports from poker_engine.network
    # (auth/connection_manager/session_manager), so importing it at module
    # level here risks a circular-import race depending on which package a
    # caller imports first. By the time create_app() is actually CALLED,
    # both packages have always finished loading.
    from poker_engine.api.rest_api import create_rest_router

    app = FastAPI(title="Poker Engine API", version=poker_engine.__version__)

    session_manager = SessionManager()
    auth = TokenAuth()
    connections = ConnectionManager()

    app.state.session_manager = session_manager
    app.state.auth = auth
    app.state.connections = connections

    app.include_router(create_rest_router(session_manager, auth, connections))
    app.include_router(create_websocket_router(session_manager, connections))

    return app
