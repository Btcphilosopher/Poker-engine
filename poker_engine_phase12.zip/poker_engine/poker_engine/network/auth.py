"""
Minimal bearer-token authentication.

Issues a random token for a player_id and validates it on incoming
requests -- enough to give the REST/WebSocket layers a genuine, testable
"who is this request actually from" mechanism, rather than trusting a
client-supplied player_id with no verification at all. NOT a claim of
production-grade security: no expiry, no refresh tokens, no hashing at
rest, no rate limiting. A real deployment would delegate to a proper
auth provider (OAuth, a managed identity service); building one is
outside the scope of a poker rules engine, the same boundary Tournament
and CashGame already draw around real-money handling.
"""

from __future__ import annotations

import secrets
from typing import Dict


class AuthError(Exception):
    pass


class TokenAuth:
    def __init__(self) -> None:
        self._tokens: Dict[str, str] = {}  # token -> player_id

    def issue(self, player_id: str) -> str:
        token = secrets.token_urlsafe(24)
        self._tokens[token] = player_id
        return token

    def validate(self, token: str) -> str:
        player_id = self._tokens.get(token)
        if player_id is None:
            raise AuthError("Invalid or unrecognized token")
        return player_id

    def revoke(self, token: str) -> None:
        self._tokens.pop(token, None)
