"""
SessionManager -- the in-memory registry tying together everything the
REST/WebSocket layers need to look up across requests: tables, the hand
currently in progress at each one, tournaments, cash games, completed
hand histories, and running player statistics.

Every earlier phase's orchestrator (Tournament, CashGame) is driven
in-process by a caller holding a direct reference to the object. A
server can't do that -- each HTTP request or WebSocket message is a
fresh call with only IDs to go on. SessionManager is the ONE new thing
this phase adds below that: a place to look up "the Table with this ID"
or "the Game currently being played at this table" by string, and the
glue that automatically records a HandHistory and updates
PlayerStatsTracker the moment a hand completes, so GET /hands/{id} and
GET /players/{id}/stats have something to serve without every caller
needing to remember to record it themselves.

This is an in-memory, single-process registry -- exactly the same scope
boundary CashGame and Tournament already draw (abstract chips, no
real-money handling; see their own docstrings). A production deployment
backing this with persistent storage or multiple server processes is
explicitly out of scope for a poker RULES engine.
"""

from __future__ import annotations

from typing import Dict, Optional, Type

from poker_engine.betting.actions import ActionType
from poker_engine.betting.structures import BettingStructure
from poker_engine.cash_games.cash_game import CashGame, CashGameConfig
from poker_engine.statistics.hand_history import HandHistory, HandHistoryBuilder, begin_hand_history
from poker_engine.statistics.stats import PlayerStatsTracker
from poker_engine.tables.table import Table
from poker_engine.tournaments.tournament import Tournament, TournamentConfig
from poker_engine.variants.base_game import BaseGame


class SessionManagerError(Exception):
    pass


class SessionManager:
    def __init__(self) -> None:
        self.tables: Dict[str, Table] = {}
        self.active_hands: Dict[str, BaseGame] = {}
        self.hand_histories: Dict[str, HandHistory] = {}
        self.tournaments: Dict[str, Tournament] = {}
        self.cash_games: Dict[str, CashGame] = {}
        self.player_stats: Dict[str, PlayerStatsTracker] = {}

        self._hand_builders: Dict[str, HandHistoryBuilder] = {}
        self._hand_starting_stacks: Dict[str, Dict[str, int]] = {}
        self._pending_hand_ids: Dict[str, str] = {}
        self._current_hand_id: Dict[str, str] = {}  # table_id -> most recent hand_id, kept even after completion
        self._hand_counter = 0

    # -- tables ----------------------------------------------------------

    def create_table(
        self, table_id: str, max_seats: int = 9, min_buyin: Optional[int] = None, max_buyin: Optional[int] = None
    ) -> Table:
        if table_id in self.tables:
            raise SessionManagerError(f"Table {table_id!r} already exists")
        table = Table(table_id=table_id, max_seats=max_seats, min_buyin=min_buyin, max_buyin=max_buyin)
        self.tables[table_id] = table
        return table

    def get_table(self, table_id: str) -> Table:
        table = self.tables.get(table_id)
        if table is None:
            raise SessionManagerError(f"No such table: {table_id!r}")
        return table

    # -- hands ----------------------------------------------------------

    def start_hand(self, table_id: str, variant_cls: Type[BaseGame], structure: BettingStructure, stakes) -> str:
        table = self.get_table(table_id)
        existing = self.active_hands.get(table_id)
        if existing is not None and not existing.is_hand_complete:
            raise SessionManagerError(f"A hand is already in progress at table {table_id!r}")

        starting_stacks = {p.player_id: p.stack for p in table.occupied_seats()}
        game = variant_cls(table, structure, stakes)
        game.start_hand()

        self._hand_counter += 1
        hand_id = f"{table_id}-hand-{self._hand_counter}"

        self.active_hands[table_id] = game
        self._hand_builders[table_id] = begin_hand_history(game)
        self._hand_starting_stacks[table_id] = starting_stacks
        self._pending_hand_ids[table_id] = hand_id
        self._current_hand_id[table_id] = hand_id

        if game.is_hand_complete:
            # Can happen immediately (e.g. everyone but one folds pre-flop
            # is impossible before any action, but an all-in-from-blinds
            # runout completes without ever needing apply_action -- see
            # Phase 8's stuck-hand fix).
            self._finalize_hand(table_id)

        return hand_id

    def get_current_hand_id(self, table_id: str) -> str:
        """The most recent hand_id for this table, whether that hand is still in progress or already complete."""
        hand_id = self._current_hand_id.get(table_id)
        if hand_id is None:
            raise SessionManagerError(f"No hand has ever been played at table {table_id!r}")
        return hand_id

    def get_active_hand(self, table_id: str) -> BaseGame:
        game = self.active_hands.get(table_id)
        if game is None:
            raise SessionManagerError(f"No hand in progress at table {table_id!r}")
        return game

    def apply_action(self, table_id: str, player_id: str, action_type: ActionType, amount: int = 0) -> BaseGame:
        game = self.get_active_hand(table_id)
        game.apply_action(player_id, action_type, amount)
        if game.is_hand_complete:
            self._finalize_hand(table_id)
        return game

    def _finalize_hand(self, table_id: str) -> None:
        game = self.active_hands[table_id]
        game.settle()
        builder = self._hand_builders.pop(table_id)
        starting_stacks = self._hand_starting_stacks.pop(table_id)
        hand_id = self._pending_hand_ids.pop(table_id)

        history = builder.finalize(hand_id, starting_stacks)
        self.hand_histories[hand_id] = history
        for player_id in history.starting_stacks:
            self.player_stats.setdefault(player_id, PlayerStatsTracker()).record_hand(history, player_id)

    def get_hand_history(self, hand_id: str) -> HandHistory:
        history = self.hand_histories.get(hand_id)
        if history is None:
            raise SessionManagerError(f"No such hand: {hand_id!r}")
        return history

    def get_player_stats(self, player_id: str) -> PlayerStatsTracker:
        return self.player_stats.setdefault(player_id, PlayerStatsTracker())

    # -- tournaments ----------------------------------------------------------

    def create_tournament(self, tournament_id: str, config: TournamentConfig) -> Tournament:
        if tournament_id in self.tournaments:
            raise SessionManagerError(f"Tournament {tournament_id!r} already exists")
        tournament = Tournament(config)
        self.tournaments[tournament_id] = tournament
        return tournament

    def get_tournament(self, tournament_id: str) -> Tournament:
        tournament = self.tournaments.get(tournament_id)
        if tournament is None:
            raise SessionManagerError(f"No such tournament: {tournament_id!r}")
        return tournament

    # -- cash games ----------------------------------------------------------

    def create_cash_game(self, cash_game_id: str, config: CashGameConfig) -> CashGame:
        if cash_game_id in self.cash_games:
            raise SessionManagerError(f"Cash game {cash_game_id!r} already exists")
        cash_game = CashGame(config, table_id=cash_game_id)
        self.cash_games[cash_game_id] = cash_game
        return cash_game

    def get_cash_game(self, cash_game_id: str) -> CashGame:
        cash_game = self.cash_games.get(cash_game_id)
        if cash_game is None:
            raise SessionManagerError(f"No such cash game: {cash_game_id!r}")
        return cash_game
