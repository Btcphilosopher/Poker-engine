"""
REST API: table/hand/tournament/cash-game lifecycle, actions, hand
history, statistics, leaderboards.

create_rest_router(session_manager, auth) returns a self-contained
APIRouter closing over the shared SessionManager/TokenAuth instances
passed to it -- explicit construction rather than a global singleton or
FastAPI's dependency-injection machinery, matching the rest of this
engine's "no hidden state, construct what you need explicitly" pattern
(Tournament and CashGame both take their config directly rather than
reading it from somewhere implicit).
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Header, HTTPException

from poker_engine.api.schemas import (
    ActionRequest,
    CashGameCreateRequest,
    CashGameJoinRequest,
    CashGameResponse,
    CreateTableRequest,
    HandHistoryResponse,
    HandStateResponse,
    JoinTableRequest,
    LeaderboardEntry,
    LeaderboardResponse,
    PlayerStatsResponse,
    StartHandRequest,
    TableResponse,
    TokenRequest,
    TokenResponse,
    TournamentCreateRequest,
    TournamentRegisterRequest,
    TournamentResponse,
)
from poker_engine.api.serializers import build_hand_history_response, build_hand_state_response
from poker_engine.api.variant_registry import VariantRegistryError, resolve_structure, resolve_variant
from poker_engine.betting.actions import ActionType
from poker_engine.betting.structures import BlindLevel
from poker_engine.cash_games.cash_game import CashGameConfig, CashGameError
from poker_engine.network.auth import AuthError, TokenAuth
from poker_engine.network.connection_manager import ConnectionManager
from poker_engine.network.session_manager import SessionManager, SessionManagerError
from poker_engine.tables.table import TableError
from poker_engine.tournaments.tournament import TournamentConfig, TournamentError
from poker_engine.variants.base_game import GameError

# broadcast_hand_state is imported lazily (inside the route handlers that
# use it, not here) specifically to break a circular import:
# network.websocket_api needs api.serializers for its own initial-state
# push on connect, and this module needs network.websocket_api's
# broadcast function -- a genuine mutual dependency between the two
# halves of the live-update pipeline, resolved the standard way.


def _require_player(auth: TokenAuth, token: Optional[str], claimed_player_id: str) -> None:
    """Validate that the bearer token actually belongs to the player_id the request claims to act as."""
    if token is None:
        raise HTTPException(status_code=401, detail="Missing bearer token")
    try:
        actual_player_id = auth.validate(token)
    except AuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    if actual_player_id != claimed_player_id:
        raise HTTPException(status_code=403, detail="Token does not authorize acting as this player")


def create_rest_router(session_manager: SessionManager, auth: TokenAuth, connections: ConnectionManager) -> APIRouter:
    router = APIRouter()

    # -- auth ----------------------------------------------------------

    @router.post("/auth/token", response_model=TokenResponse)
    def issue_token(request: TokenRequest) -> TokenResponse:
        token = auth.issue(request.player_id)
        return TokenResponse(token=token, player_id=request.player_id)

    # -- tables ----------------------------------------------------------

    @router.post("/tables", response_model=TableResponse)
    def create_table(request: CreateTableRequest) -> TableResponse:
        try:
            table = session_manager.create_table(
                request.table_id, request.max_seats, request.min_buyin, request.max_buyin
            )
        except SessionManagerError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _table_response(table)

    @router.get("/tables/{table_id}", response_model=TableResponse)
    def get_table(table_id: str) -> TableResponse:
        try:
            table = session_manager.get_table(table_id)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return _table_response(table)

    @router.post("/tables/{table_id}/join", response_model=TableResponse)
    def join_table(table_id: str, request: JoinTableRequest) -> TableResponse:
        try:
            table = session_manager.get_table(table_id)
            table.sit_down(request.player_id, request.display_name, request.buyin)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except TableError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _table_response(table)

    # -- hands ----------------------------------------------------------

    @router.post("/tables/{table_id}/hands", response_model=HandStateResponse)
    async def start_hand(table_id: str, request: StartHandRequest) -> HandStateResponse:
        from poker_engine.network.websocket_api import broadcast_hand_state

        try:
            variant_cls = resolve_variant(request.variant)
            structure = resolve_structure(request.structure)
        except VariantRegistryError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        blind_level = BlindLevel(small_blind=request.small_blind, big_blind=request.big_blind)
        try:
            hand_id = session_manager.start_hand(table_id, variant_cls, structure, blind_level)
        except SessionManagerError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except GameError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        game = session_manager.active_hands[table_id]
        await broadcast_hand_state(session_manager, connections, table_id)
        return build_hand_state_response(game, hand_id, table_id)

    @router.get("/tables/{table_id}/hands/current", response_model=HandStateResponse)
    def get_current_hand(table_id: str, viewer: Optional[str] = None) -> HandStateResponse:
        try:
            game = session_manager.get_active_hand(table_id)
            hand_id = session_manager.get_current_hand_id(table_id)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return build_hand_state_response(game, hand_id, table_id, viewer_player_id=viewer)

    @router.post("/tables/{table_id}/hands/current/actions", response_model=HandStateResponse)
    async def apply_action(
        table_id: str, request: ActionRequest, authorization: Optional[str] = Header(default=None)
    ) -> HandStateResponse:
        from poker_engine.network.websocket_api import broadcast_hand_state

        _require_player(auth, _bearer_token(authorization), request.player_id)
        try:
            action_type = ActionType(request.action_type)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=f"Unknown action_type: {request.action_type!r}") from exc

        try:
            game = session_manager.apply_action(table_id, request.player_id, action_type, request.amount)
            hand_id = session_manager.get_current_hand_id(table_id)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except GameError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        await broadcast_hand_state(session_manager, connections, table_id)
        return build_hand_state_response(game, hand_id, table_id, viewer_player_id=request.player_id)

    # -- hand history ----------------------------------------------------------

    @router.get("/hands/{hand_id}", response_model=HandHistoryResponse)
    def get_hand_history(hand_id: str) -> HandHistoryResponse:
        try:
            history = session_manager.get_hand_history(hand_id)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return build_hand_history_response(history)

    # -- statistics ----------------------------------------------------------

    @router.get("/players/{player_id}/stats", response_model=PlayerStatsResponse)
    def get_player_stats(player_id: str) -> PlayerStatsResponse:
        stats = session_manager.get_player_stats(player_id)
        return PlayerStatsResponse(
            player_id=player_id,
            hands_tracked=stats.hands_tracked,
            vpip_pct=stats.vpip_pct,
            pfr_pct=stats.pfr_pct,
            three_bet_pct=stats.three_bet_pct,
            aggression_factor=stats.aggression_factor,
            bb_per_100=stats.bb_per_100,
            total_profit=stats.total_profit,
        )

    @router.get("/leaderboard", response_model=LeaderboardResponse)
    def get_leaderboard(limit: int = 10, min_hands: int = 1) -> LeaderboardResponse:
        entries = [
            LeaderboardEntry(
                player_id=pid, hands_tracked=stats.hands_tracked, bb_per_100=stats.bb_per_100,
                total_profit=stats.total_profit,
            )
            for pid, stats in session_manager.player_stats.items()
            if stats.hands_tracked >= min_hands
        ]
        entries.sort(key=lambda e: e.bb_per_100, reverse=True)
        return LeaderboardResponse(entries=entries[:limit])

    # -- tournaments ----------------------------------------------------------

    @router.post("/tournaments", response_model=TournamentResponse)
    def create_tournament(request: TournamentCreateRequest) -> TournamentResponse:
        from poker_engine.tournaments.blind_schedule import BlindSchedule

        schedule = BlindSchedule.standard_flop_schedule(request.small_blind, num_levels=20)
        config = TournamentConfig(
            buy_in=request.buy_in,
            starting_stack=request.starting_stack,
            blind_schedule=schedule,
            max_players_per_table=request.max_players_per_table,
        )
        try:
            tournament = session_manager.create_tournament(request.tournament_id, config)
        except (SessionManagerError, TournamentError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _tournament_response(request.tournament_id, tournament)

    @router.post("/tournaments/{tournament_id}/register", response_model=TournamentResponse)
    def register_for_tournament(tournament_id: str, request: TournamentRegisterRequest) -> TournamentResponse:
        try:
            tournament = session_manager.get_tournament(tournament_id)
            tournament.register(request.player_id, request.display_name)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except TournamentError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _tournament_response(tournament_id, tournament)

    @router.post("/tournaments/{tournament_id}/start", response_model=TournamentResponse)
    def start_tournament(tournament_id: str) -> TournamentResponse:
        try:
            tournament = session_manager.get_tournament(tournament_id)
            tournament.start()
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except TournamentError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _tournament_response(tournament_id, tournament)

    @router.get("/tournaments/{tournament_id}", response_model=TournamentResponse)
    def get_tournament(tournament_id: str) -> TournamentResponse:
        try:
            tournament = session_manager.get_tournament(tournament_id)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return _tournament_response(tournament_id, tournament)

    # -- cash games ----------------------------------------------------------

    @router.post("/cash-games", response_model=CashGameResponse)
    def create_cash_game(request: CashGameCreateRequest) -> CashGameResponse:
        config = CashGameConfig(
            min_buyin=request.min_buyin, max_buyin=request.max_buyin, max_seats=request.max_seats
        )
        try:
            cash_game = session_manager.create_cash_game(request.cash_game_id, config)
        except (SessionManagerError, CashGameError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _cash_game_response(request.cash_game_id, cash_game)

    @router.post("/cash-games/{cash_game_id}/join", response_model=CashGameResponse)
    def join_cash_game(cash_game_id: str, request: CashGameJoinRequest) -> CashGameResponse:
        try:
            cash_game = session_manager.get_cash_game(cash_game_id)
            cash_game.join(request.player_id, request.display_name, request.buyin)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except (TableError, CashGameError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _cash_game_response(cash_game_id, cash_game)

    @router.post("/cash-games/{cash_game_id}/leave/{player_id}", response_model=CashGameResponse)
    def leave_cash_game(cash_game_id: str, player_id: str) -> CashGameResponse:
        try:
            cash_game = session_manager.get_cash_game(cash_game_id)
            cash_game.leave(player_id)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except TableError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _cash_game_response(cash_game_id, cash_game)

    @router.get("/cash-games/{cash_game_id}", response_model=CashGameResponse)
    def get_cash_game(cash_game_id: str) -> CashGameResponse:
        try:
            cash_game = session_manager.get_cash_game(cash_game_id)
        except SessionManagerError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return _cash_game_response(cash_game_id, cash_game)

    return router


def _bearer_token(authorization: Optional[str]) -> Optional[str]:
    if authorization is None:
        return None
    if authorization.lower().startswith("bearer "):
        return authorization[7:]
    return authorization


def _table_response(table) -> TableResponse:
    return TableResponse(
        table_id=table.table_id,
        max_seats=table.max_seats,
        occupied_seats=table.occupied_count(),
        player_ids=[p.player_id for p in table.occupied_seats()],
    )


def _tournament_response(tournament_id: str, tournament) -> TournamentResponse:
    return TournamentResponse(
        tournament_id=tournament_id,
        is_started=tournament.is_started,
        is_finished=tournament.is_finished,
        registered_player_ids=tournament.registered_player_ids,
        remaining_player_ids=tournament.remaining_player_ids if tournament.is_started else [],
        prize_pool=tournament.prize_pool,
        num_tables=len(tournament.tables),
    )


def _cash_game_response(cash_game_id: str, cash_game) -> CashGameResponse:
    return CashGameResponse(
        cash_game_id=cash_game_id,
        occupied_seats=cash_game.table.occupied_count(),
        max_seats=cash_game.config.max_seats,
        waiting_list_length=len(cash_game.waiting_list),
    )
