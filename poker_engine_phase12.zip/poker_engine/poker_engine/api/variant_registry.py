"""
Maps the string names the REST API accepts (`"TexasHoldem"`,
`"no_limit"`, ...) to the actual engine classes/enum members.

Scoped to the blind-based (FlopGame/DrawGame family) variants for the
REST API's `POST /tables/{id}/hands` endpoint -- Stud games use a
different stakes shape (StudStakes: ante/bring-in/small-bet/big-bet
instead of small-blind/big-blind) that would need its own request schema
to expose cleanly over HTTP. The engine itself already supports every
variant identically underneath (see poker_engine.variants); this is a
REST-surface scoping decision, not an engine limitation, the same kind
of "start narrow, the seam already supports more" scoping MonteCarloAI
made for flop-game equity in Phase 10.
"""

from __future__ import annotations

from typing import Dict, Type

from poker_engine.betting.structures import BettingStructure
from poker_engine.variants.base_game import BaseGame
from poker_engine.variants.five_card_draw import FiveCardDraw, TripleDraw
from poker_engine.variants.omaha import Omaha, OmahaHiLo
from poker_engine.variants.pineapple import CrazyPineapple, Irish, Pineapple
from poker_engine.variants.short_deck_holdem import ShortDeckHoldem
from poker_engine.variants.texas_holdem import TexasHoldem


class VariantRegistryError(Exception):
    pass


VARIANTS: Dict[str, Type[BaseGame]] = {
    "TexasHoldem": TexasHoldem,
    "Omaha": Omaha,
    "OmahaHiLo": OmahaHiLo,
    "ShortDeckHoldem": ShortDeckHoldem,
    "Pineapple": Pineapple,
    "CrazyPineapple": CrazyPineapple,
    "Irish": Irish,
    "FiveCardDraw": FiveCardDraw,
    "TripleDraw": TripleDraw,
}

STRUCTURES: Dict[str, BettingStructure] = {
    "no_limit": BettingStructure.NO_LIMIT,
    "pot_limit": BettingStructure.POT_LIMIT,
    "fixed_limit": BettingStructure.FIXED_LIMIT,
}


def resolve_variant(name: str) -> Type[BaseGame]:
    variant = VARIANTS.get(name)
    if variant is None:
        raise VariantRegistryError(f"Unknown or unsupported variant: {name!r}")
    return variant


def resolve_structure(name: str) -> BettingStructure:
    structure = STRUCTURES.get(name)
    if structure is None:
        raise VariantRegistryError(f"Unknown betting structure: {name!r}")
    return structure
