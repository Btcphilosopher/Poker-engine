"""Pydantic request/response models for the REST API and WebSocket messages."""

from __future__ import annotations

from typing import Dict, List, Optional

from pydantic import BaseModel


class CardSchema(BaseModel):
    rank: str
    suit: str
    display: str


class LegalActionsSchema(BaseModel):
    to_call: int
    can_fold: bool
    can_check: bool
    can_call: bool
    can_bet: bool
    can_raise: bool
    bet_min: Optional[int] = None
    bet_max: Optional[int] = None
    raise_min: Optional[int] = None
    raise_max: Optional[int] = None


class CreateTableRequest(BaseModel):
    table_id: str
    max_seats: int = 9
    min_buyin: Optional[int] = None
    max_buyin: Optional[int] = None


class TableResponse(BaseModel):
    table_id: str
    max_seats: int
    occupied_seats: int
    player_ids: List[str]


class JoinTableRequest(BaseModel):
    player_id: str
    display_name: str
    buyin: int


class StartHandRequest(BaseModel):
    variant: str = "TexasHoldem"
    structure: str = "no_limit"
    small_blind: int
    big_blind: int


class ActionRequest(BaseModel):
    player_id: str
    action_type: str
    amount: int = 0


class HandStateResponse(BaseModel):
    hand_id: str
    table_id: str
    is_complete: bool
    current_player: Optional[str] = None
    legal_actions: Optional[LegalActionsSchema] = None
    board: List[CardSchema]
    pot_size: int
    your_hole_cards: Optional[List[CardSchema]] = None
    winners: Optional[Dict[str, int]] = None


class HandHistoryActionResponse(BaseModel):
    player_id: str
    action_type: str
    amount: int
    street_label: str
    pot_after: int


class HandHistoryResponse(BaseModel):
    hand_id: str
    variant_name: str
    structure: str
    table_id: str
    seat_order: List[str]
    starting_stacks: Dict[str, int]
    board: List[CardSchema]
    actions: List[HandHistoryActionResponse]
    winners: Dict[str, int]
    final_stacks: Dict[str, int]


class PlayerStatsResponse(BaseModel):
    player_id: str
    hands_tracked: int
    vpip_pct: float
    pfr_pct: float
    three_bet_pct: float
    aggression_factor: float
    bb_per_100: float
    total_profit: int


class LeaderboardEntry(BaseModel):
    player_id: str
    hands_tracked: int
    bb_per_100: float
    total_profit: int


class LeaderboardResponse(BaseModel):
    entries: List[LeaderboardEntry]


class TournamentCreateRequest(BaseModel):
    tournament_id: str
    buy_in: int
    starting_stack: int
    small_blind: int
    big_blind: int
    max_players_per_table: int = 9


class TournamentRegisterRequest(BaseModel):
    player_id: str
    display_name: str


class TournamentResponse(BaseModel):
    tournament_id: str
    is_started: bool
    is_finished: bool
    registered_player_ids: List[str]
    remaining_player_ids: List[str]
    prize_pool: int
    num_tables: int


class CashGameCreateRequest(BaseModel):
    cash_game_id: str
    min_buyin: int
    max_buyin: int
    max_seats: int = 9


class CashGameJoinRequest(BaseModel):
    player_id: str
    display_name: str
    buyin: int


class CashGameResponse(BaseModel):
    cash_game_id: str
    occupied_seats: int
    max_seats: int
    waiting_list_length: int


class TokenRequest(BaseModel):
    player_id: str


class TokenResponse(BaseModel):
    token: str
    player_id: str


class ErrorResponse(BaseModel):
    detail: str
