"""
Serializers -- converting engine objects into the Pydantic schemas the
REST API and WebSocket layer send over the wire.

The one thing that matters enough to call out explicitly:
build_hand_state_response takes a `viewer_player_id` and only ever
includes THAT player's hole cards, never anyone else's, in
`your_hole_cards`. HandHistory (Phase 11) stores everyone's cards
because it's an internal record built after a hand's already over, for
replay and analysis -- there's no live opponent to protect information
from at that point. A live HandStateResponse is different: it can be
requested WHILE a hand is still in progress, and leaking another
player's hole cards over the API would be a real information leak, not
a hypothetical one. Every caller of build_hand_state_response must pass
the identity of who's asking.
"""

from __future__ import annotations

from typing import Optional

from poker_engine.api.schemas import (
    CardSchema,
    HandHistoryActionResponse,
    HandHistoryResponse,
    HandStateResponse,
    LegalActionsSchema,
)
from poker_engine.betting.round import LegalActions
from poker_engine.cards.card import Card
from poker_engine.statistics.hand_history import HandHistory
from poker_engine.variants.base_game import BaseGame


def serialize_card(card: Card) -> CardSchema:
    return CardSchema(rank=card.rank.name, suit=card.suit.name, display=str(card))


def serialize_legal_actions(legal: LegalActions) -> LegalActionsSchema:
    return LegalActionsSchema(
        to_call=legal.to_call,
        can_fold=legal.can_fold,
        can_check=legal.can_check,
        can_call=legal.can_call,
        can_bet=legal.can_bet,
        can_raise=legal.can_raise,
        bet_min=legal.bet_min,
        bet_max=legal.bet_max,
        raise_min=legal.raise_min,
        raise_max=legal.raise_max,
    )


def build_hand_state_response(
    game: BaseGame, hand_id: str, table_id: str, viewer_player_id: Optional[str] = None
) -> HandStateResponse:
    current_player = game.current_player
    legal = None
    if not game.is_hand_complete and current_player is not None:
        legal = serialize_legal_actions(game.legal_actions(current_player))

    your_hole_cards = None
    if viewer_player_id is not None:
        hole_cards = getattr(game, "hole_cards", {}).get(viewer_player_id)
        if hole_cards is not None:
            your_hole_cards = [serialize_card(c) for c in hole_cards]

    board = [serialize_card(c) for c in getattr(game, "board", ())]

    winners = None
    if game.is_hand_complete and game.outcome is not None:
        winners = dict(game.outcome.total_payouts)

    return HandStateResponse(
        hand_id=hand_id,
        table_id=table_id,
        is_complete=game.is_hand_complete,
        current_player=current_player,
        legal_actions=legal,
        board=board,
        pot_size=game.pot_size,
        your_hole_cards=your_hole_cards,
        winners=winners,
    )


def build_hand_history_response(history: HandHistory) -> HandHistoryResponse:
    return HandHistoryResponse(
        hand_id=history.hand_id,
        variant_name=history.variant_name,
        structure=history.structure,
        table_id=history.table_id,
        seat_order=list(history.seat_order),
        starting_stacks=history.starting_stacks,
        board=[serialize_card(c) for c in history.board],
        actions=[
            HandHistoryActionResponse(
                player_id=a.player_id,
                action_type=a.action_type.value,
                amount=a.amount,
                street_label=a.street_label,
                pot_after=a.pot_after,
            )
            for a in history.actions
        ],
        winners=history.winners,
        final_stacks=history.final_stacks,
    )
