# Architecture — Phase 1 (Foundation)

## Design principles carried through from here on

- **Immutability where it's free.** `Card` is a frozen, slotted dataclass —
  hashable, safe to share across threads, cheap to compare. This matters
  later for the multi-threaded Monte Carlo engine (Phase 10), which will
  pass cards between worker threads without locking.
- **Rank values ARE poker values.** `Rank.ACE.value == 14`. Evaluation code
  never needs a translation table between "what the enum says" and "what the
  hand ranking needs" — that's a common source of off-by-one bugs in poker
  engines and it's designed out from the start.
- **Comparison keys, not comparison functions.** Both `HandResult` and
  `LowHandResult` reduce to a plain tuple (`sort_key` / `rank_key`) such that
  Python's built-in tuple comparison produces the correct poker ranking.
  This means `max()`, `sorted()`, `min()` and the `<`/`>` operators all just
  work, including across combinatorial search (`evaluate_best_of`).
- **Display values and comparison keys are kept separate.** `LowHandResult`
  had a real bug caught during Phase 1 testing: the internal comparison key
  for Ace-to-5 low hands (which must be shape-prefixed — see below) is *not*
  the same as the actual card ranks you'd want to show a user. The dataclass
  now carries both `values` (display) and `rank_key` (comparison) explicitly
  rather than overloading one field for both purposes.

## Hand evaluation algorithm

`evaluate_5` classifies a 5-card hand by:
1. Sorting ranks descending and counting duplicates (`Counter`).
2. Checking flush (all one suit) and straight (5 consecutive distinct ranks,
   with the wheel A-2-3-4-5 as a special case where the Ace plays low).
3. Mapping the rank-count "pattern" (e.g. `(4,1)`, `(3,2)`, `(2,2,1)`) plus
   the flush/straight flags to one of the 9 `HandCategory` values.
4. Building an ordered tiebreaker tuple specific to that category (e.g. for
   two pair: `(high_pair, low_pair, kicker)`), so any two hands of the same
   category compare correctly including full kicker resolution.

`evaluate_best_of` (7-card hold'em/stud) and `evaluate_omaha` (Omaha's
"exactly 2 hole + 3 board" restriction) are built on top of `evaluate_5` via
`itertools.combinations` — correct by construction, since they're just
"evaluate every legal 5-card hand and take the best." This is the right
starting point for correctness; see the roadmap for the planned lookup-table
optimisation once the full rule engine depends on this API and a stable
before/after benchmark is meaningful.

## Ace-to-5 low evaluation

This is the one place in Phase 1 where the "obvious" implementation is
actually wrong, and it's worth documenting why.

A tempting shortcut for low-hand comparison is: sort each hand's ace-low
values descending, then compare the two tuples lexicographically (lower
tuple wins). This is correct for *unpaired* hands, but breaks the moment a
pair is involved:

```
7-5-4-3-2 (no pair)  vs  6-6-4-3-2 (pair of sixes)
```

Naive lexicographic comparison checks the highest card first (7 vs 6) and
would call the paired 6-6-4-3-2 hand better — which is wrong. In real
Ace-to-5 low (used by Razz, and for resolving the low side of Hi-Lo split
pots when a qualifier is disabled), **hand shape dominates first**, exactly
like a standard high hand: five-distinct-ranks beats one-pair beats two-pair
beats trips beats full house beats quads, *regardless* of what the actual
ranks are. Only within the same shape do lower ranks win.

`_low_sort_key` builds a `(shape_rank, *ordered_ranks)` tuple that encodes
this correctly, and `LowHandResult.rank_key` is what all comparisons go
through. `LowHandResult.values` is a separate, plain-English field (actual
ace-low ranks, sorted descending) kept purely for display and hand-history
export.

## What's deliberately not here yet

- **Badugi evaluation** — structurally different (suit-uniqueness based
  rather than rank-counting) and belongs with the Draw-games phase where
  it'll be built alongside the game rules that actually use it.
- **2-7 (Deuce-to-Seven) lowball** — straights/flushes count *against* the
  hand and Ace plays high-only, the opposite of Ace-to-5. Deferred to the
  Triple Draw implementation.
- **Lookup-table hand evaluation** — the current combinatorial approach is
  correct and already fast enough for turn-based gameplay (~100K hands/sec
  for `evaluate_5`); a perfect-hash table is planned once the full rule
  engine exists and Monte Carlo simulation volume actually demands it.

---

# Phase 2 — Betting Engine

## Why BettingRound is street-scoped, not hand-scoped

`BettingRound` handles exactly one street. `PlayerBettingState` is the
object that persists across the whole hand — the dealer phase is expected
to build a fresh `BettingRound` per street, passing the *same*
`PlayerBettingState` instances through each one, calling
`start_new_street()` between them. This mirrors how the money actually
behaves: `street_contributed` is street-scoped (what you owe/have put in
*this round*), `total_contributed` is hand-scoped (what side-pot
computation needs). Trying to make one object handle all streets would
mean either resetting internal state mid-object (fragile) or duplicating
the street/hand distinction that already exists naturally in the two
contribution fields.

## The minimum-raise / incomplete-raise rule

This is the single trickiest rule in the whole betting engine, so it gets
its own section (also documented inline in `round.py`).

A raise must increase the current bet by at least the size of the previous
full bet or raise. A player going all-in for less than that is still
allowed — but it does NOT let players who already called the previous bet
level re-raise; they may only call the extra amount or fold. Meanwhile, a
player who *hasn't* acted yet at the current level keeps full options
(including raising) even after an incomplete raise, since they never used
up their chance to respond to a legitimate full bet.

The implementation tracks this with a single set, `_acted_since_full_raise`,
cleared only on a COMPLETE bet/raise:
- Any action (fold/check/call/bet/raise) adds the actor to the set.
- A COMPLETE bet/raise clears the set and starts it over with just the
  actor — reopening full options for everyone else.
- An INCOMPLETE (short all-in) raise does NOT clear the set — the raiser
  is added to it, but everyone already in the set stays restricted to
  call/fold when `legal_actions` is asked for their options next.

Getting this right mattered enough that three of the test file's scenarios
(`test_incomplete_raise_*`) exist purely to pin down each side of this
rule with a worked example, rather than trusting the general logic alone.

## Bugs caught while writing Phase 2's own tests

Two are worth recording because they're the kind of bug that looks
plausible until you write the test that specifically targets it:

1. **Short-stacked "raise" below the current bet.** The first version of
   `legal_actions` computed a raise range for *any* player with `stack > 0`
   facing a bet, without checking whether their stack could actually
   exceed the current bet. A player with less in their stack than the
   current bet (e.g. facing a bet of 100 with only 30 chips) was offered a
   legal "raise" to 30 — which is less than the current bet, i.e. not a
   raise at all, just a disguised short call. Fixed by requiring
   `max_reachable() > current_bet` before offering RAISE; see
   `test_very_short_stack_cannot_raise_only_call_all_in_or_fold`.

2. **Pot-limit sizing fallback could balloon to full stack.** The original
   pot-limit `bet_max`/`raise_max` computed the structural cap and the
   stack-based floor *independently*, then patched disagreements with a
   fallback that set both to the player's full stack. In a degenerate
   (but code-reachable) case — a pot-limit street with nothing at all in
   the pot yet — this let a player with a million-chip stack "open" for
   their entire stack, ignoring the pot-limit cap entirely. Fixed by
   deriving the minimum from the already-correctly-capped maximum
   (`bet_min = min(self.min_bet, bet_max)`) instead of computing both
   independently; see
   `test_pot_limit_with_truly_empty_pot_disallows_betting_rather_than_ballooning_to_full_stack`.

Both were caught by deliberately writing a test for the exact edge case
the logic needed to handle, not by generic fuzzing — a reminder that the
property-based tests (which caught neither of these) are a complement to
targeted edge-case tests, not a replacement for them.

## `is_betting_complete()` vs. "the hand should end"

`BettingRound.is_betting_complete()` answers a narrow, mechanical question:
has every live player matched the current bet and had a turn this street?
It deliberately does NOT check "does only one non-folded player remain" —
that's a hand-level decision (award the pot immediately, don't even ask
the survivor to act) that belongs to the dealer/orchestrator in Phase 3,
which has visibility across the whole hand rather than one street. Mixing
that concern into `BettingRound` would couple street-mechanics to
hand-lifecycle decisions that differ per variant (e.g. running it twice in
some cash-game "run it twice" rules). See
`tests/test_betting_integration.py::test_uncontested_pot_when_everyone_but_one_folds`
for a worked example of the distinction.

## Pot construction: why layering by contribution level works

`compute_pots` doesn't track *when* side pots formed during play — it
recomputes them from scratch at the end from each player's
`total_contributed` and `is_folded` status. This is simpler and less
bug-prone than trying to maintain pot state incrementally as all-ins
happen mid-hand: sort the distinct contribution levels, and each layer
between two consecutive levels is a pot of `layer_size * contributors`,
eligible to whoever in that layer didn't fold. Adjacent pots that happen to
share an identical eligible set get merged for display — this changes
nothing about payouts (whoever wins between the same set of players wins
the combined amount either way) but avoids showing a poker room three
identically-eligible "pots" when there's no practical difference between
them.

---

# Phase 3 — Dealer + Table Management

## Player vs. PlayerBettingState: two objects, two lifetimes

It would be tempting to have one "Player" object carry both a persistent
stack and the per-hand betting fields (`street_contributed`,
`total_contributed`, `is_folded`, `is_all_in`). Phase 3 deliberately keeps
them as two separate objects instead:

- `Player` (this phase) lives at the table across many hands: name, seat,
  status (active / sitting out / waiting / eliminated), and the stack size
  that persists between hands.
- `PlayerBettingState` (Phase 2) lives for exactly one hand: it's built
  fresh from `Player.to_betting_state()` at the start of a hand and
  discarded once `Table.settle_hand()` folds its result back into `Player`.

The alternative — one long-lived object — would need to either reset a
pile of per-hand fields at the start of every hand (easy to forget one) or
carry hand-scoped noise (`is_folded`, `is_all_in`) that's meaningless
between hands. Two objects with two clear lifetimes is less code overall
once you account for the bugs the alternative invites.

## Deriving action order instead of hard-coding seat positions

`Table.preflop_action_order()` / `postflop_action_order()` don't store "who
is UTG" anywhere — they derive it fresh from `seats_from_button()` every
time, filtered to active players. This matters because the alternative
(tracking named positions like "UTG", "MP", "CO" as table state) has to be
kept in sync with every seating change, elimination, and button move; a
derived function can't drift out of sync with reality because there's
nothing to keep in sync — it just re-reads the current seat layout.

The one piece of real logic worth calling out is the 3-handed pre-flop
case: with exactly button+SB+BB and nobody else, the player *after* the
BB, who acts first pre-flop, is the button themselves (action wraps all
the way around). `order[3:] + order[:3]` on a 3-element list naturally
produces `[] + [button, SB, BB]` — the same order, which is correct — so
no special-casing was needed once the general slicing formula was right;
see `test_three_handed_action_order` for this worked out explicitly, since
it's easy to eyeball as a bug when it isn't one.

## The `advance_to_next_street` footgun (and why it's now an API, not a habit)

While writing Phase 3's own end-to-end integration test, a scratch version
of the dealer loop did this, in this order:

```python
for player in players_bs.values():
    player.start_new_street()          # resets street_contributed to 0

flop_round = BettingRound(
    ..., carried_pot=preflop.total_pot()   # <-- reads street_contributed AFTER it was reset
)
```

`BettingRound.total_pot()` is a live computation
(`carried_pot + sum(p.street_contributed for p in players)`), not a value
captured when the street ended. Resetting `street_contributed` before
reading it silently produces `0` for what should have been the entire pot
so far — no exception, no warning, just a hand that plays out for a pot
that's quietly stopped existing. This is exactly the kind of bug that's
invisible in a quick test (the code runs, nothing crashes) and only shows
up as "why did everyone's chip count come out wrong."

The fix wasn't "remember to call these in the right order" — that's not a
fix, it's a hope. `dealer.dealing.advance_to_next_street(round_)` captures
`total_pot()` and resets every player's street state as a single atomic
operation, so the two steps can no longer be reordered by a caller. Every
street-transition in the codebase (including the integration test that
found the bug) goes through it now.

## Table balancing: greedy nearest-pair, not a global optimum

`balance_tables` repeatedly moves one player from the currently-fullest
table to the currently-emptiest table until no two tables differ by more
than one. This is a greedy heuristic, not a proof-optimal minimum-move
solution — but table balancing doesn't need optimality, it needs to
converge to "within one player" quickly and deterministically, which the
greedy approach does in at most `O(total players)` moves. `find_table_to_break`
/ `plan_table_break` are kept as a separate, explicit two-step process
(decide whether a table *should* break, then plan where its players go)
rather than folded into `balance_tables` directly, since "should we
reduce the number of tables" is a judgment call a tournament director
makes deliberately, not something that should happen as a side effect of
routine rebalancing.

## resolve_showdown's scope: single-ranking pots only, on purpose

`resolve_showdown` picks one winning group per pot (the best hand among
eligible players, split evenly among exact ties). This covers Hold'em,
Omaha (high), Stud, and Draw games — everything Phase 4-6 needs before
Hi-Lo variants exist. It deliberately does NOT attempt to guess at a
Hi-Lo-shaped API now (e.g. "high_hand_results" and "low_hand_results"
parameters) — building that against no concrete variant to validate it
against would mean guessing at requirements Phase 5 (Omaha Hi-Lo) hasn't
surfaced yet. The natural extension when that phase arrives is calling pot
resolution twice (once against high hands, once against qualifying low
hands, each for half the pot) rather than a redesign, since `compute_pots`
already doesn't care what "winning" means — it just needs a comparison.

---

# Phase 4 — Texas Hold'em (First Playable Variant)

## One Game instance = one hand

`TexasHoldem.start_hand()` can only be called once per instance — playing
a second hand means constructing a new `TexasHoldem(table, ...)`. This
mirrors the `PlayerBettingState` design from Phase 2 (rebuilt fresh per
hand from `Player.stack`) rather than fighting it with reset logic. The
alternative — a `TexasHoldem` that can play hand after hand via some
`next_hand()` method — would need to carefully reset a dozen internal
fields (`_board`, `_hole_cards`, `_action_log`, `_outcome`, `_round`,
`_street`, ...) and get every one of them right, every time. A fresh
object per hand makes forgetting to reset something structurally
impossible: there's nothing left over from the last hand because there
*is* no last hand in this object.

The `Table` is what actually persists across hands (seating, stacks,
button position) — exactly the split Phase 3 set up on purpose.

## The state machine: one method decides everything

Every action funnels through `apply_action()` → `_advance_if_needed()`,
which asks exactly two questions, in this order:

1. **Is only one non-folded player left?** If so, the hand ends
   immediately and uncontested — no more cards get dealt, because a real
   dealer wouldn't deal cards nobody's going to see. This is the exact
   rule Phase 3 documented as explicitly out of scope for
   `BettingRound.is_betting_complete()` (see that docstring) — it lives
   here instead, at the hand-orchestration layer, because "should the hand
   end" is a decision that needs visibility across the whole hand, not
   just the current street.

2. **Is the current street's betting complete?** If not, nothing happens
   yet — wait for more actions. If so, advance: carry the pot forward
   (via `advance_to_next_street`, the Phase 3 API that exists specifically
   to prevent the pot-zeroing footgun), deal the next street's cards, and
   open a new `BettingRound` — *unless* fewer than two players have any
   chips left to bet with, in which case every remaining street gets
   dealt in one go and the hand jumps straight to showdown. This is the
   "everyone's all-in, run it out" case, and it's the same code path
   whether it happens on the flop, the turn, or even mid-preflop — the
   check runs after every single street transition, so it doesn't matter
   which street triggered it.

Nothing else in the class needs to know about hand-ending conditions —
every other method just does its one job (deal cards, run a betting round,
compute a showdown) and trusts `_advance_if_needed` to have decided
correctly that it's time to call it.

## Why structure-specific behaviour lives in one method, not three classes

`NoLimitHoldem`, `LimitHoldem`, and `PotLimitHoldem` could have been three
separate classes. They're one class (`TexasHoldem(structure=...)`)
because, looked at closely, exactly two things differ between them:

1. **Bet sizing.** `BettingRound` (Phase 2) already fully owns this — it
   takes a `BettingStructure` and computes legal ranges correctly for all
   three. `TexasHoldem` doesn't reimplement any of that; it just picks the
   right `min_bet` per street (`_min_bet_for_street()`: big blind for
   NL/PL, small_bet/big_bet for Limit depending on which street).
2. **The raise cap.** Fixed-limit games cap the number of raises per
   street (traditionally 4); NL/PL don't. This is a single `cap_raises`
   value computed once at `start_hand()` and passed through to every
   street's `BettingRound`.

Neither of these affects *how a hand is dealt, when streets advance, how
showdown is resolved, or how pots are split* — all of which is 100%
identical across the three structures. Three subclasses would mean three
copies of that identical logic (or an inheritance hierarchy built solely
to avoid duplicating two small computations), for zero behavioural
benefit. The property tests
(`test_random_full_games_terminate_and_conserve_chips`) run all three
structures through the exact same test body for exactly this reason: they
*are* the same game with different money rules, not three different games.
