"""
TexasHoldem — No-Limit, Limit, and Pot-Limit Hold'em, in one class
parametrized by `BettingStructure`. This is the flow that
`tests/test_dealer_integration.py` (Phase 3) played out by hand, wrapped
into a reusable, stateful game object.

One instance = one hand. See BaseGame's docstring for why.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from poker_engine.betting.actions import Action, ActionType
from poker_engine.betting.round import BettingRound, LegalActions
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.betting.structures import BettingStructure, BlindLevel
from poker_engine.betting.blinds import assign_blinds, post_ante, post_big_blind, post_small_blind
from poker_engine.cards.card import Card
from poker_engine.dealer.dealing import advance_to_next_street, deal_community_cards, deal_hole_cards
from poker_engine.dealer.showdown import HandOutcome, resolve_showdown
from poker_engine.deck.deck import Deck
from poker_engine.evaluation.evaluator import evaluate_best_of
from poker_engine.tables.table import Table
from poker_engine.variants.base_game import BaseGame, GameError, Street


@dataclass(frozen=True, slots=True)
class StreetAction:
    """One action, tagged with which street it happened on — the basic unit
    Phase 11's hand-history export will eventually consume."""

    street: Street
    action: Action


class TexasHoldem(BaseGame):
    def __init__(
        self,
        table: Table,
        structure: BettingStructure,
        blind_level: BlindLevel,
        *,
        deck: Optional[Deck] = None,
        fixed_limit_raise_cap: int = 4,
    ) -> None:
        self.table = table
        self.structure = structure
        self.blind_level = blind_level
        self.fixed_limit_raise_cap = fixed_limit_raise_cap

        self._deck = deck if deck is not None else self._fresh_shuffled_deck()
        self._betting_states: Dict[str, PlayerBettingState] = {}
        self._round: Optional[BettingRound] = None
        self._street: Street = Street.PREFLOP
        self._board: List[Card] = []
        self._burned: List[Card] = []
        self._hole_cards: Dict[str, List[Card]] = {}
        self._action_log: List[StreetAction] = []
        self._outcome: Optional[HandOutcome] = None
        self._cap_raises: Optional[int] = None
        self._started = False

    @staticmethod
    def _fresh_shuffled_deck() -> Deck:
        deck = Deck()
        deck.shuffle(secure=True)
        return deck

    # -- BaseGame interface ----------------------------------------------------------

    def start_hand(self) -> None:
        if self._started:
            raise GameError("start_hand() may only be called once per Game instance")
        self._started = True

        self.table.advance_button()
        active_ids = self.table.active_player_ids()
        if len(active_ids) < 2:
            raise GameError("Need at least 2 active players to start a hand")

        self._betting_states = {
            pid: self.table.find_player(pid).to_betting_state() for pid in active_ids
        }
        heads_up = self.table.is_heads_up()
        self._cap_raises = (
            self.fixed_limit_raise_cap
            if (self.structure is BettingStructure.FIXED_LIMIT and not heads_up)
            else None
        )

        ante_total = 0
        if self.blind_level.ante > 0:
            for pid in active_ids:
                ante_total += post_ante(self._betting_states[pid], self.blind_level.ante).amount

        blind_order = self.table.active_seats_from_button()
        sb_id, bb_id = assign_blinds(blind_order, heads_up=heads_up)
        post_small_blind(self._betting_states[sb_id], self.blind_level.small_blind)
        post_big_blind(self._betting_states[bb_id], self.blind_level.big_blind)

        deal_order = self.table.postflop_action_order()  # deal starting left of the button
        self._hole_cards = deal_hole_cards(self._deck, deal_order, 2)

        preflop_order = self.table.preflop_action_order()
        self._round = BettingRound(
            [self._betting_states[pid] for pid in preflop_order],
            self.structure,
            self._min_bet_for_street(),
            carried_pot=ante_total,
            cap_raises=self._cap_raises,
        )

    def legal_actions(self, player_id: str) -> LegalActions:
        if self._round is None:
            raise GameError("No betting round is currently open")
        return self._round.legal_actions(player_id)

    def apply_action(self, player_id: str, action_type: ActionType, amount: int = 0) -> Action:
        if self.is_hand_complete:
            raise GameError("This hand is already complete")
        if self._round is None:
            raise GameError("No betting round is currently open")

        action = self._round.apply(player_id, action_type, amount)
        self._action_log.append(StreetAction(street=self._street, action=action))
        self._advance_if_needed()
        return action

    @property
    def current_player(self) -> Optional[str]:
        return self._round.next_to_act() if self._round is not None else None

    @property
    def is_hand_complete(self) -> bool:
        return self._street is Street.COMPLETE

    @property
    def outcome(self) -> Optional[HandOutcome]:
        return self._outcome

    # -- read-only hand state, for UIs / hand-history / AI callers ----------------------------------------------------------

    @property
    def street(self) -> Street:
        return self._street

    @property
    def board(self) -> List[Card]:
        return list(self._board)

    @property
    def hole_cards(self) -> Dict[str, List[Card]]:
        return {pid: list(cards) for pid, cards in self._hole_cards.items()}

    @property
    def action_log(self) -> List[StreetAction]:
        return list(self._action_log)

    def settle(self) -> None:
        """Apply this hand's outcome back to the Table's persistent player stacks."""
        if not self.is_hand_complete or self._outcome is None:
            raise GameError("Cannot settle a hand that isn't complete yet")
        self.table.settle_hand(self._betting_states, self._outcome.total_payouts)

    # -- internals ----------------------------------------------------------

    def _min_bet_for_street(self) -> int:
        if self.structure is not BettingStructure.FIXED_LIMIT:
            return self.blind_level.big_blind
        if self._street in (Street.PREFLOP, Street.FLOP):
            return self.blind_level.small_bet or self.blind_level.big_blind
        return self.blind_level.big_bet or (2 * self.blind_level.big_blind)

    def _live_player_ids(self) -> List[str]:
        return [pid for pid, bs in self._betting_states.items() if not bs.is_folded]

    def _contestable_player_ids(self) -> List[str]:
        """Non-folded players who still have chips to bet with this street."""
        return [
            pid
            for pid, bs in self._betting_states.items()
            if not bs.is_folded and not bs.is_all_in
        ]

    def _advance_if_needed(self) -> None:
        if len(self._live_player_ids()) <= 1:
            self._finish_uncontested()
            return
        if self._round is not None and not self._round.is_betting_complete():
            return

        carried_pot = advance_to_next_street(self._round)
        if self._street is Street.RIVER:
            self._go_to_showdown()
            return

        self._deal_next_board_cards()
        self._open_next_betting_round(carried_pot)

    def _deal_next_board_cards(self) -> None:
        if self._street is Street.PREFLOP:
            dealt = deal_community_cards(self._deck, 3)
            self._street = Street.FLOP
        elif self._street is Street.FLOP:
            dealt = deal_community_cards(self._deck, 1)
            self._street = Street.TURN
        elif self._street is Street.TURN:
            dealt = deal_community_cards(self._deck, 1)
            self._street = Street.RIVER
        else:
            raise GameError(f"Cannot deal further board cards from street {self._street}")
        self._board.extend(dealt.cards)
        self._burned.extend(dealt.burned)

    def _open_next_betting_round(self, carried_pot: int) -> None:
        contestable = set(self._contestable_player_ids())
        if len(contestable) < 2:
            # Everyone left is either all-in or there's only one contestable
            # player with chips behind -- no more betting is possible. Deal
            # straight through to the river ("running it out") and settle
            # at showdown, exactly like a real dealer would.
            self._round = None
            while self._street is not Street.RIVER:
                self._deal_next_board_cards()
            self._go_to_showdown()
            return

        order = [pid for pid in self.table.postflop_action_order() if pid in contestable]
        self._round = BettingRound(
            [self._betting_states[pid] for pid in order],
            self.structure,
            self._min_bet_for_street(),
            carried_pot=carried_pot,
            cap_raises=self._cap_raises,
        )

    def _go_to_showdown(self) -> None:
        self._street = Street.SHOWDOWN
        self._round = None
        live = self._live_player_ids()
        hand_results = (
            {pid: evaluate_best_of(self._hole_cards[pid] + self._board) for pid in live}
            if len(live) > 1
            else {}
        )
        self._outcome = resolve_showdown(
            list(self._betting_states.values()), hand_results, order_from_button=self.table.seats_from_button()
        )
        self._street = Street.COMPLETE

    def _finish_uncontested(self) -> None:
        self._round = None
        self._outcome = resolve_showdown(
            list(self._betting_states.values()), {}, order_from_button=self.table.seats_from_button()
        )
        self._street = Street.COMPLETE
