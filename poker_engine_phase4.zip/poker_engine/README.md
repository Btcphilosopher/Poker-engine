# Poker Engine

A production-grade, multi-variant poker engine core, built in phases. This
repository currently contains **Phase 1: Foundation**, **Phase 2: Betting
Engine**, **Phase 3: Dealer + Table Management**, and **Phase 4: Texas
Hold'em** — the first fully playable variant, in No-Limit, Limit, and
Pot-Limit.

See [`docs/roadmap.md`](docs/roadmap.md) for the full 13-phase build plan and
current status, and [`docs/architecture.md`](docs/architecture.md) for design
notes — including real bugs caught and fixed during each phase's own
test-writing, documented in detail because they're instructive.

## What's implemented

**Phase 1 — Foundation**
- **Cards** (`poker_engine.cards`) — immutable `Card`, `Rank`, `Suit`, with
  string parsing/formatting (`Card.from_str("Ah")`, `str(card)`).
- **Deck** (`poker_engine.deck`) — standard 52-card and short (6+) 36-card
  decks, multi-deck support, three shuffle strategies (secure/CSPRNG, seeded/
  deterministic, standard), deal, burn, reset.
- **Evaluation** (`poker_engine.evaluation`) — full 5-card hand evaluation
  (all 9 categories, complete tie-breaking), best-of-N (7-card hold'em/stud),
  Omaha-restricted evaluation (exactly 2 hole + 3 board), and Ace-to-5 low
  evaluation (Razz / Hi-Lo split, with configurable qualifier).

**Phase 2 — Betting Engine**
- **`BettingRound`** (`poker_engine.betting`) — the core street state
  machine: turn order, legal-action computation, correct minimum-raise
  tracking (including the "incomplete all-in raise doesn't reopen the
  action" rule), pot-limit sizing, fixed-limit exact sizing + raise cap,
  all-in handling.
- **Pots** — `compute_pots` builds main + side pots from contributions
  (handles any number of simultaneous all-ins at different stack depths);
  `distribute_pot` splits a pot evenly with the standard odd-chip rule.
- **Forced bets** — blinds, antes, bring-in, dead blinds, blind assignment
  (including heads-up), stud bring-in determination (low or high card).
- **Button** — dealer button rotation across seats, skipping empty ones.

**Phase 3 — Dealer + Table Management**
- **`Player`** (`poker_engine.players`) — persistent, across-hands player
  state (name, seat, status, stack), separate from the ephemeral
  per-hand `PlayerBettingState`.
- **`Table`** (`poker_engine.tables`) — seating, buy-in range enforcement,
  dealer button rotation, and correct pre-flop/post-flop action-order
  derivation for any table size, including heads-up and 3-handed.
- **Table balancing** — `balance_tables` keeps multi-table player counts
  within one of each other; `find_table_to_break`/`plan_table_break`
  handle standard tournament table consolidation.
- **Dealing** (`poker_engine.dealer`) — round-robin hole cards, community
  cards with burns, stud streets, draw replacements.
- **Showdown** — `resolve_showdown` ties pot computation to hand evaluation
  to determine winners and payouts; `determine_reveal_order` and
  `last_aggressor_of` for showdown procedure.

**Phase 4 — Texas Hold'em (first playable variant)**
- **`TexasHoldem`** (`poker_engine.variants`) — a complete, self-contained
  hand from blinds through settlement: deal → four betting rounds with
  automatic street progression → automatic "run it out" when everyone's
  all-in → automatic uncontested-pot handling when folds leave one player
  → showdown → settlement. One class, parametrized by `BettingStructure`,
  covers No-Limit, Limit, and Pot-Limit.
- **`BaseGame`** — the ABC every future variant (Omaha, Stud, Draw, ...)
  will implement, established now with exactly one concrete example behind
  it rather than guessed at in the abstract.

292 tests total, 96%+ coverage (unit, edge-case, property-based via
Hypothesis, and — the strongest signal of correctness for a stateful game
class — 300+ fully-randomized complete games across every structure,
player count, and stack configuration, all verified to terminate and
conserve chips exactly). See `tests/`.

## Quickstart

```bash
pip install -e ".[dev]"
pytest
```

```python
from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem

# Seat players at a table
table = Table(table_id="main", max_seats=6)
table.sit_down("alice", "Alice", 1000, seat_index=0)
table.sit_down("bob", "Bob", 1000, seat_index=1)
table.sit_down("carol", "Carol", 1000, seat_index=2)

# Play one complete hand
deck = Deck()
deck.shuffle(seed=42)  # deterministic, for reproducible tests/replays
game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
game.start_hand()

while not game.is_hand_complete:
    pid = game.current_player
    legal = game.legal_actions(pid)
    action = ActionType.CHECK if legal.can_check else ActionType.CALL
    game.apply_action(pid, action)

print(game.outcome)   # pots, winners, payouts
game.settle()          # apply results back to each Player's persistent stack
```

See `tests/test_variants_texas_holdem.py` and
`tests/test_dealer_integration.py` for the same flow with real betting
(raises, all-ins, side pots) instead of check/call.

## Benchmark

```bash
python3 -m poker_engine.evaluation.benchmark
```

Current throughput (single-threaded, no lookup-table optimisation yet):
~100K hands/sec for `evaluate_5`, ~5K hands/sec for `evaluate_best_of` on
7 cards (brute-force over the 21 five-card combinations). A perfect-hash
lookup table is planned as a hardening pass — see the roadmap.

## Project layout

```
poker_engine/
    cards/        implemented — Card, Rank, Suit
    deck/         implemented — Deck
    evaluation/   implemented — evaluators + benchmark
    betting/      implemented — BettingRound, pots, blinds, button
    players/      implemented — Player, PlayerStatus
    tables/       implemented — Table, multi-table balancing
    dealer/       implemented — dealing mechanics, showdown resolution
    variants/     implemented — BaseGame, TexasHoldem (NL/Limit/PL)
    hands/        scaffolded — Phase 4-6
    tournaments/  scaffolded — Phase 8
    ai/           scaffolded — Phase 10
    simulation/   scaffolded — Phase 10
    statistics/   scaffolded — Phase 11
    network/      scaffolded — Phase 12
    api/          scaffolded — Phase 12
tests/
```

Every scaffolded module has a docstring in its `__init__.py` naming which
phase will fill it in.
