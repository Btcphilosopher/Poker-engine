"""
BettingRound — the state machine for a single street of betting.

This is the trickiest piece of a correct poker engine, so the rules it
enforces are documented here rather than scattered through the code:

1. MINIMUM RAISE. A raise must increase the current bet by at least the size
   of the previous full bet or raise on this street (or the table's min_bet,
   if nobody has bet yet). Example: blinds 10/20, UTG raises to 60 (a raise
   of 40 over the BB's 20) — the next legal raise must be to at least 100
   (60 + 40), not 80.

2. INCOMPLETE (SHORT ALL-IN) RAISES. A player may always go all-in with
   whatever they have, even if it's less than a full raise. This still
   increases the current bet (everyone else owes the difference to stay in),
   but it does NOT reset the minimum-raise size, and — critically — it does
   NOT reopen betting for players who already acted at the previous bet
   level: they may only call the extra amount or fold, not re-raise. A
   player who has NOT yet acted at the current level keeps full options
   (fold/call/raise) when their turn comes, incomplete raise or not.

   This engine tracks this per player via `_acted_since_full_raise`, which
   is cleared only when a COMPLETE bet/raise happens.

3. POT-LIMIT sizing. The maximum raise is "the size of the pot after the
   call is made": carried_pot (from earlier streets/antes) + everything
   already in front of players this street + the amount this player owes to
   call, all added to the current bet.

4. FIXED-LIMIT sizing. Every bet/raise is exactly one fixed increment
   (`min_bet`, i.e. small_bet or big_bet for whichever street the caller is
   running), with an optional raise cap (`cap_raises`, typically 4 = one bet
   + three raises) after which only call/fold remain.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Deque, Dict, List, Optional, Sequence, Set

from poker_engine.betting.actions import Action, ActionType
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.betting.structures import BettingStructure


class BettingError(Exception):
    """Base class for all betting-round errors."""


class NotPlayersTurnError(BettingError):
    pass


class IllegalActionError(BettingError):
    pass


@dataclass(frozen=True, slots=True)
class LegalActions:
    to_call: int
    can_fold: bool
    can_check: bool
    can_call: bool
    can_bet: bool
    can_raise: bool
    bet_min: Optional[int] = None
    bet_max: Optional[int] = None
    raise_min: Optional[int] = None
    raise_max: Optional[int] = None


class BettingRound:
    """
    Orchestrates one street of betting for a fixed group of players.

    Callers are responsible for:
      - Passing `players` already in correct action order for this street
        (whoever acts first is players[0]).
      - Posting any blinds/antes/bring-in onto the PlayerBettingState objects
        BEFORE constructing this round (see poker_engine.betting.blinds) —
        the round reads the initial `current_bet` off of what's already
        posted, it doesn't post anything itself.
      - Passing `carried_pot` = everything already in the pot from earlier
        streets/antes (needed for correct pot-limit sizing).
      - Calling `player.start_new_street()` on every PlayerBettingState
        before building the *next* street's BettingRound.
    """

    def __init__(
        self,
        players: Sequence[PlayerBettingState],
        structure: BettingStructure,
        min_bet: int,
        *,
        carried_pot: int = 0,
        cap_raises: Optional[int] = None,
    ) -> None:
        if min_bet <= 0:
            raise ValueError("min_bet must be positive")
        if carried_pot < 0:
            raise ValueError("carried_pot cannot be negative")

        self.players: List[PlayerBettingState] = list(players)
        self._by_id: Dict[str, PlayerBettingState] = {p.player_id: p for p in self.players}
        if len(self._by_id) != len(self.players):
            raise ValueError("Duplicate player_id in players")

        self.structure = structure
        self.min_bet = min_bet
        self.carried_pot = carried_pot
        self.cap_raises = cap_raises

        self.current_bet: int = max((p.street_contributed for p in self.players), default=0)
        self.last_raise_size: int = min_bet
        self.raise_count: int = 0
        self.history: List[Action] = []

        self._has_acted_this_street: Set[str] = set()
        self._acted_since_full_raise: Set[str] = set()
        self.to_act: Deque[str] = deque(p.player_id for p in self.players if p.is_live)

    # -- queries ----------------------------------------------------------

    def is_betting_complete(self) -> bool:
        """
        True once every live (non-folded, non-all-in) player has matched
        the current bet and had at least one turn this street.

        This does NOT check "only one player remains" — a hand where
        everyone but one player has folded should end immediately without
        waiting for the survivor to act, but that's a hand-level decision
        for the dealer/orchestrator (Phase 3+), not this street-mechanics
        check. Callers should check live player count separately.
        """
        for p in self.players:
            if not p.is_live:
                continue
            if p.street_contributed != self.current_bet:
                return False
            if p.player_id not in self._has_acted_this_street:
                return False
        return True

    def next_to_act(self) -> Optional[str]:
        return self.to_act[0] if self.to_act else None

    def street_pot(self) -> int:
        return sum(p.street_contributed for p in self.players)

    def total_pot(self) -> int:
        return self.carried_pot + self.street_pot()

    def legal_actions(self, player_id: str) -> LegalActions:
        player = self._require_player(player_id)
        if player.is_folded or player.is_all_in:
            raise IllegalActionError(f"{player_id} cannot act (folded or all-in)")

        to_call_raw = self.current_bet - player.street_contributed
        can_check = to_call_raw == 0
        can_call = to_call_raw > 0 and player.stack > 0
        can_fold = to_call_raw > 0

        raises_capped = self.cap_raises is not None and self.raise_count >= self.cap_raises
        max_reach = player.max_reachable()

        bet_min = bet_max = raise_min = raise_max = None
        can_bet = can_raise = False

        if self.current_bet == 0:
            if player.stack > 0 and not raises_capped:
                if self.structure is BettingStructure.FIXED_LIMIT:
                    candidate_max = min(self.min_bet, max_reach)
                else:
                    candidate_max = self._max_wager_ceiling(player)
                if candidate_max > 0:
                    can_bet = True
                    bet_max = candidate_max
                    bet_min = min(self.min_bet, bet_max)
        else:
            already_acted_at_this_level = player.player_id in self._acted_since_full_raise
            can_exceed_current_bet = max_reach > self.current_bet
            if (
                player.stack > 0
                and can_exceed_current_bet
                and not already_acted_at_this_level
                and not raises_capped
            ):
                if self.structure is BettingStructure.FIXED_LIMIT:
                    candidate_max = min(self.current_bet + self.min_bet, max_reach)
                else:
                    candidate_max = self._max_wager_ceiling(player)
                if candidate_max > self.current_bet:
                    can_raise = True
                    raise_max = candidate_max
                    raise_min = min(self.current_bet + self.last_raise_size, raise_max)

        return LegalActions(
            to_call=min(to_call_raw, player.stack),
            can_fold=can_fold,
            can_check=can_check,
            can_call=can_call,
            can_bet=can_bet,
            can_raise=can_raise,
            bet_min=bet_min,
            bet_max=bet_max,
            raise_min=raise_min,
            raise_max=raise_max,
        )

    def _max_wager_ceiling(self, player: PlayerBettingState) -> int:
        """The largest total street_contributed this player may reach with a
        single wager, accounting for both their stack and the structure's cap."""
        max_reach = player.max_reachable()
        if self.structure is BettingStructure.NO_LIMIT:
            return max_reach
        if self.structure is BettingStructure.POT_LIMIT:
            to_call = self.current_bet - player.street_contributed
            pot_after_call = self.total_pot() + to_call
            pot_limit_amount = self.current_bet + pot_after_call
            return min(pot_limit_amount, max_reach)
        raise AssertionError("_max_wager_ceiling is not used for FIXED_LIMIT")

    # -- actions ------------------------------------------------------------

    def apply(self, player_id: str, action_type: ActionType, amount: int = 0) -> Action:
        if self.next_to_act() != player_id:
            raise NotPlayersTurnError(f"It is not {player_id}'s turn to act")
        player = self._require_player(player_id)
        legal = self.legal_actions(player_id)

        if action_type is ActionType.FOLD:
            if not legal.can_fold:
                raise IllegalActionError(f"{player_id} cannot fold (nothing to call)")
            player.is_folded = True
            self._has_acted_this_street.add(player_id)
            self._acted_since_full_raise.add(player_id)
            self.to_act.popleft()
            return self._record(player_id, ActionType.FOLD, 0)

        if action_type is ActionType.CHECK:
            if not legal.can_check:
                raise IllegalActionError(f"{player_id} cannot check; {legal.to_call} to call")
            self._has_acted_this_street.add(player_id)
            self._acted_since_full_raise.add(player_id)
            self.to_act.popleft()
            return self._record(player_id, ActionType.CHECK, 0)

        if action_type is ActionType.CALL:
            if not legal.can_call:
                raise IllegalActionError(f"{player_id} has nothing to call")
            put_in = legal.to_call
            self._commit(player, put_in)
            self._has_acted_this_street.add(player_id)
            self._acted_since_full_raise.add(player_id)
            self.to_act.popleft()
            return self._record(player_id, ActionType.CALL, put_in)

        if action_type in (ActionType.BET, ActionType.RAISE):
            return self._apply_wager(player, action_type, amount, legal)

        raise IllegalActionError(f"Unsupported action in a betting round: {action_type}")

    def apply_all_in(self, player_id: str) -> Action:
        """
        Convenience: push in as much as is legally possible right now.

        Note that in POT_LIMIT this may leave the player with chips still in
        their stack (not truly all-in) if their stack exceeds the pot-limit
        cap — that's correct pot-limit behaviour, not a bug: a player can
        never legally wager more than the pot allows in a single action,
        even if they have more chips than that behind.
        """
        legal = self.legal_actions(player_id)
        if self.current_bet == 0:
            if legal.can_bet:
                return self.apply(player_id, ActionType.BET, legal.bet_max)
        else:
            if legal.can_raise:
                return self.apply(player_id, ActionType.RAISE, legal.raise_max)
        if legal.can_call:
            return self.apply(player_id, ActionType.CALL)
        if legal.can_check:
            return self.apply(player_id, ActionType.CHECK)
        raise IllegalActionError(f"No legal all-in action available for {player_id}")

    def _apply_wager(
        self, player: PlayerBettingState, action_type: ActionType, amount: int, legal: LegalActions
    ) -> Action:
        if action_type is ActionType.BET:
            if not legal.can_bet:
                raise IllegalActionError(f"{player.player_id} cannot bet right now")
            if not (legal.bet_min <= amount <= legal.bet_max):
                raise IllegalActionError(
                    f"Bet amount {amount} out of legal range [{legal.bet_min}, {legal.bet_max}]"
                )
        else:
            if not legal.can_raise:
                raise IllegalActionError(f"{player.player_id} cannot raise right now")
            if not (legal.raise_min <= amount <= legal.raise_max):
                raise IllegalActionError(
                    f"Raise-to amount {amount} out of legal range [{legal.raise_min}, {legal.raise_max}]"
                )

        put_in = amount - player.street_contributed
        raise_increment = amount - self.current_bet
        is_complete = (
            raise_increment >= self.min_bet
            if self.current_bet == 0
            else raise_increment >= self.last_raise_size
        )

        self._commit(player, put_in)
        self.current_bet = amount
        self.raise_count += 1
        self._has_acted_this_street.add(player.player_id)

        if is_complete:
            self.last_raise_size = raise_increment
            self._acted_since_full_raise = {player.player_id}
        else:
            self._acted_since_full_raise.add(player.player_id)

        self._reopen_for_others(player.player_id)
        return self._record(player.player_id, action_type, put_in)

    # -- internals ------------------------------------------------------------

    def _commit(self, player: PlayerBettingState, amount: int) -> None:
        if amount < 0 or amount > player.stack:
            raise IllegalActionError(
                f"{player.player_id} cannot commit {amount}; stack is {player.stack}"
            )
        player.stack -= amount
        player.street_contributed += amount
        player.total_contributed += amount
        if player.stack == 0:
            player.is_all_in = True

    def _reopen_for_others(self, actor_id: str) -> None:
        start = self.players.index(self._by_id[actor_id])
        ordered = self.players[start + 1 :] + self.players[:start]
        self.to_act = deque(p.player_id for p in ordered if p.is_live)

    def _record(self, player_id: str, action_type: ActionType, amount: int) -> Action:
        action = Action(player_id=player_id, action_type=action_type, amount=amount)
        self.history.append(action)
        return action

    def _require_player(self, player_id: str) -> PlayerBettingState:
        try:
            return self._by_id[player_id]
        except KeyError as exc:
            raise BettingError(f"Unknown player_id: {player_id!r}") from exc
