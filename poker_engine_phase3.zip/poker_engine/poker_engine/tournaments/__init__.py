"""
tournaments — not yet implemented.

Phase 8 — SNG/MTT/KO/PKO/satellite structures, blind and break schedules, prize pools, table balancing/merging.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
