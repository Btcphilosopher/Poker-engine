"""
Table — seat management for a single table.

Handles seating, buy-ins, dealer-button rotation, and deriving the correct
action order for pre-flop vs. post-flop streets in blind-based (flop) games.

Deliberately out of scope here (see docs/roadmap.md):
  - Waiting lists / auto top-up / cash-game table limits enforcement beyond
    a basic buy-in range check — that's Phase 9 (Cash Games).
  - Blind schedules, rebuy/add-on *rules*, prize pools — Phase 8 (Tournaments).
  - Stud/draw action order (no button/blinds involved) — those variants
    derive their own order from the bring-in / dealer position directly
    when they're built in Phase 6.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from poker_engine.betting.button import advance_button, seats_from_button
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.players.player import Player


class TableError(Exception):
    pass


@dataclass
class Table:
    table_id: str
    max_seats: int
    min_buyin: Optional[int] = None
    max_buyin: Optional[int] = None
    seats: List[Optional[Player]] = field(default_factory=list)
    button_index: int = 0

    def __post_init__(self) -> None:
        if self.max_seats < 2:
            raise ValueError("max_seats must be at least 2")
        if not self.seats:
            self.seats = [None] * self.max_seats
        elif len(self.seats) != self.max_seats:
            raise ValueError("seats length must equal max_seats")
        if self.min_buyin is not None and self.max_buyin is not None:
            if self.min_buyin > self.max_buyin:
                raise ValueError("min_buyin cannot exceed max_buyin")

    # -- seating ----------------------------------------------------------

    def occupied_seats(self) -> List[Player]:
        return [p for p in self.seats if p is not None]

    def occupied_count(self) -> int:
        return len(self.occupied_seats())

    def empty_seat_indices(self) -> List[int]:
        return [i for i, p in enumerate(self.seats) if p is None]

    def find_player(self, player_id: str) -> Optional[Player]:
        for p in self.seats:
            if p is not None and p.player_id == player_id:
                return p
        return None

    def sit_down(
        self, player_id: str, display_name: str, buyin: int, *, seat_index: Optional[int] = None
    ) -> Player:
        if self.find_player(player_id) is not None:
            raise TableError(f"{player_id} is already seated at this table")
        if self.min_buyin is not None and buyin < self.min_buyin:
            raise TableError(f"Buy-in {buyin} is below the table minimum {self.min_buyin}")
        if self.max_buyin is not None and buyin > self.max_buyin:
            raise TableError(f"Buy-in {buyin} is above the table maximum {self.max_buyin}")

        if seat_index is None:
            empties = self.empty_seat_indices()
            if not empties:
                raise TableError("Table is full")
            seat_index = empties[0]
        else:
            if not (0 <= seat_index < self.max_seats):
                raise TableError(f"Seat index {seat_index} out of range")
            if self.seats[seat_index] is not None:
                raise TableError(f"Seat {seat_index} is already occupied")

        player = Player(player_id=player_id, display_name=display_name, stack=buyin, seat_index=seat_index)
        self.seats[seat_index] = player
        return player

    def stand_up(self, player_id: str) -> Player:
        player = self.find_player(player_id)
        if player is None:
            raise TableError(f"{player_id} is not seated at this table")
        self.seats[player.seat_index] = None
        player.seat_index = None
        return player

    # -- button / action order ----------------------------------------------------------

    def advance_button(self) -> int:
        self.button_index = advance_button(self._seat_ids(), self.button_index)
        return self.button_index

    def _seat_ids(self) -> List[Optional[str]]:
        return [p.player_id if p is not None else None for p in self.seats]

    def active_player_ids(self) -> List[str]:
        """Player IDs eligible for the next hand (ACTIVE status, stack > 0)."""
        return [p.player_id for p in self.occupied_seats() if p.is_active]

    def seats_from_button(self) -> List[str]:
        """
        Occupied player_ids starting at the button, in table order — includes
        sitting-out players (the button still rotates past their seat).
        """
        return seats_from_button(self._seat_ids(), self.button_index)

    def active_seats_from_button(self) -> List[str]:
        """seats_from_button(), filtered to only players active for the next hand."""
        active = set(self.active_player_ids())
        return [pid for pid in self.seats_from_button() if pid in active]

    def is_heads_up(self) -> bool:
        return len(self.active_player_ids()) == 2

    def preflop_action_order(self) -> List[str]:
        """
        Action order for a blind-based (flop) game's first betting round.
        Heads-up: button (small blind) acts first. Otherwise: everyone after
        the big blind, i.e. skip button/SB/BB, ending with the button.
        """
        order = self.active_seats_from_button()
        if len(order) < 2:
            raise TableError("Need at least 2 active players for action order")
        if len(order) == 2:
            return order  # [button/SB, other/BB] -- button acts first pre-flop
        return order[3:] + order[:3]

    def postflop_action_order(self) -> List[str]:
        """
        Action order for every betting round after the first, in a
        blind-based (flop) game. Heads-up: big blind acts first (reverse of
        pre-flop). Otherwise: everyone starting left of the button, ending
        with the button acting last.
        """
        order = self.active_seats_from_button()
        if len(order) < 2:
            raise TableError("Need at least 2 active players for action order")
        if len(order) == 2:
            return list(reversed(order))  # BB acts first post-flop
        return order[1:] + order[:1]

    # -- settlement ----------------------------------------------------------

    def settle_hand(self, betting_states: Dict[str, PlayerBettingState], payouts: Dict[str, int]) -> None:
        """
        Apply a completed hand's results back to persistent Player stacks:
        whatever's left in each player's per-hand betting state, plus
        whatever they won from the pots. Marks anyone left with 0 chips as
        eliminated (harmless no-op for cash games that immediately rebuy).
        """
        for player_id, betting_state in betting_states.items():
            player = self.find_player(player_id)
            if player is None:
                raise TableError(f"{player_id} is not seated at this table")
            player.apply_hand_result(betting_state.stack, payouts.get(player_id, 0))
