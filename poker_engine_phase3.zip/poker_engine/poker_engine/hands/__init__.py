"""
hands — not yet implemented.

Phase 4-6 — per-hand orchestration objects tying deck+evaluation+betting together for a single hand.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
