"""
variants — not yet implemented.

Phase 4-6 — BaseGame interface and one concrete class per variant (Holdem, Omaha, Stud, Draw, Badugi, HORSE, ...).

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
