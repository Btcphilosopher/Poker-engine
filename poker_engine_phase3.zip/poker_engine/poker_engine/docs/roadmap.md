# Roadmap

Status legend: ✅ done · 🔜 next · ⬜ not started

| Phase | Scope | Status |
|---|---|---|
| 1 | **Foundation** — cards, deck, hand evaluation (5-card, best-of-N, Omaha, Ace-to-5 low) | ✅ |
| 2 | **Betting engine** — blinds, antes, bring-in, pot manager with side pots, limit/pot-limit/no-limit raise rules, all-in handling | ✅ |
| 3 | **Dealer + table management** — shuffle/deal orchestration, street progression, pot distribution, table balancing | ✅ |
| 4 | Texas Hold'em (NL / Limit / Pot-Limit) end-to-end — first fully playable variant | 🔜 |
| 5 | Other flop games — Omaha, Omaha Hi-Lo, Short Deck (6+), Pineapple, Crazy Pineapple, Irish | ⬜ |
| 6 | Stud games (7-Stud, Stud Hi-Lo, Razz) + Draw games (5-Card Draw, 2-7 Triple Draw, Badugi) | ⬜ |
| 7 | Mixed games — HORSE rotation, general mixed-game framework | ⬜ |
| 8 | Tournament engine — SNG, freezeout, rebuy, KO/PKO, satellite, MTT, blind/break schedules, prize calculation, table balancing/merging | ⬜ |
| 9 | Cash games — ring games, buy-ins, seat reservations, waiting lists, auto top-up, table limits | ⬜ |
| 10 | AI framework (rule-based styles, Monte Carlo AI, CFR/NN interfaces) + Monte Carlo simulation engine (equity, range vs range, multi-threaded) | ⬜ |
| 11 | Statistics engine (VPIP/PFR/3-bet/aggression/BB-100/ROI/...) + hand history export + replay engine | ⬜ |
| 12 | Networking layer + REST API + WebSocket architecture | ⬜ |
| 13 | Hardening — full-suite coverage push, Docker, CI/CD, complete developer/API docs | ⬜ |

## Phase 1 deliverables

- `poker_engine/cards/` — `Card`, `Rank`, `Suit`
- `poker_engine/deck/` — `Deck` (standard/short/multi-deck, 3 shuffle modes)
- `poker_engine/evaluation/` — `evaluate_5`, `evaluate_best_of`,
  `evaluate_omaha`, `evaluate_low_5`, `evaluate_low_best_of`,
  `evaluate_omaha_low`, plus a throughput benchmark script
- 79 tests (unit + edge-case + property-based), 97% coverage
- Full package scaffold for every module named in the original spec, each
  stub documenting which phase will implement it

## Phase 2 deliverables

- `poker_engine/betting/structures.py` — `BettingStructure` (NL/PL/FL),
  `BlindLevel`
- `poker_engine/betting/actions.py` — `ActionType`, `Action` (hand-history
  log entry)
- `poker_engine/betting/player_state.py` — `PlayerBettingState`
- `poker_engine/betting/pot.py` — `compute_pots` (main + side pots via
  contribution layering), `distribute_pot` (split-pot chip division with
  the standard odd-chip-to-first-winner-left-of-button rule)
- `poker_engine/betting/round.py` — `BettingRound`, the core street state
  machine: turn order, legal-action computation, minimum-raise tracking,
  the "incomplete all-in raise doesn't reopen action" rule, pot-limit
  sizing, fixed-limit exact-size + raise-cap enforcement
- `poker_engine/betting/blinds.py` — blind/ante/bring-in/dead-blind
  posting, blind assignment (incl. heads-up), stud bring-in determination
- `poker_engine/betting/button.py` — dealer button rotation across seats
  (skipping empty seats)
- 105 new tests (unit, edge-case, property-based via Hypothesis, and a
  full multi-street integration test), bringing the suite to 184 tests /
  95%+ overall coverage

Real bugs caught and fixed during Phase 2's own test-writing (see
architecture.md for details): a short-stacked player could incorrectly be
offered "raise" for less than the current bet; a pot-limit sizing fallback
could balloon the legal max bet to a player's entire stack in a degenerate
zero-pot edge case.

## Phase 3 deliverables

- `poker_engine/players/player.py` — `Player` (persistent, across-hands
  state: name, seat, status, stack) and `PlayerStatus`, distinct from
  `PlayerBettingState` (ephemeral, per-hand)
- `poker_engine/tables/table.py` — `Table`: seating, buy-in range
  enforcement, dealer button rotation, and correct pre-flop/post-flop
  action-order derivation (including 3-handed and heads-up special cases)
- `poker_engine/tables/balancing.py` — `balance_tables` (keep multi-table
  player counts within one of each other), `find_table_to_break` /
  `plan_table_break` (standard tournament table consolidation)
- `poker_engine/dealer/dealing.py` — `deal_hole_cards` (round-robin),
  `deal_community_cards` (flop/turn/river with burns), `deal_stud_street`,
  `draw_replacement_cards`, and `advance_to_next_street` (see the footgun
  it prevents, below)
- `poker_engine/dealer/showdown.py` — `resolve_showdown` (pots → winners →
  payouts, single-ranking games), `determine_reveal_order`,
  `last_aggressor_of`
- 80 new tests (unit, edge-case, property-based, and a full end-to-end
  hand played through the real public API from seating to settlement),
  bringing the suite to 264 tests / 96% overall coverage

A real bug was caught while building Phase 3's own integration test: a
scratch script called `player.start_new_street()` (resetting
`street_contributed`) *before* reading `BettingRound.total_pot()` to carry
forward as the next street's pot — silently zeroing the carried pot with
no error, because `total_pot()` is a live computation over mutable state,
not a snapshot. Fixed at the API level with `advance_to_next_street()`,
which captures the pot and resets state as one atomic operation, so this
mistake isn't available to make. See architecture.md for the full story.

## Notes for the next session

- Phase 4 (Texas Hold'em end-to-end) is the natural next step, and now has
  everything it needs: `Table` for seating/button/action-order, `Deck` +
  `dealer.dealing` for cards, `BettingRound` for each street,
  `dealer.showdown.resolve_showdown` for payouts, `Table.settle_hand` for
  applying results. `tests/test_dealer_integration.py` is effectively a
  worked example of the exact flow a `TexasHoldem` class should wrap into
  a clean, reusable API (deal → bet → repeat per street → showdown →
  settle), with hand-history logging and legal-action queries exposed to
  callers.
- The 7-card evaluator's lookup-table optimisation (see architecture.md) is
  still deferred, now with a concrete reason to revisit it: Phase 4's
  real gameplay loop calls `evaluate_best_of` once per contested showdown,
  which is finally the right load to benchmark against.
- Hi-Lo split-pot resolution (`resolve_showdown` currently only handles
  single-ranking pots) is explicitly deferred to Phase 5, where Omaha
  Hi-Lo's low-hand qualification rules will motivate its actual shape,
  rather than guessing at an API now.
