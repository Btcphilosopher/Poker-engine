"""
Showdown resolution.

Ties together Phase 1 (hand evaluation), Phase 2 (pot computation and
distribution), and this phase's dealing/table machinery into "given these
players' final hands, who wins what."

Scope note: this module resolves each pot to a SINGLE winning group (the
best hand among that pot's eligible players, split evenly among ties).
Hi-Lo split-pot games (Omaha Hi-Lo, Stud Hi-Lo, Razz) need each pot divided
between a high winner and a low winner — that's naturally an extension of
`resolve_showdown` (evaluate high and low separately, distribute each half
independently), deferred to Phase 5/6 where those variants' low-hand
qualification rules actually get wired in, rather than speculatively
building it now against no concrete variant.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from poker_engine.betting.actions import ActionType
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.betting.pot import Pot, compute_pots, distribute_pot
from poker_engine.betting.round import BettingRound
from poker_engine.evaluation.hand_category import HandResult


class ShowdownError(Exception):
    pass


def last_aggressor_of(round_: BettingRound) -> Optional[str]:
    """The last player to make a COMPLETE or incomplete bet/raise on this street, if any."""
    for action in reversed(round_.history):
        if action.action_type in (ActionType.BET, ActionType.RAISE):
            return action.player_id
    return None


def determine_reveal_order(action_order_final_street: Sequence[str], last_aggressor: Optional[str]) -> List[str]:
    """
    Who shows their hand first at showdown, and in what order.

    If someone bet or raised on the final street, they show first (they
    "have the goods" or are bluffing — either way, they show), then it
    proceeds around the table from there. If everyone checked the final
    street, the first player to act shows first, in normal action order.
    """
    order = list(action_order_final_street)
    if last_aggressor is None or last_aggressor not in order:
        return order
    idx = order.index(last_aggressor)
    return order[idx:] + order[:idx]


@dataclass(frozen=True, slots=True)
class PotOutcome:
    pot: Pot
    winners: Tuple[str, ...]
    payouts: Dict[str, int]


@dataclass(frozen=True, slots=True)
class HandOutcome:
    pot_outcomes: Tuple[PotOutcome, ...]
    total_payouts: Dict[str, int]

    @property
    def total_awarded(self) -> int:
        return sum(self.total_payouts.values())


def resolve_showdown(
    players: Sequence[PlayerBettingState],
    hand_results: Dict[str, HandResult],
    order_from_button: Sequence[str],
) -> HandOutcome:
    """
    Build main/side pots from `players`' contributions, determine the
    winner(s) of each from `hand_results`, and split-distribute each pot.

    `hand_results` only needs entries for players who actually reach
    showdown with more than one live contender — an uncontested pot (a
    single eligible player, everyone else folded) is awarded to that player
    directly without requiring their hand to be evaluated at all, matching
    how a real dealer never asks a player to show when nobody else is left
    to contest the pot.
    """
    pots = compute_pots(players)
    pot_outcomes: List[PotOutcome] = []
    total_payouts: Dict[str, int] = defaultdict(int)

    for pot in pots:
        if not pot.eligible_player_ids:
            pot_outcomes.append(PotOutcome(pot=pot, winners=(), payouts={}))
            continue

        if len(pot.eligible_player_ids) == 1:
            winners: Tuple[str, ...] = pot.eligible_player_ids
        else:
            missing = [pid for pid in pot.eligible_player_ids if pid not in hand_results]
            if missing:
                raise ShowdownError(f"Missing hand_results for contested pot eligible players: {missing}")
            best = max(hand_results[pid] for pid in pot.eligible_player_ids)
            winners = tuple(pid for pid in pot.eligible_player_ids if hand_results[pid] == best)

        payouts = distribute_pot(pot, list(winners), order_from_button)
        pot_outcomes.append(PotOutcome(pot=pot, winners=winners, payouts=payouts))
        for pid, amount in payouts.items():
            total_payouts[pid] += amount

    return HandOutcome(pot_outcomes=tuple(pot_outcomes), total_payouts=dict(total_payouts))
