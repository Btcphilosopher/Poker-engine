import pytest

from poker_engine.betting import BettingStructure, BlindLevel


def test_blind_level_valid_construction():
    level = BlindLevel(small_blind=10, big_blind=20, ante=5, small_bet=20, big_bet=40)
    assert level.small_blind == 10
    assert level.big_blind == 20
    assert level.ante == 5


def test_blind_level_defaults():
    level = BlindLevel(small_blind=5, big_blind=10)
    assert level.ante == 0
    assert level.small_bet is None
    assert level.big_bet is None


def test_blind_level_rejects_zero_or_negative_small_blind():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=0, big_blind=10)


def test_blind_level_rejects_zero_or_negative_big_blind():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=5, big_blind=0)


def test_blind_level_rejects_small_blind_exceeding_big_blind():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=20, big_blind=10)


def test_blind_level_rejects_negative_ante():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=5, big_blind=10, ante=-1)


def test_betting_structure_values():
    assert BettingStructure.NO_LIMIT.value == "no_limit"
    assert BettingStructure.POT_LIMIT.value == "pot_limit"
    assert BettingStructure.FIXED_LIMIT.value == "fixed_limit"
