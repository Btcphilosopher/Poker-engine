import pytest

from poker_engine.deck import Deck, DeckExhaustedError


def test_standard_deck_has_52_unique_cards():
    d = Deck()
    assert d.total_cards == 52
    assert len(set(d.peek_draw_pile())) == 52


def test_short_deck_has_36_unique_cards_six_and_up():
    d = Deck(short_deck=True)
    assert d.total_cards == 36
    ranks = {c.rank.value for c in d.peek_draw_pile()}
    assert min(ranks) == 6
    assert max(ranks) == 14


def test_multi_deck_count():
    d = Deck(deck_count=2)
    assert d.total_cards == 104


def test_deck_count_must_be_positive():
    with pytest.raises(ValueError):
        Deck(deck_count=0)


def test_deal_reduces_draw_pile_and_tracks_dealt():
    d = Deck()
    hand = d.deal(2)
    assert len(hand) == 2
    assert d.cards_remaining() == 50
    assert set(hand) <= set(d.dealt_cards)


def test_deal_one():
    d = Deck()
    card = d.deal_one()
    assert d.cards_remaining() == 51
    assert card in d.dealt_cards


def test_burn_reduces_draw_pile_and_tracks_burned():
    d = Deck()
    burned = d.burn(1)
    assert len(burned) == 1
    assert d.cards_remaining() == 51
    assert burned == d.burned_cards


def test_deal_more_than_remaining_raises():
    d = Deck()
    d.deal(50)
    with pytest.raises(DeckExhaustedError):
        d.deal(3)


def test_burn_more_than_remaining_raises():
    d = Deck()
    d.deal(51)
    with pytest.raises(DeckExhaustedError):
        d.burn(2)


def test_reset_restores_full_deck():
    d = Deck()
    d.deal(10)
    d.burn(1)
    d.reset()
    assert d.cards_remaining() == 52
    assert d.dealt_cards == []
    assert d.burned_cards == []


def test_seeded_shuffle_is_deterministic():
    d1 = Deck()
    d1.shuffle(seed=42)
    order1 = d1.peek_draw_pile()

    d2 = Deck()
    d2.shuffle(seed=42)
    order2 = d2.peek_draw_pile()

    assert order1 == order2


def test_different_seeds_differ():
    d1 = Deck()
    d1.shuffle(seed=1)
    d2 = Deck()
    d2.shuffle(seed=2)
    assert d1.peek_draw_pile() != d2.peek_draw_pile()


def test_shuffle_preserves_all_cards():
    d = Deck()
    before = set(d.peek_draw_pile())
    d.shuffle(seed=7)
    after = set(d.peek_draw_pile())
    assert before == after


def test_secure_shuffle_preserves_all_cards_and_changes_order():
    d = Deck()
    before = d.peek_draw_pile()
    d.shuffle(secure=True)
    after = d.peek_draw_pile()
    assert set(before) == set(after)
    # Astronomically unlikely to be identical order if actually shuffled.
    assert before != after


def test_secure_shuffle_ignores_seed():
    # Should not raise, and secure takes precedence over any seed passed.
    d = Deck()
    d.shuffle(seed=123, secure=True)
    assert d.cards_remaining() == 52
