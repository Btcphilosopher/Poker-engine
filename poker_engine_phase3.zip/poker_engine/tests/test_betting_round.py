import pytest

from poker_engine.betting import (
    ActionType,
    BettingRound,
    BettingStructure,
    IllegalActionError,
    NotPlayersTurnError,
    PlayerBettingState,
    post_big_blind,
    post_small_blind,
)


def preflop_table(stacks=(1000, 1000, 1000), sb_amt=10, bb_amt=20):
    """UTG, SB, BB in that action order; SB/BB already posted."""
    utg = PlayerBettingState("utg", stack=stacks[0])
    sb = PlayerBettingState("sb", stack=stacks[1])
    bb = PlayerBettingState("bb", stack=stacks[2])
    post_small_blind(sb, sb_amt)
    post_big_blind(bb, bb_amt)
    return utg, sb, bb


# ---------------------------------------------------------------------------
# basic turn order / completion
# ---------------------------------------------------------------------------

def test_turn_order_enforced():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    with pytest.raises(NotPlayersTurnError):
        r.apply("sb", ActionType.CALL)


def test_check_around_completes_round_when_bb_gets_option():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("utg", ActionType.CALL)  # limp
    assert not r.is_betting_complete()
    r.apply("sb", ActionType.CALL)
    assert not r.is_betting_complete()  # BB still has an option
    assert r.legal_actions("bb").can_check
    assert r.legal_actions("bb").can_raise
    r.apply("bb", ActionType.CHECK)
    assert r.is_betting_complete()


def test_bb_option_to_raise_after_limps():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("utg", ActionType.CALL)
    r.apply("sb", ActionType.CALL)
    r.apply("bb", ActionType.RAISE, 60)
    assert r.current_bet == 60
    assert not r.is_betting_complete()  # utg/sb must respond to the raise


def test_fold_removes_player_from_action():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("utg", ActionType.FOLD)
    assert r.next_to_act() == "sb"
    r.apply("sb", ActionType.CALL)
    r.apply("bb", ActionType.CHECK)
    assert r.is_betting_complete()


def test_cannot_check_when_facing_a_bet():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    with pytest.raises(IllegalActionError):
        r.apply("utg", ActionType.CHECK)


def test_cannot_fold_with_nothing_to_call():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("utg", ActionType.CALL)
    r.apply("sb", ActionType.CALL)
    with pytest.raises(IllegalActionError):
        r.apply("bb", ActionType.FOLD)


def test_unknown_player_raises():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    with pytest.raises(Exception):
        r.legal_actions("ghost")


# ---------------------------------------------------------------------------
# minimum raise sizing
# ---------------------------------------------------------------------------

def test_min_raise_is_big_blind_preflop():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    legal = r.legal_actions("utg")
    assert legal.raise_min == 40  # call 20 + raise by one more BB (20)


def test_min_raise_tracks_size_of_previous_raise_not_just_bb():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("utg", ActionType.RAISE, 60)  # raise of 40 over the BB's 20
    legal = r.legal_actions("sb")
    assert legal.raise_min == 100  # 60 + 40, not 60 + 20


def test_raise_below_minimum_rejected():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    with pytest.raises(IllegalActionError):
        r.apply("utg", ActionType.RAISE, 30)  # must be >= 40


def test_opening_bet_below_min_bet_rejected_unless_all_in():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=1000)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=20)
    with pytest.raises(IllegalActionError):
        r.apply("p1", ActionType.BET, 10)


def test_short_all_in_opening_bet_is_legal_and_full_action_resumes():
    p1 = PlayerBettingState("p1", stack=10)  # can't make a full 20 min-bet
    p2 = PlayerBettingState("p2", stack=1000)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("p1", ActionType.BET, 10)
    assert p1.is_all_in
    # p2 has never acted, so they get full options despite the short bet.
    legal = r.legal_actions("p2")
    assert legal.can_call
    assert legal.can_raise


# ---------------------------------------------------------------------------
# incomplete (short all-in) raise does NOT reopen action for prior callers
# ---------------------------------------------------------------------------

def test_incomplete_raise_does_not_reopen_action_for_players_who_already_called():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=30)  # will go short all-in
    c = PlayerBettingState("c", stack=1000)
    r = BettingRound([a, b, c], BettingStructure.NO_LIMIT, min_bet=20)

    r.apply("a", ActionType.BET, 100)  # complete opening bet
    r.apply("b", ActionType.CALL)  # b can only call 30 (short call, not a raise)
    assert b.is_all_in
    assert r.current_bet == 100  # unchanged: a short CALL never raises current_bet

    r.apply("c", ActionType.RAISE, 300)  # complete raise (200 increment >= 100)
    assert r.current_bet == 300
    # 'a' already acted (bet) — must now respond to a real full raise,
    # so 'a' DOES get raise options again here (it was a complete raise).
    legal_a = r.legal_actions("a")
    assert legal_a.can_raise


def test_incomplete_raise_restricts_prior_actor_to_call_or_fold():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=1000)
    c = PlayerBettingState("c", stack=130)  # will make a short (incomplete) raise
    r = BettingRound([a, b, c], BettingStructure.NO_LIMIT, min_bet=20)

    r.apply("a", ActionType.BET, 100)  # complete, last_raise_size becomes 100
    r.apply("b", ActionType.CALL)  # b has now acted at the 100 level
    # c goes all-in for 130 total: raise increment is only 30 (<100), incomplete.
    r.apply("c", ActionType.RAISE, 130)
    assert c.is_all_in
    assert r.current_bet == 130

    # 'a' already acted (bet) before this incomplete raise -> call/fold only.
    legal_a = r.legal_actions("a")
    assert legal_a.can_call
    assert legal_a.can_fold
    assert legal_a.can_raise is False

    # 'b' already acted (called) before this incomplete raise -> call/fold only.
    legal_b = r.legal_actions("b")
    assert legal_b.can_raise is False
    assert legal_b.can_call


def test_player_who_has_not_acted_yet_keeps_raise_option_despite_incomplete_raise():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=130)  # short, will make incomplete raise
    c = PlayerBettingState("c", stack=1000)  # hasn't acted yet
    r = BettingRound([a, b, c], BettingStructure.NO_LIMIT, min_bet=20)

    r.apply("a", ActionType.BET, 100)
    r.apply("b", ActionType.RAISE, 130)  # incomplete raise (increment 30 < 100)
    assert r.current_bet == 130

    # 'c' has never acted this street; the incomplete raise doesn't take
    # away options they never used.
    legal_c = r.legal_actions("c")
    assert legal_c.can_raise is True
    assert legal_c.raise_min == 230  # 130 + last_raise_size(still 100)


def test_very_short_stack_cannot_raise_only_call_all_in_or_fold():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=15)  # can't even cover a's bet of 100
    r = BettingRound([a, b], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("a", ActionType.BET, 100)
    legal_b = r.legal_actions("b")
    assert legal_b.can_raise is False
    assert legal_b.can_call is True
    assert legal_b.to_call == 15  # capped by stack


# ---------------------------------------------------------------------------
# pot-limit sizing
# ---------------------------------------------------------------------------

def test_pot_limit_max_raise_matches_standard_formula():
    # Blinds 1/2, UTG acting first, nobody else has acted. Pot right now is
    # sb(1) + bb(2) = 3. UTG's call brings it to 5, so max raise-to = 2 + 5 = 7.
    utg, sb, bb = preflop_table(sb_amt=1, bb_amt=2)
    r = BettingRound([utg, sb, bb], BettingStructure.POT_LIMIT, min_bet=2)
    legal = r.legal_actions("utg")
    assert legal.raise_min == 4  # standard min-raise: call 2 + raise 2 = 4
    assert legal.raise_max == 7  # pot-sized raise


def test_pot_limit_max_raise_accounts_for_carried_pot_from_prior_streets():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=1000)
    # Flop betting round, pot already has 40 chips from preflop.
    r = BettingRound([p1, p2], BettingStructure.POT_LIMIT, min_bet=10, carried_pot=40)
    legal = r.legal_actions("p1")
    # Opening bet: bet_max = pot-sized bet = carried_pot(40) + street_pot(0) = 40
    # (current_bet is 0 here so pot_after_call = total_pot()+to_call = 40+0=40,
    # and pot_limit_amount = current_bet(0) + 40 = 40).
    assert legal.bet_max == 40


def test_pot_limit_raise_after_a_bet_matches_formula():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=1000)
    # Simulates a flop round carrying 20 over from preflop.
    r = BettingRound([p1, p2], BettingStructure.POT_LIMIT, min_bet=10, carried_pot=20)
    legal_open = r.legal_actions("p1")
    assert legal_open.bet_max == 20  # pot-sized opening bet: 0 + (carried 20 + 0 call)
    r.apply("p1", ActionType.BET, 20)  # pot is now 20(carried) + 20(street) = 40
    legal = r.legal_actions("p2")
    # to_call = 20; pot_after_call = total_pot(40) + to_call(20) = 60;
    # pot_limit_amount = current_bet(20) + 60 = 80.
    assert legal.raise_max == 80
    assert legal.raise_min == 40  # current_bet(20) + last_raise_size(20, the opening bet)


def test_pot_limit_caps_wager_below_players_full_stack():
    p1 = PlayerBettingState("p1", stack=1_000_000)
    p2 = PlayerBettingState("p2", stack=1_000_000)
    # A real pot-limit street always starts with something already in the
    # pot (blinds/antes carried forward); simulate that with carried_pot.
    r = BettingRound([p1, p2], BettingStructure.POT_LIMIT, min_bet=10, carried_pot=10)
    legal = r.legal_actions("p1")
    assert legal.bet_max == 10  # pot-limit cap, nowhere near their real stack


def test_pot_limit_apply_all_in_may_not_be_fully_all_in():
    p1 = PlayerBettingState("p1", stack=1_000_000)
    p2 = PlayerBettingState("p2", stack=1_000_000)
    r = BettingRound([p1, p2], BettingStructure.POT_LIMIT, min_bet=10, carried_pot=100)
    r.apply_all_in("p1")
    assert p1.stack > 0  # correct PL behaviour: capped by the pot, not truly all-in
    assert p1.street_contributed == 100


def test_pot_limit_with_truly_empty_pot_disallows_betting_rather_than_ballooning_to_full_stack():
    # Regression test: an earlier version of the sizing fallback could,
    # in this exact degenerate case (a pot-limit street with nothing at all
    # in the pot yet — unrealistic in real play, but must still be handled
    # safely), incorrectly let a player bet their ENTIRE stack instead of
    # being capped by the (zero) pot. It must never do that.
    p1 = PlayerBettingState("p1", stack=1_000_000)
    p2 = PlayerBettingState("p2", stack=1_000_000)
    r = BettingRound([p1, p2], BettingStructure.POT_LIMIT, min_bet=10, carried_pot=0)
    legal = r.legal_actions("p1")
    assert legal.can_bet is False
    assert legal.bet_max != 1_000_000


# ---------------------------------------------------------------------------
# fixed limit
# ---------------------------------------------------------------------------

def test_fixed_limit_bet_size_is_exact():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=1000)
    r = BettingRound([p1, p2], BettingStructure.FIXED_LIMIT, min_bet=10)
    legal = r.legal_actions("p1")
    assert legal.bet_min == legal.bet_max == 10
    with pytest.raises(IllegalActionError):
        r.apply("p1", ActionType.BET, 20)
    r.apply("p1", ActionType.BET, 10)


def test_fixed_limit_raise_cap_stops_after_n_raises():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=1000)
    r = BettingRound([p1, p2], BettingStructure.FIXED_LIMIT, min_bet=10, cap_raises=4)
    r.apply("p1", ActionType.BET, 10)  # raise_count=1
    r.apply("p2", ActionType.RAISE, 20)  # raise_count=2
    r.apply("p1", ActionType.RAISE, 30)  # raise_count=3
    r.apply("p2", ActionType.RAISE, 40)  # raise_count=4, cap reached
    legal = r.legal_actions("p1")
    assert legal.can_raise is False
    assert legal.can_call is True


def test_fixed_limit_short_all_in_raise_for_less_than_full_bet():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=1000)
    p3 = PlayerBettingState("p3", stack=15)  # can't make a full 10-on-top raise
    r = BettingRound([p1, p2, p3], BettingStructure.FIXED_LIMIT, min_bet=10)
    r.apply("p1", ActionType.BET, 10)
    r.apply("p2", ActionType.CALL)
    legal_p3 = r.legal_actions("p3")
    assert legal_p3.raise_min == legal_p3.raise_max == 15  # short all-in raise


# ---------------------------------------------------------------------------
# all-in / commit invariants
# ---------------------------------------------------------------------------

def test_call_for_exact_stack_marks_all_in():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=50)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("p1", ActionType.BET, 50)
    r.apply("p2", ActionType.CALL)
    assert p2.is_all_in
    assert p2.stack == 0


def test_no_limit_bet_max_is_full_stack():
    p1 = PlayerBettingState("p1", stack=500)
    p2 = PlayerBettingState("p2", stack=500)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=20)
    legal = r.legal_actions("p1")
    assert legal.bet_max == 500


def test_total_pot_includes_carried_pot():
    p1 = PlayerBettingState("p1", stack=1000)
    p2 = PlayerBettingState("p2", stack=1000)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=20, carried_pot=75)
    r.apply("p1", ActionType.BET, 20)
    assert r.street_pot() == 20
    assert r.total_pot() == 95


def test_history_records_all_actions_in_order():
    utg, sb, bb = preflop_table()
    r = BettingRound([utg, sb, bb], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("utg", ActionType.CALL)
    r.apply("sb", ActionType.FOLD)
    r.apply("bb", ActionType.CHECK)
    assert [a.action_type for a in r.history] == [
        ActionType.CALL,
        ActionType.FOLD,
        ActionType.CHECK,
    ]


def test_duplicate_player_id_rejected():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p1", stack=100)
    with pytest.raises(ValueError):
        BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=20)


def test_zero_or_negative_min_bet_rejected():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    with pytest.raises(ValueError):
        BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=0)
