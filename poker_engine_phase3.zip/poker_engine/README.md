# Poker Engine

A production-grade, multi-variant poker engine core, built in phases. This
repository currently contains **Phase 1: Foundation**, **Phase 2: Betting
Engine**, and **Phase 3: Dealer + Table Management** — cards/evaluation,
the full betting state machine, and the seating/dealing/showdown machinery
that Phase 4 will wrap into the first fully playable variant.

See [`docs/roadmap.md`](docs/roadmap.md) for the full 13-phase build plan and
current status, and [`docs/architecture.md`](docs/architecture.md) for design
notes — including real bugs caught and fixed during each phase's own
test-writing, documented in detail because they're instructive.

## What's implemented

**Phase 1 — Foundation**
- **Cards** (`poker_engine.cards`) — immutable `Card`, `Rank`, `Suit`, with
  string parsing/formatting (`Card.from_str("Ah")`, `str(card)`).
- **Deck** (`poker_engine.deck`) — standard 52-card and short (6+) 36-card
  decks, multi-deck support, three shuffle strategies (secure/CSPRNG, seeded/
  deterministic, standard), deal, burn, reset.
- **Evaluation** (`poker_engine.evaluation`) — full 5-card hand evaluation
  (all 9 categories, complete tie-breaking), best-of-N (7-card hold'em/stud),
  Omaha-restricted evaluation (exactly 2 hole + 3 board), and Ace-to-5 low
  evaluation (Razz / Hi-Lo split, with configurable qualifier).

**Phase 2 — Betting Engine**
- **`BettingRound`** (`poker_engine.betting`) — the core street state
  machine: turn order, legal-action computation, correct minimum-raise
  tracking (including the "incomplete all-in raise doesn't reopen the
  action" rule), pot-limit sizing, fixed-limit exact sizing + raise cap,
  all-in handling.
- **Pots** — `compute_pots` builds main + side pots from contributions
  (handles any number of simultaneous all-ins at different stack depths);
  `distribute_pot` splits a pot evenly with the standard odd-chip rule.
- **Forced bets** — blinds, antes, bring-in, dead blinds, blind assignment
  (including heads-up), stud bring-in determination (low or high card).
- **Button** — dealer button rotation across seats, skipping empty ones.

**Phase 3 — Dealer + Table Management**
- **`Player`** (`poker_engine.players`) — persistent, across-hands player
  state (name, seat, status, stack), separate from the ephemeral
  per-hand `PlayerBettingState`.
- **`Table`** (`poker_engine.tables`) — seating, buy-in range enforcement,
  dealer button rotation, and correct pre-flop/post-flop action-order
  derivation for any table size, including heads-up and 3-handed.
- **Table balancing** — `balance_tables` keeps multi-table player counts
  within one of each other; `find_table_to_break`/`plan_table_break`
  handle standard tournament table consolidation.
- **Dealing** (`poker_engine.dealer`) — round-robin hole cards, community
  cards with burns, stud streets, draw replacements.
- **Showdown** — `resolve_showdown` ties pot computation to hand evaluation
  to determine winners and payouts; `determine_reveal_order` and
  `last_aggressor_of` for showdown procedure.

264 tests total, 96%+ coverage (unit, edge-case, property-based via
Hypothesis, and a full end-to-end hand played through the real public API
from seating to settlement). See `tests/`.

## Quickstart

```bash
pip install -e ".[dev]"
pytest
```

```python
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.betting import BettingRound, BettingStructure, ActionType, post_small_blind, post_big_blind
from poker_engine.dealer import deal_hole_cards, deal_community_cards, advance_to_next_street, resolve_showdown
from poker_engine.evaluation import evaluate_best_of

# Seat players at a table
table = Table(table_id="main", max_seats=6)
table.sit_down("alice", "Alice", 1000, seat_index=0)
table.sit_down("bob", "Bob", 1000, seat_index=1)
table.sit_down("carol", "Carol", 1000, seat_index=2)

# Snapshot persistent stacks into per-hand betting state and post blinds
players_bs = {pid: table.find_player(pid).to_betting_state() for pid in table.active_player_ids()}
post_small_blind(players_bs["bob"], 10)
post_big_blind(players_bs["carol"], 20)

# Deal and run a betting round
deck = Deck()
deck.shuffle(seed=42)
hole = deal_hole_cards(deck, table.postflop_action_order(), 2)

preflop = BettingRound(
    [players_bs[pid] for pid in table.preflop_action_order()], BettingStructure.NO_LIMIT, min_bet=20
)
preflop.apply("alice", ActionType.CALL)
preflop.apply("bob", ActionType.CALL)
preflop.apply("carol", ActionType.CHECK)
carried = advance_to_next_street(preflop)  # safe: captures the pot before resetting state

flop = deal_community_cards(deck, 3)
# ... run flop/turn/river BettingRounds the same way ...

# At showdown: resolve pots against evaluated hands, then settle the table
board = flop.cards  # + turn + river in a real hand
hand_results = {pid: evaluate_best_of(hole[pid] + board) for pid in hole}
outcome = resolve_showdown(list(players_bs.values()), hand_results, order_from_button=table.seats_from_button())
table.settle_hand(players_bs, outcome.total_payouts)
```

See `tests/test_dealer_integration.py` for this pattern played out in full
across all four streets.

## Benchmark

```bash
python3 -m poker_engine.evaluation.benchmark
```

Current throughput (single-threaded, no lookup-table optimisation yet):
~100K hands/sec for `evaluate_5`, ~5K hands/sec for `evaluate_best_of` on
7 cards (brute-force over the 21 five-card combinations). A perfect-hash
lookup table is planned as a hardening pass — see the roadmap.

## Project layout

```
poker_engine/
    cards/        implemented — Card, Rank, Suit
    deck/         implemented — Deck
    evaluation/   implemented — evaluators + benchmark
    betting/      implemented — BettingRound, pots, blinds, button
    players/      implemented — Player, PlayerStatus
    tables/       implemented — Table, multi-table balancing
    dealer/       implemented — dealing mechanics, showdown resolution
    hands/        scaffolded — Phase 4-6
    variants/     scaffolded — Phase 4-6
    tournaments/  scaffolded — Phase 8
    ai/           scaffolded — Phase 10
    simulation/   scaffolded — Phase 10
    statistics/   scaffolded — Phase 11
    network/      scaffolded — Phase 12
    api/          scaffolded — Phase 12
tests/
```

Every scaffolded module has a docstring in its `__init__.py` naming which
phase will fill it in.
