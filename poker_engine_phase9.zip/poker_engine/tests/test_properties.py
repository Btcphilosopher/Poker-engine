"""
Property-based tests.

These check invariants that must hold for *any* input, rather than specific
worked examples — e.g. "the best 5-of-7 hand is never worse than any single
5-card subset of those 7 cards", across thousands of randomly generated
hands, not just the hand-crafted cases in test_evaluator.py.
"""

from itertools import combinations

from hypothesis import given, settings, strategies as st

from poker_engine.cards import Card, Rank, Suit
from poker_engine.deck import Deck
from poker_engine.evaluation import HandCategory, evaluate_5, evaluate_best_of

ALL_CARDS = [Card(r, s) for r in Rank for s in Suit]


@st.composite
def distinct_cards(draw, n: int):
    """A random sample of n distinct cards from a single 52-card deck."""
    indices = draw(st.lists(st.integers(0, 51), min_size=n, max_size=n, unique=True))
    return [ALL_CARDS[i] for i in indices]


@given(distinct_cards(5))
@settings(max_examples=300)
def test_evaluate_5_never_crashes_and_returns_valid_category(cards):
    result = evaluate_5(cards)
    assert isinstance(result.category, HandCategory)
    assert 1 <= int(result.category) <= 9
    assert len(result.cards) == 5
    assert set(result.cards) == set(cards)


@given(distinct_cards(7))
@settings(max_examples=200)
def test_best_of_seven_dominates_every_five_card_subset(cards):
    best = evaluate_best_of(cards)
    for combo in combinations(cards, 5):
        assert best >= evaluate_5(list(combo))


@given(distinct_cards(5))
@settings(max_examples=300)
def test_hand_result_is_reflexive_and_self_consistent(cards):
    a = evaluate_5(cards)
    b = evaluate_5(list(reversed(cards)))  # card order must not matter
    assert a == b
    assert not (a < b)
    assert not (a > b)


@given(st.integers(min_value=0, max_value=2**31 - 1))
@settings(max_examples=50)
def test_seeded_shuffle_is_always_a_permutation_of_the_full_deck(seed):
    d = Deck()
    original = set(d.peek_draw_pile())
    d.shuffle(seed=seed)
    shuffled = d.peek_draw_pile()
    assert len(shuffled) == 52
    assert set(shuffled) == original


@given(st.integers(min_value=1, max_value=52))
@settings(max_examples=50)
def test_deal_then_remaining_plus_dealt_equals_full_deck(n):
    d = Deck()
    dealt = d.deal(n)
    assert len(dealt) == n
    assert d.cards_remaining() == 52 - n
    assert set(dealt) | set(d.peek_draw_pile()) == set(ALL_CARDS)
    assert set(dealt).isdisjoint(set(d.peek_draw_pile()))
