import pytest

from poker_engine.tournaments.bounties import BountyConfig, BountyError, BountyTracker


def test_bounty_config_rejects_non_positive_amount():
    with pytest.raises(BountyError):
        BountyConfig(bounty_amount=0)


def test_bounty_config_rejects_invalid_progressive_split():
    with pytest.raises(BountyError):
        BountyConfig(bounty_amount=50, progressive=True, progressive_split=1.5)
    with pytest.raises(BountyError):
        BountyConfig(bounty_amount=50, progressive=True, progressive_split=-0.1)


def test_bounty_tracker_starts_everyone_at_base_bounty():
    config = BountyConfig(bounty_amount=50)
    tracker = BountyTracker(config, ["a", "b", "c"])
    assert tracker.bounty_of("a") == 50
    assert tracker.bounty_of("b") == 50


def test_bounty_tracker_unknown_player_has_zero_bounty():
    config = BountyConfig(bounty_amount=50)
    tracker = BountyTracker(config, ["a"])
    assert tracker.bounty_of("ghost") == 0


def test_standard_knockout_awards_full_bounty_as_cash():
    config = BountyConfig(bounty_amount=50, progressive=False)
    tracker = BountyTracker(config, ["a", "b"])
    cash = tracker.record_knockout(eliminator_id="a", eliminated_id="b")
    assert cash == 50
    assert tracker.total_bounty_cash_won("a") == 50
    assert tracker.bounty_of("a") == 50  # eliminator's own bounty unaffected in standard KO


def test_eliminated_player_bounty_is_removed():
    config = BountyConfig(bounty_amount=50)
    tracker = BountyTracker(config, ["a", "b"])
    tracker.record_knockout("a", "b")
    assert tracker.bounty_of("b") == 0


def test_progressive_knockout_splits_cash_and_growth():
    config = BountyConfig(bounty_amount=100, progressive=True, progressive_split=0.5)
    tracker = BountyTracker(config, ["a", "b"])
    cash = tracker.record_knockout(eliminator_id="a", eliminated_id="b")
    assert cash == 50  # half paid immediately
    assert tracker.bounty_of("a") == 150  # own 100 + half of collected (50)
    assert tracker.total_bounty_cash_won("a") == 50


def test_progressive_knockout_bounty_compounds_across_multiple_knockouts():
    config = BountyConfig(bounty_amount=100, progressive=True, progressive_split=0.5)
    tracker = BountyTracker(config, ["a", "b", "c"])
    tracker.record_knockout("a", "b")  # a's bounty: 100 + 50 = 150
    cash2 = tracker.record_knockout("a", "c")  # collects half of c's 100 = 50
    assert cash2 == 50
    assert tracker.bounty_of("a") == 200  # 150 + 50
    assert tracker.total_bounty_cash_won("a") == 100  # 50 + 50


def test_progressive_split_zero_means_all_cash_no_growth():
    config = BountyConfig(bounty_amount=100, progressive=True, progressive_split=0.0)
    tracker = BountyTracker(config, ["a", "b"])
    cash = tracker.record_knockout("a", "b")
    assert cash == 100
    assert tracker.bounty_of("a") == 100  # unchanged


def test_progressive_split_one_means_all_growth_no_cash():
    config = BountyConfig(bounty_amount=100, progressive=True, progressive_split=1.0)
    tracker = BountyTracker(config, ["a", "b"])
    cash = tracker.record_knockout("a", "b")
    assert cash == 0
    assert tracker.bounty_of("a") == 200


def test_record_knockout_unknown_eliminated_player_raises():
    config = BountyConfig(bounty_amount=50)
    tracker = BountyTracker(config, ["a", "b"])
    with pytest.raises(BountyError):
        tracker.record_knockout("a", "ghost")


def test_record_knockout_already_eliminated_player_raises():
    config = BountyConfig(bounty_amount=50)
    tracker = BountyTracker(config, ["a", "b", "c"])
    tracker.record_knockout("a", "b")
    with pytest.raises(BountyError):
        tracker.record_knockout("c", "b")  # b already eliminated


def test_all_bounty_cash_won_reports_every_eliminator():
    config = BountyConfig(bounty_amount=50)
    tracker = BountyTracker(config, ["a", "b", "c"])
    tracker.record_knockout("a", "b")
    tracker.record_knockout("a", "c")
    result = tracker.all_bounty_cash_won()
    assert result == {"a": 100}
