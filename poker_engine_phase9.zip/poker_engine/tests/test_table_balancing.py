import pytest

from poker_engine.tables import (
    BalancingError,
    Table,
    apply_seat_move,
    balance_tables,
    find_table_to_break,
    plan_table_break,
)


def make_table(table_id, n_players, max_seats=9):
    t = Table(table_id=table_id, max_seats=max_seats)
    for i in range(n_players):
        t.sit_down(f"{table_id}_p{i}", f"{table_id} Player {i}", 1000)
    return t


def test_balance_tables_no_moves_when_already_even():
    t1 = make_table("t1", 6)
    t2 = make_table("t2", 6)
    assert balance_tables([t1, t2]) == []


def test_balance_tables_no_moves_with_single_table():
    t1 = make_table("t1", 6)
    assert balance_tables([t1]) == []


def test_balance_tables_moves_from_fullest_to_emptiest():
    t1 = make_table("t1", 9)
    t2 = make_table("t2", 3)
    moves = balance_tables([t1, t2])
    assert len(moves) == 3  # 9 vs 3 -> balances to 6 vs 6
    assert all(m.from_table_id == "t1" and m.to_table_id == "t2" for m in moves)


def test_balance_tables_result_is_within_one_player():
    t1 = make_table("t1", 7)
    t2 = make_table("t2", 2)
    moves = balance_tables([t1, t2])
    # Simulate applying the moves to verify final counts.
    counts = {"t1": 7, "t2": 2}
    for m in moves:
        counts[m.from_table_id] -= 1
        counts[m.to_table_id] += 1
    assert abs(counts["t1"] - counts["t2"]) <= 1


def test_balance_tables_three_tables():
    t1 = make_table("t1", 9)
    t2 = make_table("t2", 9)
    t3 = make_table("t3", 3)
    moves = balance_tables([t1, t2, t3])
    counts = {"t1": 9, "t2": 9, "t3": 3}
    for m in moves:
        counts[m.from_table_id] -= 1
        counts[m.to_table_id] += 1
    assert max(counts.values()) - min(counts.values()) <= 1


def test_balance_tables_rejects_duplicate_table_ids():
    t1 = make_table("t1", 5)
    t2 = make_table("t1", 5)
    with pytest.raises(BalancingError):
        balance_tables([t1, t2])


def test_balance_tables_raises_if_destination_full_but_still_short():
    # Contrived: t2 is "full" (max_seats=2) with only 1 player, but t1 has
    # way more — balance_tables should refuse rather than silently fail,
    # since seating t1's overflow anywhere sane isn't possible.
    t1 = Table(table_id="t1", max_seats=9)
    for i in range(9):
        t1.sit_down(f"p{i}", f"p{i}", 1000)
    t2 = Table(table_id="t2", max_seats=2)
    t2.sit_down("q0", "q0", 1000)
    with pytest.raises(BalancingError):
        balance_tables([t1, t2])


def test_find_table_to_break_when_it_fits_elsewhere():
    t1 = make_table("t1", 7, max_seats=9)  # 2 empty seats
    t2 = make_table("t2", 7, max_seats=9)  # 2 empty seats
    t3 = make_table("t3", 2, max_seats=9)  # only 2 players, fits in the room above
    broken = find_table_to_break([t1, t2, t3])
    assert broken is not None
    assert broken.table_id == "t3"


def test_find_table_to_break_none_when_no_room():
    t1 = make_table("t1", 9, max_seats=9)
    t2 = make_table("t2", 9, max_seats=9)
    t3 = make_table("t3", 2, max_seats=9)
    assert find_table_to_break([t1, t2, t3]) is None  # t1/t2 both full


def test_find_table_to_break_single_table_returns_none():
    t1 = make_table("t1", 5)
    assert find_table_to_break([t1]) is None


def test_plan_table_break_distributes_evenly():
    broken = make_table("broken", 4, max_seats=9)
    t1 = make_table("t1", 3, max_seats=9)
    t2 = make_table("t2", 3, max_seats=9)
    moves = plan_table_break(broken, [t1, t2])
    assert len(moves) == 4
    assert all(m.from_table_id == "broken" for m in moves)
    counts = {"t1": 3, "t2": 3}
    for m in moves:
        counts[m.to_table_id] += 1
    assert abs(counts["t1"] - counts["t2"]) <= 1


def test_plan_table_break_respects_max_seats():
    broken = make_table("broken", 2, max_seats=9)
    t1 = Table(table_id="t1", max_seats=2)
    t1.sit_down("x", "x", 1000)
    t1.sit_down("y", "y", 1000)  # already full
    t2 = Table(table_id="t2", max_seats=3)
    t2.sit_down("z", "z", 1000)
    moves = plan_table_break(broken, [t1, t2])
    assert all(m.to_table_id == "t2" for m in moves)  # t1 has no room


def test_plan_table_break_raises_when_not_enough_room():
    broken = make_table("broken", 5, max_seats=9)
    t1 = Table(table_id="t1", max_seats=2)
    t1.sit_down("x", "x", 1000)
    t1.sit_down("y", "y", 1000)
    with pytest.raises(BalancingError):
        plan_table_break(broken, [t1])


def test_plan_table_break_requires_at_least_one_destination():
    broken = make_table("broken", 2)
    with pytest.raises(BalancingError):
        plan_table_break(broken, [])


def test_apply_seat_move_carries_over_stack():
    t1 = Table(table_id="t1", max_seats=6)
    t2 = Table(table_id="t2", max_seats=6)
    t1.sit_down("a", "Alice", 1234)
    move_target = t1.find_player("a")
    from poker_engine.tables import SeatMove

    move = SeatMove(player_id="a", from_table_id="t1", to_table_id="t2")
    apply_seat_move(move, {"t1": t1, "t2": t2})

    assert t1.find_player("a") is None
    moved = t2.find_player("a")
    assert moved is not None
    assert moved.stack == 1234


def test_full_balance_then_break_workflow():
    # Simulate a realistic late-tournament consolidation: three tables,
    # one has thinned out and should be broken into the other two, which
    # then get rebalanced.
    t1 = make_table("t1", 8, max_seats=9)
    t2 = make_table("t2", 8, max_seats=9)
    t3 = make_table("t3", 1, max_seats=9)

    to_break = find_table_to_break([t1, t2, t3])
    assert to_break is not None and to_break.table_id == "t3"

    others = [t1, t2]
    moves = plan_table_break(to_break, others)
    tables_by_id = {"t1": t1, "t2": t2, "t3": t3}
    for m in moves:
        apply_seat_move(m, tables_by_id)

    assert t3.occupied_count() == 0
    total_remaining = t1.occupied_count() + t2.occupied_count()
    assert total_remaining == 17
    assert abs(t1.occupied_count() - t2.occupied_count()) <= 1
