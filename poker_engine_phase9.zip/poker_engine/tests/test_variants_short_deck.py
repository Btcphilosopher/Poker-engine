from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.evaluation.short_deck import evaluate_best_of_short_deck, short_deck_sort_key
from poker_engine.tables import Table
from poker_engine.variants import ShortDeckHoldem


def make_table(n_players=3, stack=1000):
    table = Table(table_id="t1", max_seats=6)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, stack)
    return table, ids


def seeded(table, seed):
    deck = Deck(short_deck=True)
    deck.shuffle(seed=seed)
    return ShortDeckHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)


def play_to_completion(game):
    steps = 0
    while not game.is_hand_complete and steps < 200:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete


def test_short_deck_uses_a_36_card_deck():
    table, ids = make_table(2)
    game = seeded(table, seed=1)
    game.start_hand()
    # 36 cards total, minus 2*2 hole cards dealt = 32 remaining.
    assert game._deck.cards_remaining() == 32
    assert game._deck.total_cards == 36


def test_short_deck_never_deals_ranks_below_six():
    table, ids = make_table(2)
    game = seeded(table, seed=1)
    game.start_hand()
    dealt = [c for cards in game.hole_cards.values() for c in cards]
    assert all(c.rank.value >= 6 for c in dealt)


def test_short_deck_deals_two_hole_cards():
    table, ids = make_table(3)
    game = seeded(table, seed=1)
    game.start_hand()
    assert all(len(cards) == 2 for cards in game.hole_cards.values())


def test_short_deck_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(table, seed=7)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_short_deck_board_never_contains_ranks_below_six():
    table, ids = make_table(3)
    game = seeded(table, seed=7)
    game.start_hand()
    play_to_completion(game)
    assert all(c.rank.value >= 6 for c in game.board)


def test_short_deck_winner_matches_short_deck_ranking():
    # Verify the FULL FlopGame -> resolve_showdown(key=short_deck_sort_key)
    # wiring actually picks the winner short-deck ranking would pick,
    # across many hands, rather than trusting the plumbing blindly.
    for seed in range(1, 20):
        table, ids = make_table(2, stack=1000)
        game = seeded(table, seed=seed)
        game.start_hand()
        play_to_completion(game)
        live = [pid for pid, bs in game._betting_states.items() if not bs.is_folded]
        if len(live) < 2:
            continue
        hands = {pid: evaluate_best_of_short_deck(game.hole_cards[pid] + game.board) for pid in live}
        best_pid = max(hands, key=lambda pid: short_deck_sort_key(hands[pid]))
        winners = game.outcome.pot_outcomes[0].winners
        assert best_pid in winners
