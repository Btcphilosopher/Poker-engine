"""
Full cash-game integration test: plays real hands (via TexasHoldem) at an
ongoing CashGame session with realistic ring-game churn (players busting
out, leaving, new players joining, the waiting list feeding in when seats
open) -- the same "prove the pieces work together" pattern every earlier
phase's capstone integration test used.

Unlike a Tournament, a cash game's chip total is NOT conserved session-wide
(new players bring fresh money; departing players take theirs with them).
The invariant that DOES hold: total chips at the table at any moment equals
everything ever bought in, minus everything ever cashed out, minus
whatever's currently held on the waiting list (registered but not yet at
the table).
"""

import random

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.cash_games import AutoTopUpPolicy, CashGame, CashGameConfig
from poker_engine.deck import Deck
from poker_engine.variants import TexasHoldem


def _play_random_hand(game, rng):
    steps = 0
    while not game.is_hand_complete and steps < 300:
        pid = game.current_player
        if pid is None:
            break
        legal = game.legal_actions(pid)
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        weights = {ActionType.CHECK: 5, ActionType.CALL: 5, ActionType.FOLD: 2, ActionType.RAISE: 2}
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
        if chosen is ActionType.RAISE:
            game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
        else:
            game.apply_action(pid, chosen)
        steps += 1
    assert game.is_hand_complete


def test_full_cash_game_session_with_churn_and_waiting_list():
    rng = random.Random(42)
    config = CashGameConfig(min_buyin=200, max_buyin=1000, max_seats=4)
    cash_game = CashGame(config)

    total_bought_in = 0
    total_cashed_out = 0
    total_on_waiting_list = 0

    for i in range(4):
        cash_game.join(f"p{i}", f"p{i}", 500)
        total_bought_in += 500

    # Two more players arrive after the table's full -- they queue up.
    cash_game.join("late1", "late1", 300)
    total_bought_in += 300
    total_on_waiting_list += 300
    cash_game.join("late2", "late2", 400)
    total_bought_in += 400
    total_on_waiting_list += 400
    assert len(cash_game.waiting_list) == 2

    blind_level = BlindLevel(small_blind=10, big_blind=20)
    hands_played = 0
    new_player_counter = 0

    for _ in range(30):
        if cash_game.table.occupied_count() < 2:
            break
        waiting_before = set(cash_game.waiting_list.player_ids)

        deck = Deck()
        deck.shuffle(seed=rng.randint(0, 2**31 - 1))
        game = TexasHoldem(cash_game.table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
        game.start_hand()
        _play_random_hand(game, rng)
        game.settle()
        hands_played += 1
        cash_game.between_hands()

        for player in list(cash_game.table.occupied_seats()):
            if player.stack < blind_level.big_blind:
                cashed_out = cash_game.leave(player.player_id).stack
                total_cashed_out += cashed_out

        # Anyone who left the waiting list this round (because a seat
        # opened up) had their buy-in moved onto the table -- reconcile
        # that in one pass at the end of the hand, rather than tracking it
        # per-leave (which double-counts when multiple players bust in
        # the same hand and several waiting-list members get seated).
        waiting_after = set(cash_game.waiting_list.player_ids)
        for pid in waiting_before - waiting_after:
            seated_player = cash_game.table.find_player(pid)
            if seated_player is not None:
                total_on_waiting_list -= seated_player.stack

        if cash_game.waiting_list.is_empty and 0 < cash_game.table.occupied_count() < 4:
            new_player_counter += 1
            new_id = f"new{new_player_counter}"
            cash_game.join(new_id, new_id, 500)
            total_bought_in += 500

    still_at_table = sum(p.stack for p in cash_game.table.occupied_seats())
    assert hands_played > 0
    assert still_at_table == total_bought_in - total_cashed_out - total_on_waiting_list


def test_seat_reservation_and_expiry_flow_across_real_hands():
    rng = random.Random(7)
    config = CashGameConfig(min_buyin=200, max_buyin=1000, max_seats=3, seat_reservation_hands=2)
    cash_game = CashGame(config)
    cash_game.join("a", "a", 500)
    cash_game.join("b", "b", 500)
    reservation = cash_game.reserve_seat("c", "c")

    blind_level = BlindLevel(small_blind=10, big_blind=20)

    # Play two hands -- only a/b, since c's seat is reserved (not occupied).
    for _ in range(2):
        deck = Deck()
        deck.shuffle(seed=rng.randint(0, 2**31 - 1))
        game = TexasHoldem(cash_game.table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
        game.start_hand()
        _play_random_hand(game, rng)
        game.settle()
        cash_game.between_hands()

    # Reservation should have expired by now (expires_after_hands=2).
    assert not cash_game.reservations.is_reserved(reservation.seat_index)
    # The seat is free again for anyone.
    player = cash_game.join("d", "d", 500)
    assert player is not None
    assert player.seat_index == reservation.seat_index


def test_auto_topup_keeps_players_in_the_game_across_real_hands():
    rng = random.Random(3)
    policy = AutoTopUpPolicy(threshold=100, target=500)
    config = CashGameConfig(min_buyin=200, max_buyin=1000, max_seats=4, auto_topup_policy=policy)
    cash_game = CashGame(config)
    for i in range(3):
        cash_game.join(f"p{i}", f"p{i}", 500)

    blind_level = BlindLevel(small_blind=10, big_blind=20)
    for _ in range(15):
        if cash_game.table.occupied_count() < 2:
            break
        deck = Deck()
        deck.shuffle(seed=rng.randint(0, 2**31 - 1))
        game = TexasHoldem(cash_game.table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
        game.start_hand()
        _play_random_hand(game, rng)
        game.settle()
        cash_game.between_hands()  # auto top-up applied here

        for player in cash_game.table.occupied_seats():
            assert player.stack > policy.threshold or player.stack == policy.target
