"""
Property-based tests for Phase 3 (dealer + table management).
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.betting import ActionType, BettingRound, BettingStructure, post_big_blind, post_small_blind
from poker_engine.dealer import advance_to_next_street, deal_community_cards, deal_hole_cards, resolve_showdown
from poker_engine.deck import Deck
from poker_engine.evaluation import evaluate_best_of
from poker_engine.tables import Table, balance_tables


# ---------------------------------------------------------------------------
# table balancing
# ---------------------------------------------------------------------------

@given(
    counts=st.lists(st.integers(min_value=0, max_value=9), min_size=2, max_size=6),
)
@settings(max_examples=150)
def test_balance_tables_always_ends_within_one_player(counts):
    tables = []
    for i, n in enumerate(counts):
        t = Table(table_id=f"t{i}", max_seats=9)
        for j in range(n):
            t.sit_down(f"t{i}_p{j}", f"t{i}_p{j}", 1000)
        tables.append(t)

    total_before = sum(len(t.active_player_ids()) for t in tables)
    moves = balance_tables(tables)

    simulated = {t.table_id: len(t.active_player_ids()) for t in tables}
    for m in moves:
        simulated[m.from_table_id] -= 1
        simulated[m.to_table_id] += 1

    assert sum(simulated.values()) == total_before  # no players created/destroyed
    assert max(simulated.values()) - min(simulated.values()) <= 1
    for t in tables:
        assert simulated[t.table_id] <= t.max_seats


# ---------------------------------------------------------------------------
# full randomized hands: money conservation across the whole pipeline
# ---------------------------------------------------------------------------

def _play_full_random_hand(seed: int, n_players: int, starting_stack: int) -> None:
    rng = random.Random(seed)
    table = Table(table_id="main", max_seats=9)
    player_ids = [f"p{i}" for i in range(n_players)]
    for pid in player_ids:
        table.sit_down(pid, pid, starting_stack)
    table.button_index = 0

    total_before = sum(table.find_player(pid).stack for pid in player_ids)

    deck = Deck()
    deck.shuffle(seed=seed)

    players_bs = {pid: table.find_player(pid).to_betting_state() for pid in table.active_player_ids()}

    if table.is_heads_up():
        sb_id, bb_id = table.seats_from_button()
    else:
        order = table.seats_from_button()
        sb_id, bb_id = order[1], order[2]
    post_small_blind(players_bs[sb_id], 10)
    post_big_blind(players_bs[bb_id], 20)

    deal_order = table.postflop_action_order()
    hole = deal_hole_cards(deck, deal_order, 2)

    def run_street(order, carried_pot):
        live_order = [pid for pid in order if not players_bs[pid].is_folded and not players_bs[pid].is_all_in]
        if len(live_order) < 2:
            return carried_pot
        round_ = BettingRound(
            [players_bs[pid] for pid in live_order], BettingStructure.NO_LIMIT, min_bet=20, carried_pot=carried_pot
        )
        steps = 0
        while not round_.is_betting_complete() and steps < 200:
            pid = round_.next_to_act()
            if pid is None:
                break
            legal = round_.legal_actions(pid)
            options = []
            if legal.can_check:
                options.append(ActionType.CHECK)
            if legal.can_call:
                options.append(ActionType.CALL)
            if legal.can_fold:
                options.append(ActionType.FOLD)
            if legal.can_raise:
                options.append(ActionType.RAISE)
            weights = {ActionType.CHECK: 6, ActionType.CALL: 6, ActionType.FOLD: 1, ActionType.RAISE: 1}
            chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
            if chosen is ActionType.RAISE:
                round_.apply(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
            else:
                round_.apply(pid, chosen)
            steps += 1
            if len([p for p in players_bs.values() if not p.is_folded]) <= 1:
                break
        return advance_to_next_street(round_)

    carried = run_street(table.preflop_action_order(), 0)

    live_count = len([p for p in players_bs.values() if not p.is_folded])
    board = []
    if live_count > 1:
        flop = deal_community_cards(deck, 3)
        board += flop.cards
        carried = run_street(table.postflop_action_order(), carried)

    live_count = len([p for p in players_bs.values() if not p.is_folded])
    if live_count > 1:
        turn = deal_community_cards(deck, 1)
        board += turn.cards
        carried = run_street(table.postflop_action_order(), carried)

    live_count = len([p for p in players_bs.values() if not p.is_folded])
    if live_count > 1:
        river = deal_community_cards(deck, 1)
        board += river.cards
        carried = run_street(table.postflop_action_order(), carried)

    live_players = [pid for pid in player_ids if not players_bs[pid].is_folded]
    hand_results = {}
    if len(live_players) > 1 and len(board) == 5:
        hand_results = {pid: evaluate_best_of(hole[pid] + board) for pid in live_players}

    outcome = resolve_showdown(list(players_bs.values()), hand_results, order_from_button=table.seats_from_button())

    # Money conservation through betting: everything wagered plus everyone's
    # remaining stack, must equal what everyone started with.
    wagered_and_remaining = sum(bs.stack for bs in players_bs.values()) + sum(
        bs.total_contributed for bs in players_bs.values()
    )
    assert wagered_and_remaining == total_before

    table.settle_hand(players_bs, outcome.total_payouts)
    total_after = sum(table.find_player(pid).stack for pid in player_ids)
    assert total_after == total_before


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=6),
)
@settings(max_examples=100, deadline=None)
def test_random_full_hands_conserve_chips(seed, n_players):
    _play_full_random_hand(seed, n_players, starting_stack=1000)
