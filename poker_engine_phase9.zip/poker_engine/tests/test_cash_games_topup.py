import pytest

from poker_engine.cash_games import AutoTopUpError, AutoTopUpPolicy, apply_auto_topup
from poker_engine.tables import Table, TableError


def test_policy_rejects_negative_threshold():
    with pytest.raises(AutoTopUpError):
        AutoTopUpPolicy(threshold=-1, target=100)


def test_policy_rejects_target_not_exceeding_threshold():
    with pytest.raises(AutoTopUpError):
        AutoTopUpPolicy(threshold=100, target=100)
    with pytest.raises(AutoTopUpError):
        AutoTopUpPolicy(threshold=100, target=50)


def test_apply_tops_up_when_at_or_below_threshold():
    t = Table(table_id="t1", max_seats=4)
    t.sit_down("a", "Alice", 150)
    policy = AutoTopUpPolicy(threshold=200, target=500)
    added = apply_auto_topup(t, policy, "a")
    assert added == 350
    assert t.find_player("a").stack == 500


def test_apply_exactly_at_threshold_triggers():
    t = Table(table_id="t1", max_seats=4)
    t.sit_down("a", "Alice", 200)
    policy = AutoTopUpPolicy(threshold=200, target=500)
    added = apply_auto_topup(t, policy, "a")
    assert added == 300


def test_apply_above_threshold_does_nothing():
    t = Table(table_id="t1", max_seats=4)
    t.sit_down("a", "Alice", 250)
    policy = AutoTopUpPolicy(threshold=200, target=500)
    added = apply_auto_topup(t, policy, "a")
    assert added == 0
    assert t.find_player("a").stack == 250


def test_apply_respects_table_max_buyin():
    t = Table(table_id="t1", max_seats=4, max_buyin=400)
    t.sit_down("a", "Alice", 150)
    policy = AutoTopUpPolicy(threshold=200, target=500)
    added = apply_auto_topup(t, policy, "a")
    assert added == 250  # capped to reach 400, not 500
    assert t.find_player("a").stack == 400


def test_apply_unseated_player_raises():
    t = Table(table_id="t1", max_seats=4)
    policy = AutoTopUpPolicy(threshold=200, target=500)
    with pytest.raises(TableError):
        apply_auto_topup(t, policy, "ghost")
