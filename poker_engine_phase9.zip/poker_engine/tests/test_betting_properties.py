"""
Property-based tests for the betting engine.

These check invariants that must hold for ANY input, not just hand-picked
examples: money is never created or destroyed, pots always sum back to
exactly what was contributed, and a betting round always terminates.
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.betting import (
    ActionType,
    BettingRound,
    BettingStructure,
    Pot,
    PlayerBettingState,
    compute_pots,
    distribute_pot,
)


# ---------------------------------------------------------------------------
# compute_pots — money conservation
# ---------------------------------------------------------------------------

@st.composite
def contribution_scenarios(draw, max_players: int = 6):
    n = draw(st.integers(min_value=1, max_value=max_players))
    players = []
    for i in range(n):
        total = draw(st.integers(min_value=0, max_value=1000))
        folded = draw(st.booleans())
        p = PlayerBettingState(f"p{i}", stack=0, total_contributed=total)
        p.is_folded = folded
        players.append(p)
    return players


@given(contribution_scenarios())
@settings(max_examples=200)
def test_compute_pots_conserves_total_money(players):
    pots = compute_pots(players)
    assert sum(p.amount for p in pots) == sum(p.total_contributed for p in players)


@given(contribution_scenarios())
@settings(max_examples=200)
def test_compute_pots_amounts_are_never_negative(players):
    pots = compute_pots(players)
    assert all(p.amount >= 0 for p in pots)


@given(contribution_scenarios())
@settings(max_examples=200)
def test_compute_pots_eligible_players_never_include_folded(players):
    folded_ids = {p.player_id for p in players if p.is_folded}
    pots = compute_pots(players)
    for pot in pots:
        assert not (set(pot.eligible_player_ids) & folded_ids)


# ---------------------------------------------------------------------------
# distribute_pot — money conservation
# ---------------------------------------------------------------------------

@given(
    amount=st.integers(min_value=0, max_value=10_000),
    n_winners=st.integers(min_value=1, max_value=8),
)
@settings(max_examples=200)
def test_distribute_pot_sums_back_to_exact_amount(amount, n_winners):
    winners = [f"w{i}" for i in range(n_winners)]
    order = list(winners)
    random.Random(amount * 31 + n_winners).shuffle(order)
    pot = Pot(amount=amount, eligible_player_ids=tuple(winners))
    payouts = distribute_pot(pot, winners, order_from_button=order)
    assert sum(payouts.values()) == amount
    assert set(payouts.keys()) == set(winners)


@given(
    amount=st.integers(min_value=1, max_value=10_000),
    n_winners=st.integers(min_value=1, max_value=8),
)
@settings(max_examples=200)
def test_distribute_pot_shares_never_differ_by_more_than_one_chip(amount, n_winners):
    winners = [f"w{i}" for i in range(n_winners)]
    pot = Pot(amount=amount, eligible_player_ids=tuple(winners))
    payouts = distribute_pot(pot, winners, order_from_button=winners)
    assert max(payouts.values()) - min(payouts.values()) <= 1


# ---------------------------------------------------------------------------
# BettingRound — money conservation + termination under random legal play
# ---------------------------------------------------------------------------

def _play_random_round(stacks, structure, min_bet, seed):
    rng = random.Random(seed)
    players = [PlayerBettingState(f"p{i}", stack=s) for i, s in enumerate(stacks)]
    total_chips_before = sum(p.stack for p in players)

    r = BettingRound(players, structure, min_bet)
    steps = 0
    max_steps = 500  # generous upper bound; a real round never needs this many

    while not r.is_betting_complete() and steps < max_steps:
        pid = r.next_to_act()
        if pid is None:
            break
        legal = r.legal_actions(pid)

        # Invariant, checked every single step: total chips (in stacks +
        # already wagered this street) never changes within a round.
        chips_now = sum(p.stack for p in players) + sum(p.street_contributed for p in players)
        assert chips_now == total_chips_before

        options = []
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_bet:
            options.append(ActionType.BET)
        if legal.can_raise:
            options.append(ActionType.RAISE)

        # Heavily bias toward ending action (call/check/fold) so rounds
        # terminate quickly in the test even with many players.
        weights = {
            ActionType.FOLD: 1,
            ActionType.CHECK: 5,
            ActionType.CALL: 5,
            ActionType.BET: 1,
            ActionType.RAISE: 1,
        }
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]

        if chosen is ActionType.BET:
            amount = rng.randint(legal.bet_min, legal.bet_max)
            r.apply(pid, ActionType.BET, amount)
        elif chosen is ActionType.RAISE:
            amount = rng.randint(legal.raise_min, legal.raise_max)
            r.apply(pid, ActionType.RAISE, amount)
        else:
            r.apply(pid, chosen)

        steps += 1

        live_or_allin = [p for p in players if not p.is_folded]
        if len(live_or_allin) <= 1:
            break

    return r, players, total_chips_before, steps, max_steps


@given(
    stacks=st.lists(st.integers(min_value=20, max_value=2000), min_size=2, max_size=5),
    min_bet=st.integers(min_value=2, max_value=50),
    seed=st.integers(min_value=0, max_value=2**31 - 1),
)
@settings(max_examples=100)
def test_random_no_limit_round_conserves_chips_and_terminates(stacks, min_bet, seed):
    r, players, total_before, steps, max_steps = _play_random_round(
        stacks, BettingStructure.NO_LIMIT, min_bet, seed
    )
    assert steps < max_steps  # must actually terminate, not hit the safety cap
    chips_after = sum(p.stack for p in players) + sum(p.street_contributed for p in players)
    assert chips_after == total_before


@given(
    stacks=st.lists(st.integers(min_value=20, max_value=2000), min_size=2, max_size=5),
    min_bet=st.integers(min_value=2, max_value=50),
    seed=st.integers(min_value=0, max_value=2**31 - 1),
)
@settings(max_examples=100)
def test_random_pot_limit_round_conserves_chips_and_terminates(stacks, min_bet, seed):
    r, players, total_before, steps, max_steps = _play_random_round(
        stacks, BettingStructure.POT_LIMIT, min_bet, seed
    )
    assert steps < max_steps
    chips_after = sum(p.stack for p in players) + sum(p.street_contributed for p in players)
    assert chips_after == total_before


@given(
    stacks=st.lists(st.integers(min_value=200, max_value=2000), min_size=2, max_size=5),
    min_bet=st.integers(min_value=2, max_value=50),
    seed=st.integers(min_value=0, max_value=2**31 - 1),
)
@settings(max_examples=100)
def test_random_fixed_limit_round_conserves_chips_and_terminates(stacks, min_bet, seed):
    r, players, total_before, steps, max_steps = _play_random_round(
        stacks, BettingStructure.FIXED_LIMIT, min_bet, seed
    )
    assert steps < max_steps
    chips_after = sum(p.stack for p in players) + sum(p.street_contributed for p in players)
    assert chips_after == total_before


@given(
    stacks=st.lists(st.integers(min_value=20, max_value=2000), min_size=2, max_size=5),
    min_bet=st.integers(min_value=2, max_value=50),
    seed=st.integers(min_value=0, max_value=2**31 - 1),
)
@settings(max_examples=100)
def test_current_bet_never_decreases_during_a_round(stacks, min_bet, seed):
    rng = random.Random(seed)
    players = [PlayerBettingState(f"p{i}", stack=s) for i, s in enumerate(stacks)]
    r = BettingRound(players, BettingStructure.NO_LIMIT, min_bet)
    last_seen = r.current_bet
    steps = 0
    while not r.is_betting_complete() and steps < 500:
        pid = r.next_to_act()
        if pid is None:
            break
        legal = r.legal_actions(pid)
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        chosen = rng.choice(options)
        if chosen is ActionType.RAISE:
            r.apply(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
        else:
            r.apply(pid, chosen)
        assert r.current_bet >= last_seen
        last_seen = r.current_bet
        steps += 1
        if len([p for p in players if not p.is_folded]) <= 1:
            break
