import pytest

from poker_engine.cash_games import WaitingList, WaitingListError


def test_add_returns_position():
    wl = WaitingList()
    assert wl.add("a", "Alice", 500) == 1
    assert wl.add("b", "Bob", 500) == 2


def test_add_duplicate_raises():
    wl = WaitingList()
    wl.add("a", "Alice", 500)
    with pytest.raises(WaitingListError):
        wl.add("a", "Alice Again", 500)


def test_add_rejects_non_positive_buyin():
    wl = WaitingList()
    with pytest.raises(WaitingListError):
        wl.add("a", "Alice", 0)


def test_position_reflects_join_order():
    wl = WaitingList()
    wl.add("a", "Alice", 500)
    wl.add("b", "Bob", 500)
    wl.add("c", "Carol", 500)
    assert wl.position("a") == 1
    assert wl.position("b") == 2
    assert wl.position("c") == 3


def test_position_unknown_player_raises():
    wl = WaitingList()
    with pytest.raises(WaitingListError):
        wl.position("ghost")


def test_remove_updates_positions():
    wl = WaitingList()
    wl.add("a", "Alice", 500)
    wl.add("b", "Bob", 500)
    wl.add("c", "Carol", 500)
    wl.remove("a")
    assert wl.position("b") == 1
    assert wl.position("c") == 2


def test_remove_unknown_player_raises():
    wl = WaitingList()
    with pytest.raises(WaitingListError):
        wl.remove("ghost")


def test_peek_next_does_not_remove():
    wl = WaitingList()
    wl.add("a", "Alice", 500)
    assert wl.peek_next() == ("a", "Alice", 500)
    assert wl.peek_next() == ("a", "Alice", 500)  # still there
    assert len(wl) == 1


def test_peek_next_empty_returns_none():
    wl = WaitingList()
    assert wl.peek_next() is None


def test_pop_next_removes_and_returns_fifo_order():
    wl = WaitingList()
    wl.add("a", "Alice", 500)
    wl.add("b", "Bob", 300)
    assert wl.pop_next() == ("a", "Alice", 500)
    assert wl.pop_next() == ("b", "Bob", 300)
    assert wl.pop_next() is None


def test_len_and_is_empty():
    wl = WaitingList()
    assert len(wl) == 0
    assert wl.is_empty is True
    wl.add("a", "Alice", 500)
    assert len(wl) == 1
    assert wl.is_empty is False


def test_player_ids_reflects_current_queue():
    wl = WaitingList()
    wl.add("a", "Alice", 500)
    wl.add("b", "Bob", 500)
    assert wl.player_ids == ["a", "b"]
    wl.pop_next()
    assert wl.player_ids == ["b"]
