import pytest

from poker_engine.cards import Card
from poker_engine.evaluation.badugi import BadugiError, evaluate_badugi


def cards(text: str):
    return [Card.from_str(t) for t in text.split()]


def test_perfect_four_card_badugi():
    result = evaluate_badugi(cards("Ac 2d 3h 4s"))
    assert result.count == 4
    assert set(result.cards) == set(cards("Ac 2d 3h 4s"))


def test_best_possible_badugi_is_ace_two_three_four():
    best = evaluate_badugi(cards("Ac 2d 3h 4s"))
    worse = evaluate_badugi(cards("2c 3d 4h 5s"))
    assert best > worse


def test_paired_rank_drops_to_three_card_badugi():
    result = evaluate_badugi(cards("Ac Ad 3h 4s"))
    assert result.count == 3
    assert len({c.rank for c in result.cards}) == 3


def test_paired_rank_keeps_the_lower_ace_low_reading():
    # Between keeping Ac or Ad (identical rank), the choice doesn't affect
    # value, but the kept set must reflect the best available reading:
    # Ac/3h/4s (ace low) beats any reading that doesn't use the ace.
    result = evaluate_badugi(cards("Ac Ad 3h 4s"))
    ranks = sorted(c.rank.low_ace_value() for c in result.cards)
    assert ranks == [1, 3, 4]


def test_suit_clash_drops_to_three_card_badugi():
    result = evaluate_badugi(cards("Ac 2c 3h 4s"))
    assert result.count == 3
    assert len({c.suit for c in result.cards}) == 3


def test_suit_clash_prefers_keeping_the_lower_card():
    # Ac/2c clash (both clubs); keeping Ac (with 3h/4s) gives a lower hand
    # than keeping 2c (with 3h/4s), so the ace must be the one kept.
    result = evaluate_badugi(cards("Ac 2c 3h 4s"))
    assert Card.from_str("Ac") in result.cards
    assert Card.from_str("2c") not in result.cards


def test_four_card_badugi_always_beats_three_card_regardless_of_rank():
    high_four_card = evaluate_badugi(cards("9c 8d 7h 6s"))
    low_three_card = evaluate_badugi(cards("Ac Ad 2h 3s"))  # paired aces -> 3-card
    assert high_four_card > low_three_card


def test_three_card_always_beats_two_card():
    three_card = evaluate_badugi(cards("9c 8d 7h 7s"))  # one pair -> 3-card (9,8,7)
    two_card = evaluate_badugi(cards("Ac Ad Ah 2s"))  # trips -> 2-card (A,2)
    assert three_card > two_card


def test_worst_possible_hand_is_one_card():
    # All four cards share a suit and pairwise rank clashes force it down
    # to a single card.
    result = evaluate_badugi(cards("Ac Ad Ah As"))
    assert result.count == 1


def test_lower_rank_wins_within_same_count():
    lower = evaluate_badugi(cards("2c 3d 4h 5s"))
    higher = evaluate_badugi(cards("3c 4d 5h 6s"))
    assert lower > higher


def test_evaluate_badugi_requires_exactly_four_cards():
    with pytest.raises(BadugiError):
        evaluate_badugi(cards("Ac 2d 3h"))
    with pytest.raises(BadugiError):
        evaluate_badugi(cards("Ac 2d 3h 4s 5c"))


def test_evaluate_badugi_rejects_duplicate_card():
    with pytest.raises(BadugiError):
        evaluate_badugi(cards("Ac Ac 3h 4s"))


def test_badugi_result_str_labels_by_count():
    assert "Badugi" in str(evaluate_badugi(cards("Ac 2d 3h 4s")))
    three = evaluate_badugi(cards("Ac Ad 3h 4s"))
    assert "3-card Badugi" in str(three)


def test_badugi_result_equality_and_ordering():
    a = evaluate_badugi(cards("Ac 2d 3h 4s"))
    b = evaluate_badugi(cards("As 2h 3c 4d"))  # same ranks, different suits
    assert a == b
    assert not (a < b)
    assert not (a > b)


def test_badugi_result_full_ordering_dunders():
    better = evaluate_badugi(cards("Ac 2d 3h 4s"))
    worse = evaluate_badugi(cards("9c 8d 7h 6s"))
    assert worse < better
    assert worse <= better
    assert better > worse
    assert better >= worse
    assert better <= better
    assert worse >= worse


def test_badugi_result_equality_with_non_badugi_result():
    result = evaluate_badugi(cards("Ac 2d 3h 4s"))
    assert (result == "not a badugi") is False
    assert result != "not a badugi"


def test_sort_key_is_directly_compatible_with_resolve_showdown_default():
    # BadugiResult exposes .sort_key with the same "higher = better"
    # convention as HandResult/LowHandResult, so resolve_showdown's
    # default key function (lambda hr: hr.sort_key) works without any
    # custom key override.
    from poker_engine.betting import PlayerBettingState
    from poker_engine.dealer import resolve_showdown

    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    hands = {
        "a": evaluate_badugi(cards("Ac 2d 3h 4s")),  # best possible
        "b": evaluate_badugi(cards("9c 8d 7h 6s")),  # worse
    }
    outcome = resolve_showdown([a, b], hands, order_from_button=["a", "b"])
    assert outcome.total_payouts == {"a": 200}
