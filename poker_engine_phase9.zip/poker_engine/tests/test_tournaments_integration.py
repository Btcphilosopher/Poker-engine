"""
Full tournament integration test: plays real hands (via TexasHoldem)
across multiple tables, eliminating players and rebalancing as it goes,
down to a winner, then verifies payouts. This is the same pattern every
earlier phase's capstone integration test used (test_dealer_integration.py,
etc.) -- proving the pieces work together, not just in isolation.
"""

import random

from poker_engine.betting import ActionType, BettingStructure
from poker_engine.deck import Deck
from poker_engine.tournaments import BlindSchedule, Tournament, TournamentConfig
from poker_engine.variants import TexasHoldem


def _play_random_hand(game, rng):
    steps = 0
    while not game.is_hand_complete and steps < 300:
        pid = game.current_player
        if pid is None:
            break
        legal = game.legal_actions(pid)
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        weights = {ActionType.CHECK: 5, ActionType.CALL: 5, ActionType.FOLD: 2, ActionType.RAISE: 2}
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
        if chosen is ActionType.RAISE:
            game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
        else:
            game.apply_action(pid, chosen)
        steps += 1
    assert game.is_hand_complete


def test_full_nine_player_tournament_end_to_end():
    rng = random.Random(42)
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=25, break_every=4)
    config = TournamentConfig(buy_in=100, starting_stack=500, blind_schedule=schedule, max_players_per_table=4)
    t = Tournament(config)
    for i in range(9):
        t.register(f"p{i}", f"p{i}")
    t.start()

    assert len(t.tables) == 3
    assert t.prize_pool == 900

    hands_played = 0
    while not t.is_finished and hands_played < 500:
        for table in list(t.tables):
            if table.occupied_count() < 2:
                continue
            blind_level = t.clock.current_level.stakes
            deck = Deck()
            deck.shuffle(seed=rng.randint(0, 2**31 - 1))
            game = TexasHoldem(table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
            game.start_hand()
            _play_random_hand(game, rng)
            game.settle()
            hands_played += 1

            for busted_id in t.busted_player_ids(table):
                t.eliminate(table, busted_id)

        t.rebalance_tables()
        t.clock.advance_level()

    assert t.is_finished
    assert hands_played < 500  # actually finished, didn't hit the safety cap
    assert len(t.remaining_player_ids) == 1
    assert len(t.eliminations) == 8

    payouts = t.finalize()
    assert sum(payouts.values()) == t.prize_pool == 900

    winner = t.remaining_player_ids[0]
    assert payouts[winner] == max(payouts.values())

    from poker_engine.tournaments.elimination import compute_finishing_positions

    positions = compute_finishing_positions(t.eliminations, winner)
    assert sorted(positions.values()) == list(range(1, 10))


def test_full_tournament_with_progressive_knockouts():
    from poker_engine.tournaments.bounties import BountyConfig

    rng = random.Random(7)
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=25)
    bounty = BountyConfig(bounty_amount=20, progressive=True, progressive_split=0.5)
    config = TournamentConfig(
        buy_in=100, starting_stack=500, blind_schedule=schedule, max_players_per_table=6, bounty_config=bounty
    )
    t = Tournament(config)
    for i in range(6):
        t.register(f"p{i}", f"p{i}")
    t.start()

    hands_played = 0
    while not t.is_finished and hands_played < 300:
        table = t.tables[0]
        if table.occupied_count() < 2:
            break
        blind_level = t.clock.current_level.stakes
        deck = Deck()
        deck.shuffle(seed=rng.randint(0, 2**31 - 1))
        game = TexasHoldem(table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
        game.start_hand()

        last_aggressor = None
        while not game.is_hand_complete:
            pid = game.current_player
            legal = game.legal_actions(pid)
            options = []
            if legal.can_check:
                options.append(ActionType.CHECK)
            if legal.can_call:
                options.append(ActionType.CALL)
            if legal.can_fold:
                options.append(ActionType.FOLD)
            if legal.can_raise:
                options.append(ActionType.RAISE)
            weights = {ActionType.CHECK: 5, ActionType.CALL: 5, ActionType.FOLD: 2, ActionType.RAISE: 2}
            chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
            if chosen is ActionType.RAISE:
                last_aggressor = pid
                game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
            else:
                game.apply_action(pid, chosen)
        game.settle()
        hands_played += 1

        busted = t.busted_player_ids(table)
        if busted:
            # Attribute the knockout to whoever won the most from the pot
            # this hand (a reasonable proxy for "who eliminated whom"
            # without needing per-action hand-history tracking here).
            winners_by_payout = sorted(game.outcome.total_payouts.items(), key=lambda kv: -kv[1])
            eliminator = winners_by_payout[0][0] if winners_by_payout else last_aggressor
            for busted_id in busted:
                if busted_id != eliminator:
                    t.eliminate(table, busted_id, eliminator_id=eliminator)

    assert t.is_finished
    payouts = t.finalize()
    total_bounty_cash = sum(t.bounty_tracker.all_bounty_cash_won().values())
    total_base_prize = t.prize_pool
    assert sum(payouts.values()) == total_base_prize + total_bounty_cash
