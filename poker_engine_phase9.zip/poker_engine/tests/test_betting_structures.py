import pytest

from poker_engine.betting import BettingStructure, BlindLevel, StudStakes


def test_blind_level_valid_construction():
    level = BlindLevel(small_blind=10, big_blind=20, ante=5, small_bet=20, big_bet=40)
    assert level.small_blind == 10
    assert level.big_blind == 20
    assert level.ante == 5


def test_blind_level_defaults():
    level = BlindLevel(small_blind=5, big_blind=10)
    assert level.ante == 0
    assert level.small_bet is None
    assert level.big_bet is None


def test_blind_level_rejects_zero_or_negative_small_blind():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=0, big_blind=10)


def test_blind_level_rejects_zero_or_negative_big_blind():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=5, big_blind=0)


def test_blind_level_rejects_small_blind_exceeding_big_blind():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=20, big_blind=10)


def test_blind_level_rejects_negative_ante():
    with pytest.raises(ValueError):
        BlindLevel(small_blind=5, big_blind=10, ante=-1)


def test_betting_structure_values():
    assert BettingStructure.NO_LIMIT.value == "no_limit"
    assert BettingStructure.POT_LIMIT.value == "pot_limit"
    assert BettingStructure.FIXED_LIMIT.value == "fixed_limit"


def test_stud_stakes_valid_construction():
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    assert stakes.ante == 1
    assert stakes.bring_in == 3
    assert stakes.small_bet == 10
    assert stakes.big_bet == 20


def test_stud_stakes_rejects_non_positive_values():
    with pytest.raises(ValueError):
        StudStakes(ante=0, bring_in=3, small_bet=10, big_bet=20)
    with pytest.raises(ValueError):
        StudStakes(ante=1, bring_in=0, small_bet=10, big_bet=20)
    with pytest.raises(ValueError):
        StudStakes(ante=1, bring_in=3, small_bet=0, big_bet=20)
    with pytest.raises(ValueError):
        StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=0)


def test_stud_stakes_rejects_bring_in_not_below_small_bet():
    with pytest.raises(ValueError):
        StudStakes(ante=1, bring_in=10, small_bet=10, big_bet=20)
    with pytest.raises(ValueError):
        StudStakes(ante=1, bring_in=15, small_bet=10, big_bet=20)


def test_stud_stakes_rejects_small_bet_exceeding_big_bet():
    with pytest.raises(ValueError):
        StudStakes(ante=1, bring_in=3, small_bet=30, big_bet=20)
