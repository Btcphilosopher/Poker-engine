import pytest

from poker_engine.cash_games import SeatReservationError, SeatReservationManager
from poker_engine.tables import Table


def make_table(n_players=1, max_seats=4):
    t = Table(table_id="t1", max_seats=max_seats)
    for i in range(n_players):
        t.sit_down(f"p{i}", f"p{i}", 500, seat_index=i)
    return t


def test_reserve_holds_a_seat():
    t = make_table(1)
    mgr = SeatReservationManager()
    reservation = mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=3, current_hand_count=0)
    assert reservation.seat_index == 1
    assert reservation.expires_at_hand == 3
    assert mgr.is_reserved(1) is True


def test_reserve_rejects_occupied_seat():
    t = make_table(1)
    mgr = SeatReservationManager()
    with pytest.raises(SeatReservationError):
        mgr.reserve(t, "bob", "Bob", 0, expires_after_hands=3, current_hand_count=0)


def test_reserve_rejects_already_reserved_seat():
    t = make_table(1)
    mgr = SeatReservationManager()
    mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=3, current_hand_count=0)
    with pytest.raises(SeatReservationError):
        mgr.reserve(t, "carol", "Carol", 1, expires_after_hands=3, current_hand_count=0)


def test_reserve_rejects_out_of_range_seat():
    t = make_table(1)
    mgr = SeatReservationManager()
    with pytest.raises(SeatReservationError):
        mgr.reserve(t, "bob", "Bob", 99, expires_after_hands=3, current_hand_count=0)


def test_reserve_rejects_non_positive_expiry():
    t = make_table(1)
    mgr = SeatReservationManager()
    with pytest.raises(SeatReservationError):
        mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=0, current_hand_count=0)


def test_available_seats_excludes_reserved():
    t = make_table(1, max_seats=4)
    mgr = SeatReservationManager()
    mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=3, current_hand_count=0)
    assert mgr.available_seats(t) == [2, 3]


def test_available_seats_excludes_occupied():
    t = make_table(2, max_seats=4)
    mgr = SeatReservationManager()
    assert mgr.available_seats(t) == [2, 3]


def test_fulfil_seats_the_reserved_player():
    t = make_table(1)
    mgr = SeatReservationManager()
    mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=3, current_hand_count=0)
    player = mgr.fulfil(t, 1, 500)
    assert player.player_id == "bob"
    assert t.find_player("bob") is not None
    assert mgr.is_reserved(1) is False


def test_fulfil_with_no_reservation_raises():
    t = make_table(1)
    mgr = SeatReservationManager()
    with pytest.raises(SeatReservationError):
        mgr.fulfil(t, 1, 500)


def test_cancel_removes_reservation():
    t = make_table(1)
    mgr = SeatReservationManager()
    mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=3, current_hand_count=0)
    mgr.cancel(1)
    assert mgr.is_reserved(1) is False


def test_cancel_with_no_reservation_raises():
    mgr = SeatReservationManager()
    with pytest.raises(SeatReservationError):
        mgr.cancel(1)


def test_expire_stale_removes_only_expired():
    t = make_table(1, max_seats=4)
    mgr = SeatReservationManager()
    mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=2, current_hand_count=0)
    mgr.reserve(t, "carol", "Carol", 2, expires_after_hands=5, current_hand_count=0)
    expired = mgr.expire_stale(current_hand_count=2)
    assert [r.player_id for r in expired] == ["bob"]
    assert mgr.is_reserved(1) is False
    assert mgr.is_reserved(2) is True


def test_expire_stale_before_expiry_removes_nothing():
    t = make_table(1)
    mgr = SeatReservationManager()
    mgr.reserve(t, "bob", "Bob", 1, expires_after_hands=5, current_hand_count=0)
    expired = mgr.expire_stale(current_hand_count=1)
    assert expired == []
    assert mgr.is_reserved(1) is True


def test_reservation_at_returns_none_for_unreserved_seat():
    mgr = SeatReservationManager()
    assert mgr.reservation_at(0) is None
