import pytest

from poker_engine.betting import (
    ActionType,
    ForcedBetError,
    PlayerBettingState,
    assign_blinds,
    determine_bring_in,
    post_ante,
    post_big_blind,
    post_bring_in,
    post_dead_blind,
    post_small_blind,
)
from poker_engine.cards import Card


def test_player_betting_state_rejects_negative_stack():
    with pytest.raises(ValueError):
        PlayerBettingState("p1", stack=-5)


def test_player_is_live_and_max_reachable():
    p = PlayerBettingState("p1", stack=100, street_contributed=20)
    assert p.is_live is True
    assert p.max_reachable() == 120


def test_start_new_street_resets_street_contributed_only():
    p = PlayerBettingState("p1", stack=100, street_contributed=30, total_contributed=30)
    p.start_new_street()
    assert p.street_contributed == 0
    assert p.total_contributed == 30


def test_post_small_and_big_blind():
    sb = PlayerBettingState("sb", stack=1000)
    bb = PlayerBettingState("bb", stack=1000)
    a1 = post_small_blind(sb, 10)
    a2 = post_big_blind(bb, 20)
    assert sb.stack == 990 and sb.street_contributed == 10 and sb.total_contributed == 10
    assert bb.stack == 980 and bb.street_contributed == 20 and bb.total_contributed == 20
    assert a1.action_type is ActionType.POST_SMALL_BLIND
    assert a2.action_type is ActionType.POST_BIG_BLIND


def test_post_blind_short_stack_goes_all_in():
    sb = PlayerBettingState("sb", stack=6)
    action = post_small_blind(sb, 10)
    assert action.amount == 6
    assert sb.stack == 0
    assert sb.is_all_in is True
    assert sb.street_contributed == 6


def test_post_ante_does_not_count_toward_street_contributed():
    p = PlayerBettingState("p1", stack=1000)
    post_ante(p, 5)
    assert p.stack == 995
    assert p.total_contributed == 5
    assert p.street_contributed == 0  # ante is dead money, not a street wager


def test_post_dead_blind_does_not_count_toward_street_contributed():
    p = PlayerBettingState("p1", stack=1000)
    post_dead_blind(p, 20)
    assert p.stack == 980
    assert p.total_contributed == 20
    assert p.street_contributed == 0


def test_post_bring_in_counts_toward_street_contributed():
    p = PlayerBettingState("p1", stack=1000)
    post_bring_in(p, 5)
    assert p.street_contributed == 5
    assert p.total_contributed == 5


def test_negative_forced_bet_rejected():
    p = PlayerBettingState("p1", stack=1000)
    with pytest.raises(ForcedBetError):
        post_ante(p, -1)


def test_assign_blinds_heads_up():
    sb, bb = assign_blinds(["A", "B"], heads_up=True)
    assert (sb, bb) == ("A", "B")  # button (A) is SB heads-up


def test_assign_blinds_multiway():
    sb, bb = assign_blinds(["BTN", "SB", "BB", "UTG", "CO"], heads_up=False)
    assert (sb, bb) == ("SB", "BB")


def test_assign_blinds_requires_heads_up_flag_for_two_players():
    with pytest.raises(ForcedBetError):
        assign_blinds(["A", "B"], heads_up=False)


def test_assign_blinds_requires_at_least_two_players():
    with pytest.raises(ForcedBetError):
        assign_blinds(["A"], heads_up=False)


def test_determine_bring_in_lowest_card_stud():
    up_cards = {
        "p1": Card.from_str("9c"),
        "p2": Card.from_str("2d"),
        "p3": Card.from_str("Ks"),
    }
    assert determine_bring_in(up_cards, low_brings_in=True) == "p2"


def test_determine_bring_in_highest_card_razz():
    up_cards = {
        "p1": Card.from_str("9c"),
        "p2": Card.from_str("2d"),
        "p3": Card.from_str("Ks"),
    }
    assert determine_bring_in(up_cards, low_brings_in=False) == "p3"


def test_determine_bring_in_tie_broken_by_suit_priority():
    # Both have rank 5; clubs (priority 0) beats hearts (priority 2) for
    # the low bring-in tie-break.
    up_cards = {
        "p1": Card.from_str("5h"),
        "p2": Card.from_str("5c"),
    }
    assert determine_bring_in(up_cards, low_brings_in=True) == "p2"


def test_determine_bring_in_empty_raises():
    with pytest.raises(ForcedBetError):
        determine_bring_in({})
