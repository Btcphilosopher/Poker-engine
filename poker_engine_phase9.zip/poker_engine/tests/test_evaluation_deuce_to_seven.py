import pytest

from poker_engine.cards import Card
from poker_engine.evaluation import HandCategory, evaluate_5
from poker_engine.evaluation.deuce_to_seven import (
    best_deuce_to_seven_of,
    deuce_to_seven_sort_key,
    evaluate_5_deuce_to_seven,
)


def cards(text: str):
    return [Card.from_str(t) for t in text.split()]


def test_wheel_is_not_a_straight_in_deuce_to_seven():
    wheel = evaluate_5_deuce_to_seven(cards("Ah 2d 3c 4s 5h"))
    assert wheel.category == HandCategory.HIGH_CARD


def test_wheel_is_a_straight_under_standard_rules_for_comparison():
    standard_wheel = evaluate_5(cards("Ah 2d 3c 4s 5h"))
    assert standard_wheel.category == HandCategory.STRAIGHT


def test_seven_five_four_three_two_is_the_best_possible_hand():
    best = evaluate_5_deuce_to_seven(cards("7h 5d 4c 3s 2h"))
    assert best.category == HandCategory.HIGH_CARD
    assert best.tiebreakers == (7, 5, 4, 3, 2)


def test_seven_high_beats_the_wheel_in_deuce_to_seven():
    best = evaluate_5_deuce_to_seven(cards("7h 5d 4c 3s 2h"))
    wheel = evaluate_5_deuce_to_seven(cards("Ah 2d 3c 4s 5h"))
    assert deuce_to_seven_sort_key(best) > deuce_to_seven_sort_key(wheel)


def test_no_pair_beats_a_pair_in_deuce_to_seven():
    no_pair = evaluate_5_deuce_to_seven(cards("9h 7d 6c 4s 2h"))
    pair = evaluate_5_deuce_to_seven(cards("2h 2d 3c 4s 5h"))
    assert deuce_to_seven_sort_key(no_pair) > deuce_to_seven_sort_key(pair)


def test_lower_high_card_beats_higher_high_card_in_deuce_to_seven():
    lower = evaluate_5_deuce_to_seven(cards("9h 7d 6c 4s 2h"))
    higher = evaluate_5_deuce_to_seven(cards("Th 7d 6c 4s 2h"))
    assert deuce_to_seven_sort_key(lower) > deuce_to_seven_sort_key(higher)


def test_straight_flush_is_the_worst_possible_hand():
    straight_flush = evaluate_5_deuce_to_seven(cards("9h 8h 7h 6h 5h"))
    high_card = evaluate_5_deuce_to_seven(cards("Kh Qd Jc 9s 2h"))
    assert deuce_to_seven_sort_key(high_card) > deuce_to_seven_sort_key(straight_flush)


def test_best_deuce_to_seven_of_picks_correctly_from_extra_cards():
    seven = cards("7h 5d 4c 3s 2h Kd Kc")
    best = best_deuce_to_seven_of(seven)
    assert best.tiebreakers == (7, 5, 4, 3, 2)


def test_best_deuce_to_seven_of_requires_at_least_five_cards():
    with pytest.raises(ValueError):
        best_deuce_to_seven_of(cards("7h 5d 4c"))


def test_full_category_ordering_inverted():
    # Straight flush (worst) < quads < full house < flush < straight <
    # trips < two pair < pair < high card (best), all inverted from standard.
    straight_flush = evaluate_5_deuce_to_seven(cards("9h 8h 7h 6h 5h"))
    quads = evaluate_5_deuce_to_seven(cards("2h 2d 2c 2s 5h"))
    full_house = evaluate_5_deuce_to_seven(cards("2h 2d 2c 5s 5h"))
    flush = evaluate_5_deuce_to_seven(cards("9h 7h 6h 4h 2h"))
    straight = evaluate_5_deuce_to_seven(cards("9c 8d 7h 6s 5c"))
    trips = evaluate_5_deuce_to_seven(cards("2h 2d 2c 7s 5h"))
    two_pair = evaluate_5_deuce_to_seven(cards("2h 2d 5c 5s 7h"))
    pair = evaluate_5_deuce_to_seven(cards("2h 2d 7c 5s 4h"))
    high_card = evaluate_5_deuce_to_seven(cards("9h 7d 6c 4s 2h"))

    worst_to_best = [straight_flush, quads, full_house, flush, straight, trips, two_pair, pair, high_card]
    keys = [deuce_to_seven_sort_key(h) for h in worst_to_best]
    assert keys == sorted(keys)
