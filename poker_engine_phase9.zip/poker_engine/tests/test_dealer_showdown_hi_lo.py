import pytest

from poker_engine.betting import PlayerBettingState
from poker_engine.cards import Card
from poker_engine.dealer import ShowdownError, resolve_showdown_hi_lo
from poker_engine.evaluation import evaluate_5, evaluate_low_5


def cards(text: str):
    return [Card.from_str(t) for t in text.split()]


def test_high_scoops_when_no_qualifying_low():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    high = {
        "a": evaluate_5(cards("Ah Ad Kc Qd 2s")),
        "b": evaluate_5(cards("Kc Kd 9h 4s 2c")),
    }
    low = {"a": None, "b": None}  # neither qualifies
    outcome = resolve_showdown_hi_lo([a, b], high, low, order_from_button=["a", "b"])
    assert outcome.total_payouts == {"a": 200}


def test_pot_splits_evenly_between_high_and_low_winners():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    high = {
        "a": evaluate_5(cards("Ah Ad Kc Qd 2s")),  # best high
        "b": evaluate_5(cards("9h 8d 7c 6s 4h")),  # worse high, but qualifies for low
    }
    low = {
        "a": evaluate_low_5(cards("Ac 2d 3h 4s Kd")),  # doesn't qualify (K in there)
        "b": evaluate_low_5(cards("8d 7c 6s 4h 2s")),  # qualifies (8-7-6-4-2, all <= 8)
    }
    outcome = resolve_showdown_hi_lo([a, b], high, low, order_from_button=["a", "b"])
    assert outcome.total_payouts == {"a": 100, "b": 100}


def test_odd_total_pot_gives_extra_chip_to_high_winner():
    a = PlayerBettingState("a", stack=0, total_contributed=101)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    high = {
        "a": evaluate_5(cards("Ah Ad Kc Qd 2s")),
        "b": evaluate_5(cards("9h 8d 7c 6s 4h")),
    }
    low = {
        "a": None,
        "b": evaluate_low_5(cards("8d 7c 6s 4h 2s")),
    }
    outcome = resolve_showdown_hi_lo([a, b], high, low, order_from_button=["a", "b"])
    pots = outcome.pot_outcomes
    main = pots[0]
    assert main.pot.amount == 200  # both reach the 100 level
    # 200 splits evenly (100/100) at this level -- no odd chip here.
    assert main.payouts == {"a": 100, "b": 100}
    side = pots[1]
    assert side.pot.amount == 1  # a's extra chip beyond b's contribution
    assert side.pot.eligible_player_ids == ("a",)
    assert side.payouts == {"a": 1}
    assert outcome.total_payouts == {"a": 101, "b": 100}


def test_odd_split_pot_amount_gives_extra_chip_to_high_half():
    a = PlayerBettingState("a", stack=0, total_contributed=101)
    b = PlayerBettingState("b", stack=0, total_contributed=101)
    c = PlayerBettingState("c", stack=0, total_contributed=101)
    high = {
        "a": evaluate_5(cards("Ah Ad Kc Qd 2s")),  # sole high winner
        "b": evaluate_5(cards("9h 8d 7c 6s 4h")),
        "c": evaluate_5(cards("9c 8h 7d 6h 4c")),
    }
    low = {
        "a": None,
        "b": evaluate_low_5(cards("8d 7c 6s 4h 2s")),  # sole qualifying low
        "c": None,
    }
    outcome = resolve_showdown_hi_lo([a, b, c], high, low, order_from_button=["a", "b", "c"])
    pot = outcome.pot_outcomes[0]
    assert pot.pot.amount == 303
    # high_half = ceil(303/2) = 152, low_half = 151
    assert pot.payouts == {"a": 152, "b": 151}
    assert pot.payouts["a"] + pot.payouts["b"] == 303


def test_uncontested_pot_skips_hand_lookups():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    b.is_folded = True
    outcome = resolve_showdown_hi_lo([a, b], {}, {}, order_from_button=["a", "b"])
    assert outcome.total_payouts == {"a": 200}


def test_missing_high_hand_result_raises():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    high = {"a": evaluate_5(cards("Ah Ad Kc Qd 2s"))}  # missing b
    with pytest.raises(ShowdownError):
        resolve_showdown_hi_lo([a, b], high, {}, order_from_button=["a", "b"])


def test_multiple_low_winners_split_the_low_half():
    a = PlayerBettingState("a", stack=0, total_contributed=90)
    b = PlayerBettingState("b", stack=0, total_contributed=90)
    c = PlayerBettingState("c", stack=0, total_contributed=90)
    high = {
        "a": evaluate_5(cards("Ah Ad Kc Qd 2s")),  # best high, no low
        "b": evaluate_5(cards("9h 8d 7c 6s 4h")),  # tied low with c
        "c": evaluate_5(cards("9c 8h 7d 6h 4c")),
    }
    low = {
        "a": None,
        "b": evaluate_low_5(cards("8d 7c 6s 4h 2s")),
        "c": evaluate_low_5(cards("8h 7d 6h 4c 2c")),  # identical ranks, different suits -> tie
    }
    outcome = resolve_showdown_hi_lo([a, b, c], high, low, order_from_button=["a", "b", "c"])
    pot = outcome.pot_outcomes[0]
    assert pot.pot.amount == 270
    # high half 135 to a; low half 135 split between b and c (67/68 with odd chip rule)
    assert pot.payouts["a"] == 135
    assert pot.payouts["b"] + pot.payouts["c"] == 135
    assert abs(pot.payouts["b"] - pot.payouts["c"]) <= 1


def test_hi_lo_handles_pot_with_no_eligible_players():
    # Same edge case as resolve_showdown's equivalent test: a contribution
    # layer where every contributor at that level folded.
    a = PlayerBettingState("a", stack=0, total_contributed=50)
    b = PlayerBettingState("b", stack=0, total_contributed=150)
    c = PlayerBettingState("c", stack=0, total_contributed=100)
    a.is_folded = True
    b.is_folded = True

    high = {"c": evaluate_5(cards("Ah Ad Kc Qd 2s"))}
    low = {"c": None}
    outcome = resolve_showdown_hi_lo([a, b, c], high, low, order_from_button=["a", "b", "c"])

    empty_pots = [po for po in outcome.pot_outcomes if not po.pot.eligible_player_ids]
    assert len(empty_pots) == 1
    assert empty_pots[0].winners == ()
    assert outcome.total_payouts == {"c": 250}


def test_all_players_win_both_halves_gives_whole_pot_to_the_group():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    high = {
        "a": evaluate_5(cards("8h 7d 6h 4c 2c")),
        "b": evaluate_5(cards("8d 7c 6s 4h 2s")),  # same ranks -> tied high too
    }
    low = {
        "a": evaluate_low_5(cards("8h 7d 6h 4c 2c")),
        "b": evaluate_low_5(cards("8d 7c 6s 4h 2s")),  # tied low too
    }
    outcome = resolve_showdown_hi_lo([a, b], high, low, order_from_button=["a", "b"])
    assert outcome.total_payouts == {"a": 100, "b": 100}
