import pytest

from poker_engine.players import Player, PlayerStatus


def test_player_basic_construction():
    p = Player(player_id="p1", display_name="Alice", stack=1000)
    assert p.status is PlayerStatus.ACTIVE
    assert p.is_active is True
    assert p.is_eliminated is False


def test_player_rejects_negative_stack():
    with pytest.raises(ValueError):
        Player(player_id="p1", display_name="Alice", stack=-1)


def test_player_not_active_if_sitting_out():
    p = Player(player_id="p1", display_name="Alice", stack=1000, status=PlayerStatus.SITTING_OUT)
    assert p.is_active is False


def test_player_not_active_if_zero_stack():
    p = Player(player_id="p1", display_name="Alice", stack=0)
    assert p.is_active is False


def test_to_betting_state_snapshots_current_stack():
    p = Player(player_id="p1", display_name="Alice", stack=500)
    bs = p.to_betting_state()
    assert bs.player_id == "p1"
    assert bs.stack == 500
    assert bs.street_contributed == 0
    assert bs.total_contributed == 0


def test_apply_hand_result_updates_stack():
    p = Player(player_id="p1", display_name="Alice", stack=500)
    bs = p.to_betting_state()
    bs.stack -= 200  # simulate having bet 200 during the hand, 300 left
    p.apply_hand_result(remaining_stack=bs.stack, payout=350)
    assert p.stack == 650  # 300 remaining + 350 won from the pot


def test_apply_hand_result_marks_eliminated_at_zero():
    p = Player(player_id="p1", display_name="Alice", stack=500)
    p.apply_hand_result(remaining_stack=0, payout=0)
    assert p.stack == 0
    assert p.status is PlayerStatus.ELIMINATED
    assert p.is_eliminated is True


def test_apply_hand_result_rejects_negative_inputs():
    p = Player(player_id="p1", display_name="Alice", stack=500)
    with pytest.raises(ValueError):
        p.apply_hand_result(remaining_stack=-1, payout=0)
    with pytest.raises(ValueError):
        p.apply_hand_result(remaining_stack=0, payout=-1)


def test_rebuy_adds_chips_and_reactivates():
    p = Player(player_id="p1", display_name="Alice", stack=0, status=PlayerStatus.ELIMINATED)
    p.rebuy(500)
    assert p.stack == 500
    assert p.status is PlayerStatus.ACTIVE


def test_rebuy_rejects_non_positive_amount():
    p = Player(player_id="p1", display_name="Alice", stack=100)
    with pytest.raises(ValueError):
        p.rebuy(0)
    with pytest.raises(ValueError):
        p.rebuy(-10)
