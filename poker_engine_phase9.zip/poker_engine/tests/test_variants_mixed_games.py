import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.structures import StudStakes
from poker_engine.tables import Table
from poker_engine.variants import (
    MixedGameError,
    MixedGameRotation,
    Omaha,
    OmahaHiLo,
    Razz,
    RotationLeg,
    SevenCardStud,
    StudHiLo,
    TexasHoldem,
    horse_rotation,
)


def make_table(n_players=3, stack=5000):
    table = Table(table_id="t1", max_seats=8)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, stack)
    return table, ids


def play_hand_to_completion(game):
    steps = 0
    while not game.is_hand_complete and steps < 300:
        if getattr(game, "awaiting_discard", False):
            pid = game.current_player
            game.discard(pid, game.hole_cards[pid][: game.HOLE_CARDS_FINAL])
            steps += 1
            continue
        if getattr(game, "awaiting_draw", False):
            pid = game.current_player
            game.draw(pid, [])
            steps += 1
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete


BLIND_LEVEL = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
STUD_STAKES = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)


# ---------------------------------------------------------------------------
# RotationLeg validation
# ---------------------------------------------------------------------------

def test_rotation_leg_valid_flop_game_construction():
    leg = RotationLeg(TexasHoldem, BettingStructure.FIXED_LIMIT, BLIND_LEVEL)
    assert leg.hands_per_leg == 1


def test_rotation_leg_valid_stud_game_construction():
    leg = RotationLeg(Razz, BettingStructure.FIXED_LIMIT, STUD_STAKES)
    assert leg.game_class is Razz


def test_rotation_leg_rejects_stud_stakes_for_flop_game():
    with pytest.raises(MixedGameError):
        RotationLeg(TexasHoldem, BettingStructure.FIXED_LIMIT, STUD_STAKES)


def test_rotation_leg_rejects_blind_level_for_stud_game():
    with pytest.raises(MixedGameError):
        RotationLeg(Razz, BettingStructure.FIXED_LIMIT, BLIND_LEVEL)


def test_rotation_leg_rejects_non_positive_hands_per_leg():
    with pytest.raises(MixedGameError):
        RotationLeg(TexasHoldem, BettingStructure.FIXED_LIMIT, BLIND_LEVEL, hands_per_leg=0)


# ---------------------------------------------------------------------------
# MixedGameRotation
# ---------------------------------------------------------------------------

def test_rotation_requires_at_least_one_leg():
    table, ids = make_table(3)
    with pytest.raises(MixedGameError):
        MixedGameRotation(table, [])


def test_rotation_starts_at_first_leg():
    table, ids = make_table(3)
    legs = [
        RotationLeg(TexasHoldem, BettingStructure.FIXED_LIMIT, BLIND_LEVEL),
        RotationLeg(Omaha, BettingStructure.FIXED_LIMIT, BLIND_LEVEL),
    ]
    rotation = MixedGameRotation(table, legs)
    assert rotation.leg_index == 0
    assert rotation.current_leg.game_class is TexasHoldem


def test_advance_moves_to_next_leg_after_hands_per_leg():
    table, ids = make_table(3)
    legs = [
        RotationLeg(TexasHoldem, BettingStructure.FIXED_LIMIT, BLIND_LEVEL, hands_per_leg=2),
        RotationLeg(Omaha, BettingStructure.FIXED_LIMIT, BLIND_LEVEL, hands_per_leg=1),
    ]
    rotation = MixedGameRotation(table, legs)
    rotation.advance()
    assert rotation.leg_index == 0  # still on leg 0 (needs 2 hands)
    assert rotation.hands_played_this_leg == 1
    rotation.advance()
    assert rotation.leg_index == 1  # now moved to leg 1
    assert rotation.hands_played_this_leg == 0


def test_advance_wraps_back_to_first_leg():
    table, ids = make_table(3)
    legs = [
        RotationLeg(TexasHoldem, BettingStructure.FIXED_LIMIT, BLIND_LEVEL),
        RotationLeg(Omaha, BettingStructure.FIXED_LIMIT, BLIND_LEVEL),
    ]
    rotation = MixedGameRotation(table, legs)
    rotation.advance()  # -> leg 1
    rotation.advance()  # -> wraps to leg 0
    assert rotation.leg_index == 0


def test_start_next_hand_constructs_the_current_legs_game_class():
    table, ids = make_table(3)
    legs = [RotationLeg(Omaha, BettingStructure.FIXED_LIMIT, BLIND_LEVEL)]
    rotation = MixedGameRotation(table, legs)
    game = rotation.start_next_hand()
    assert isinstance(game, Omaha)
    assert game.hole_cards is not None


def test_button_advances_exactly_once_per_hand_across_stud_legs():
    # Stud never advances the button itself (irrelevant to its own action
    # order), but the rotation must still advance it every hand for
    # fairness once the rotation returns to a blind-based game.
    table, ids = make_table(3)
    table.button_index = 0
    legs = [
        RotationLeg(Razz, BettingStructure.FIXED_LIMIT, STUD_STAKES),
        RotationLeg(SevenCardStud, BettingStructure.FIXED_LIMIT, STUD_STAKES),
    ]
    rotation = MixedGameRotation(table, legs)

    rotation.start_next_hand()
    first_button = table.button_index
    assert first_button != 0  # advanced from the initial position

    rotation.advance()
    rotation.start_next_hand()
    second_button = table.button_index
    assert second_button != first_button  # advanced again for the next leg


def test_full_rotation_across_all_horse_legs_conserves_chips():
    table, ids = make_table(3, stack=5000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    rotation = MixedGameRotation(table, horse_rotation(BLIND_LEVEL, STUD_STAKES, hands_per_leg=1))

    for _ in range(5):  # one full cycle through all 5 HORSE legs
        game = rotation.start_next_hand()
        play_hand_to_completion(game)
        game.settle()
        rotation.advance()

    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_horse_rotation_covers_all_five_classic_games():
    legs = horse_rotation(BLIND_LEVEL, STUD_STAKES)
    game_classes = [leg.game_class for leg in legs]
    assert game_classes == [TexasHoldem, OmahaHiLo, Razz, SevenCardStud, StudHiLo]


def test_horse_rotation_wraps_around_after_fifth_leg():
    table, ids = make_table(3, stack=5000)
    rotation = MixedGameRotation(table, horse_rotation(BLIND_LEVEL, STUD_STAKES, hands_per_leg=1))
    for _ in range(5):
        rotation.advance()
    assert rotation.leg_index == 0
    assert rotation.current_leg.game_class is TexasHoldem


def test_horse_rotation_respects_custom_hands_per_leg():
    legs = horse_rotation(BLIND_LEVEL, STUD_STAKES, hands_per_leg=8)
    assert all(leg.hands_per_leg == 8 for leg in legs)
