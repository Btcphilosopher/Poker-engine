import pytest

from poker_engine.tables import Table, TableError


def test_top_up_adds_chips():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("a", "Alice", 500)
    added = t.top_up("a", 200)
    assert added == 200
    assert t.find_player("a").stack == 700


def test_top_up_caps_at_max_buyin():
    t = Table(table_id="t1", max_seats=6, max_buyin=1000)
    t.sit_down("a", "Alice", 800)
    added = t.top_up("a", 500)
    assert added == 200  # only enough to reach 1000
    assert t.find_player("a").stack == 1000


def test_top_up_no_op_when_already_at_or_above_max_buyin():
    t = Table(table_id="t1", max_seats=6, max_buyin=1000)
    t.sit_down("a", "Alice", 1000)
    added = t.top_up("a", 500)
    assert added == 0
    assert t.find_player("a").stack == 1000


def test_top_up_does_not_reduce_stack_already_above_max_buyin():
    # A player who won a big pot can legitimately have more than
    # max_buyin; top_up must never claw that back.
    t = Table(table_id="t1", max_seats=6, max_buyin=1000)
    t.sit_down("a", "Alice", 800)
    t.find_player("a").stack = 1500  # simulate winnings
    added = t.top_up("a", 500)
    assert added == 0
    assert t.find_player("a").stack == 1500


def test_top_up_unlimited_without_max_buyin():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("a", "Alice", 500)
    added = t.top_up("a", 10_000)
    assert added == 10_000
    assert t.find_player("a").stack == 10_500


def test_top_up_unseated_player_raises():
    t = Table(table_id="t1", max_seats=6)
    with pytest.raises(TableError):
        t.top_up("ghost", 100)


def test_top_up_rejects_negative_amount():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("a", "Alice", 500)
    with pytest.raises(TableError):
        t.top_up("a", -1)


def test_top_up_reactivates_a_player_eliminated_by_hitting_zero():
    # Regression test: settle_hand() -> Player.apply_hand_result() marks a
    # player ELIMINATED the moment their stack hits exactly 0. Topping
    # them back up must reactivate them to ACTIVE (the same reactivation
    # Player.rebuy() already does) -- otherwise they'd sit at the table
    # with chips but be silently excluded from every future hand, since
    # start_hand() only ever looks at ACTIVE players with stack > 0.
    from poker_engine.players import PlayerStatus

    t = Table(table_id="t1", max_seats=4)
    t.sit_down("a", "Alice", 500)
    player = t.find_player("a")
    player.stack = 0
    player.status = PlayerStatus.ELIMINATED

    t.top_up("a", 500)

    assert player.stack == 500
    assert player.status is PlayerStatus.ACTIVE
    assert player.is_active is True


def test_top_up_zero_is_a_no_op():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("a", "Alice", 500)
    added = t.top_up("a", 0)
    assert added == 0
    assert t.find_player("a").stack == 500
