"""
Integration test: a full multi-street hand, exercising blinds -> preflop
betting -> flop betting -> side-pot computation -> distribution as one
pipeline, rather than each piece in isolation. This is the canonical
"short stack gets outdrawn but still wins the pot they're entitled to"
scenario every poker engine needs to get right.

Scenario: 3-handed No-Limit, blinds 10/20.
  - Preflop: Carol raises to 60, Alice (SB) calls, Bob (BB, short stack)
    shoves for 150 total (all-in), Carol and Alice both call.
  - Flop: Bob is out of chips and sits out. Carol shoves her remaining 150,
    Alice calls all-in too.

Final contributions: Alice 300, Bob 150, Carol 300 -> a 450 main pot
(everyone eligible) and a 300 side pot (only Alice/Carol eligible, since
Bob's stack ran out at the 150 level).
"""

from poker_engine.betting import (
    ActionType,
    BettingRound,
    BettingStructure,
    PlayerBettingState,
    compute_pots,
    distribute_pot,
    post_big_blind,
    post_small_blind,
)


def test_full_hand_produces_correct_main_and_side_pot():
    alice = PlayerBettingState("alice", stack=300)
    bob = PlayerBettingState("bob", stack=150)
    carol = PlayerBettingState("carol", stack=300)

    post_small_blind(alice, 10)
    post_big_blind(bob, 20)

    preflop = BettingRound([carol, alice, bob], BettingStructure.NO_LIMIT, min_bet=20)
    preflop.apply("carol", ActionType.RAISE, 60)
    preflop.apply("alice", ActionType.CALL)
    preflop.apply("bob", ActionType.RAISE, 150)  # bob's whole stack
    preflop.apply("carol", ActionType.CALL)
    preflop.apply("alice", ActionType.CALL)

    assert preflop.is_betting_complete()
    assert preflop.total_pot() == 450
    assert bob.is_all_in

    for p in (alice, bob, carol):
        p.start_new_street()

    # Bob is all-in and out of the action; only Alice/Carol act on the flop.
    flop = BettingRound(
        [carol, alice], BettingStructure.NO_LIMIT, min_bet=20, carried_pot=preflop.total_pot()
    )
    flop.apply("carol", ActionType.BET, 150)
    flop.apply("alice", ActionType.CALL)

    assert flop.is_betting_complete()
    assert alice.is_all_in and carol.is_all_in

    assert alice.total_contributed == 300
    assert bob.total_contributed == 150
    assert carol.total_contributed == 300

    pots = compute_pots([alice, bob, carol])
    assert len(pots) == 2
    main, side = pots
    assert main.amount == 450
    assert set(main.eligible_player_ids) == {"alice", "bob", "carol"}
    assert side.amount == 300
    assert set(side.eligible_player_ids) == {"alice", "carol"}

    # Suppose Bob has the best hand overall (wins the main pot), and
    # between Alice/Carol, Carol has the better hand (wins the side pot).
    main_payouts = distribute_pot(main, ["bob"], order_from_button=["alice", "bob", "carol"])
    side_payouts = distribute_pot(side, ["carol"], order_from_button=["alice", "carol"])

    assert main_payouts == {"bob": 450}
    assert side_payouts == {"carol": 300}

    # Money conservation across the whole hand: every chip that left a
    # stack is accounted for in exactly one payout.
    total_paid = sum(main_payouts.values()) + sum(side_payouts.values())
    total_contributed = alice.total_contributed + bob.total_contributed + carol.total_contributed
    assert total_paid == total_contributed == 750

    # Bob correctly triples up despite being the shortest stack, and never
    # had a chance to win Alice/Carol's flop side-pot money since he
    # couldn't cover it.
    assert main_payouts["bob"] == 450


def test_uncontested_pot_when_everyone_but_one_folds():
    alice = PlayerBettingState("alice", stack=300)
    bob = PlayerBettingState("bob", stack=300)
    carol = PlayerBettingState("carol", stack=300)
    post_small_blind(alice, 10)
    post_big_blind(bob, 20)

    preflop = BettingRound([carol, alice, bob], BettingStructure.NO_LIMIT, min_bet=20)
    preflop.apply("carol", ActionType.FOLD)
    preflop.apply("alice", ActionType.FOLD)

    # NOTE: is_betting_complete() answers "has everyone matched the current
    # bet and had a turn on THIS street" — it does not, by itself, know that
    # the hand should end the instant only one player remains. That check
    # ("how many players are still live?") belongs to the dealer/hand
    # orchestrator (Phase 3/4), which would award the pot to Bob immediately
    # here without even asking him to act. We verify that signal directly:
    live_players = [p for p in (alice, bob, carol) if not p.is_folded]
    assert [p.player_id for p in live_players] == ["bob"]

    pots = compute_pots([alice, bob, carol])
    assert len(pots) == 1
    assert pots[0].amount == 30  # sb(10) + bb(20), carol never contributed
    assert set(pots[0].eligible_player_ids) == {"bob"}

    payouts = distribute_pot(pots[0], ["bob"], order_from_button=["alice", "bob", "carol"])
    assert payouts == {"bob": 30}
