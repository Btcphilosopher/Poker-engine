import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import Omaha, OmahaHiLo


def make_table(n_players=3, stack=1000):
    table = Table(table_id="t1", max_seats=6)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, stack)
    return table, ids


def seeded(cls, table, seed, structure=BettingStructure.NO_LIMIT, blind_level=None):
    deck = Deck()
    deck.shuffle(seed=seed)
    blind_level = blind_level or BlindLevel(small_blind=10, big_blind=20)
    return cls(table, structure, blind_level, deck=deck)


def play_to_completion(game):
    steps = 0
    while not game.is_hand_complete and steps < 200:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete


# ---------------------------------------------------------------------------
# Omaha
# ---------------------------------------------------------------------------

def test_omaha_deals_four_hole_cards():
    table, ids = make_table(3)
    game = seeded(Omaha, table, seed=1)
    game.start_hand()
    assert all(len(cards) == 4 for cards in game.hole_cards.values())


def test_omaha_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(Omaha, table, seed=5)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_omaha_showdowns_stay_internally_consistent_across_seeds():
    for seed in range(1, 15):
        table, ids = make_table(3, stack=1000)
        game = seeded(Omaha, table, seed=seed)
        game.start_hand()
        play_to_completion(game)
        assert game.outcome.total_awarded == sum(bs.total_contributed for bs in game._betting_states.values())


# ---------------------------------------------------------------------------
# Omaha Hi-Lo
# ---------------------------------------------------------------------------

def test_omaha_hi_lo_deals_four_hole_cards():
    table, ids = make_table(3)
    game = seeded(OmahaHiLo, table, seed=1)
    game.start_hand()
    assert all(len(cards) == 4 for cards in game.hole_cards.values())


def test_omaha_hi_lo_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(OmahaHiLo, table, seed=5)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_omaha_hi_lo_can_produce_a_genuine_split_pot():
    # Search a small range of seeds for a hand where the pot is actually
    # split between different high and low winners -- verifies the full
    # FlopGame -> resolve_showdown_hi_lo wiring, not just the resolver in
    # isolation (already covered by test_dealer_showdown_hi_lo.py).
    found = False
    for seed in range(1, 40):
        table, ids = make_table(3, stack=1000)
        game = seeded(OmahaHiLo, table, seed=seed)
        game.start_hand()
        play_to_completion(game)
        for po in game.outcome.pot_outcomes:
            if len(po.winners) > 1:
                found = True
                assert po.pot.amount == sum(po.payouts.values())
        if found:
            break
    assert found, "expected at least one split pot within the sampled seeds"


def test_omaha_hi_lo_scoop_when_no_low_qualifies():
    # High-card-heavy boards where nobody can make a qualifying low --
    # the single best high hand should take the entire pot.
    for seed in range(1, 15):
        table, ids = make_table(2, stack=1000)
        game = seeded(OmahaHiLo, table, seed=seed)
        game.start_hand()
        play_to_completion(game)
        for po in game.outcome.pot_outcomes:
            if len(po.winners) == 1:
                assert po.payouts[po.winners[0]] == po.pot.amount


# ---------------------------------------------------------------------------
# structures
# ---------------------------------------------------------------------------

def test_omaha_pot_limit_completes():
    table, ids = make_table(3, stack=1000)
    game = seeded(Omaha, table, seed=3, structure=BettingStructure.POT_LIMIT)
    game.start_hand()
    play_to_completion(game)
    assert game.outcome is not None


def test_omaha_hi_lo_fixed_limit_completes():
    table, ids = make_table(3, stack=2000)
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = seeded(OmahaHiLo, table, seed=3, structure=BettingStructure.FIXED_LIMIT, blind_level=blind_level)
    game.start_hand()
    play_to_completion(game)
    assert game.outcome is not None
