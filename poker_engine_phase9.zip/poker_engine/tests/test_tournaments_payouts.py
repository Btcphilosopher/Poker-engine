import pytest

from poker_engine.tournaments.payouts import (
    PayoutError,
    calculate_payouts,
    satellite_payouts,
    standard_paid_places,
    standard_payout_percentages,
)


def test_standard_paid_places_small_field():
    assert standard_paid_places(1) == 1
    assert standard_paid_places(6) == 1


def test_standard_paid_places_sng_sized_field():
    assert standard_paid_places(9) == 3
    assert standard_paid_places(45) == 3


def test_standard_paid_places_large_field():
    assert standard_paid_places(1000) == 120  # round(1000*0.12)


def test_standard_paid_places_rejects_non_positive():
    with pytest.raises(PayoutError):
        standard_paid_places(0)


def test_standard_payout_percentages_sums_to_one():
    percentages = standard_payout_percentages(9)
    assert abs(sum(percentages) - 1.0) < 1e-9


def test_standard_payout_percentages_is_top_heavy():
    percentages = standard_payout_percentages(5)
    # most-to-least: first place pays the most
    assert percentages == sorted(percentages, reverse=True)
    assert percentages[0] > percentages[-1]


def test_standard_payout_percentages_higher_ratio_is_more_top_heavy():
    flat_ish = standard_payout_percentages(3, top_heavy_ratio=1.01)
    steep = standard_payout_percentages(3, top_heavy_ratio=3.0)
    assert steep[0] > flat_ish[0]


def test_standard_payout_percentages_rejects_invalid_ratio():
    with pytest.raises(PayoutError):
        standard_payout_percentages(3, top_heavy_ratio=1.0)
    with pytest.raises(PayoutError):
        standard_payout_percentages(3, top_heavy_ratio=0.5)


def test_standard_payout_percentages_rejects_non_positive_places():
    with pytest.raises(PayoutError):
        standard_payout_percentages(0)


def test_calculate_payouts_sums_to_exact_prize_pool():
    percentages = standard_payout_percentages(5)
    payouts = calculate_payouts(1000, percentages)
    assert sum(payouts) == 1000


def test_calculate_payouts_most_to_least():
    percentages = standard_payout_percentages(3)
    payouts = calculate_payouts(1000, percentages)
    assert payouts == sorted(payouts, reverse=True)


def test_calculate_payouts_remainder_goes_to_first_place():
    # Odd prize pool guarantees a rounding remainder somewhere.
    payouts = calculate_payouts(1001, [0.5, 0.3, 0.2])
    assert sum(payouts) == 1001


def test_calculate_payouts_rejects_percentages_not_summing_to_one():
    with pytest.raises(PayoutError):
        calculate_payouts(1000, [0.5, 0.3])


def test_calculate_payouts_rejects_empty_percentages():
    with pytest.raises(PayoutError):
        calculate_payouts(1000, [])


def test_calculate_payouts_rejects_negative_prize_pool():
    with pytest.raises(PayoutError):
        calculate_payouts(-100, [1.0])


def test_calculate_payouts_single_place_gets_everything():
    payouts = calculate_payouts(500, [1.0])
    assert payouts == [500]


def test_satellite_payouts_equal_split():
    payouts = satellite_payouts(1000, 5)
    assert payouts == [200, 200, 200, 200, 200]


def test_satellite_payouts_sums_to_exact_prize_pool():
    payouts = satellite_payouts(1001, 5)
    assert sum(payouts) == 1001


def test_satellite_payouts_remainder_distributed_from_first_place():
    payouts = satellite_payouts(1002, 5)  # 1002/5 = 200 remainder 2
    assert payouts[0] == 201
    assert payouts[1] == 201
    assert payouts[2] == 200
    assert sum(payouts) == 1002


def test_satellite_payouts_rejects_non_positive_seats():
    with pytest.raises(PayoutError):
        satellite_payouts(1000, 0)


def test_satellite_payouts_rejects_negative_prize_pool():
    with pytest.raises(PayoutError):
        satellite_payouts(-100, 5)
