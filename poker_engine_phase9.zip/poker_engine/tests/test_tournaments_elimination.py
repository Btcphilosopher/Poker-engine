from poker_engine.tournaments.elimination import compute_finishing_positions


def test_winner_gets_position_one():
    positions = compute_finishing_positions(["a", "b", "c"], winner_id="d")
    assert positions["d"] == 1


def test_first_eliminated_gets_last_position():
    positions = compute_finishing_positions(["a", "b", "c"], winner_id="d")
    assert positions["a"] == 4  # first out of 4 total


def test_last_eliminated_gets_runner_up():
    positions = compute_finishing_positions(["a", "b", "c"], winner_id="d")
    assert positions["c"] == 2


def test_middle_eliminations_ordered_correctly():
    positions = compute_finishing_positions(["a", "b", "c", "d", "e"], winner_id="f")
    assert positions == {"f": 1, "e": 2, "d": 3, "c": 4, "b": 5, "a": 6}


def test_heads_up_single_elimination():
    positions = compute_finishing_positions(["a"], winner_id="b")
    assert positions == {"b": 1, "a": 2}


def test_empty_elimination_order_means_solo_winner():
    positions = compute_finishing_positions([], winner_id="a")
    assert positions == {"a": 1}
