"""
Property-based tests for Phase 6 (Stud + Draw games). Separate from
test_variants_flop_game_properties.py since Stud and Draw have entirely
different setup (antes+bring-in vs blinds, up-cards vs discard-and-redraw).
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.betting.structures import StudStakes
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import FiveCardDraw, Razz, SevenCardStud, StudHiLo, TripleDraw

STUD_VARIANTS = [SevenCardStud, StudHiLo, Razz]
DRAW_VARIANTS = [FiveCardDraw, TripleDraw]


def _play_random_stud_game(cls, seed, n_players, stacks, structure):
    rng = random.Random(seed)
    table = Table(table_id="t1", max_seats=8)
    ids = [f"p{i}" for i in range(n_players)]
    for pid, stack in zip(ids, stacks):
        table.sit_down(pid, pid, stack)

    total_before = sum(table.find_player(pid).stack for pid in ids)

    deck = Deck()
    deck.shuffle(seed=seed)
    stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
    game = cls(table, structure, stakes, deck=deck)
    game.start_hand()

    steps = 0
    while not game.is_hand_complete and steps < 400:
        pid = game.current_player
        if pid is None:
            break
        legal = game.legal_actions(pid)
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_bet:
            options.append(ActionType.BET)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        weights = {
            ActionType.CHECK: 6,
            ActionType.CALL: 6,
            ActionType.FOLD: 1,
            ActionType.BET: 2,
            ActionType.RAISE: 2,
        }
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
        if chosen is ActionType.BET:
            game.apply_action(pid, ActionType.BET, rng.randint(legal.bet_min, legal.bet_max))
        elif chosen is ActionType.RAISE:
            game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
        else:
            game.apply_action(pid, chosen)
        steps += 1

    assert game.is_hand_complete
    assert steps < 400
    assert game.outcome is not None
    assert game.outcome.total_awarded == sum(bs.total_contributed for bs in game._betting_states.values())

    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def _play_random_draw_game(cls, seed, n_players, stacks, structure):
    rng = random.Random(seed)
    table = Table(table_id="t1", max_seats=9)
    ids = [f"p{i}" for i in range(n_players)]
    for pid, stack in zip(ids, stacks):
        table.sit_down(pid, pid, stack)

    total_before = sum(table.find_player(pid).stack for pid in ids)

    deck = Deck()
    deck.shuffle(seed=seed)
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = cls(table, structure, blind_level, deck=deck)
    game.start_hand()

    steps = 0
    while not game.is_hand_complete and steps < 400:
        if game.awaiting_draw:
            pid = game.current_player
            hand = game.hole_cards[pid]
            num_discard = rng.randint(0, len(hand))
            discard = rng.sample(hand, num_discard)
            game.draw(pid, discard)
            steps += 1
            continue

        pid = game.current_player
        if pid is None:
            break
        legal = game.legal_actions(pid)
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_bet:
            options.append(ActionType.BET)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        weights = {
            ActionType.CHECK: 6,
            ActionType.CALL: 6,
            ActionType.FOLD: 1,
            ActionType.BET: 2,
            ActionType.RAISE: 2,
        }
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
        if chosen is ActionType.BET:
            game.apply_action(pid, ActionType.BET, rng.randint(legal.bet_min, legal.bet_max))
        elif chosen is ActionType.RAISE:
            game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
        else:
            game.apply_action(pid, chosen)
        steps += 1

    assert game.is_hand_complete
    assert steps < 400
    assert game.outcome is not None
    assert game.outcome.total_awarded == sum(bs.total_contributed for bs in game._betting_states.values())

    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=6),
    stack=st.integers(min_value=100, max_value=3000),
    variant=st.sampled_from(STUD_VARIANTS),
    structure=st.sampled_from([BettingStructure.FIXED_LIMIT, BettingStructure.NO_LIMIT]),
)
@settings(max_examples=150, deadline=None)
def test_random_full_stud_games_terminate_and_conserve_chips(seed, n_players, stack, variant, structure):
    stacks = [stack] * n_players
    _play_random_stud_game(variant, seed, n_players, stacks, structure)


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    variant=st.sampled_from(STUD_VARIANTS),
)
@settings(max_examples=60, deadline=None)
def test_random_uneven_stack_stud_games(seed, variant):
    rng = random.Random(seed)
    n_players = rng.randint(2, 5)
    stacks = [rng.randint(20, 2500) for _ in range(n_players)]
    _play_random_stud_game(variant, seed, n_players, stacks, BettingStructure.FIXED_LIMIT)


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=6),
    stack=st.integers(min_value=100, max_value=3000),
    variant=st.sampled_from(DRAW_VARIANTS),
    structure=st.sampled_from([BettingStructure.NO_LIMIT, BettingStructure.POT_LIMIT, BettingStructure.FIXED_LIMIT]),
)
@settings(max_examples=150, deadline=None)
def test_random_full_draw_games_terminate_and_conserve_chips(seed, n_players, stack, variant, structure):
    stacks = [stack] * n_players
    _play_random_draw_game(variant, seed, n_players, stacks, structure)


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    variant=st.sampled_from(DRAW_VARIANTS),
)
@settings(max_examples=60, deadline=None)
def test_random_uneven_stack_draw_games(seed, variant):
    rng = random.Random(seed)
    n_players = rng.randint(2, 5)
    stacks = [rng.randint(20, 2500) for _ in range(n_players)]
    _play_random_draw_game(variant, seed, n_players, stacks, BettingStructure.NO_LIMIT)


@given(seed=st.integers(min_value=0, max_value=2**31 - 1), variant=st.sampled_from(STUD_VARIANTS))
@settings(max_examples=40, deadline=None)
def test_random_heads_up_stud_games(seed, variant):
    _play_random_stud_game(variant, seed, 2, [1000, 1000], BettingStructure.FIXED_LIMIT)


@given(seed=st.integers(min_value=0, max_value=2**31 - 1), variant=st.sampled_from(DRAW_VARIANTS))
@settings(max_examples=40, deadline=None)
def test_random_heads_up_draw_games(seed, variant):
    _play_random_draw_game(variant, seed, 2, [1000, 1000], BettingStructure.NO_LIMIT)
