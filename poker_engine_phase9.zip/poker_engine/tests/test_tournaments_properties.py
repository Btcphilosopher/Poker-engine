"""
Property-based tests for the Tournament engine: randomized full
tournaments (registration -> hands -> eliminations -> rebalancing ->
payouts) must always conserve money, regardless of field size or table
size.
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.betting import ActionType, BettingStructure
from poker_engine.deck import Deck
from poker_engine.tournaments import BlindSchedule, Tournament, TournamentConfig
from poker_engine.variants import TexasHoldem


def _run_tournament(seed, n_players, max_players_per_table, buy_in, starting_stack):
    rng = random.Random(seed)
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=30, break_every=5)
    config = TournamentConfig(
        buy_in=buy_in,
        starting_stack=starting_stack,
        blind_schedule=schedule,
        max_players_per_table=max_players_per_table,
    )
    t = Tournament(config)
    for i in range(n_players):
        t.register(f"p{i}", f"p{i}")
    t.start()

    expected_prize_pool = n_players * buy_in
    assert t.prize_pool == expected_prize_pool

    hands_played = 0
    while not t.is_finished and hands_played < 400:
        for table in list(t.tables):
            if table.occupied_count() < 2:
                continue
            blind_level = t.clock.current_level.stakes
            deck = Deck()
            deck.shuffle(seed=rng.randint(0, 2**31 - 1))
            game = TexasHoldem(table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
            game.start_hand()

            steps = 0
            while not game.is_hand_complete and steps < 500:
                pid = game.current_player
                if pid is None:
                    break
                legal = game.legal_actions(pid)
                options = []
                if legal.can_check:
                    options.append(ActionType.CHECK)
                if legal.can_call:
                    options.append(ActionType.CALL)
                if legal.can_fold:
                    options.append(ActionType.FOLD)
                if legal.can_raise:
                    options.append(ActionType.RAISE)
                weights = {ActionType.CHECK: 5, ActionType.CALL: 5, ActionType.FOLD: 2, ActionType.RAISE: 2}
                chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
                if chosen is ActionType.RAISE:
                    game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
                else:
                    game.apply_action(pid, chosen)
                steps += 1
            assert game.is_hand_complete
            game.settle()
            hands_played += 1

            for busted_id in t.busted_player_ids(table):
                t.eliminate(table, busted_id)

        chips_in_play = sum(p.stack for tb in t.tables for p in tb.occupied_seats())
        assert chips_in_play == n_players * starting_stack

        t.rebalance_tables()
        t.clock.advance_level()

    assert t.is_finished
    assert hands_played < 400

    payouts = t.finalize()
    assert sum(payouts.values()) == t.prize_pool == expected_prize_pool
    assert all(amount >= 0 for amount in payouts.values())


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=12),
    max_players_per_table=st.integers(min_value=2, max_value=6),
)
@settings(max_examples=25, deadline=None)
def test_random_tournaments_conserve_money(seed, n_players, max_players_per_table):
    _run_tournament(seed, n_players, max_players_per_table, buy_in=100, starting_stack=500)


@given(seed=st.integers(min_value=0, max_value=2**31 - 1))
@settings(max_examples=10, deadline=None)
def test_random_heads_up_tournament(seed):
    _run_tournament(seed, 2, 9, buy_in=50, starting_stack=1000)


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    buy_in=st.integers(min_value=10, max_value=500),
)
@settings(max_examples=15, deadline=None)
def test_random_tournaments_with_varied_buy_ins(seed, buy_in):
    _run_tournament(seed, 6, 4, buy_in=buy_in, starting_stack=1000)
