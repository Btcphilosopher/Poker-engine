"""
Property-based tests for TexasHoldem: randomized full games, driven
entirely through the public Game API (start_hand -> apply_action* ->
settle), must always terminate and conserve chips -- regardless of
structure, player count, stack sizes, or the specific random actions taken.
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem


def _play_random_game(seed, n_players, stacks, structure):
    rng = random.Random(seed)
    table = Table(table_id="t1", max_seats=9)
    ids = [f"p{i}" for i in range(n_players)]
    for pid, stack in zip(ids, stacks):
        table.sit_down(pid, pid, stack)

    total_before = sum(table.find_player(pid).stack for pid in ids)

    deck = Deck()
    deck.shuffle(seed=seed)
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = TexasHoldem(table, structure, blind_level, deck=deck)
    game.start_hand()

    steps = 0
    while not game.is_hand_complete and steps < 300:
        pid = game.current_player
        if pid is None:
            break
        legal = game.legal_actions(pid)
        options = []
        if legal.can_check:
            options.append(ActionType.CHECK)
        if legal.can_call:
            options.append(ActionType.CALL)
        if legal.can_fold:
            options.append(ActionType.FOLD)
        if legal.can_bet:
            options.append(ActionType.BET)
        if legal.can_raise:
            options.append(ActionType.RAISE)
        weights = {
            ActionType.CHECK: 6,
            ActionType.CALL: 6,
            ActionType.FOLD: 1,
            ActionType.BET: 2,
            ActionType.RAISE: 2,
        }
        chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
        if chosen is ActionType.BET:
            game.apply_action(pid, ActionType.BET, rng.randint(legal.bet_min, legal.bet_max))
        elif chosen is ActionType.RAISE:
            game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
        else:
            game.apply_action(pid, chosen)
        steps += 1

    assert game.is_hand_complete
    assert steps < 300  # must actually terminate, not hit the safety cap
    assert game.outcome is not None
    assert game.outcome.total_awarded == sum(
        bs.total_contributed for bs in game._betting_states.values()
    )

    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=6),
    stack=st.integers(min_value=100, max_value=5000),
    structure=st.sampled_from([BettingStructure.NO_LIMIT, BettingStructure.POT_LIMIT, BettingStructure.FIXED_LIMIT]),
)
@settings(max_examples=150, deadline=None)
def test_random_full_games_terminate_and_conserve_chips(seed, n_players, stack, structure):
    stacks = [stack] * n_players
    _play_random_game(seed, n_players, stacks, structure)


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_players=st.integers(min_value=2, max_value=5),
    structure=st.sampled_from([BettingStructure.NO_LIMIT, BettingStructure.POT_LIMIT]),
)
@settings(max_examples=100, deadline=None)
def test_random_full_games_with_uneven_stacks(seed, n_players, structure):
    rng = random.Random(seed)
    stacks = [rng.randint(20, 3000) for _ in range(n_players)]
    _play_random_game(seed, n_players, stacks, structure)


@given(seed=st.integers(min_value=0, max_value=2**31 - 1))
@settings(max_examples=50, deadline=None)
def test_random_heads_up_games(seed):
    _play_random_game(seed, 2, [1000, 1000], BettingStructure.NO_LIMIT)
