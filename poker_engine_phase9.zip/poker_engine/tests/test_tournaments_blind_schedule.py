import pytest

from poker_engine.betting import BlindLevel
from poker_engine.tournaments import BlindSchedule, BlindScheduleError, TournamentClock
from poker_engine.tournaments.blind_schedule import BlindScheduleLevel


def make_level(n, sb=10, bb=20, duration=15, is_break=False):
    return BlindScheduleLevel(
        level_number=n, stakes=BlindLevel(small_blind=sb, big_blind=bb), duration_minutes=duration, is_break=is_break
    )


def test_blind_schedule_level_rejects_non_positive_level_number():
    with pytest.raises(BlindScheduleError):
        BlindScheduleLevel(level_number=0, stakes=BlindLevel(small_blind=10, big_blind=20), duration_minutes=15)


def test_blind_schedule_level_rejects_non_positive_duration():
    with pytest.raises(BlindScheduleError):
        BlindScheduleLevel(level_number=1, stakes=BlindLevel(small_blind=10, big_blind=20), duration_minutes=0)


def test_blind_schedule_requires_at_least_one_level():
    with pytest.raises(BlindScheduleError):
        BlindSchedule([])


def test_blind_schedule_level_lookup():
    schedule = BlindSchedule([make_level(1), make_level(2, sb=20, bb=40), make_level(3, sb=40, bb=80)])
    assert schedule.level(0).stakes.small_blind == 10
    assert schedule.level(1).stakes.small_blind == 20
    assert schedule.level(2).stakes.small_blind == 40


def test_blind_schedule_clamps_to_last_level_once_exhausted():
    schedule = BlindSchedule([make_level(1), make_level(2, sb=20, bb=40)])
    assert schedule.level(5).stakes.small_blind == 20
    assert schedule.level(100).level_number == 2


def test_blind_schedule_rejects_negative_index():
    schedule = BlindSchedule([make_level(1)])
    with pytest.raises(BlindScheduleError):
        schedule.level(-1)


def test_standard_flop_schedule_blinds_increase():
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=5)
    small_blinds = [lvl.stakes.small_blind for lvl in schedule.levels]
    assert small_blinds == sorted(small_blinds)
    assert small_blinds[0] < small_blinds[-1]


def test_standard_flop_schedule_big_blind_always_double_small():
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=5)
    for lvl in schedule.levels:
        assert lvl.stakes.big_blind == lvl.stakes.small_blind * 2


def test_standard_flop_schedule_inserts_breaks():
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=8, break_every=4)
    breaks = [lvl for lvl in schedule.levels if lvl.is_break]
    assert len(breaks) == 1  # one break after level 4, none after level 8 (final level)


def test_standard_flop_schedule_no_breaks_by_default():
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=5)
    assert not any(lvl.is_break for lvl in schedule.levels)


def test_standard_flop_schedule_rejects_non_positive_num_levels():
    with pytest.raises(BlindScheduleError):
        BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=0)


# ---------------------------------------------------------------------------
# TournamentClock
# ---------------------------------------------------------------------------

def test_clock_starts_at_level_zero():
    schedule = BlindSchedule([make_level(1), make_level(2, sb=20, bb=40)])
    clock = TournamentClock(schedule)
    assert clock.level_index == 0
    assert clock.current_level.stakes.small_blind == 10


def test_clock_advance_level():
    schedule = BlindSchedule([make_level(1), make_level(2, sb=20, bb=40)])
    clock = TournamentClock(schedule)
    clock.advance_level()
    assert clock.level_index == 1
    assert clock.current_level.stakes.small_blind == 20


def test_clock_advance_stays_on_last_level():
    schedule = BlindSchedule([make_level(1), make_level(2, sb=20, bb=40)])
    clock = TournamentClock(schedule)
    clock.advance_level()
    clock.advance_level()
    clock.advance_level()
    assert clock.level_index == 1  # clamped


def test_clock_is_on_break():
    schedule = BlindSchedule([make_level(1), make_level(2, is_break=True)])
    clock = TournamentClock(schedule)
    assert clock.is_on_break is False
    clock.advance_level()
    assert clock.is_on_break is True
