import pytest

from poker_engine.cards import Card, Rank, Suit


def test_card_str_and_repr():
    c = Card(Rank.ACE, Suit.SPADES)
    assert str(c) == "As"
    assert "ACE" in repr(c)
    assert "SPADES" in repr(c)


def test_card_from_str_round_trip():
    for text in ["Ah", "Td", "9c", "2s", "Ks", "Qh"]:
        c = Card.from_str(text)
        assert str(c) == text


def test_card_from_str_ten_two_char_ok():
    c = Card.from_str("10d")
    assert c.rank is Rank.TEN
    assert c.suit is Suit.DIAMONDS


def test_card_equality_and_hash():
    a = Card(Rank.KING, Suit.HEARTS)
    b = Card(Rank.KING, Suit.HEARTS)
    c = Card(Rank.KING, Suit.CLUBS)
    assert a == b
    assert a != c
    assert hash(a) == hash(b)
    assert len({a, b, c}) == 2


def test_card_ordering():
    low = Card(Rank.TWO, Suit.CLUBS)
    high = Card(Rank.ACE, Suit.CLUBS)
    assert low < high
    assert sorted([high, low]) == [low, high]


def test_card_immutable():
    c = Card(Rank.TEN, Suit.SPADES)
    with pytest.raises(Exception):
        c.rank = Rank.ACE  # type: ignore[misc]


def test_rank_low_ace_value():
    assert Rank.ACE.low_ace_value() == 1
    assert Rank.KING.low_ace_value() == 13
    assert Rank.TWO.low_ace_value() == 2


def test_suit_and_rank_from_code_invalid():
    with pytest.raises(ValueError):
        Suit.from_code("x")
    with pytest.raises(ValueError):
        Rank.from_code("Z")


def test_all_52_cards_unique():
    all_cards = {Card(r, s) for r in Rank for s in Suit}
    assert len(all_cards) == 52


def test_card_pretty_uses_suit_symbol():
    c = Card(Rank.QUEEN, Suit.HEARTS)
    assert c.pretty() == "Q♥"


def test_card_equality_with_non_card_is_not_implemented():
    c = Card(Rank.ACE, Suit.SPADES)
    assert (c == "As") is False  # falls back to default via NotImplemented
    assert c != "As"


def test_card_lt_with_non_card_raises_type_error():
    c = Card(Rank.ACE, Suit.SPADES)
    with pytest.raises(TypeError):
        _ = c < "As"


def test_card_from_str_too_short_raises():
    with pytest.raises(ValueError):
        Card.from_str("A")
