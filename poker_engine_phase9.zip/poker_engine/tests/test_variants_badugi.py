import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import Badugi, GameError


def make_table(n_players=3, stack=1000):
    table = Table(table_id="t1", max_seats=6)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, stack)
    return table, ids


def seeded(table, seed, structure=BettingStructure.NO_LIMIT, blind_level=None):
    deck = Deck()
    deck.shuffle(seed=seed)
    blind_level = blind_level or BlindLevel(small_blind=10, big_blind=20)
    return Badugi(table, structure, blind_level, deck=deck)


def play_to_completion(game):
    steps = 0
    while not game.is_hand_complete and steps < 300:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, game.hole_cards[pid][:1])
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete


def test_deals_four_hole_cards():
    table, ids = make_table(3)
    game = seeded(table, seed=1)
    game.start_hand()
    assert all(len(cards) == 4 for cards in game.hole_cards.values())


def test_three_draw_rounds():
    assert Badugi.NUM_DRAW_ROUNDS == 3


def test_uses_badugi_evaluation_mode():
    assert Badugi.EVALUATION_MODE == "badugi"


def test_full_hand_completes_all_three_draws_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(table, seed=9)
    game.start_hand()
    play_to_completion(game)
    assert game.draws_completed == 3
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_draw_replaces_cards_correctly():
    table, ids = make_table(2)
    game = seeded(table, seed=1)
    game.start_hand()
    while not game.awaiting_draw and not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        game.apply_action(pid, ActionType.CHECK if legal.can_check else ActionType.CALL)
    pid = game.current_player
    original = game.hole_cards[pid]
    discard = original[:2]
    game.draw(pid, discard)
    new_hand = game.hole_cards[pid]
    assert len(new_hand) == 4
    assert all(c not in new_hand for c in discard)


def test_uncontested_pot_when_all_but_one_fold():
    table, ids = make_table(3, stack=1000)
    game = seeded(table, seed=1)
    game.start_hand()
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    assert game.is_hand_complete
    assert len(game.outcome.pot_outcomes[0].winners) == 1


def test_all_in_before_first_draw_still_completes_all_three_draws():
    table = Table(table_id="t2", max_seats=6)
    table.sit_down("short", "short", 50)
    table.sit_down("big", "big", 1000)
    game = seeded(table, seed=1)
    game.start_hand()

    pid = game.current_player
    legal = game.legal_actions(pid)
    game.apply_action(pid, ActionType.RAISE, legal.raise_max)
    game.apply_action(game.current_player, ActionType.CALL)

    assert game.awaiting_draw
    draws_taken = 0
    while not game.is_hand_complete:
        if game.awaiting_draw:
            pid = game.current_player
            game.draw(pid, [])
            draws_taken += 1
        else:
            break

    assert draws_taken == 6  # 3 rounds x 2 players
    assert game.is_hand_complete
    assert game.draws_completed == 3


def test_start_hand_requires_at_least_two_active_players():
    table, ids = make_table(1)
    game = seeded(table, seed=1)
    with pytest.raises(GameError):
        game.start_hand()


def test_fixed_limit_full_hand_completes():
    table, ids = make_table(3, stack=2000)
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = seeded(table, seed=11, structure=BettingStructure.FIXED_LIMIT, blind_level=blind_level)
    game.start_hand()
    play_to_completion(game)
    assert game.outcome is not None


def test_heads_up_hand_completes():
    table, ids = make_table(2, stack=1000)
    game = seeded(table, seed=42)
    game.start_hand()
    play_to_completion(game)
    assert game.outcome is not None
