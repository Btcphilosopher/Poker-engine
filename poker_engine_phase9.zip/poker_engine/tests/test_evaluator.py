import pytest

from poker_engine.cards import Card
from poker_engine.evaluation import (
    HandCategory,
    evaluate_5,
    evaluate_best_of,
    evaluate_omaha,
    evaluate_low_5,
    evaluate_low_best_of,
    evaluate_omaha_low,
)


def cards(text: str):
    """Parse a space-separated string of card codes, e.g. 'Ah Kh Qh Jh Th'."""
    return [Card.from_str(t) for t in text.split()]


# ---------------------------------------------------------------------------
# evaluate_5 — category detection
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "hand_text,expected_category",
    [
        ("Ah Kh Qh Jh Th", HandCategory.STRAIGHT_FLUSH),
        ("5h 4h 3h 2h Ah", HandCategory.STRAIGHT_FLUSH),  # wheel straight flush
        ("9c 9d 9h 9s 2c", HandCategory.FOUR_OF_A_KIND),
        ("Kc Kd Kh 4s 4c", HandCategory.FULL_HOUSE),
        ("2c 5c 9c Jc Kc", HandCategory.FLUSH),
        ("5c 6d 7h 8s 9c", HandCategory.STRAIGHT),
        ("Ac 2d 3h 4s 5c", HandCategory.STRAIGHT),  # wheel, not flush
        ("9c 9d 9h 4s 2c", HandCategory.THREE_OF_A_KIND),
        ("Kc Kd 4h 4s 2c", HandCategory.TWO_PAIR),
        ("Kc Kd 9h 4s 2c", HandCategory.PAIR),
        ("Kc Jd 9h 4s 2c", HandCategory.HIGH_CARD),
    ],
)
def test_hand_categories(hand_text, expected_category):
    result = evaluate_5(cards(hand_text))
    assert result.category == expected_category


def test_hand_result_full_ordering_dunders():
    pair = evaluate_5(cards("Kc Kd 9h 4s 2c"))
    trips = evaluate_5(cards("9c 9d 9h 4s 2c"))
    assert pair < trips
    assert pair <= trips
    assert trips > pair
    assert trips >= pair
    assert pair <= pair
    assert trips >= trips


def test_hand_result_equality_with_non_hand_result():
    pair = evaluate_5(cards("Kc Kd 9h 4s 2c"))
    assert (pair == "not a hand") is False
    assert pair != "not a hand"


def test_hand_result_str_contains_hand_name_and_cards():
    pair = evaluate_5(cards("Kc Kd 9h 4s 2c"))
    text = str(pair)
    assert "Pair" in text
    assert "Kc" in text


def test_low_hand_result_str_and_equality():
    a = evaluate_low_5(cards("7c 5d 4h 3s 2c"))
    b = evaluate_low_5(cards("7d 5h 4s 3c 2d"))
    assert a == b  # same ranks, different suits => equal low hand
    assert (a == "not a low hand") is False
    text = str(a)
    assert "7-5-4-3-2" in text


def test_royal_flush_naming():
    result = evaluate_5(cards("Ah Kh Qh Jh Th"))
    assert result.category == HandCategory.STRAIGHT_FLUSH
    assert result.hand_name == "Royal Flush"


def test_ordinary_straight_flush_naming():
    result = evaluate_5(cards("9h 8h 7h 6h 5h"))
    assert result.hand_name == "Straight Flush"


def test_evaluate_5_rejects_wrong_count():
    with pytest.raises(ValueError):
        evaluate_5(cards("Ah Kh Qh Jh"))


def test_evaluate_5_rejects_duplicate_card():
    with pytest.raises(ValueError):
        evaluate_5(cards("Ah Ah Kh Qh Jh"))


# ---------------------------------------------------------------------------
# evaluate_5 — tie-breaking within a category
# ---------------------------------------------------------------------------

def test_high_card_kicker_order_breaks_tie():
    a = evaluate_5(cards("Kc Jd 9h 4s 2c"))
    b = evaluate_5(cards("Kc Td 9h 4s 2c"))
    assert a > b  # J kicker beats T kicker


def test_pair_rank_beats_higher_kickers():
    pair_of_fours = evaluate_5(cards("4c 4d Ah Kh Qh"))
    pair_of_threes = evaluate_5(cards("3c 3d Ah Kh Qh"))
    assert pair_of_fours > pair_of_threes


def test_two_pair_compares_high_pair_first():
    aces_and_twos = evaluate_5(cards("Ac Ad 2h 2s Kc"))
    kings_and_queens = evaluate_5(cards("Kc Kd Qh Qs Ac"))
    assert aces_and_twos > kings_and_queens


def test_two_pair_same_high_pair_compares_low_pair():
    aces_and_fours = evaluate_5(cards("Ac Ad 4h 4s Kc"))
    aces_and_threes = evaluate_5(cards("Ac Ad 3h 3s Kc"))
    assert aces_and_fours > aces_and_threes


def test_flush_compares_highest_card_first():
    ace_high_flush = evaluate_5(cards("Ac 9c 7c 4c 2c"))
    king_high_flush = evaluate_5(cards("Kc Qc 7c 4c 2c"))
    assert ace_high_flush > king_high_flush


def test_full_house_trips_rank_dominates():
    fours_full_of_aces = evaluate_5(cards("4c 4d 4h Ac Ad"))
    fives_full_of_twos = evaluate_5(cards("5c 5d 5h 2c 2d"))
    assert fives_full_of_twos > fours_full_of_aces


def test_wheel_straight_loses_to_six_high_straight():
    wheel = evaluate_5(cards("Ac 2d 3h 4s 5c"))
    six_high = evaluate_5(cards("2c 3d 4h 5s 6c"))
    assert six_high > wheel


def test_category_ordering_across_types():
    high_card = evaluate_5(cards("Kc Jd 9h 4s 2c"))
    pair = evaluate_5(cards("Kc Kd 9h 4s 2c"))
    two_pair = evaluate_5(cards("Kc Kd 4h 4s 2c"))
    trips = evaluate_5(cards("9c 9d 9h 4s 2c"))
    straight = evaluate_5(cards("5c 6d 7h 8s 9c"))
    flush = evaluate_5(cards("2c 5c 9c Jc Kc"))
    full_house = evaluate_5(cards("Kc Kd Kh 4s 4c"))
    quads = evaluate_5(cards("9c 9d 9h 9s 2c"))
    straight_flush = evaluate_5(cards("9h 8h 7h 6h 5h"))

    ordered = [high_card, pair, two_pair, trips, straight, flush, full_house, quads, straight_flush]
    assert ordered == sorted(ordered)
    for worse, better in zip(ordered, ordered[1:]):
        assert better > worse


# ---------------------------------------------------------------------------
# evaluate_best_of — 7-card (hold'em/stud) evaluation
# ---------------------------------------------------------------------------

def test_best_of_seven_picks_best_five():
    # Board makes a flush possible; hole cards are irrelevant to the best hand.
    seven = cards("2c 3c 4c 5c 6c 9h 2h")
    result = evaluate_best_of(seven)
    assert result.category == HandCategory.STRAIGHT_FLUSH


def test_best_of_seven_uses_best_kicker_from_extra_cards():
    # No 5 consecutive ranks (J missing) and no 4-to-a-flush suit, so the
    # best hand really is just the pair of aces with the top three kickers.
    seven = cards("Ac Ad Kh Qd 9c Th 2s")
    result = evaluate_best_of(seven)
    assert result.category == HandCategory.PAIR
    assert result.tiebreakers[0] == 14  # pair of aces
    assert result.tiebreakers[1] == 13  # best kicker is the King


def test_best_of_rejects_fewer_than_five():
    with pytest.raises(ValueError):
        evaluate_best_of(cards("Ac Kc Qc Jc"))


# ---------------------------------------------------------------------------
# evaluate_omaha — exactly 2 hole + 3 board
# ---------------------------------------------------------------------------

def test_omaha_must_use_exactly_two_hole_cards():
    # Board is four to a flush in clubs; hole has only ONE club, so the
    # player CANNOT make the flush (unlike hold'em, where board-flush would count).
    hole = cards("Ac 7d 2h 3s")
    board = cards("Kc Qc Jc Tc 2d")
    result = evaluate_omaha(hole, board)
    assert result.category != HandCategory.FLUSH
    assert result.category != HandCategory.STRAIGHT_FLUSH


def test_omaha_can_use_two_suited_hole_cards_for_flush():
    hole = cards("Ac 9c 2h 3s")
    board = cards("Kc Qc 4c 8d 2d")
    result = evaluate_omaha(hole, board)
    assert result.category == HandCategory.FLUSH


def test_omaha_requires_minimum_cards():
    with pytest.raises(ValueError):
        evaluate_omaha(cards("Ac"), cards("Kc Qc Jc"))
    with pytest.raises(ValueError):
        evaluate_omaha(cards("Ac 9c"), cards("Kc Qc"))


# ---------------------------------------------------------------------------
# Ace-to-5 low evaluation
# ---------------------------------------------------------------------------

def test_low_seven_high_beats_low_eight_high():
    seven_low = evaluate_low_5(cards("7c 5d 4h 3s 2c"))
    eight_low = evaluate_low_5(cards("8c 5d 4h 3s 2c"))
    assert seven_low < eight_low  # lower is better


def test_low_qualification_eight_or_better():
    good = evaluate_low_5(cards("8c 5d 4h 3s 2c"))
    bad = evaluate_low_5(cards("9c 5d 4h 3s 2c"))
    assert good.qualifies_for_low is True
    assert bad.qualifies_for_low is False


def test_low_wheel_is_the_best_possible_low():
    wheel_low = evaluate_low_5(cards("Ac 2d 3h 4s 5c"))
    assert wheel_low.qualifies_for_low is True
    # The wheel (5-4-3-2-A) is the nut low.
    other = evaluate_low_5(cards("6c 4d 3h 2s Ac"))
    assert wheel_low < other


def test_unpaired_low_beats_any_paired_hand_regardless_of_rank():
    # 7-5-4-3-2 (no pair) must beat 6-6-4-3-2 (a pair), even though 6 < 7,
    # because in Ace-to-5 low, hand "shape" (pair vs no pair) dominates.
    seven_low_no_pair = evaluate_low_5(cards("7c 5d 4h 3s 2c"))
    six_low_pair = evaluate_low_5(cards("6c 6d 4h 3s 2c"))
    assert seven_low_no_pair < six_low_pair


def test_low_best_of_seven_finds_qualifying_low():
    seven = cards("Kc Qd 7h 5s 4c 3d 2h")
    result = evaluate_low_best_of(seven, qualifier=8)
    assert result is not None
    assert result.qualifies_for_low


def test_low_best_of_returns_none_when_no_qualifier():
    seven = cards("Kc Qd Jh Ts 9c 9d 9h")
    result = evaluate_low_best_of(seven, qualifier=8)
    assert result is None


def test_low_best_of_disabled_qualifier_for_razz():
    # Razz has no qualifier — should always return the best low even if high.
    seven = cards("Kc Qd Jh Ts 9c 8d 7h")
    result = evaluate_low_best_of(seven, qualifier=None)
    assert result is not None


def test_omaha_low_requires_two_hole_and_three_board():
    hole = cards("Ac 2d Kh Qs")
    board = cards("3c 4d 5h 9s Tc")
    result = evaluate_omaha_low(hole, board, qualifier=8)
    assert result is not None
    assert result.qualifies_for_low


def test_low_display_values_are_actual_ranks_not_internal_key():
    # Regression test: `values` must show the real ace-low card ranks for
    # display/export, even though comparisons go through `rank_key`.
    result = evaluate_low_5(cards("7c 5d 4h 3s 2c"))
    assert result.values == (7, 5, 4, 3, 2)


def test_low_display_values_correct_for_paired_hand():
    result = evaluate_low_5(cards("6c 6d 4h 3s 2c"))
    assert result.values == (6, 6, 4, 3, 2)


def test_low_two_pair_beats_trips_in_shape():
    two_pair = evaluate_low_5(cards("6c 6d 3h 3s 2c"))
    trips = evaluate_low_5(cards("6c 6d 6h 3s 2c"))
    assert two_pair < trips


def test_low_full_house_beats_quads_multideck():
    # Full house and quads for low hands only arise with duplicate ranks
    # across multiple decks (impossible in a single 52-card deck); exercised
    # directly here via the internal sort-key helper for completeness.
    from poker_engine.evaluation.evaluator import _low_sort_key

    full_house_key = _low_sort_key([6, 6, 6, 3, 3])
    quads_key = _low_sort_key([6, 6, 6, 6, 3])
    two_pair_key = _low_sort_key([6, 6, 3, 3, 2])
    trips_key = _low_sort_key([6, 6, 6, 3, 2])
    assert two_pair_key < trips_key < full_house_key < quads_key


def test_omaha_low_none_when_no_qualifying_combo():
    hole = cards("Kc Qd Jh Ts")
    board = cards("9c 8d 7h 6s 5c")
    result = evaluate_omaha_low(hole, board, qualifier=8)
    # Board alone would qualify in hold'em, but Omaha forces exactly 2 hole
    # cards to be used — Kc/Qd/Jh/Ts hole cards are all too high to help,
    # so no valid 2-hole+3-board combo makes a qualifying low.
    assert result is None
