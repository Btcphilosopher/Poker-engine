import pytest

from poker_engine.cards import Card
from poker_engine.evaluation import HandCategory, evaluate_5, evaluate_best_of
from poker_engine.evaluation.short_deck import evaluate_best_of_short_deck, short_deck_sort_key


def cards(text: str):
    return [Card.from_str(t) for t in text.split()]


def test_short_deck_flush_outranks_full_house():
    flush = evaluate_5(cards("Ac 9c 7c 6c Tc"))
    full_house = evaluate_5(cards("Kc Kd Kh 8s 8c"))
    assert short_deck_sort_key(flush) > short_deck_sort_key(full_house)
    # Sanity: under STANDARD rules it's the opposite.
    assert full_house > flush


def test_short_deck_ranking_otherwise_matches_standard():
    pairs_case = [
        ("9c 9d 9h 4s 2c", "9s 9h 9c Ah Kh"),  # same trips, better kickers
        ("Kc Kd 9h 4s 2c", "Ks Kh Ah Qh Jh"),  # same pair, better kickers
        ("5c 6d 7h 8s 9c", "6c 7d 8h 9s Tc"),  # straight vs higher straight
    ]
    for worse_text, better_text in pairs_case:
        worse = evaluate_5(cards(worse_text))
        better = evaluate_5(cards(better_text))
        assert short_deck_sort_key(better) > short_deck_sort_key(worse)


def test_evaluate_best_of_short_deck_prefers_flush_over_full_house():
    # A full house and a flush can never both be achievable from just 7
    # cards (the math: overlap between a 2-rank full house and a 5-suit
    # flush is at most 2 cards, so it needs at least 8 total) -- so this
    # uses 8 constructed cards to actually exercise the selection
    # difference: evaluate_best_of_short_deck must pick the flush,
    # evaluate_best_of (standard) must pick the full house.
    eight = cards("Ac Ah Ad Kc Kd 9c 7c 6c")
    short_deck_result = evaluate_best_of_short_deck(eight)
    standard_result = evaluate_best_of(eight)
    assert short_deck_result.category == HandCategory.FLUSH
    assert standard_result.category == HandCategory.FULL_HOUSE


def test_evaluate_best_of_short_deck_requires_at_least_five_cards():
    with pytest.raises(ValueError):
        evaluate_best_of_short_deck(cards("Ac Kc Qc"))


def test_short_deck_category_rank_covers_all_categories():
    from poker_engine.evaluation.short_deck import SHORT_DECK_CATEGORY_RANK

    assert set(SHORT_DECK_CATEGORY_RANK.keys()) == set(HandCategory)
    assert len(set(SHORT_DECK_CATEGORY_RANK.values())) == len(HandCategory)
