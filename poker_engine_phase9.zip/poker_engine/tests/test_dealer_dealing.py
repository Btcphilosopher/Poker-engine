import pytest

from poker_engine.deck import Deck, DeckExhaustedError
from poker_engine.dealer import (
    DealingError,
    deal_community_cards,
    deal_hole_cards,
    deal_stud_street,
    draw_replacement_cards,
)


def test_deal_hole_cards_round_robin_order():
    deck = Deck()
    deck.shuffle(seed=1)
    top_cards = deck.peek_draw_pile()[:6]  # what round-robin dealing should consume, in order

    hands = deal_hole_cards(deck, ["a", "b", "c"], 2)
    assert hands["a"] == [top_cards[0], top_cards[3]]
    assert hands["b"] == [top_cards[1], top_cards[4]]
    assert hands["c"] == [top_cards[2], top_cards[5]]


def test_deal_hole_cards_removes_from_deck():
    deck = Deck()
    deck.shuffle(seed=1)
    deal_hole_cards(deck, ["a", "b"], 2)
    assert deck.cards_remaining() == 48


def test_deal_hole_cards_empty_player_order_rejected():
    deck = Deck()
    with pytest.raises(DealingError):
        deal_hole_cards(deck, [], 2)


def test_deal_hole_cards_negative_count_rejected():
    deck = Deck()
    with pytest.raises(ValueError):
        deal_hole_cards(deck, ["a"], -1)


def test_deal_hole_cards_zero_cards_gives_empty_hands():
    deck = Deck()
    hands = deal_hole_cards(deck, ["a", "b"], 0)
    assert hands == {"a": [], "b": []}


def test_deal_hole_cards_exhausts_deck_raises():
    deck = Deck()
    with pytest.raises(DeckExhaustedError):
        deal_hole_cards(deck, ["a", "b", "c"], 20)  # needs 60 cards


def test_deal_community_cards_burns_by_default():
    deck = Deck()
    before = deck.cards_remaining()
    flop = deal_community_cards(deck, 3)
    assert len(flop.burned) == 1
    assert len(flop.cards) == 3
    assert deck.cards_remaining() == before - 4


def test_deal_community_cards_without_burn():
    deck = Deck()
    before = deck.cards_remaining()
    turn = deal_community_cards(deck, 1, burn=False)
    assert turn.burned == []
    assert len(turn.cards) == 1
    assert deck.cards_remaining() == before - 1


def test_deal_community_cards_rejects_non_positive_count():
    deck = Deck()
    with pytest.raises(ValueError):
        deal_community_cards(deck, 0)


def test_deal_stud_street_deals_one_card_each_and_tags_face():
    deck = Deck()
    before = deck.cards_remaining()
    street = deal_stud_street(deck, ["a", "b", "c"], face_up=True)
    assert set(street.cards.keys()) == {"a", "b", "c"}
    assert street.face_up is True
    assert len(street.burned) == 1
    assert deck.cards_remaining() == before - 4


def test_deal_stud_street_without_burn():
    deck = Deck()
    before = deck.cards_remaining()
    street = deal_stud_street(deck, ["a", "b"], face_up=False, burn=False)
    assert street.burned == []
    assert deck.cards_remaining() == before - 2


def test_deal_stud_street_empty_players_rejected():
    deck = Deck()
    with pytest.raises(DealingError):
        deal_stud_street(deck, [], face_up=True)


def test_draw_replacement_cards_deals_requested_count():
    deck = Deck()
    before = deck.cards_remaining()
    replacements = draw_replacement_cards(deck, 3)
    assert len(replacements) == 3
    assert deck.cards_remaining() == before - 3


def test_draw_replacement_cards_zero_is_fine():
    deck = Deck()
    assert draw_replacement_cards(deck, 0) == []


def test_draw_replacement_cards_negative_rejected():
    deck = Deck()
    with pytest.raises(ValueError):
        draw_replacement_cards(deck, -1)
