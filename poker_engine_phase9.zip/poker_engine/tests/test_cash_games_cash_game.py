import pytest

from poker_engine.cash_games import AutoTopUpPolicy, CashGame, CashGameConfig, CashGameError


def make_config(**overrides):
    defaults = dict(min_buyin=100, max_buyin=1000, max_seats=4)
    defaults.update(overrides)
    return CashGameConfig(**defaults)


# ---------------------------------------------------------------------------
# CashGameConfig validation
# ---------------------------------------------------------------------------

def test_config_rejects_non_positive_min_buyin():
    with pytest.raises(CashGameError):
        make_config(min_buyin=0)


def test_config_rejects_max_buyin_below_min_buyin():
    with pytest.raises(CashGameError):
        make_config(min_buyin=500, max_buyin=100)


def test_config_rejects_too_few_seats():
    with pytest.raises(CashGameError):
        make_config(max_seats=1)


def test_config_rejects_negative_seat_reservation_hands():
    with pytest.raises(CashGameError):
        make_config(seat_reservation_hands=-1)


# ---------------------------------------------------------------------------
# joining / leaving
# ---------------------------------------------------------------------------

def test_join_seats_immediately_when_room():
    game = CashGame(make_config())
    player = game.join("a", "Alice", 500)
    assert player is not None
    assert game.table.find_player("a") is not None


def test_join_enforces_table_buyin_range():
    game = CashGame(make_config(min_buyin=100, max_buyin=1000))
    with pytest.raises(Exception):
        game.join("a", "Alice", 50)


def test_join_waitlists_when_table_full():
    game = CashGame(make_config(max_seats=2))
    game.join("a", "Alice", 500)
    game.join("b", "Bob", 500)
    result = game.join("c", "Carol", 500)
    assert result is None
    assert game.waiting_list.position("c") == 1


def test_leave_frees_the_seat():
    game = CashGame(make_config())
    game.join("a", "Alice", 500)
    game.leave("a")
    assert game.table.find_player("a") is None


def test_leave_seats_next_waiting_player():
    game = CashGame(make_config(max_seats=2))
    game.join("a", "Alice", 500)
    game.join("b", "Bob", 500)
    game.join("c", "Carol", 300)  # waitlisted
    game.leave("a")
    assert game.table.find_player("c") is not None
    assert game.table.find_player("c").stack == 300  # their own requested buy-in
    assert game.waiting_list.is_empty


def test_leave_with_empty_waiting_list_just_frees_seat():
    game = CashGame(make_config())
    game.join("a", "Alice", 500)
    game.leave("a")
    assert game.table.occupied_count() == 0


def test_multiple_waiting_players_seated_in_fifo_order():
    game = CashGame(make_config(max_seats=2))
    game.join("a", "Alice", 500)
    game.join("b", "Bob", 500)
    game.join("c", "Carol", 500)
    game.join("d", "Dave", 500)
    game.leave("a")
    assert game.table.find_player("c") is not None
    assert game.waiting_list.position("d") == 1


# ---------------------------------------------------------------------------
# seat reservations
# ---------------------------------------------------------------------------

def test_reserve_seat_disabled_by_default():
    game = CashGame(make_config())
    with pytest.raises(CashGameError):
        game.reserve_seat("bob", "Bob")


def test_reserve_seat_holds_a_spot():
    game = CashGame(make_config(seat_reservation_hands=3))
    game.join("a", "Alice", 500)
    reservation = game.reserve_seat("bob", "Bob")
    assert reservation.player_id == "bob"
    assert game.reservations.is_reserved(reservation.seat_index)


def test_reserved_seat_is_not_given_to_a_new_joiner():
    game = CashGame(make_config(max_seats=2, seat_reservation_hands=3))
    game.join("a", "Alice", 500)
    game.reserve_seat("bob", "Bob")
    # Only one seat left, and it's reserved -- carol should be waitlisted.
    result = game.join("carol", "Carol", 500)
    assert result is None


def test_reserve_seat_no_room_raises():
    game = CashGame(make_config(max_seats=2, seat_reservation_hands=3))
    game.join("a", "Alice", 500)
    game.join("b", "Bob", 500)
    with pytest.raises(CashGameError):
        game.reserve_seat("carol", "Carol")


def test_fulfil_reservation_seats_the_player():
    game = CashGame(make_config(seat_reservation_hands=3))
    game.join("a", "Alice", 500)
    reservation = game.reserve_seat("bob", "Bob")
    player = game.fulfil_reservation(reservation.seat_index, 500)
    assert player.player_id == "bob"
    assert game.table.find_player("bob") is not None


def test_between_hands_expires_stale_reservations():
    game = CashGame(make_config(max_seats=2, seat_reservation_hands=2))
    game.join("a", "Alice", 500)
    reservation = game.reserve_seat("bob", "Bob")
    game.between_hands()
    game.between_hands()
    assert not game.reservations.is_reserved(reservation.seat_index)
    result = game.join("carol", "Carol", 500)
    assert result is not None


# ---------------------------------------------------------------------------
# rebuy / auto top-up
# ---------------------------------------------------------------------------

def test_rebuy_adds_chips():
    game = CashGame(make_config())
    game.join("a", "Alice", 300)
    added = game.rebuy("a", 200)
    assert added == 200
    assert game.table.find_player("a").stack == 500


def test_rebuy_capped_by_max_buyin():
    game = CashGame(make_config(max_buyin=1000))
    game.join("a", "Alice", 900)
    added = game.rebuy("a", 500)
    assert added == 100
    assert game.table.find_player("a").stack == 1000


def test_apply_auto_topups_no_policy_is_a_no_op():
    game = CashGame(make_config())
    game.join("a", "Alice", 500)
    game.table.find_player("a").stack = 50
    game.apply_auto_topups()
    assert game.table.find_player("a").stack == 50


def test_apply_auto_topups_tops_up_everyone_who_qualifies():
    policy = AutoTopUpPolicy(threshold=200, target=500)
    game = CashGame(make_config(auto_topup_policy=policy))
    game.join("a", "Alice", 500)
    game.join("b", "Bob", 500)
    game.table.find_player("a").stack = 100
    game.table.find_player("b").stack = 300  # above threshold, untouched
    game.apply_auto_topups()
    assert game.table.find_player("a").stack == 500
    assert game.table.find_player("b").stack == 300


def test_between_hands_applies_auto_topups():
    policy = AutoTopUpPolicy(threshold=200, target=500)
    game = CashGame(make_config(auto_topup_policy=policy))
    game.join("a", "Alice", 500)
    game.table.find_player("a").stack = 50
    game.between_hands()
    assert game.table.find_player("a").stack == 500


# ---------------------------------------------------------------------------
# hand_count
# ---------------------------------------------------------------------------

def test_hand_count_starts_at_zero_and_increments():
    game = CashGame(make_config())
    assert game.hand_count == 0
    game.between_hands()
    assert game.hand_count == 1
    game.between_hands()
    assert game.hand_count == 2
