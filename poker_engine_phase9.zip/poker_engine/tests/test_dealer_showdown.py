import pytest

from poker_engine.betting import ActionType, BettingRound, BettingStructure, PlayerBettingState
from poker_engine.cards import Card
from poker_engine.dealer import (
    ShowdownError,
    determine_reveal_order,
    last_aggressor_of,
    resolve_showdown,
)
from poker_engine.evaluation import evaluate_5


def cards(text: str):
    return [Card.from_str(t) for t in text.split()]


# ---------------------------------------------------------------------------
# last_aggressor_of / determine_reveal_order
# ---------------------------------------------------------------------------

def test_last_aggressor_of_finds_the_last_bet_or_raise():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=1000)
    c = PlayerBettingState("c", stack=1000)
    r = BettingRound([a, b, c], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("a", ActionType.BET, 40)
    r.apply("b", ActionType.RAISE, 100)
    r.apply("c", ActionType.CALL)
    r.apply("a", ActionType.CALL)
    assert last_aggressor_of(r) == "b"


def test_last_aggressor_of_none_when_everyone_checks():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=1000)
    r = BettingRound([a, b], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("a", ActionType.CHECK)
    r.apply("b", ActionType.CHECK)
    assert last_aggressor_of(r) is None


def test_reveal_order_starts_with_last_aggressor():
    order = determine_reveal_order(["a", "b", "c", "d"], last_aggressor="c")
    assert order == ["c", "d", "a", "b"]


def test_reveal_order_defaults_to_action_order_when_no_aggressor():
    order = determine_reveal_order(["a", "b", "c"], last_aggressor=None)
    assert order == ["a", "b", "c"]


def test_reveal_order_falls_back_when_aggressor_not_in_order():
    # e.g. the aggressor folded to a later street's action somehow, or this
    # is a stale reference -- defensive fallback, not expected in practice.
    order = determine_reveal_order(["a", "b", "c"], last_aggressor="ghost")
    assert order == ["a", "b", "c"]


# ---------------------------------------------------------------------------
# resolve_showdown
# ---------------------------------------------------------------------------

def test_resolve_showdown_single_pot_one_winner():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    hands = {
        "a": evaluate_5(cards("Ah Ad Kc Qd 2s")),  # pair of aces
        "b": evaluate_5(cards("Kc Kd 9h 4s 2c")),  # pair of kings
    }
    outcome = resolve_showdown([a, b], hands, order_from_button=["a", "b"])
    assert len(outcome.pot_outcomes) == 1
    assert outcome.pot_outcomes[0].winners == ("a",)
    assert outcome.total_payouts == {"a": 200}
    assert outcome.total_awarded == 200


def test_resolve_showdown_splits_tied_hands():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    # Both have the exact same hand rank (using different suits).
    hands = {
        "a": evaluate_5(cards("Ah Kd Qc Jd 9s")),
        "b": evaluate_5(cards("As Kh Qd Jc 9h")),
    }
    outcome = resolve_showdown([a, b], hands, order_from_button=["a", "b"])
    assert set(outcome.pot_outcomes[0].winners) == {"a", "b"}
    assert outcome.total_payouts == {"a": 100, "b": 100}


def test_resolve_showdown_uncontested_pot_skips_hand_lookup():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    b.is_folded = True
    # No hand_results at all -- shouldn't matter, since only 'a' is eligible.
    outcome = resolve_showdown([a, b], {}, order_from_button=["a", "b"])
    assert outcome.pot_outcomes[0].winners == ("a",)
    assert outcome.total_payouts == {"a": 200}


def test_resolve_showdown_handles_pot_with_no_eligible_players():
    # a and b both fold after committing different amounts; c stays in.
    # The layer between b's and c's contribution level has exactly one
    # contributor (b) who folded -- nobody is eligible to win that slice.
    a = PlayerBettingState("a", stack=0, total_contributed=50)
    b = PlayerBettingState("b", stack=0, total_contributed=150)
    c = PlayerBettingState("c", stack=0, total_contributed=100)
    a.is_folded = True
    b.is_folded = True

    hands = {"c": evaluate_5(cards("Ah Ad Kc Qd 2s"))}
    outcome = resolve_showdown([a, b, c], hands, order_from_button=["a", "b", "c"])

    empty_pots = [po for po in outcome.pot_outcomes if not po.pot.eligible_player_ids]
    assert len(empty_pots) == 1
    assert empty_pots[0].winners == ()
    assert empty_pots[0].payouts == {}
    # c still collects everything they were actually eligible for.
    assert outcome.total_payouts == {"c": 250}


def test_resolve_showdown_missing_hand_result_for_contested_pot_raises():
    a = PlayerBettingState("a", stack=0, total_contributed=100)
    b = PlayerBettingState("b", stack=0, total_contributed=100)
    hands = {"a": evaluate_5(cards("Ah Ad Kc Qd 2s"))}  # missing b's hand
    with pytest.raises(ShowdownError):
        resolve_showdown([a, b], hands, order_from_button=["a", "b"])


def test_resolve_showdown_side_pot_different_winners():
    # a all-in for 50 with the best hand overall (wins the main pot only);
    # b and c go to 150 each, with c beating b for the side pot.
    a = PlayerBettingState("a", stack=0, total_contributed=50)
    b = PlayerBettingState("b", stack=0, total_contributed=150)
    c = PlayerBettingState("c", stack=0, total_contributed=150)

    hands = {
        "a": evaluate_5(cards("Ah Ad As Kd Qc")),  # trips aces -- best overall
        "b": evaluate_5(cards("9h 9d 4c 3s 2h")),  # pair of nines
        "c": evaluate_5(cards("Th Td 4c 3s 2h")),  # pair of tens -- beats b
    }
    outcome = resolve_showdown([a, b, c], hands, order_from_button=["a", "b", "c"])
    assert len(outcome.pot_outcomes) == 2

    main, side = outcome.pot_outcomes
    assert main.pot.amount == 150  # 50 * 3
    assert main.winners == ("a",)
    assert side.pot.amount == 200  # 100 * 2
    assert side.winners == ("c",)

    assert outcome.total_payouts == {"a": 150, "c": 200}
    assert outcome.total_awarded == 350


def test_resolve_showdown_conserves_all_money():
    a = PlayerBettingState("a", stack=0, total_contributed=37)
    b = PlayerBettingState("b", stack=0, total_contributed=91)
    c = PlayerBettingState("c", stack=0, total_contributed=91)
    hands = {
        "a": evaluate_5(cards("2h 3d 4c 5s 7h")),
        "b": evaluate_5(cards("Ah Ad Kc Qd 2s")),
        "c": evaluate_5(cards("Kc Kd 9h 4s 2c")),
    }
    outcome = resolve_showdown([a, b, c], hands, order_from_button=["a", "b", "c"])
    assert outcome.total_awarded == 37 + 91 + 91
