"""
Property-based tests for CashGame: randomized ring-game sessions (real
hands, random joins/leaves/rebuys) must always reconcile money exactly —
total chips at the table equals total bought in, minus total cashed out,
minus whatever's still held on the waiting list.
"""

import random

from hypothesis import given, settings, strategies as st

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.cash_games import CashGame, CashGameConfig
from poker_engine.deck import Deck
from poker_engine.variants import TexasHoldem


def _run_random_cash_session(seed, n_initial_players, max_seats, n_hands):
    rng = random.Random(seed)
    config = CashGameConfig(min_buyin=100, max_buyin=1000, max_seats=max_seats)
    cash_game = CashGame(config)

    total_bought_in = 0
    total_cashed_out = 0
    total_on_waiting_list = 0

    for i in range(n_initial_players):
        buyin = rng.randint(config.min_buyin, config.max_buyin)
        result = cash_game.join(f"p{i}", f"p{i}", buyin)
        total_bought_in += buyin
        if result is None:
            total_on_waiting_list += buyin

    blind_level = BlindLevel(small_blind=5, big_blind=10)
    join_counter = n_initial_players

    for _ in range(n_hands):
        if cash_game.table.occupied_count() < 2:
            break

        waiting_before = set(cash_game.waiting_list.player_ids)

        deck = Deck()
        deck.shuffle(seed=rng.randint(0, 2**31 - 1))
        game = TexasHoldem(cash_game.table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
        game.start_hand()

        steps = 0
        while not game.is_hand_complete and steps < 300:
            pid = game.current_player
            if pid is None:
                break
            legal = game.legal_actions(pid)
            options = []
            if legal.can_check:
                options.append(ActionType.CHECK)
            if legal.can_call:
                options.append(ActionType.CALL)
            if legal.can_fold:
                options.append(ActionType.FOLD)
            if legal.can_raise:
                options.append(ActionType.RAISE)
            weights = {ActionType.CHECK: 5, ActionType.CALL: 5, ActionType.FOLD: 2, ActionType.RAISE: 2}
            chosen = rng.choices(options, weights=[weights[o] for o in options])[0]
            if chosen is ActionType.RAISE:
                game.apply_action(pid, ActionType.RAISE, rng.randint(legal.raise_min, legal.raise_max))
            else:
                game.apply_action(pid, chosen)
            steps += 1
        assert game.is_hand_complete
        game.settle()
        cash_game.between_hands()

        for player in list(cash_game.table.occupied_seats()):
            if player.stack == 0:
                cashed_out = cash_game.leave(player.player_id).stack
                total_cashed_out += cashed_out

        if rng.random() < 0.3:
            join_counter += 1
            buyin = rng.randint(config.min_buyin, config.max_buyin)
            result = cash_game.join(f"p{join_counter}", f"p{join_counter}", buyin)
            total_bought_in += buyin
            if result is None:
                total_on_waiting_list += buyin

        # Reconcile the waiting list AFTER every event that could have
        # popped someone off it this iteration (leave() itself can
        # auto-seat a waiting player via _seat_next_waiting_player, not
        # just the explicit join() calls above).
        waiting_after = set(cash_game.waiting_list.player_ids)
        for pid in waiting_before - waiting_after:
            seated = cash_game.table.find_player(pid)
            if seated is not None:
                total_on_waiting_list -= seated.stack

        still_at_table = sum(p.stack for p in cash_game.table.occupied_seats())
        assert still_at_table == total_bought_in - total_cashed_out - total_on_waiting_list
        assert still_at_table >= 0
        assert total_on_waiting_list >= 0


@given(
    seed=st.integers(min_value=0, max_value=2**31 - 1),
    n_initial_players=st.integers(min_value=2, max_value=8),
    max_seats=st.integers(min_value=2, max_value=6),
    n_hands=st.integers(min_value=1, max_value=15),
)
@settings(max_examples=40, deadline=None)
def test_random_cash_game_sessions_reconcile_money_exactly(seed, n_initial_players, max_seats, n_hands):
    _run_random_cash_session(seed, n_initial_players, max_seats, n_hands)


@given(seed=st.integers(min_value=0, max_value=2**31 - 1))
@settings(max_examples=20, deadline=None)
def test_random_heads_up_cash_game_sessions(seed):
    _run_random_cash_session(seed, 2, 6, n_hands=10)
