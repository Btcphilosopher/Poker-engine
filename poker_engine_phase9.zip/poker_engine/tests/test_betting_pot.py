import pytest

from poker_engine.betting import PlayerBettingState, Pot, PotError, compute_pots, distribute_pot


def make(player_id, total_contributed, *, folded=False):
    p = PlayerBettingState(player_id, stack=0, total_contributed=total_contributed)
    p.is_folded = folded
    return p


def test_no_contributors_returns_empty():
    assert compute_pots([]) == []
    assert compute_pots([PlayerBettingState("p1", stack=100)]) == []


def test_single_level_everyone_equal_contribution():
    players = [make("a", 100), make("b", 100), make("c", 100)]
    pots = compute_pots(players)
    assert len(pots) == 1
    assert pots[0].amount == 300
    assert pots[0].name == "Main Pot"
    assert set(pots[0].eligible_player_ids) == {"a", "b", "c"}


def test_classic_three_way_all_in_creates_main_and_side_pot():
    # a all-in for 50, b all-in for 150, c calls 150.
    players = [make("a", 50), make("b", 150), make("c", 150)]
    pots = compute_pots(players)
    assert len(pots) == 2

    main = pots[0]
    assert main.name == "Main Pot"
    assert main.amount == 150  # 50 * 3 contributors
    assert set(main.eligible_player_ids) == {"a", "b", "c"}

    side = pots[1]
    assert side.name == "Side Pot 1"
    assert side.amount == 200  # (150-50) * 2 remaining contributors
    assert set(side.eligible_player_ids) == {"b", "c"}


def test_four_way_multiple_side_pots():
    # a all-in 25, b all-in 75, c all-in 150, d calls 150.
    players = [make("a", 25), make("b", 75), make("c", 150), make("d", 150)]
    pots = compute_pots(players)
    assert [p.amount for p in pots] == [100, 150, 150]
    assert set(pots[0].eligible_player_ids) == {"a", "b", "c", "d"}
    assert set(pots[1].eligible_player_ids) == {"b", "c", "d"}
    assert set(pots[2].eligible_player_ids) == {"c", "d"}


def test_folded_player_money_stays_in_pot_but_they_cannot_win_it():
    players = [make("a", 100, folded=True), make("b", 100), make("c", 100)]
    pots = compute_pots(players)
    assert len(pots) == 1
    assert pots[0].amount == 300
    assert set(pots[0].eligible_player_ids) == {"b", "c"}  # a folded, forfeits eligibility


def test_folded_short_all_in_still_shows_correct_amount_and_eligibility():
    # a folded after committing 50 (their chips stay in the pot but they
    # can't win). Because both contribution layers here end up with the
    # SAME eligible winner set ({b, c} — a never counts, having folded),
    # they legitimately merge into a single pot: whoever wins between b/c
    # wins the whole amount either way, so this is a safe simplification,
    # not a bug.
    players = [make("a", 50, folded=True), make("b", 150), make("c", 150)]
    pots = compute_pots(players)
    assert len(pots) == 1
    assert pots[0].amount == 350  # 50*3 + 100*2 = 150 + 200
    assert set(pots[0].eligible_player_ids) == {"b", "c"}


def test_folded_all_in_at_a_distinct_level_does_create_a_separate_side_pot():
    # Here the folded player's level (50) is distinct from a THIRD live
    # player's higher level, and there are two different live-eligible sets
    # across the layers, so merging must NOT happen.
    players = [make("a", 50, folded=True), make("b", 150), make("c", 150), make("d", 300)]
    pots = compute_pots(players)
    # Layer 0-50 (all 4 reach it): 50*4=200, eligible {b,c,d} (a folded)
    # Layer 50-150 (b,c,d reach it): 100*3=300, eligible {b,c,d} -> merges with above
    # Layer 150-300 (only d reaches it): 150*1=150, eligible {d} -> distinct
    assert [p.amount for p in pots] == [500, 150]
    assert set(pots[0].eligible_player_ids) == {"b", "c", "d"}
    assert set(pots[1].eligible_player_ids) == {"d"}


def test_zero_contribution_players_ignored():
    players = [make("a", 100), make("b", 0), make("c", 100)]
    pots = compute_pots(players)
    assert len(pots) == 1
    assert pots[0].amount == 200
    assert set(pots[0].eligible_player_ids) == {"a", "c"}


def test_adjacent_pots_with_identical_eligibility_are_merged():
    # b and c both all-in for exactly 150 with a below at 50 and d covering
    # everyone at 200 -> layers (0-50: a,b,c,d) and (50-150: b,c,d) and
    # (150-200: d only, but d is the sole eligible, still a distinct pot).
    players = [make("a", 50), make("b", 150), make("c", 150), make("d", 200)]
    pots = compute_pots(players)
    # Layer 1: 50*4=200 eligible {a,b,c,d}; Layer 2: 100*3=300 eligible {b,c,d};
    # Layer 3: 50*1=50 eligible {d}. None of these have identical adjacent
    # eligibility sets, so no merging should occur here — this also exercises
    # that distinct pots are NOT incorrectly merged.
    assert [p.amount for p in pots] == [200, 300, 50]
    assert set(pots[2].eligible_player_ids) == {"d"}


# ---------------------------------------------------------------------------
# distribute_pot
# ---------------------------------------------------------------------------

def test_distribute_pot_even_split():
    pot = Pot(amount=300, eligible_player_ids=("a", "b", "c"))
    payouts = distribute_pot(pot, ["a", "b", "c"], order_from_button=["a", "b", "c"])
    assert payouts == {"a": 100, "b": 100, "c": 100}


def test_distribute_pot_single_winner_gets_everything():
    pot = Pot(amount=300, eligible_player_ids=("a",))
    payouts = distribute_pot(pot, ["a"], order_from_button=["a"])
    assert payouts == {"a": 300}


def test_distribute_pot_odd_chip_goes_to_first_winner_left_of_button():
    pot = Pot(amount=101, eligible_player_ids=("a", "b", "c"))
    # order_from_button = seating order starting left of the button;
    # winners a and c split, with b eliminated from contention elsewhere.
    payouts = distribute_pot(pot, ["a", "c"], order_from_button=["b", "c", "a"])
    # 101 // 2 = 50 each, 1 remainder chip goes to whichever of the winners
    # comes first in order_from_button: c is before a.
    assert payouts["c"] == 51
    assert payouts["a"] == 50
    assert sum(payouts.values()) == 101


def test_distribute_pot_multiple_odd_chips_distributed_in_order():
    pot = Pot(amount=101, eligible_player_ids=("a", "b", "c"))
    payouts = distribute_pot(pot, ["a", "b", "c"], order_from_button=["a", "b", "c"])
    assert sum(payouts.values()) == 101
    assert payouts["a"] == 34  # gets the sole odd chip (101 = 33*3 + 2... check below)


def test_distribute_pot_empty_winners_raises():
    pot = Pot(amount=100, eligible_player_ids=("a",))
    with pytest.raises(PotError):
        distribute_pot(pot, [], order_from_button=["a"])


def test_pot_str_with_eligible_players():
    pot = Pot(amount=150, eligible_player_ids=("a", "b"), name="Main Pot")
    assert str(pot) == "Main Pot: 150 [a, b]"


def test_pot_str_with_no_eligible_players():
    pot = Pot(amount=50, eligible_player_ids=())
    assert "(no eligible players)" in str(pot)


def test_distribute_pot_negative_amount_raises():
    pot = Pot(amount=-10, eligible_player_ids=("a",))
    with pytest.raises(PotError):
        distribute_pot(pot, ["a"], order_from_button=["a"])


def test_distribute_pot_winner_not_in_order_raises():
    pot = Pot(amount=101, eligible_player_ids=("a", "b"))
    with pytest.raises(PotError):
        distribute_pot(pot, ["a", "b"], order_from_button=["c", "d"])
