import pytest

from poker_engine.cards import Card
from poker_engine.evaluation.exposed import ExposedHandError, best_exposed_player, exposed_hand_key


def cards(text: str):
    return [Card.from_str(t) for t in text.split()]


def test_pair_beats_no_pair():
    pair = exposed_hand_key(cards("9c 9d"))
    no_pair = exposed_hand_key(cards("Kc 4d"))
    assert pair > no_pair


def test_higher_pair_beats_lower_pair():
    high_pair = exposed_hand_key(cards("Kc Kd"))
    low_pair = exposed_hand_key(cards("2c 2d"))
    assert high_pair > low_pair


def test_trips_beats_pair():
    trips = exposed_hand_key(cards("5c 5d 5h"))
    pair = exposed_hand_key(cards("9c 9d 2h"))
    assert trips > pair


def test_no_pair_compares_by_kickers():
    better = exposed_hand_key(cards("Kc 9d"))
    worse = exposed_hand_key(cards("Kc 4d"))
    assert better > worse


def test_tie_broken_by_suit_of_highest_card():
    a = exposed_hand_key(cards("Kc 4d"))
    b = exposed_hand_key(cards("Kd 4c"))
    assert a != b  # different actual cards must never produce a true tie


def test_exposed_hand_key_rejects_empty():
    with pytest.raises(ExposedHandError):
        exposed_hand_key([])


def test_best_exposed_player_high_game():
    up = {
        "a": cards("Kc 4d"),
        "b": cards("9h 9s"),
        "c": cards("2c 3d"),
    }
    assert best_exposed_player(up) == "b"  # pair of nines


def test_best_exposed_player_low_game_picks_worst_looking():
    up = {
        "a": cards("Kc 4d"),
        "b": cards("9h 9s"),
        "c": cards("2c 3d"),
    }
    assert best_exposed_player(up, low_hand=True) == "c"  # no pair, lowest cards


def test_best_exposed_player_rejects_empty():
    with pytest.raises(ExposedHandError):
        best_exposed_player({})


def test_best_exposed_player_single_up_card_third_street_style():
    up = {
        "a": cards("Kc"),
        "b": cards("2d"),
    }
    assert best_exposed_player(up) == "a"
    assert best_exposed_player(up, low_hand=True) == "b"
