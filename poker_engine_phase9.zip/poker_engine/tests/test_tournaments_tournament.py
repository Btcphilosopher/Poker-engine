import pytest

from poker_engine.tournaments import BlindSchedule, Tournament, TournamentConfig, TournamentError
from poker_engine.tournaments.bounties import BountyConfig
from poker_engine.tournaments.rebuys import RebuyPolicy


def make_config(**overrides):
    schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=10)
    defaults = dict(buy_in=100, starting_stack=1000, blind_schedule=schedule, max_players_per_table=6)
    defaults.update(overrides)
    return TournamentConfig(**defaults)


# ---------------------------------------------------------------------------
# TournamentConfig validation
# ---------------------------------------------------------------------------

def test_config_rejects_negative_buy_in():
    with pytest.raises(TournamentError):
        make_config(buy_in=-1)


def test_config_rejects_non_positive_starting_stack():
    with pytest.raises(TournamentError):
        make_config(starting_stack=0)


def test_config_rejects_too_few_seats_per_table():
    with pytest.raises(TournamentError):
        make_config(max_players_per_table=1)


def test_config_satellite_requires_num_seats():
    with pytest.raises(TournamentError):
        make_config(is_satellite=True)


def test_config_rejects_payout_percentages_not_summing_to_one():
    with pytest.raises(TournamentError):
        make_config(payout_percentages=[0.5, 0.3])


# ---------------------------------------------------------------------------
# registration
# ---------------------------------------------------------------------------

def test_register_adds_player():
    t = Tournament(make_config())
    t.register("a", "Alice")
    assert t.registered_player_ids == ["a"]


def test_register_duplicate_raises():
    t = Tournament(make_config())
    t.register("a", "Alice")
    with pytest.raises(TournamentError):
        t.register("a", "Alice Again")


def test_register_after_start_raises():
    t = Tournament(make_config())
    t.register("a", "Alice")
    t.register("b", "Bob")
    t.start()
    with pytest.raises(TournamentError):
        t.register("c", "Carol")


def test_unregister_removes_player():
    t = Tournament(make_config())
    t.register("a", "Alice")
    t.unregister("a")
    assert t.registered_player_ids == []


def test_unregister_unknown_player_raises():
    t = Tournament(make_config())
    with pytest.raises(TournamentError):
        t.unregister("ghost")


def test_unregister_after_start_raises():
    t = Tournament(make_config())
    t.register("a", "Alice")
    t.register("b", "Bob")
    t.start()
    with pytest.raises(TournamentError):
        t.unregister("a")


# ---------------------------------------------------------------------------
# start / seating
# ---------------------------------------------------------------------------

def test_start_requires_at_least_two_players():
    t = Tournament(make_config())
    t.register("a", "Alice")
    with pytest.raises(TournamentError):
        t.start()


def test_start_cannot_be_called_twice():
    t = Tournament(make_config())
    t.register("a", "Alice")
    t.register("b", "Bob")
    t.start()
    with pytest.raises(TournamentError):
        t.start()


def test_start_seats_everyone():
    t = Tournament(make_config())
    for i in range(5):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert sorted(t.remaining_player_ids) == sorted(f"p{i}" for i in range(5))


def test_start_creates_correct_number_of_tables():
    t = Tournament(make_config(max_players_per_table=4))
    for i in range(9):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert len(t.tables) == 3  # ceil(9/4)


def test_start_distributes_players_evenly():
    t = Tournament(make_config(max_players_per_table=4))
    for i in range(9):
        t.register(f"p{i}", f"p{i}")
    t.start()
    counts = sorted(tb.occupied_count() for tb in t.tables)
    assert counts == [3, 3, 3]


def test_start_gives_everyone_the_starting_stack():
    t = Tournament(make_config(starting_stack=1500))
    t.register("a", "Alice")
    t.register("b", "Bob")
    t.start()
    for table in t.tables:
        for player in table.occupied_seats():
            assert player.stack == 1500


def test_single_table_for_small_field():
    t = Tournament(make_config(max_players_per_table=9))
    for i in range(6):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert len(t.tables) == 1


def test_is_started_reflects_lifecycle():
    t = Tournament(make_config())
    assert t.is_started is False
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    assert t.is_started is True


def test_is_finished_false_before_start():
    t = Tournament(make_config())
    t.register("a", "a")
    t.register("b", "b")
    assert t.is_finished is False


def test_is_final_table_true_with_one_occupied_table():
    t = Tournament(make_config(max_players_per_table=9))
    for i in range(6):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert t.is_final_table is True


def test_is_final_table_false_with_multiple_occupied_tables():
    t = Tournament(make_config(max_players_per_table=4))
    for i in range(9):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert t.is_final_table is False


def test_rebuy_unseated_player_raises():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=5)
    t = Tournament(make_config(rebuy_policy=policy))
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    with pytest.raises(TournamentError):
        t.rebuy(t.tables[0], "ghost")


def test_addon_unseated_player_raises():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, addon_available=True, addon_chips=300)
    t = Tournament(make_config(rebuy_policy=policy))
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    with pytest.raises(TournamentError):
        t.addon(t.tables[0], "ghost")


# ---------------------------------------------------------------------------
# elimination
# ---------------------------------------------------------------------------

def test_eliminate_removes_player_from_table():
    t = Tournament(make_config())
    for i in range(3):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    t.eliminate(table, "p0")
    assert table.find_player("p0") is None


def test_eliminate_records_elimination_order():
    t = Tournament(make_config())
    for i in range(3):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    t.eliminate(table, "p0")
    assert t.eliminations == ["p0"]


def test_eliminate_returns_finishing_position():
    t = Tournament(make_config())
    for i in range(4):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    position = t.eliminate(table, "p0")
    assert position == 4  # first out of 4


def test_eliminate_unseated_player_raises():
    t = Tournament(make_config())
    for i in range(2):
        t.register(f"p{i}", f"p{i}")
    t.start()
    with pytest.raises(TournamentError):
        t.eliminate(t.tables[0], "ghost")


def test_is_finished_true_with_one_player_left():
    t = Tournament(make_config())
    for i in range(2):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert not t.is_finished
    t.eliminate(t.tables[0], "p0")
    assert t.is_finished


def test_busted_player_ids_detects_zero_stack():
    t = Tournament(make_config())
    for i in range(2):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    table.find_player("p0").stack = 0
    assert t.busted_player_ids(table) == ["p0"]


# ---------------------------------------------------------------------------
# bounty tournaments
# ---------------------------------------------------------------------------

def test_bounty_tracker_built_on_start():
    config = make_config(bounty_config=BountyConfig(bounty_amount=50))
    t = Tournament(config)
    t.register("a", "a")
    t.register("b", "b")
    assert t.bounty_tracker is None
    t.start()
    assert t.bounty_tracker is not None
    assert t.bounty_tracker.bounty_of("a") == 50


def test_bounty_tournament_requires_eliminator_id():
    config = make_config(bounty_config=BountyConfig(bounty_amount=50))
    t = Tournament(config)
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    with pytest.raises(TournamentError):
        t.eliminate(t.tables[0], "a")  # missing eliminator_id


def test_bounty_tournament_awards_cash_on_elimination():
    config = make_config(bounty_config=BountyConfig(bounty_amount=50))
    t = Tournament(config)
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    t.eliminate(t.tables[0], "a", eliminator_id="b")
    assert t.bounty_tracker.total_bounty_cash_won("b") == 50


def test_non_bounty_tournament_does_not_require_eliminator_id():
    t = Tournament(make_config())
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    t.eliminate(t.tables[0], "a")  # no eliminator_id needed


# ---------------------------------------------------------------------------
# rebuy tournaments
# ---------------------------------------------------------------------------

def test_rebuy_without_policy_raises():
    t = Tournament(make_config())
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    with pytest.raises(TournamentError):
        t.rebuy(t.tables[0], "a")


def test_rebuy_adds_chips_and_grows_prize_pool():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=5)
    t = Tournament(make_config(rebuy_policy=policy))
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    pool_before = t.prize_pool
    table = t.tables[0]
    table.find_player("a").stack = 0
    t.rebuy(table, "a")
    assert table.find_player("a").stack == 500
    assert t.prize_pool == pool_before + 50  # rebuy_cost, not buy_in


def test_addon_without_policy_raises():
    t = Tournament(make_config())
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    with pytest.raises(TournamentError):
        t.addon(t.tables[0], "a")


def test_addon_adds_chips_and_grows_prize_pool_by_addon_cost():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, addon_available=True, addon_chips=300, addon_cost=25)
    t = Tournament(make_config(rebuy_policy=policy))
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    pool_before = t.prize_pool
    table = t.tables[0]
    stack_before = table.find_player("a").stack
    t.addon(table, "a")
    assert table.find_player("a").stack == stack_before + 300
    assert t.prize_pool == pool_before + 25


# ---------------------------------------------------------------------------
# table balancing
# ---------------------------------------------------------------------------

def test_rebalance_consolidates_after_eliminations():
    t = Tournament(make_config(max_players_per_table=4))
    for i in range(8):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert len(t.tables) == 2
    table_a = t.tables[0]
    for pid in [p.player_id for p in table_a.occupied_seats()][:3]:
        t.eliminate(table_a, pid)
    t.rebalance_tables()
    counts = sorted(tb.occupied_count() for tb in t.tables if tb.occupied_count() > 0)
    assert max(counts) - min(counts) <= 1


def test_rebalance_breaks_table_when_field_shrinks_enough():
    t = Tournament(make_config(max_players_per_table=9))
    for i in range(12):
        t.register(f"p{i}", f"p{i}")
    t.start()
    assert len(t.tables) == 2
    all_ids = [p.player_id for tb in t.tables for p in tb.occupied_seats()]
    for pid in all_ids[:4]:
        for tb in t.tables:
            if tb.find_player(pid) is not None:
                t.eliminate(tb, pid)
                break
    t.rebalance_tables()
    remaining_tables = [tb for tb in t.tables if tb.occupied_count() > 0]
    assert len(remaining_tables) == 1


# ---------------------------------------------------------------------------
# finalize / payouts
# ---------------------------------------------------------------------------

def test_finalize_before_finished_raises():
    t = Tournament(make_config())
    t.register("a", "a")
    t.register("b", "b")
    t.start()
    with pytest.raises(TournamentError):
        t.finalize()


def test_finalize_pays_exactly_the_prize_pool():
    t = Tournament(make_config())
    for i in range(5):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    for pid in ["p0", "p1", "p2", "p3"]:
        t.eliminate(table, pid)
    payouts = t.finalize()
    assert sum(payouts.values()) == t.prize_pool


def test_finalize_winner_gets_the_most():
    t = Tournament(make_config())
    for i in range(5):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    for pid in ["p0", "p1", "p2", "p3"]:
        t.eliminate(table, pid)
    payouts = t.finalize()
    winner = t.remaining_player_ids[0]
    assert payouts[winner] == max(payouts.values())


def test_satellite_is_finished_once_exactly_num_seats_remain():
    # Standard satellite convention: stop once the field is down to exactly
    # num_seats -- everyone left has "made it" and every seat is worth the
    # same, so there's no reason to keep playing to a single winner.
    t = Tournament(make_config(is_satellite=True, num_seats=2))
    for i in range(5):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    t.eliminate(table, "p0")
    t.eliminate(table, "p1")
    assert not t.is_finished  # 3 remain, still above num_seats
    t.eliminate(table, "p2")
    assert t.is_finished  # exactly 2 remain now
    assert len(t.remaining_player_ids) == 2


def test_finalize_satellite_gives_equal_payouts():
    t = Tournament(make_config(is_satellite=True, num_seats=2))
    for i in range(5):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    for pid in ["p0", "p1", "p2"]:
        t.eliminate(table, pid)
    payouts = t.finalize()
    assert len(set(payouts.values())) == 1  # all equal
    assert sum(payouts.values()) == t.prize_pool


def test_finalize_uses_custom_payout_percentages():
    t = Tournament(make_config(payout_percentages=[0.7, 0.3]))
    for i in range(4):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    for pid in ["p0", "p1", "p2"]:
        t.eliminate(table, pid)
    payouts = t.finalize()
    assert sum(payouts.values()) == t.prize_pool
    assert len(payouts) == 2  # only top 2 places paid


def test_finalize_includes_bounty_cash_on_top_of_base_payout():
    config = make_config(bounty_config=BountyConfig(bounty_amount=50))
    t = Tournament(config)
    for i in range(3):
        t.register(f"p{i}", f"p{i}")
    t.start()
    table = t.tables[0]
    t.eliminate(table, "p0", eliminator_id="p1")
    t.eliminate(table, "p1", eliminator_id="p2")
    payouts = t.finalize()
    assert payouts["p2"] >= 50  # at least p1's bounty collected
