import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.variants import CrazyPineapple, GameError, Irish, Pineapple, Street
from poker_engine.tables import Table


def make_table(n_players=3, stack=1000):
    table = Table(table_id="t1", max_seats=6)
    ids = [f"p{i}" for i in range(n_players)]
    for pid in ids:
        table.sit_down(pid, pid, stack)
    return table, ids


def seeded(cls, table, seed, structure=BettingStructure.NO_LIMIT):
    deck = Deck()
    deck.shuffle(seed=seed)
    return cls(table, structure, BlindLevel(small_blind=10, big_blind=20), deck=deck)


def bet_to_discard_phase(game):
    while not game.awaiting_discard and not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)


def discard_all_keeping_first_n(game, n):
    while game.awaiting_discard:
        pid = game.current_player
        game.discard(pid, game.hole_cards[pid][:n])


def play_to_completion(game):
    steps = 0
    while not game.is_hand_complete and steps < 300:
        if game.awaiting_discard:
            discard_all_keeping_first_n(game, game.HOLE_CARDS_FINAL)
            continue
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete


# ---------------------------------------------------------------------------
# Pineapple: discard after preflop
# ---------------------------------------------------------------------------

def test_pineapple_deals_three_hole_cards():
    table, ids = make_table(3)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    assert all(len(cards) == 3 for cards in game.hole_cards.values())


def test_pineapple_discard_phase_begins_after_preflop_before_flop_dealt():
    table, ids = make_table(3)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    assert game.awaiting_discard
    assert game.street is Street.PREFLOP  # flop not dealt yet
    assert len(game.board) == 0


def test_pineapple_discard_reduces_to_two_cards_and_deals_flop():
    table, ids = make_table(3)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    discard_all_keeping_first_n(game, 2)
    assert not game.awaiting_discard
    assert all(len(cards) == 2 for cards in game.hole_cards.values())
    assert game.street is Street.FLOP
    assert len(game.board) == 3


def test_pineapple_discard_must_keep_exact_count():
    table, ids = make_table(2)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    pid = game.current_player
    with pytest.raises(GameError):
        game.discard(pid, game.hole_cards[pid][:1])  # too few


def test_pineapple_discard_rejects_cards_not_in_hand():
    table, ids = make_table(2)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    pid = game.current_player
    other_pid = [p for p in ids if p != pid][0]
    with pytest.raises(GameError):
        game.discard(pid, game.hole_cards[other_pid][:2])  # not this player's cards


def test_pineapple_discard_rejects_duplicate_cards():
    table, ids = make_table(2)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    pid = game.current_player
    card = game.hole_cards[pid][0]
    with pytest.raises(GameError):
        game.discard(pid, [card, card])


def test_pineapple_cannot_discard_when_not_awaiting():
    table, ids = make_table(2)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    pid = game.current_player
    with pytest.raises(GameError):
        game.discard(pid, game.hole_cards[pid][:2])


def test_pineapple_legal_actions_blocked_during_discard():
    table, ids = make_table(2)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    with pytest.raises(GameError):
        game.legal_actions(game.current_player)


def test_pineapple_apply_action_blocked_during_discard():
    table, ids = make_table(2)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    with pytest.raises(GameError):
        game.apply_action(game.current_player, ActionType.CHECK)


def test_pineapple_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(Pineapple, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_pineapple_discard_pauses_run_it_out_when_all_in_preflop():
    table = Table(table_id="t2", max_seats=6)
    table.sit_down("short", "short", 50)
    table.sit_down("big", "big", 1000)
    game = seeded(Pineapple, table, seed=2)
    game.start_hand()
    pid = game.current_player
    legal = game.legal_actions(pid)
    game.apply_action(pid, ActionType.RAISE, legal.raise_max)
    game.apply_action(game.current_player, ActionType.CALL)
    # Both players are now all-in, but discard must still happen before
    # the board gets run out.
    assert game.awaiting_discard
    assert not game.is_hand_complete
    discard_all_keeping_first_n(game, 2)
    assert game.is_hand_complete
    assert len(game.board) == 5


def test_discard_from_a_player_not_awaiting_raises():
    table, ids = make_table(2)
    game = seeded(Pineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    pid = game.current_player
    game.discard(pid, game.hole_cards[pid][:2])  # first player discards
    # Trying to discard again for the same (now-done) player should fail.
    with pytest.raises(GameError):
        game.discard(pid, game.hole_cards[pid][:2])


def test_flop_game_subclass_rejects_dealt_less_than_final():
    from poker_engine.variants.flop_game import FlopGame

    class BadVariant(FlopGame):
        HOLE_CARDS_DEALT = 2
        HOLE_CARDS_FINAL = 4

    table, ids = make_table(2)
    with pytest.raises(GameError):
        seeded(BadVariant, table, seed=1)


def test_flop_game_subclass_requires_discard_street_when_counts_differ():
    from poker_engine.variants.flop_game import FlopGame

    class BadVariant(FlopGame):
        HOLE_CARDS_DEALT = 3
        HOLE_CARDS_FINAL = 2
        DISCARD_AFTER_STREET = None  # forgot to set this

    table, ids = make_table(2)
    with pytest.raises(GameError):
        seeded(BadVariant, table, seed=1)


# ---------------------------------------------------------------------------
# Crazy Pineapple: discard after flop
# ---------------------------------------------------------------------------

def test_crazy_pineapple_discard_begins_after_flop_is_dealt():
    table, ids = make_table(3)
    game = seeded(CrazyPineapple, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    assert game.awaiting_discard
    assert game.street is Street.FLOP
    assert len(game.board) == 3  # flop already dealt


def test_crazy_pineapple_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(CrazyPineapple, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


# ---------------------------------------------------------------------------
# Irish: 4 hole cards, discard after flop, standard hold'em evaluation
# ---------------------------------------------------------------------------

def test_irish_deals_four_hole_cards():
    table, ids = make_table(3)
    game = seeded(Irish, table, seed=1)
    game.start_hand()
    assert all(len(cards) == 4 for cards in game.hole_cards.values())


def test_irish_discard_begins_after_flop_and_reduces_to_two():
    table, ids = make_table(3)
    game = seeded(Irish, table, seed=1)
    game.start_hand()
    bet_to_discard_phase(game)
    assert game.street is Street.FLOP
    discard_all_keeping_first_n(game, 2)
    assert all(len(cards) == 2 for cards in game.hole_cards.values())


def test_irish_full_hand_completes_and_conserves_chips():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded(Irish, table, seed=9)
    game.start_hand()
    play_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before
