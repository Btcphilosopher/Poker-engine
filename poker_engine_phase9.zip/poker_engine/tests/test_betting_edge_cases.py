import pytest

from poker_engine.betting import (
    ActionType,
    BettingRound,
    BettingStructure,
    IllegalActionError,
    PlayerBettingState,
)
from poker_engine.betting.actions import Action


def test_negative_carried_pot_rejected():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    with pytest.raises(ValueError):
        BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10, carried_pot=-1)


def test_legal_actions_on_folded_player_raises():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10)
    r.apply("p1", ActionType.BET, 20)
    r.apply("p2", ActionType.RAISE, 40)
    r.apply("p1", ActionType.FOLD)
    with pytest.raises(IllegalActionError):
        r.legal_actions("p1")


def test_legal_actions_on_all_in_player_raises():
    p1 = PlayerBettingState("p1", stack=10)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10)
    r.apply("p1", ActionType.BET, 10)  # goes all-in
    with pytest.raises(IllegalActionError):
        r.legal_actions("p1")


def test_call_with_nothing_owed_raises():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10)
    with pytest.raises(IllegalActionError):
        r.apply("p1", ActionType.CALL)  # nothing to call yet


def test_unsupported_action_type_rejected():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10)
    with pytest.raises(IllegalActionError):
        r.apply("p1", ActionType.POST_ANTE)


def test_bet_rejected_when_facing_an_existing_bet():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10)
    r.apply("p1", ActionType.BET, 20)
    with pytest.raises(IllegalActionError):
        r.apply("p2", ActionType.BET, 40)  # must RAISE, not BET, once there's a bet


def test_raise_rejected_when_nothing_to_raise_over():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10)
    with pytest.raises(IllegalActionError):
        r.apply("p1", ActionType.RAISE, 20)  # no existing bet to raise


def test_apply_all_in_raises_when_facing_a_bet_with_enough_stack():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=1000)
    r = BettingRound([a, b], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("a", ActionType.BET, 100)
    action = r.apply_all_in("b")
    assert action.action_type is ActionType.RAISE
    assert b.is_all_in


def test_apply_all_in_calls_when_too_short_to_raise():
    a = PlayerBettingState("a", stack=1000)
    b = PlayerBettingState("b", stack=15)  # can't even cover a's bet, let alone raise
    r = BettingRound([a, b], BettingStructure.NO_LIMIT, min_bet=20)
    r.apply("a", ActionType.BET, 100)
    action = r.apply_all_in("b")
    assert action.action_type is ActionType.CALL
    assert b.is_all_in
    assert b.stack == 0


def test_apply_all_in_falls_back_to_check_when_capped_and_nothing_to_call():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.FIXED_LIMIT, min_bet=10, cap_raises=0)
    action = r.apply_all_in("p1")
    assert action.action_type is ActionType.CHECK


def test_commit_more_than_stack_raises_defensively():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.NO_LIMIT, min_bet=10)
    with pytest.raises(IllegalActionError):
        r._commit(p1, 1000)  # white-box: internal invariant guard


def test_max_wager_ceiling_not_used_for_fixed_limit():
    p1 = PlayerBettingState("p1", stack=100)
    p2 = PlayerBettingState("p2", stack=100)
    r = BettingRound([p1, p2], BettingStructure.FIXED_LIMIT, min_bet=10)
    # White-box: this internal helper is only ever called for NO_LIMIT/POT_LIMIT
    # in normal operation; assert it fails loudly if misused for FIXED_LIMIT.
    with pytest.raises(AssertionError):
        r._max_wager_ceiling(p1)


def test_action_str_with_and_without_amount():
    a1 = Action(player_id="p1", action_type=ActionType.CHECK, amount=0)
    a2 = Action(player_id="p1", action_type=ActionType.BET, amount=50)
    assert str(a1) == "p1 check"
    assert str(a2) == "p1 bet 50"
