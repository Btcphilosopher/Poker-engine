import pytest

from poker_engine.players import Player
from poker_engine.tournaments.rebuys import RebuyError, RebuyPolicy, RebuyTracker


def test_rebuy_policy_rejects_non_positive_rebuy_chips():
    with pytest.raises(RebuyError):
        RebuyPolicy(rebuy_chips=0, rebuy_cost=50)


def test_rebuy_policy_rejects_negative_cost():
    with pytest.raises(RebuyError):
        RebuyPolicy(rebuy_chips=500, rebuy_cost=-1)


def test_rebuy_policy_rejects_non_positive_max_rebuys():
    with pytest.raises(RebuyError):
        RebuyPolicy(rebuy_chips=500, rebuy_cost=50, max_rebuys=0)


def test_rebuy_policy_rejects_negative_level_cutoff():
    with pytest.raises(RebuyError):
        RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=-1)


def test_rebuy_policy_addon_available_requires_positive_addon_chips():
    with pytest.raises(RebuyError):
        RebuyPolicy(rebuy_chips=500, rebuy_cost=50, addon_available=True, addon_chips=0)


def test_can_rebuy_within_level_cutoff():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=3)
    tracker = RebuyTracker(policy)
    assert tracker.can_rebuy("a", current_level_index=2) is True
    assert tracker.can_rebuy("a", current_level_index=3) is True
    assert tracker.can_rebuy("a", current_level_index=4) is False


def test_rebuy_adds_chips_and_increments_count():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=5)
    tracker = RebuyTracker(policy)
    player = Player(player_id="a", display_name="a", stack=0)
    tracker.rebuy(player, current_level_index=1)
    assert player.stack == 500
    assert tracker.rebuys_taken("a") == 1


def test_rebuy_respects_max_rebuys():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, max_rebuys=2, rebuy_level_cutoff=5)
    tracker = RebuyTracker(policy)
    player = Player(player_id="a", display_name="a", stack=0)
    tracker.rebuy(player, current_level_index=1)
    tracker.rebuy(player, current_level_index=1)
    assert tracker.can_rebuy("a", current_level_index=1) is False
    with pytest.raises(RebuyError):
        tracker.rebuy(player, current_level_index=1)


def test_rebuy_outside_window_raises():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=1)
    tracker = RebuyTracker(policy)
    player = Player(player_id="a", display_name="a", stack=0)
    with pytest.raises(RebuyError):
        tracker.rebuy(player, current_level_index=2)


def test_rebuy_reactivates_eliminated_player_via_player_rebuy():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=5)
    tracker = RebuyTracker(policy)
    from poker_engine.players import PlayerStatus

    player = Player(player_id="a", display_name="a", stack=0, status=PlayerStatus.ELIMINATED)
    tracker.rebuy(player, current_level_index=1)
    assert player.status is PlayerStatus.ACTIVE


def test_addon_unavailable_by_default():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50)
    tracker = RebuyTracker(policy)
    assert tracker.can_addon("a") is False


def test_addon_available_and_adds_chips():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, addon_available=True, addon_chips=300, addon_cost=30)
    tracker = RebuyTracker(policy)
    player = Player(player_id="a", display_name="a", stack=200)
    assert tracker.can_addon("a") is True
    tracker.addon(player)
    assert player.stack == 500


def test_addon_can_only_be_used_once():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, addon_available=True, addon_chips=300)
    tracker = RebuyTracker(policy)
    player = Player(player_id="a", display_name="a", stack=200)
    tracker.addon(player)
    assert tracker.can_addon("a") is False
    with pytest.raises(RebuyError):
        tracker.addon(player)


def test_unlimited_rebuys_when_max_rebuys_is_none():
    policy = RebuyPolicy(rebuy_chips=500, rebuy_cost=50, rebuy_level_cutoff=5)
    tracker = RebuyTracker(policy)
    player = Player(player_id="a", display_name="a", stack=0)
    for _ in range(10):
        tracker.rebuy(player, current_level_index=1)
    assert tracker.rebuys_taken("a") == 10
