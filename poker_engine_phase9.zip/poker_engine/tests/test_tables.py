import pytest

from poker_engine.betting import PlayerBettingState
from poker_engine.players import PlayerStatus
from poker_engine.tables import Table, TableError


def test_table_construction_defaults():
    t = Table(table_id="t1", max_seats=6)
    assert len(t.seats) == 6
    assert t.occupied_count() == 0


def test_table_rejects_too_few_seats():
    with pytest.raises(ValueError):
        Table(table_id="t1", max_seats=1)


def test_table_min_exceeds_max_buyin_rejected():
    with pytest.raises(ValueError):
        Table(table_id="t1", max_seats=6, min_buyin=500, max_buyin=100)


def test_sit_down_assigns_first_empty_seat():
    t = Table(table_id="t1", max_seats=3)
    p = t.sit_down("a", "Alice", 1000)
    assert p.seat_index == 0
    assert t.seats[0] is p


def test_sit_down_specific_seat():
    t = Table(table_id="t1", max_seats=3)
    p = t.sit_down("a", "Alice", 1000, seat_index=2)
    assert p.seat_index == 2
    assert t.seats[2] is p


def test_sit_down_rejects_occupied_seat():
    t = Table(table_id="t1", max_seats=3)
    t.sit_down("a", "Alice", 1000, seat_index=0)
    with pytest.raises(TableError):
        t.sit_down("b", "Bob", 1000, seat_index=0)


def test_sit_down_rejects_out_of_range_seat():
    t = Table(table_id="t1", max_seats=3)
    with pytest.raises(TableError):
        t.sit_down("a", "Alice", 1000, seat_index=5)


def test_sit_down_rejects_duplicate_player_id():
    t = Table(table_id="t1", max_seats=3)
    t.sit_down("a", "Alice", 1000)
    with pytest.raises(TableError):
        t.sit_down("a", "Alice Again", 500)


def test_sit_down_full_table_rejected():
    t = Table(table_id="t1", max_seats=2)
    t.sit_down("a", "Alice", 1000)
    t.sit_down("b", "Bob", 1000)
    with pytest.raises(TableError):
        t.sit_down("c", "Carol", 1000)


def test_sit_down_enforces_buyin_range():
    t = Table(table_id="t1", max_seats=3, min_buyin=100, max_buyin=1000)
    with pytest.raises(TableError):
        t.sit_down("a", "Alice", 50)
    with pytest.raises(TableError):
        t.sit_down("a", "Alice", 5000)
    t.sit_down("a", "Alice", 500)  # within range, fine


def test_stand_up_frees_seat():
    t = Table(table_id="t1", max_seats=3)
    t.sit_down("a", "Alice", 1000, seat_index=1)
    p = t.stand_up("a")
    assert p.player_id == "a"
    assert t.seats[1] is None
    assert t.find_player("a") is None


def test_stand_up_unknown_player_raises():
    t = Table(table_id="t1", max_seats=3)
    with pytest.raises(TableError):
        t.stand_up("ghost")


def test_active_player_ids_excludes_sitting_out_and_busted():
    t = Table(table_id="t1", max_seats=4)
    t.sit_down("a", "Alice", 1000)
    t.sit_down("b", "Bob", 1000)
    t.sit_down("c", "Carol", 0)  # busted, still seated
    t.find_player("b").status = PlayerStatus.SITTING_OUT
    assert t.active_player_ids() == ["a"]


def test_advance_button_moves_to_next_occupied_seat():
    t = Table(table_id="t1", max_seats=4)
    t.sit_down("a", "Alice", 1000, seat_index=0)
    t.sit_down("b", "Bob", 1000, seat_index=2)
    t.button_index = 0
    new_index = t.advance_button()
    assert new_index == 2  # skips the empty seat 1


def test_seats_from_button_includes_sitting_out_players():
    t = Table(table_id="t1", max_seats=3)
    t.sit_down("a", "Alice", 1000, seat_index=0)
    t.sit_down("b", "Bob", 1000, seat_index=1)
    t.find_player("b").status = PlayerStatus.SITTING_OUT
    t.sit_down("c", "Carol", 1000, seat_index=2)
    t.button_index = 0
    assert t.seats_from_button() == ["a", "b", "c"]


def test_active_seats_from_button_excludes_sitting_out_players():
    t = Table(table_id="t1", max_seats=3)
    t.sit_down("a", "Alice", 1000, seat_index=0)
    t.sit_down("b", "Bob", 1000, seat_index=1)
    t.find_player("b").status = PlayerStatus.SITTING_OUT
    t.sit_down("c", "Carol", 1000, seat_index=2)
    t.button_index = 0
    assert t.active_seats_from_button() == ["a", "c"]


def test_is_heads_up():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("a", "Alice", 1000)
    t.sit_down("b", "Bob", 1000)
    assert t.is_heads_up() is True
    t.sit_down("c", "Carol", 1000)
    assert t.is_heads_up() is False


def test_action_order_requires_at_least_two_active_players():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("a", "Alice", 1000)
    with pytest.raises(TableError):
        t.preflop_action_order()
    with pytest.raises(TableError):
        t.postflop_action_order()


def test_heads_up_action_order():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("a", "Alice", 1000)
    t.sit_down("b", "Bob", 1000)
    t.button_index = 0
    assert t.preflop_action_order() == ["a", "b"]
    assert t.postflop_action_order() == ["b", "a"]


def test_three_handed_action_order():
    t = Table(table_id="t1", max_seats=6)
    t.sit_down("btn", "Button", 1000)
    t.sit_down("sb", "SmallBlind", 1000)
    t.sit_down("bb", "BigBlind", 1000)
    t.button_index = 0
    # In 3-handed, the button is effectively UTG pre-flop.
    assert t.preflop_action_order() == ["btn", "sb", "bb"]
    assert t.postflop_action_order() == ["sb", "bb", "btn"]


def test_five_handed_action_order():
    t = Table(table_id="t1", max_seats=6)
    for pid in ["btn", "sb", "bb", "utg", "utg1"]:
        t.sit_down(pid, pid, 1000)
    t.button_index = 0
    assert t.preflop_action_order() == ["utg", "utg1", "btn", "sb", "bb"]
    assert t.postflop_action_order() == ["sb", "bb", "utg", "utg1", "btn"]


def test_settle_hand_updates_stacks_and_marks_elimination():
    t = Table(table_id="t1", max_seats=3)
    t.sit_down("a", "Alice", 1000)
    t.sit_down("b", "Bob", 500)

    alice_bs = PlayerBettingState("a", stack=800)  # bet 200, has 800 left
    bob_bs = PlayerBettingState("b", stack=0)  # bet it all, has 0 left

    t.settle_hand(
        betting_states={"a": alice_bs, "b": bob_bs},
        payouts={"b": 700},  # bob won the pot
    )
    assert t.find_player("a").stack == 800
    assert t.find_player("b").stack == 700
    assert t.find_player("b").status is PlayerStatus.ACTIVE


def test_settle_hand_unknown_player_raises():
    t = Table(table_id="t1", max_seats=3)
    t.sit_down("a", "Alice", 1000)
    ghost_bs = PlayerBettingState("ghost", stack=100)
    with pytest.raises(TableError):
        t.settle_hand(betting_states={"ghost": ghost_bs}, payouts={})


def test_seats_length_mismatch_rejected():
    with pytest.raises(ValueError):
        Table(table_id="t1", max_seats=3, seats=[None, None])
