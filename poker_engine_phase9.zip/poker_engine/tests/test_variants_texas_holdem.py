import pytest

from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import GameError, Street, TexasHoldem


def make_table(n_players=3, stack=1000, max_seats=6):
    table = Table(table_id="t1", max_seats=max_seats)
    ids = [f"p{i}" for i in range(n_players)]
    for i, pid in enumerate(ids):
        table.sit_down(pid, pid, stack, seat_index=i)
    return table, ids


def seeded_game(table, structure=BettingStructure.NO_LIMIT, seed=1, blind_level=None):
    deck = Deck()
    deck.shuffle(seed=seed)
    blind_level = blind_level or BlindLevel(small_blind=10, big_blind=20)
    return TexasHoldem(table, structure, blind_level, deck=deck)


def check_or_call_to_completion(game):
    """Drive a hand to completion using only check/call, for tests that
    don't care about the specific betting line."""
    steps = 0
    while not game.is_hand_complete and steps < 200:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
        steps += 1
    assert game.is_hand_complete


# ---------------------------------------------------------------------------
# start_hand
# ---------------------------------------------------------------------------

def test_start_hand_deals_two_hole_cards_to_each_active_player():
    table, ids = make_table(3)
    game = seeded_game(table)
    game.start_hand()
    assert set(game.hole_cards.keys()) == set(ids)
    assert all(len(cards) == 2 for cards in game.hole_cards.values())


def test_start_hand_advances_the_button():
    table, ids = make_table(3)
    table.button_index = 0
    game = seeded_game(table)
    game.start_hand()
    assert table.button_index != 0


def test_start_hand_requires_at_least_two_active_players():
    table, ids = make_table(1)
    game = seeded_game(table)
    with pytest.raises(GameError):
        game.start_hand()


def test_start_hand_can_only_be_called_once():
    table, ids = make_table(3)
    game = seeded_game(table)
    game.start_hand()
    with pytest.raises(GameError):
        game.start_hand()


def test_legal_actions_before_start_hand_raises():
    table, ids = make_table(3)
    game = seeded_game(table)
    with pytest.raises(GameError):
        game.legal_actions("p0")


def test_apply_action_before_start_hand_raises():
    table, ids = make_table(3)
    game = seeded_game(table)
    with pytest.raises(GameError):
        game.apply_action("p0", ActionType.CHECK)


def test_current_player_is_none_before_start():
    table, ids = make_table(3)
    game = seeded_game(table)
    assert game.current_player is None


def test_start_hand_creates_own_securely_shuffled_deck_if_none_provided():
    table, ids = make_table(3)
    blind_level = BlindLevel(small_blind=10, big_blind=20)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, blind_level)  # no deck passed
    game.start_hand()
    assert all(len(cards) == 2 for cards in game.hole_cards.values())
    dealt = [c for cards in game.hole_cards.values() for c in cards]
    assert len(dealt) == len(set(dealt))  # no duplicate cards


def test_antes_are_collected_into_the_preflop_pot():
    table, ids = make_table(3, stack=1000)
    blind_level = BlindLevel(small_blind=10, big_blind=20, ante=5)
    game = seeded_game(table, seed=1, blind_level=blind_level)
    game.start_hand()
    # 3 players x 5 ante = 15, plus blinds 10+20 = 30 -> pot starts at 45
    assert game._round.total_pot() == 45


def test_preflop_pot_reflects_blinds_immediately():
    table, ids = make_table(3)
    game = seeded_game(table)
    game.start_hand()
    assert game.street is Street.PREFLOP
    assert game.current_player is not None


# ---------------------------------------------------------------------------
# full hand flow via check/call
# ---------------------------------------------------------------------------

def test_full_hand_reaches_showdown_and_deals_five_board_cards():
    table, ids = make_table(3)
    game = seeded_game(table, seed=99)
    game.start_hand()
    check_or_call_to_completion(game)
    assert len(game.board) == 5
    assert game.outcome is not None
    assert game.outcome.total_awarded == sum(game.outcome.total_payouts.values())


def test_full_hand_conserves_chips_after_settlement():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded_game(table, seed=99)
    game.start_hand()
    check_or_call_to_completion(game)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


def test_action_log_records_every_action_tagged_with_street():
    table, ids = make_table(3)
    game = seeded_game(table, seed=99)
    game.start_hand()
    check_or_call_to_completion(game)
    streets_seen = {sa.street for sa in game.action_log}
    assert Street.PREFLOP in streets_seen
    assert Street.RIVER in streets_seen
    assert len(game.action_log) > 0


def test_settle_before_hand_complete_raises():
    table, ids = make_table(3)
    game = seeded_game(table)
    game.start_hand()
    with pytest.raises(GameError):
        game.settle()


def test_apply_action_after_hand_complete_raises():
    table, ids = make_table(3)
    game = seeded_game(table, seed=99)
    game.start_hand()
    check_or_call_to_completion(game)
    with pytest.raises(GameError):
        game.apply_action(ids[0], ActionType.CHECK)


# ---------------------------------------------------------------------------
# uncontested pots (folding)
# ---------------------------------------------------------------------------

def test_everyone_folds_but_one_ends_hand_immediately_without_dealing_board():
    table, ids = make_table(3)
    game = seeded_game(table, seed=3)
    game.start_hand()
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    assert game.is_hand_complete
    assert game.board == []  # never dealt -- nobody needed to see it
    assert len(game.outcome.pot_outcomes) == 1
    assert len(game.outcome.pot_outcomes[0].winners) == 1


def test_uncontested_pot_settles_correctly():
    table, ids = make_table(3, stack=1000)
    total_before = sum(table.find_player(pid).stack for pid in ids)
    game = seeded_game(table, seed=3)
    game.start_hand()
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    pid = game.current_player
    game.apply_action(pid, ActionType.FOLD)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ids)
    assert total_after == total_before


# ---------------------------------------------------------------------------
# all-in / running it out
# ---------------------------------------------------------------------------

def test_all_in_runs_the_board_out_automatically():
    table = Table(table_id="t1", max_seats=6)
    table.sit_down("short", "short", 100, seat_index=0)
    table.sit_down("b", "b", 1000, seat_index=1)
    table.sit_down("c", "c", 1000, seat_index=2)
    game = seeded_game(table, seed=7)
    game.start_hand()

    pid = game.current_player
    legal = game.legal_actions(pid)
    game.apply_action(pid, ActionType.RAISE, legal.raise_max)  # shove full stack
    pid = game.current_player
    game.apply_action(pid, ActionType.CALL)
    pid = game.current_player
    game.apply_action(pid, ActionType.CALL)

    assert game.is_hand_complete
    assert len(game.board) == 5  # ran out automatically, no more actions needed
    assert game.current_player is None


def test_all_in_produces_correct_side_pots():
    table = Table(table_id="t1", max_seats=6)
    table.sit_down("short", "short", 100, seat_index=0)
    table.sit_down("b", "b", 1000, seat_index=1)
    table.sit_down("c", "c", 1000, seat_index=2)
    game = seeded_game(table, seed=7)
    game.start_hand()

    pid = game.current_player
    legal = game.legal_actions(pid)
    game.apply_action(pid, ActionType.RAISE, legal.raise_max)
    pid = game.current_player
    game.apply_action(pid, ActionType.CALL)
    pid = game.current_player
    game.apply_action(pid, ActionType.CALL)

    assert len(game.outcome.pot_outcomes) == 2
    assert game.outcome.total_awarded == 100 + 1000 + 1000


def test_all_in_then_settle_conserves_chips():
    table = Table(table_id="t1", max_seats=6)
    for pid, stack in [("short", 100), ("b", 1000), ("c", 1000)]:
        table.sit_down(pid, pid, stack)
    total_before = 100 + 1000 + 1000
    game = seeded_game(table, seed=7)
    game.start_hand()
    pid = game.current_player
    legal = game.legal_actions(pid)
    game.apply_action(pid, ActionType.RAISE, legal.raise_max)
    game.apply_action(game.current_player, ActionType.CALL)
    game.apply_action(game.current_player, ActionType.CALL)
    game.settle()
    total_after = sum(table.find_player(pid).stack for pid in ("short", "b", "c"))
    assert total_after == total_before


# ---------------------------------------------------------------------------
# betting structures
# ---------------------------------------------------------------------------

def test_pot_limit_hold_em_caps_raises_to_pot_size():
    table, ids = make_table(3)
    game = seeded_game(table, structure=BettingStructure.POT_LIMIT, seed=1)
    game.start_hand()
    pid = game.current_player
    legal = game.legal_actions(pid)
    assert legal.can_raise
    assert legal.raise_max < 1000  # far less than full stack, capped by the pot


def test_fixed_limit_hold_em_uses_exact_bet_sizes():
    table, ids = make_table(3)
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = seeded_game(table, structure=BettingStructure.FIXED_LIMIT, seed=1, blind_level=blind_level)
    game.start_hand()
    pid = game.current_player
    legal = game.legal_actions(pid)
    assert legal.raise_min == legal.raise_max  # fixed-limit: no choice of size


def test_fixed_limit_uses_big_bet_on_turn_and_river():
    table, ids = make_table(2)  # heads-up keeps this simple
    blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
    game = seeded_game(table, structure=BettingStructure.FIXED_LIMIT, seed=5, blind_level=blind_level)
    game.start_hand()
    while game.street in (Street.PREFLOP, Street.FLOP) and not game.is_hand_complete:
        pid = game.current_player
        legal = game.legal_actions(pid)
        action = ActionType.CHECK if legal.can_check else ActionType.CALL
        game.apply_action(pid, action)
    if not game.is_hand_complete:
        assert game.street in (Street.TURN, Street.RIVER)
        pid = game.current_player
        legal = game.legal_actions(pid)
        if legal.can_bet:
            assert legal.bet_min == 40


def test_no_limit_and_pot_limit_and_fixed_limit_all_complete_a_hand():
    for structure in (BettingStructure.NO_LIMIT, BettingStructure.POT_LIMIT, BettingStructure.FIXED_LIMIT):
        table, ids = make_table(3, stack=2000)
        blind_level = BlindLevel(small_blind=10, big_blind=20, small_bet=20, big_bet=40)
        game = seeded_game(table, structure=structure, seed=11, blind_level=blind_level)
        game.start_hand()
        check_or_call_to_completion(game)
        assert game.outcome is not None


# ---------------------------------------------------------------------------
# heads-up
# ---------------------------------------------------------------------------

def test_heads_up_hand_completes():
    table, ids = make_table(2, stack=1000)
    game = seeded_game(table, seed=42)
    game.start_hand()
    check_or_call_to_completion(game)
    assert game.outcome is not None
    assert game.outcome.total_awarded == 40  # both blinds, nobody raised


def test_both_players_all_in_from_blinds_alone_completes_immediately():
    # Regression test: if blinds exceed both players' stacks (a realistic
    # late-tournament scenario with short stacks and large blinds), BOTH
    # players go all-in just from posting forced blinds -- nobody is left
    # who can act. Before the fix, current_player was None immediately
    # after start_hand() and the hand never progressed (nothing ever
    # triggers the "run it out" logic if no action is ever possible).
    table, ids = make_table(2, stack=100)
    table.find_player(ids[0]).stack = 60
    table.find_player(ids[1]).stack = 45
    blind_level = BlindLevel(small_blind=100, big_blind=200)  # bigger than either stack
    deck = Deck()
    deck.shuffle(seed=1)
    game = TexasHoldem(table, BettingStructure.NO_LIMIT, blind_level, deck=deck)
    game.start_hand()
    assert game.is_hand_complete
    assert game.current_player is None
    assert len(game.board) == 5
    assert game.outcome is not None
    assert game.outcome.total_awarded == 105  # 60 + 45, both entirely posted as blinds
