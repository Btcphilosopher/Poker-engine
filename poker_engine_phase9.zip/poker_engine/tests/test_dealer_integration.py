"""
The capstone integration test for Phase 3: a complete hand played entirely
through the public API, from seating players at a table through settling
their stacks afterward. Nothing here is variant-specific game logic (that's
Phase 4's `TexasHoldem` class) — it's the dealer/table plumbing exercised
exactly the way that class will use it, with a fixed seed so the outcome
is fully deterministic and verifiable.

Table: Alice (button), Bob (SB), Carol (BB), blinds 10/20, seed 99.
Everyone just calls/checks their way to showdown on every street. The final
board and hole cards are what they are from the seeded shuffle; the
specific winner (Bob, with a bigger kicker on a board-paired hand) is
verified below rather than assumed.
"""

from poker_engine.betting import ActionType, BettingRound, BettingStructure, post_big_blind, post_small_blind
from poker_engine.dealer import (
    advance_to_next_street,
    deal_community_cards,
    deal_hole_cards,
    resolve_showdown,
)
from poker_engine.deck import Deck
from poker_engine.evaluation import evaluate_best_of
from poker_engine.tables import Table


def test_full_hand_end_to_end_with_deterministic_seed():
    table = Table(table_id="main", max_seats=6)
    table.sit_down("alice", "Alice", 1000, seat_index=0)
    table.sit_down("bob", "Bob", 1000, seat_index=1)
    table.sit_down("carol", "Carol", 1000, seat_index=2)
    table.button_index = 0  # alice on the button

    total_chips_before = sum(table.find_player(pid).stack for pid in ("alice", "bob", "carol"))

    deck = Deck()
    deck.shuffle(seed=99)

    players_bs = {pid: table.find_player(pid).to_betting_state() for pid in table.active_player_ids()}
    post_small_blind(players_bs["bob"], 10)
    post_big_blind(players_bs["carol"], 20)

    deal_order = table.postflop_action_order()  # deal starting left of the button (SB first)
    hole = deal_hole_cards(deck, deal_order, 2)
    assert all(len(cards) == 2 for cards in hole.values())

    preflop_order = table.preflop_action_order()
    preflop = BettingRound([players_bs[pid] for pid in preflop_order], BettingStructure.NO_LIMIT, min_bet=20)
    preflop.apply("alice", ActionType.CALL)
    preflop.apply("bob", ActionType.CALL)
    preflop.apply("carol", ActionType.CHECK)
    assert preflop.is_betting_complete()
    assert preflop.total_pot() == 60
    carried = advance_to_next_street(preflop)

    postflop_order = table.postflop_action_order()

    flop = deal_community_cards(deck, 3)
    assert len(flop.cards) == 3
    flop_round = BettingRound(
        [players_bs[pid] for pid in postflop_order], BettingStructure.NO_LIMIT, min_bet=20, carried_pot=carried
    )
    flop_round.apply("bob", ActionType.CHECK)
    flop_round.apply("carol", ActionType.CHECK)
    flop_round.apply("alice", ActionType.CHECK)
    carried = advance_to_next_street(flop_round)
    assert carried == 60  # nobody bet on the flop

    turn = deal_community_cards(deck, 1)
    turn_round = BettingRound(
        [players_bs[pid] for pid in postflop_order], BettingStructure.NO_LIMIT, min_bet=20, carried_pot=carried
    )
    turn_round.apply("bob", ActionType.CHECK)
    turn_round.apply("carol", ActionType.CHECK)
    turn_round.apply("alice", ActionType.CHECK)
    carried = advance_to_next_street(turn_round)

    river = deal_community_cards(deck, 1)
    river_round = BettingRound(
        [players_bs[pid] for pid in postflop_order], BettingStructure.NO_LIMIT, min_bet=20, carried_pot=carried
    )
    river_round.apply("bob", ActionType.CHECK)
    river_round.apply("carol", ActionType.CHECK)
    river_round.apply("alice", ActionType.CHECK)
    assert river_round.total_pot() == 60  # nobody ever bet after the blinds

    board = flop.cards + turn.cards + river.cards
    assert len(board) == 5

    hand_results = {pid: evaluate_best_of(hole[pid] + board) for pid in hole}
    outcome = resolve_showdown(
        list(players_bs.values()), hand_results, order_from_button=table.seats_from_button()
    )

    assert len(outcome.pot_outcomes) == 1
    assert outcome.pot_outcomes[0].pot.amount == 60
    assert outcome.total_awarded == 60

    # Deterministic given the seed: verify the winner actually holds the
    # best hand among the three, rather than trusting the plumbing blindly.
    winner = outcome.pot_outcomes[0].winners[0]
    assert len(outcome.pot_outcomes[0].winners) == 1
    for pid, result in hand_results.items():
        if pid != winner:
            assert hand_results[winner] >= result

    table.settle_hand(players_bs, outcome.total_payouts)

    total_chips_after = sum(table.find_player(pid).stack for pid in ("alice", "bob", "carol"))
    assert total_chips_after == total_chips_before  # no chips created or destroyed

    winner_player = table.find_player(winner)
    assert winner_player.stack == 1000 + (60 - 20)  # won the pot, minus what they put in
