import pytest

from poker_engine.betting import ButtonError, advance_button, next_occupied_seat, seats_from_button


def test_next_occupied_seat_simple():
    seats = ["A", "B", "C", "D"]
    assert next_occupied_seat(seats, 0) == 1
    assert next_occupied_seat(seats, 3) == 0  # wraps around


def test_next_occupied_seat_skips_empty_seats():
    seats = ["A", None, None, "D"]
    assert next_occupied_seat(seats, 0) == 3


def test_next_occupied_seat_all_empty_raises():
    with pytest.raises(ButtonError):
        next_occupied_seat([None, None, None], 0)


def test_advance_button_wraps_and_skips_busted_seats():
    seats = [None, "B", None, "D"]
    assert advance_button(seats, 3) == 1  # D -> wraps past empty 0 -> B


def test_seats_from_button_starts_at_button_and_skips_empties():
    seats = ["A", None, "C", "D"]
    assert seats_from_button(seats, 2) == ["C", "D", "A"]


def test_seats_from_button_full_wrap():
    seats = ["A", "B", "C", "D"]
    assert seats_from_button(seats, 0) == ["A", "B", "C", "D"]
    assert seats_from_button(seats, 2) == ["C", "D", "A", "B"]


def test_seats_from_button_empty_button_seat_raises():
    seats = ["A", None, "C"]
    with pytest.raises(ButtonError):
        seats_from_button(seats, 1)


def test_seats_from_button_out_of_range_raises():
    seats = ["A", "B"]
    with pytest.raises(ButtonError):
        seats_from_button(seats, 5)
