"""
network — not yet implemented.

Phase 12 — multiplayer/table/tournament server, auth, reconnect, spectators, chat, WebSocket support.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
