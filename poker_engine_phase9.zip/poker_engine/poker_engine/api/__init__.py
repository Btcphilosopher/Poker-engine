"""
api — not yet implemented.

Phase 12 — REST API for table/tournament lifecycle, actions, hand history, statistics, leaderboards.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
