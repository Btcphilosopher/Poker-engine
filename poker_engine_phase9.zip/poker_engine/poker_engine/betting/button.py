"""Dealer button rotation across table seats."""

from __future__ import annotations

from typing import List, Optional, Sequence


class ButtonError(Exception):
    pass


def next_occupied_seat(seats: Sequence[Optional[str]], from_index: int) -> int:
    """Index of the next occupied seat strictly after `from_index`, wrapping around."""
    n = len(seats)
    if n == 0 or all(s is None for s in seats):
        raise ButtonError("No occupied seats at the table")
    i = (from_index + 1) % n
    for _ in range(n):
        if seats[i] is not None:
            return i
        i = (i + 1) % n
    raise ButtonError("No occupied seats at the table")  # unreachable given the check above


def advance_button(seats: Sequence[Optional[str]], current_button_index: int) -> int:
    """Move the button to the next occupied seat, clockwise."""
    return next_occupied_seat(seats, current_button_index)


def seats_from_button(seats: Sequence[Optional[str]], button_index: int) -> List[str]:
    """
    Occupied player_ids in table order starting AT the button (button first,
    then clockwise), skipping empty seats. This is the canonical order that
    `assign_blinds` and per-street action-order builders expect.
    """
    n = len(seats)
    if not (0 <= button_index < n) or seats[button_index] is None:
        raise ButtonError("Button is not on an occupied seat")
    order: List[str] = []
    i = button_index
    for _ in range(n):
        seat = seats[i]
        if seat is not None:
            order.append(seat)
        i = (i + 1) % n
    return order
