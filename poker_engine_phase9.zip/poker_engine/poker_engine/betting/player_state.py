"""Per-player betting state, tracked across a whole hand (all streets)."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class PlayerBettingState:
    """
    Mutable betting state for one player across a single hand.

    `street_contributed` resets to 0 at the start of each new betting round
    (street) via `start_new_street()`. `total_contributed` accumulates across
    the whole hand and is what side-pot computation (poker_engine.betting.pot)
    keys off of.
    """

    player_id: str
    stack: int
    street_contributed: int = 0
    total_contributed: int = 0
    is_folded: bool = False
    is_all_in: bool = False

    def __post_init__(self) -> None:
        if self.stack < 0:
            raise ValueError("stack cannot be negative")

    @property
    def is_live(self) -> bool:
        """Still in the hand and able to take a voluntary action this street."""
        return not self.is_folded and not self.is_all_in

    def max_reachable(self) -> int:
        """Total street contribution reachable if this player shoves all-in now."""
        return self.street_contributed + self.stack

    def start_new_street(self) -> None:
        self.street_contributed = 0
