"""
Pot construction and distribution.

`compute_pots` builds the main pot and any side pots from each player's
*total* contribution for the hand (all streets combined) and fold status.
It is deliberately a pure function over a snapshot of PlayerBettingState —
it doesn't know or care how many streets were played, only where the money
ended up.

Algorithm: layer the money by distinct contribution level. Each layer's pot
is (level - previous_level) * (number of players who reached this level),
and is won only by players in that layer who never folded.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Dict, List, Sequence, Tuple

from poker_engine.betting.player_state import PlayerBettingState


@dataclass(frozen=True, slots=True)
class Pot:
    amount: int
    eligible_player_ids: Tuple[str, ...]
    name: str = "Pot"

    def __str__(self) -> str:
        who = ", ".join(self.eligible_player_ids) if self.eligible_player_ids else "(no eligible players)"
        return f"{self.name}: {self.amount} [{who}]"


class PotError(Exception):
    pass


def compute_pots(players: Sequence[PlayerBettingState]) -> List[Pot]:
    """
    Build main + side pots from total_contributed across a whole hand.

    Players with total_contributed == 0 are ignored entirely (never dealt
    in, or folded before putting any chips in). The result is ordered main
    pot first, then side pots in ascending order of formation, with adjacent
    pots that share an identical eligible-player set merged for a cleaner
    display (a common simplification with no effect on payouts).
    """
    contributors = [p for p in players if p.total_contributed > 0]
    if not contributors:
        return []

    levels = sorted({p.total_contributed for p in contributors})
    raw_pots: List[Pot] = []
    prev_level = 0
    for level in levels:
        layer_size = level - prev_level
        prev_level = level
        if layer_size <= 0:
            continue
        contributors_at_or_above = [p for p in contributors if p.total_contributed >= level]
        amount = layer_size * len(contributors_at_or_above)
        eligible = tuple(p.player_id for p in contributors_at_or_above if not p.is_folded)
        raw_pots.append(Pot(amount=amount, eligible_player_ids=eligible))

    merged = _merge_adjacent_equal_eligibility(raw_pots)
    named = []
    for i, pot in enumerate(merged):
        name = "Main Pot" if i == 0 else f"Side Pot {i}"
        named.append(replace(pot, name=name))
    return named


def _merge_adjacent_equal_eligibility(pots: Sequence[Pot]) -> List[Pot]:
    merged: List[Pot] = []
    for pot in pots:
        if merged and merged[-1].eligible_player_ids == pot.eligible_player_ids:
            merged[-1] = replace(merged[-1], amount=merged[-1].amount + pot.amount)
        else:
            merged.append(pot)
    return merged


def distribute_pot(pot: Pot, winner_ids: Sequence[str], order_from_button: Sequence[str]) -> Dict[str, int]:
    """
    Split a pot evenly (in whole chips) among winner_ids. Any remainder from
    integer division ("odd chips") is awarded one at a time, in seat order
    starting immediately left of the button, to the winners — the standard
    poker convention (also used for hi/lo split odd-chip awards).

    `order_from_button` must be the full seating order starting immediately
    left of the button (i.e. NOT including the button itself as the first
    entry unless the button is also a winner and next in rotation).
    """
    if not winner_ids:
        raise PotError("winner_ids must not be empty")
    if pot.amount < 0:
        raise PotError("pot.amount cannot be negative")

    n = len(winner_ids)
    base_share = pot.amount // n
    remainder = pot.amount % n
    payouts: Dict[str, int] = {pid: base_share for pid in winner_ids}

    if remainder:
        winner_set = set(winner_ids)
        ordered_winners = [pid for pid in order_from_button if pid in winner_set]
        if not ordered_winners:
            raise PotError("order_from_button does not contain any of winner_ids")
        for i in range(remainder):
            pid = ordered_winners[i % len(ordered_winners)]
            payouts[pid] += 1

    return payouts
