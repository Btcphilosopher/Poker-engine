"""Betting structures and blind-level configuration."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class BettingStructure(Enum):
    NO_LIMIT = "no_limit"
    POT_LIMIT = "pot_limit"
    FIXED_LIMIT = "fixed_limit"


@dataclass(frozen=True, slots=True)
class BlindLevel:
    """
    One level of a blind schedule. `ante` is per-player (0 if none).

    For FIXED_LIMIT games, `small_bet`/`big_bet` give the two fixed wager
    sizes (e.g. $2/$4 limit hold'em uses small_bet on pre-flop/flop and
    big_bet, usually 2x small_bet, on turn/river). They're unused for
    NO_LIMIT/POT_LIMIT, where the betting round's `min_bet` is simply the
    big blind.
    """

    small_blind: int
    big_blind: int
    ante: int = 0
    small_bet: int | None = None
    big_bet: int | None = None

    def __post_init__(self) -> None:
        if self.small_blind <= 0 or self.big_blind <= 0:
            raise ValueError("small_blind and big_blind must be positive")
        if self.small_blind > self.big_blind:
            raise ValueError("small_blind cannot exceed big_blind")
        if self.ante < 0:
            raise ValueError("ante cannot be negative")


@dataclass(frozen=True, slots=True)
class StudStakes:
    """
    Betting configuration for Stud games, which use antes + a bring-in
    forced bet instead of blinds. `small_bet` applies to 3rd/4th street,
    `big_bet` to 5th street onward — the same "first half of streets use
    the small size" convention as fixed-limit flop games.
    """

    ante: int
    bring_in: int
    small_bet: int
    big_bet: int

    def __post_init__(self) -> None:
        if self.ante <= 0:
            raise ValueError("ante must be positive")
        if self.bring_in <= 0:
            raise ValueError("bring_in must be positive")
        if self.small_bet <= 0 or self.big_bet <= 0:
            raise ValueError("small_bet and big_bet must be positive")
        if self.bring_in >= self.small_bet:
            raise ValueError("bring_in must be less than small_bet")
        if self.small_bet > self.big_bet:
            raise ValueError("small_bet cannot exceed big_bet")
