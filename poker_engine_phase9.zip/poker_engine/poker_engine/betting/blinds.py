"""Forced-bet posting: blinds, antes, bring-in, and dead blinds."""

from __future__ import annotations

from typing import Dict, Sequence, Tuple

from poker_engine.betting.actions import Action, ActionType
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.cards.card import Card

_SUIT_PRIORITY = {"c": 0, "d": 1, "h": 2, "s": 3}


class ForcedBetError(Exception):
    pass


def _post(
    player: PlayerBettingState, amount: int, action_type: ActionType, *, counts_toward_street: bool
) -> Action:
    if amount < 0:
        raise ForcedBetError("Forced bet amount cannot be negative")
    put_in = min(amount, player.stack)
    player.stack -= put_in
    player.total_contributed += put_in
    if counts_toward_street:
        player.street_contributed += put_in
    if player.stack == 0:
        player.is_all_in = True
    return Action(player_id=player.player_id, action_type=action_type, amount=put_in)


def post_small_blind(player: PlayerBettingState, amount: int) -> Action:
    return _post(player, amount, ActionType.POST_SMALL_BLIND, counts_toward_street=True)


def post_big_blind(player: PlayerBettingState, amount: int) -> Action:
    return _post(player, amount, ActionType.POST_BIG_BLIND, counts_toward_street=True)


def post_ante(player: PlayerBettingState, amount: int) -> Action:
    # Antes are dead money: they go straight to the pot and do not count
    # toward the "current bet" that other players must match this street.
    return _post(player, amount, ActionType.POST_ANTE, counts_toward_street=False)


def post_bring_in(player: PlayerBettingState, amount: int) -> Action:
    return _post(player, amount, ActionType.POST_BRING_IN, counts_toward_street=True)


def post_dead_blind(player: PlayerBettingState, amount: int) -> Action:
    # A dead blind (e.g. posted by a player returning to the table after
    # missing blinds) is dead money: it reaches the pot but creates no call
    # obligation for anyone, and is not "live" action for this street.
    return _post(player, amount, ActionType.POST_DEAD_BLIND, counts_toward_street=False)


def assign_blinds(order_from_button: Sequence[str], *, heads_up: bool) -> Tuple[str, str]:
    """
    Given players in seating order STARTING AT the button (order_from_button[0]
    is the button), return (small_blind_player_id, big_blind_player_id).

    Heads-up is a special case: the button posts the small blind (and acts
    first pre-flop, but last on every later street — that ordering is the
    dealer/hand orchestrator's responsibility, not this function's).
    """
    n = len(order_from_button)
    if n < 2:
        raise ForcedBetError("Need at least 2 players to assign blinds")
    if heads_up:
        if n != 2:
            raise ForcedBetError("heads_up=True requires exactly 2 players")
        return order_from_button[0], order_from_button[1]
    if n == 2:
        raise ForcedBetError("2 players requires heads_up=True")
    return order_from_button[1], order_from_button[2]


def determine_bring_in(up_cards: Dict[str, Card], *, low_brings_in: bool = True) -> str:
    """
    Determine which player posts the stud bring-in from their visible up-card.
    Ties are broken by suit priority (clubs < diamonds < hearts < spades),
    the standard convention.

    low_brings_in=True: the worst (lowest) up-card brings it in — standard
    7-Card Stud / Stud Hi-Lo.
    low_brings_in=False: the best (highest) up-card brings it in — Razz,
    where the "worst" starting hand for a lowball game is the highest card.
    """
    if not up_cards:
        raise ForcedBetError("up_cards must not be empty")

    def sort_key(item: Tuple[str, Card]) -> Tuple[int, int]:
        _, card = item
        return (card.rank.value, _SUIT_PRIORITY[card.suit.code])

    chooser = min if low_brings_in else max
    player_id, _ = chooser(up_cards.items(), key=sort_key)
    return player_id
