"""Player and forced-bet actions."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ActionType(Enum):
    FOLD = "fold"
    CHECK = "check"
    CALL = "call"
    BET = "bet"
    RAISE = "raise"
    POST_SMALL_BLIND = "post_small_blind"
    POST_BIG_BLIND = "post_big_blind"
    POST_ANTE = "post_ante"
    POST_BRING_IN = "post_bring_in"
    POST_DEAD_BLIND = "post_dead_blind"


@dataclass(frozen=True, slots=True)
class Action:
    """
    A single logged action.

    `amount` meaning depends on `action_type`:
      - FOLD / CHECK: always 0
      - CALL: the amount actually put into the pot by this action
      - BET / RAISE: the amount actually put into the pot by this action
        (NOT the "raise to" total — use the betting round's history plus
        player state to reconstruct totals if needed for hand-history export)
      - POST_*: the amount actually posted (may be less than the nominal
        blind/ante/bring-in if the player was short-stacked)
    """

    player_id: str
    action_type: ActionType
    amount: int = 0

    def __str__(self) -> str:
        if self.amount:
            return f"{self.player_id} {self.action_type.value} {self.amount}"
        return f"{self.player_id} {self.action_type.value}"
