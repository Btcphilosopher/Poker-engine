"""
Player — persistent, across-hands player state.

This is deliberately a different object from
`poker_engine.betting.PlayerBettingState`: that one is ephemeral (built
fresh for each hand from `Player.stack`, and thrown away once the hand's
pots are settled). `Player` is the thing that lives at a table between
hands — it has a name, a seat, a status, and a stack that persists.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from poker_engine.betting.player_state import PlayerBettingState


class PlayerStatus(Enum):
    ACTIVE = "active"  # seated and playing the next hand
    SITTING_OUT = "sitting_out"  # seated, but skipped for the next hand
    WAITING = "waiting"  # not seated yet (waiting list)
    ELIMINATED = "eliminated"  # busted out (tournament context)


@dataclass(slots=True)
class Player:
    player_id: str
    display_name: str
    stack: int
    status: PlayerStatus = PlayerStatus.ACTIVE
    seat_index: int | None = None

    def __post_init__(self) -> None:
        if self.stack < 0:
            raise ValueError("stack cannot be negative")

    @property
    def is_active(self) -> bool:
        return self.status is PlayerStatus.ACTIVE and self.stack > 0

    @property
    def is_eliminated(self) -> bool:
        return self.status is PlayerStatus.ELIMINATED

    def to_betting_state(self) -> PlayerBettingState:
        """Snapshot this player's current stack into a fresh per-hand betting state."""
        return PlayerBettingState(player_id=self.player_id, stack=self.stack)

    def apply_hand_result(self, remaining_stack: int, payout: int) -> None:
        """
        Update the persistent stack after a hand: whatever chips are left in
        the per-hand betting state, plus whatever this player won from pots.
        """
        if remaining_stack < 0 or payout < 0:
            raise ValueError("remaining_stack and payout cannot be negative")
        self.stack = remaining_stack + payout
        if self.stack == 0 and self.status is PlayerStatus.ACTIVE:
            self.status = PlayerStatus.ELIMINATED

    def rebuy(self, amount: int) -> None:
        if amount <= 0:
            raise ValueError("rebuy amount must be positive")
        self.stack += amount
        if self.status is PlayerStatus.ELIMINATED:
            self.status = PlayerStatus.ACTIVE
