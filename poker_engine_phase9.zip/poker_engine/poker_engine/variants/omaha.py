"""Omaha and Omaha Hi-Lo (Omaha/8)."""

from __future__ import annotations

from poker_engine.variants.flop_game import FlopGame


class Omaha(FlopGame):
    """
    No-Limit / Limit / Pot-Limit Omaha: 4 hole cards, standard deck.

    Unlike Hold'em, a hand MUST use exactly 2 hole cards and exactly 3
    board cards (`evaluate_omaha` — see Phase 1) — never more, never
    fewer, of either, even if a "better" 5-card combination exists among
    the 7 total cards ignoring that restriction.
    """

    HOLE_CARDS_DEALT = 4
    HOLE_CARDS_FINAL = 4
    EVALUATION_MODE = "omaha"


class OmahaHiLo(FlopGame):
    """
    Omaha Hi-Lo (Omaha/8-or-better): 4 hole cards, standard deck.

    Each contested pot splits in half between the best high hand (Omaha
    rules: exactly 2 hole + 3 board) and the best QUALIFYING low hand
    (Ace-to-5, all five cards ranked 8 or below, same 2-hole+3-board
    restriction). If no low qualifies, high scoops the entire pot.
    """

    HOLE_CARDS_DEALT = 4
    HOLE_CARDS_FINAL = 4
    EVALUATION_MODE = "omaha_hi_lo"
    LOW_QUALIFIER = 8
