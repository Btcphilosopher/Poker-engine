"""
Pineapple, Crazy Pineapple, and Irish Poker — all standard Hold'em at
showdown (best 5 of hole+board, no Omaha-style restriction), but dealt
extra hole cards that get discarded down mid-hand. They differ only in how
many cards are dealt and when the discard happens — see
FlopGame.DISCARD_AFTER_STREET and the `discard()` method it provides.
"""

from __future__ import annotations

from poker_engine.variants.base_game import Street
from poker_engine.variants.flop_game import FlopGame


class Pineapple(FlopGame):
    """
    Pineapple: 3 hole cards dealt, pre-flop betting happens with all 3,
    THEN each player discards one card (down to 2) before the flop is
    dealt. Standard Hold'em evaluation from there.
    """

    HOLE_CARDS_DEALT = 3
    HOLE_CARDS_FINAL = 2
    DISCARD_AFTER_STREET = Street.PREFLOP


class CrazyPineapple(FlopGame):
    """
    Crazy Pineapple: 3 hole cards dealt, but the discard happens later than
    in Pineapple — after the FLOP is dealt and flop betting completes
    (so players see the flop before deciding which of their 3 cards to
    keep), down to 2, then standard Hold'em for turn/river.
    """

    HOLE_CARDS_DEALT = 3
    HOLE_CARDS_FINAL = 2
    DISCARD_AFTER_STREET = Street.FLOP


class Irish(FlopGame):
    """
    Irish Poker: 4 hole cards dealt (like Omaha), pre-flop betting, flop
    dealt, THEN discard down to 2 — but unlike Omaha, once down to 2 cards
    it plays out as standard Hold'em (best 5 of hole+board), not the
    Omaha-restricted evaluation.
    """

    HOLE_CARDS_DEALT = 4
    HOLE_CARDS_FINAL = 2
    DISCARD_AFTER_STREET = Street.FLOP
