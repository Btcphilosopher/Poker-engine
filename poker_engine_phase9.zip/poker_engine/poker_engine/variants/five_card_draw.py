"""Five Card Draw and 2-7 Triple Draw."""

from __future__ import annotations

from poker_engine.variants.draw_game import DrawGame


class FiveCardDraw(DrawGame):
    """Standard 5-Card Draw: high hand, one draw round."""


class TripleDraw(DrawGame):
    """
    2-7 Triple Draw: three draw rounds (four betting rounds total), ranked
    by 2-7 lowball rules (Ace high only, straights/flushes count against
    the hand — see poker_engine.evaluation.deuce_to_seven). The best
    possible hand is 7-5-4-3-2.
    """

    NUM_DRAW_ROUNDS = 3
    EVALUATION_MODE = "deuce_to_seven"
