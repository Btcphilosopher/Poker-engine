"""Badugi."""

from __future__ import annotations

from poker_engine.variants.draw_game import DrawGame


class Badugi(DrawGame):
    """
    Badugi: 4 hole cards, 3 draw rounds (4 betting rounds total, same
    cadence as 2-7 Triple Draw). Best hand is a 4-card "badugi" — one card
    each of 4 different ranks AND 4 different suits, Ace playing low. See
    poker_engine.evaluation.badugi for how hands that don't already
    qualify are read (best qualifying subset, more cards always beats
    fewer).
    """

    CARDS_PER_PLAYER = 4
    NUM_DRAW_ROUNDS = 3
    EVALUATION_MODE = "badugi"
