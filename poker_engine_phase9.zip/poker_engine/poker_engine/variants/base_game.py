"""
BaseGame — the common interface every poker variant implements.

A "Game" instance orchestrates exactly ONE hand: from `start_hand()`
(shuffle, post blinds/antes, deal) through street-by-street betting to a
final `HandOutcome`. Playing many hands means constructing a new Game
instance per hand against the same persistent `Table` — this keeps a
Game's internal state trivially simple (no reset logic) and matches how
`PlayerBettingState` (Phase 2) and `Table.settle_hand()` (Phase 3) already
expect to be used.

Concrete variants (TexasHoldem in this phase; Omaha, Stud, Draw variants in
Phase 5-6) subclass BaseGame and implement its abstract methods using the
Phase 1-3 building blocks: Deck, evaluation functions, BettingRound,
dealer.dealing, dealer.showdown.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Optional

from poker_engine.betting.actions import Action, ActionType
from poker_engine.betting.round import LegalActions
from poker_engine.dealer.showdown import HandOutcome


class GameError(Exception):
    pass


class Street(Enum):
    """
    Betting-round progression for flop-based games (Hold'em, Omaha, Short
    Deck, Pineapple, Irish, ...). Stud and Draw variants (Phase 6) will
    define their own Street enum — "third street"/"fourth street" and
    "pre-draw"/"post-draw" don't map onto PREFLOP/FLOP/TURN/RIVER, and
    forcing them to would be a worse fit than just having two enums.
    """

    PREFLOP = "preflop"
    FLOP = "flop"
    TURN = "turn"
    RIVER = "river"
    SHOWDOWN = "showdown"
    COMPLETE = "complete"


class BaseGame(ABC):
    """Common interface for a single hand of any poker variant."""

    @abstractmethod
    def start_hand(self) -> None:
        """Shuffle, post blinds/antes, deal hole cards, and open the first betting round."""

    @abstractmethod
    def legal_actions(self, player_id: str) -> LegalActions:
        """What `player_id` may legally do right now."""

    @abstractmethod
    def apply_action(self, player_id: str, action_type: ActionType, amount: int = 0) -> Action:
        """Apply a player's action, automatically advancing streets/showdown as needed."""

    @property
    @abstractmethod
    def current_player(self) -> Optional[str]:
        """Whose turn it is, or None if no betting is currently open (e.g. hand complete)."""

    @property
    @abstractmethod
    def is_hand_complete(self) -> bool:
        ...

    @property
    @abstractmethod
    def outcome(self) -> Optional[HandOutcome]:
        """The resolved pots/winners/payouts, or None until the hand is complete."""
