"""Short Deck (6+) Hold'em."""

from __future__ import annotations

from poker_engine.variants.flop_game import FlopGame


class ShortDeckHoldem(FlopGame):
    """
    Short Deck ("6+") Hold'em: 2 hole cards, 36-card deck (ranks 6 through
    Ace only), flush ranks above full house at showdown (see
    `poker_engine.evaluation.short_deck` for why, and for the scope note on
    the ace-low straight rule this engine does NOT implement).

    Many rooms use a button-ante structure (everyone antes, the button
    posts an extra amount) instead of traditional blinds for Short Deck.
    This class still uses the standard `BlindLevel`/small-blind/big-blind
    mechanics from Phase 2 — set `BlindLevel.ante` for the common
    "everyone antes, blinds still apply" hybrid, or construct a `BlindLevel`
    with equal small_blind/big_blind to approximate a single forced bet.
    True button-ante-only structures are a possible future addition to
    `poker_engine.betting.blinds` if a specific ruleset requires them.
    """

    SHORT_DECK = True
