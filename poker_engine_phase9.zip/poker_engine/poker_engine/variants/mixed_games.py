"""
Mixed-game rotation: cycling through a sequence of poker variants across
many hands at the same table — the general mechanism HORSE (and other
rotations like 8-Game, HOSE, etc.) are built from.

Not a BaseGame itself: it manages a SEQUENCE of hands, each of which is
still its own fresh Game instance (matching the "one Game instance = one
hand" design every variant already follows — see FlopGame's docstring).
All FlopGame/DrawGame subclasses share the constructor shape
(table, structure, BlindLevel, ...), and all StudGame subclasses share
(table, structure, StudStakes, ...) — so a rotation only needs to know
which class and which stakes object go with each leg; it doesn't need any
variant-specific knowledge beyond that.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Type, Union

from poker_engine.betting.structures import BettingStructure, BlindLevel, StudStakes
from poker_engine.deck.deck import Deck
from poker_engine.tables.table import Table
from poker_engine.variants.base_game import BaseGame
from poker_engine.variants.omaha import OmahaHiLo
from poker_engine.variants.seven_card_stud import Razz, SevenCardStud, StudHiLo
from poker_engine.variants.stud_game import StudGame
from poker_engine.variants.texas_holdem import TexasHoldem


class MixedGameError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class RotationLeg:
    """One game in a mixed-game rotation."""

    game_class: Type[BaseGame]
    structure: BettingStructure
    stakes: Union[BlindLevel, StudStakes]
    hands_per_leg: int = 1

    def __post_init__(self) -> None:
        if self.hands_per_leg < 1:
            raise MixedGameError("hands_per_leg must be at least 1")
        expects_stud_stakes = isinstance(self.game_class, type) and issubclass(self.game_class, StudGame)
        if expects_stud_stakes and not isinstance(self.stakes, StudStakes):
            raise MixedGameError(f"{self.game_class.__name__} requires StudStakes, not {type(self.stakes).__name__}")
        if not expects_stud_stakes and not isinstance(self.stakes, BlindLevel):
            raise MixedGameError(f"{self.game_class.__name__} requires BlindLevel, not {type(self.stakes).__name__}")


class MixedGameRotation:
    """
    Cycles through `legs` in order, `leg.hands_per_leg` hands at a time,
    wrapping back to the first leg after the last. One instance persists
    for a whole session (like Table); call `start_next_hand()` for each
    new hand and `advance()` once it's complete and settled.
    """

    def __init__(self, table: Table, legs: Sequence[RotationLeg]) -> None:
        if not legs:
            raise MixedGameError("legs must not be empty")
        self.table = table
        self.legs: List[RotationLeg] = list(legs)
        self._leg_index = 0
        self._hands_played_this_leg = 0

    @property
    def current_leg(self) -> RotationLeg:
        return self.legs[self._leg_index]

    @property
    def leg_index(self) -> int:
        return self._leg_index

    @property
    def hands_played_this_leg(self) -> int:
        return self._hands_played_this_leg

    def start_next_hand(self, *, deck: Optional[Deck] = None) -> BaseGame:
        """Construct and start the next hand as a fresh Game instance for the current leg."""
        leg = self.current_leg
        if issubclass(leg.game_class, StudGame):
            # Stud never touches the button itself (it's irrelevant to
            # Stud's own action order), but rotation fairness still wants
            # it to advance every hand -- otherwise a player could stay on
            # the button across several Stud hands and then still be on it
            # when the rotation returns to a blind-based game. FlopGame/
            # DrawGame subclasses already advance it themselves in
            # start_hand(), so this must only happen for Stud legs, or
            # blind-based legs would double-advance.
            self.table.advance_button()
        game = leg.game_class(self.table, leg.structure, leg.stakes, deck=deck)
        game.start_hand()
        return game

    def advance(self) -> None:
        """Call once a hand is complete and settled, to move to the next hand (and leg, if due)."""
        self._hands_played_this_leg += 1
        if self._hands_played_this_leg >= self.current_leg.hands_per_leg:
            self._hands_played_this_leg = 0
            self._leg_index = (self._leg_index + 1) % len(self.legs)


def horse_rotation(blind_level: BlindLevel, stud_stakes: StudStakes, *, hands_per_leg: int = 1) -> List[RotationLeg]:
    """
    The classic HORSE rotation: Hold'em, Omaha Hi-Lo, Razz, (7-Card) Stud,
    (Stud) Eight-or-better. Returns the leg list; construct the rotation
    with `MixedGameRotation(table, horse_rotation(...))`.

    Real HORSE cadence (how many hands per game before rotating) varies by
    room and stakes level — this engine leaves that choice to the caller
    via `hands_per_leg` rather than assuming one.
    """
    return [
        RotationLeg(TexasHoldem, BettingStructure.FIXED_LIMIT, blind_level, hands_per_leg),
        RotationLeg(OmahaHiLo, BettingStructure.FIXED_LIMIT, blind_level, hands_per_leg),
        RotationLeg(Razz, BettingStructure.FIXED_LIMIT, stud_stakes, hands_per_leg),
        RotationLeg(SevenCardStud, BettingStructure.FIXED_LIMIT, stud_stakes, hands_per_leg),
        RotationLeg(StudHiLo, BettingStructure.FIXED_LIMIT, stud_stakes, hands_per_leg),
    ]
