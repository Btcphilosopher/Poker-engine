"""
TexasHoldem — No-Limit, Limit, and Pot-Limit Hold'em, in one class
parametrized by `BettingStructure`. Built directly in Phase 4; refactored
in Phase 5 to inherit FlopGame's shared street-progression machine once
enough other variants existed to extract it correctly.

Standard Hold'em is FlopGame's default configuration exactly, so there's
nothing left to override.
"""

from __future__ import annotations

from poker_engine.variants.flop_game import FlopGame


class TexasHoldem(FlopGame):
    """No-Limit / Limit / Pot-Limit Texas Hold'em: 2 hole cards, standard deck, best 5 of 7."""
