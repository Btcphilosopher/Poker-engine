"""
DrawGame — the shared state machine behind 5-Card Draw and 2-7 Triple
Draw. Uses blinds/button exactly like FlopGame (reuses Table's existing
preflop_action_order/postflop_action_order directly), but has no community
cards at all — betting rounds alternate with DRAW rounds (discard 0-N
cards, receive that many replacements from the deck) instead of board
reveals. Kept as its own base class rather than folded into FlopGame: the
"discard and replace from the deck" mechanic is fundamentally different
from FlopGame's one-time narrowing discard (built for Pineapple), and
there's no board state to track at all.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from poker_engine.betting.actions import Action, ActionType
from poker_engine.betting.round import BettingRound, LegalActions
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.betting.structures import BettingStructure, BlindLevel
from poker_engine.betting.blinds import assign_blinds, post_ante, post_big_blind, post_small_blind
from poker_engine.cards.card import Card
from poker_engine.dealer.dealing import advance_to_next_street, deal_hole_cards, draw_replacement_cards
from poker_engine.dealer.showdown import HandOutcome, resolve_showdown
from poker_engine.deck.deck import Deck
from poker_engine.evaluation.badugi import evaluate_badugi
from poker_engine.evaluation.deuce_to_seven import deuce_to_seven_sort_key, evaluate_5_deuce_to_seven
from poker_engine.evaluation.evaluator import evaluate_5
from poker_engine.tables.table import Table
from poker_engine.variants.base_game import BaseGame, GameError


@dataclass(frozen=True, slots=True)
class DrawRoundAction:
    """One action, tagged with which betting round (0-indexed: 0 = pre-draw) it happened in."""

    round_index: int
    action: Action


class DrawGame(BaseGame):
    # -- variant configuration (override in subclasses) ----------------------------------------------------------
    CARDS_PER_PLAYER: int = 5
    NUM_DRAW_ROUNDS: int = 1  # 1 for 5-Card Draw, 3 for Triple Draw
    EVALUATION_MODE: str = "high"  # "high" | "deuce_to_seven" | "badugi"

    def __init__(
        self,
        table: Table,
        structure: BettingStructure,
        blind_level: BlindLevel,
        *,
        deck: Optional[Deck] = None,
        fixed_limit_raise_cap: int = 4,
    ) -> None:
        self.table = table
        self.structure = structure
        self.blind_level = blind_level
        self.fixed_limit_raise_cap = fixed_limit_raise_cap

        self._deck = deck if deck is not None else self._build_deck()
        self._betting_states: Dict[str, PlayerBettingState] = {}
        self._round: Optional[BettingRound] = None
        self._round_index: int = 0  # 0 = pre-draw; increments after each draw round
        self._draws_completed: int = 0
        self._complete: bool = False
        self._hole_cards: Dict[str, List[Card]] = {}
        self._action_log: List[DrawRoundAction] = []
        self._outcome: Optional[HandOutcome] = None
        self._cap_raises: Optional[int] = None
        self._started = False

        self._awaiting_draw = False
        self._draw_queue: List[str] = []
        self._pending_carried_pot = 0
        self._discard_pile: List[Card] = []  # every card discarded so far, safe to reshuffle in

    def _build_deck(self) -> Deck:
        deck = Deck()
        deck.shuffle(secure=True)
        return deck

    # -- BaseGame interface ----------------------------------------------------------

    def start_hand(self) -> None:
        if self._started:
            raise GameError("start_hand() may only be called once per Game instance")
        self._started = True

        self.table.advance_button()
        active_ids = self.table.active_player_ids()
        if len(active_ids) < 2:
            raise GameError("Need at least 2 active players to start a hand")

        self._betting_states = {pid: self.table.find_player(pid).to_betting_state() for pid in active_ids}
        heads_up = self.table.is_heads_up()
        self._cap_raises = (
            self.fixed_limit_raise_cap
            if (self.structure is BettingStructure.FIXED_LIMIT and not heads_up)
            else None
        )

        ante_total = 0
        if self.blind_level.ante > 0:
            for pid in active_ids:
                ante_total += post_ante(self._betting_states[pid], self.blind_level.ante).amount

        blind_order = self.table.active_seats_from_button()
        sb_id, bb_id = assign_blinds(blind_order, heads_up=heads_up)
        post_small_blind(self._betting_states[sb_id], self.blind_level.small_blind)
        post_big_blind(self._betting_states[bb_id], self.blind_level.big_blind)

        deal_order = self.table.postflop_action_order()
        self._hole_cards = deal_hole_cards(self._deck, deal_order, self.CARDS_PER_PLAYER)

        preflop_order = self.table.preflop_action_order()
        self._round = BettingRound(
            [self._betting_states[pid] for pid in preflop_order],
            self.structure,
            self._min_bet_for_round(),
            carried_pot=ante_total,
            cap_raises=self._cap_raises,
        )
        # See FlopGame.start_hand()'s identical comment: blinds alone can
        # already leave nobody able to act.
        self._advance_if_needed()

    def legal_actions(self, player_id: str) -> LegalActions:
        if self._awaiting_draw:
            raise GameError("Awaiting draws this round; call draw() instead of legal_actions()")
        if self._round is None:
            raise GameError("No betting round is currently open")
        return self._round.legal_actions(player_id)

    def apply_action(self, player_id: str, action_type: ActionType, amount: int = 0) -> Action:
        if self.is_hand_complete:
            raise GameError("This hand is already complete")
        if self._awaiting_draw:
            raise GameError("Awaiting draws this round; call draw() instead of apply_action()")
        if self._round is None:
            raise GameError("No betting round is currently open")

        action = self._round.apply(player_id, action_type, amount)
        self._action_log.append(DrawRoundAction(round_index=self._round_index, action=action))
        self._advance_if_needed()
        return action

    @property
    def current_player(self) -> Optional[str]:
        if self._awaiting_draw:
            return self._draw_queue[0] if self._draw_queue else None
        return self._round.next_to_act() if self._round is not None else None

    @property
    def is_hand_complete(self) -> bool:
        return self._complete

    @property
    def outcome(self) -> Optional[HandOutcome]:
        return self._outcome

    # -- draw phase ----------------------------------------------------------

    @property
    def awaiting_draw(self) -> bool:
        return self._awaiting_draw

    def draw(self, player_id: str, discard: List[Card]) -> None:
        """Discard 0 to CARDS_PER_PLAYER cards; replacements are dealt automatically."""
        if not self._awaiting_draw:
            raise GameError("Not currently awaiting a draw")
        if player_id not in self._draw_queue:
            raise GameError(f"{player_id} is not awaiting a draw right now")
        if len(discard) > self.CARDS_PER_PLAYER:
            raise GameError(f"Cannot discard more than {self.CARDS_PER_PLAYER} cards")
        if len(set(discard)) != len(discard):
            raise GameError("Duplicate cards in discard list")
        current = self._hole_cards[player_id]
        missing = [c for c in discard if c not in current]
        if missing:
            raise GameError(f"{missing} are not among {player_id}'s current hand")

        if len(discard) > self._deck.cards_remaining() and self._discard_pile:
            # The deck can't cover this draw -- reshuffle in every card
            # discarded so far this hand (including earlier in this same
            # round) rather than ending the hand early. A live casino
            # avoids reusing the CURRENT round's own discards, purely so
            # players still waiting to draw never see what was just
            # mucked; that concern doesn't apply to a headless rules
            # engine, and a hand simply crashing because too many players
            # discarded heavily in a single-draw-round game (5-Card Draw
            # has nowhere else to reuse from) is a worse outcome than this
            # deliberate simplification.
            self._deck.replenish(self._discard_pile, secure=True)
            self._discard_pile = []

        replacements = draw_replacement_cards(self._deck, len(discard))
        discard_set = set(discard)
        kept = [c for c in current if c not in discard_set]
        self._hole_cards[player_id] = kept + replacements
        self._discard_pile.extend(discard)

        self._draw_queue.remove(player_id)
        if not self._draw_queue:
            self._awaiting_draw = False
            self._draws_completed += 1
            self._round_index += 1
            self._open_next_betting_round(self._pending_carried_pot)

    # -- read-only hand state ----------------------------------------------------------

    @property
    def round_index(self) -> int:
        return self._round_index

    @property
    def draws_completed(self) -> int:
        return self._draws_completed

    @property
    def hole_cards(self) -> Dict[str, List[Card]]:
        return {pid: list(cards) for pid, cards in self._hole_cards.items()}

    @property
    def action_log(self) -> List[DrawRoundAction]:
        return list(self._action_log)

    def settle(self) -> None:
        if not self.is_hand_complete or self._outcome is None:
            raise GameError("Cannot settle a hand that isn't complete yet")
        self.table.settle_hand(self._betting_states, self._outcome.total_payouts)

    # -- internals ----------------------------------------------------------

    def _total_betting_rounds(self) -> int:
        return self.NUM_DRAW_ROUNDS + 1

    def _min_bet_for_round(self) -> int:
        if self.structure is not BettingStructure.FIXED_LIMIT:
            return self.blind_level.big_blind
        half = self._total_betting_rounds() // 2
        small = self.blind_level.small_bet or self.blind_level.big_blind
        big = self.blind_level.big_bet or (2 * self.blind_level.big_blind)
        return small if self._round_index < half else big

    def _live_player_ids(self) -> List[str]:
        return [pid for pid, bs in self._betting_states.items() if not bs.is_folded]

    def _contestable_player_ids(self) -> List[str]:
        return [pid for pid, bs in self._betting_states.items() if not bs.is_folded and not bs.is_all_in]

    def _advance_if_needed(self) -> None:
        if len(self._live_player_ids()) <= 1:
            self._finish_uncontested()
            return
        if self._round is not None and not self._round.is_betting_complete():
            return

        carried_pot = advance_to_next_street(self._round)
        if self._draws_completed >= self.NUM_DRAW_ROUNDS:
            self._go_to_showdown()
            return
        self._begin_draw_phase(carried_pot)

    def _begin_draw_phase(self, carried_pot: int) -> None:
        self._pending_carried_pot = carried_pot
        self._awaiting_draw = True
        self._draw_queue = list(self._live_player_ids())  # all live players draw, even all-in ones

    def _open_next_betting_round(self, carried_pot: int) -> None:
        contestable = set(self._contestable_player_ids())
        if len(contestable) < 2:
            self._round = None
            if self._draws_completed < self.NUM_DRAW_ROUNDS:
                self._begin_draw_phase(carried_pot)
                return
            self._go_to_showdown()
            return

        order = [pid for pid in self.table.postflop_action_order() if pid in contestable]
        self._round = BettingRound(
            [self._betting_states[pid] for pid in order],
            self.structure,
            self._min_bet_for_round(),
            carried_pot=carried_pot,
            cap_raises=self._cap_raises,
        )

    def _go_to_showdown(self) -> None:
        self._round = None
        self._outcome = self._resolve_showdown()
        self._complete = True

    def _finish_uncontested(self) -> None:
        self._round = None
        self._outcome = self._resolve_showdown()
        self._complete = True

    def _resolve_showdown(self) -> HandOutcome:
        live = self._live_player_ids()
        order = self.table.seats_from_button()

        hand_results = {}
        if len(live) > 1:
            for pid in live:
                hand = self._hole_cards[pid]
                if self.EVALUATION_MODE == "deuce_to_seven":
                    hand_results[pid] = evaluate_5_deuce_to_seven(hand)
                elif self.EVALUATION_MODE == "badugi":
                    hand_results[pid] = evaluate_badugi(hand)
                else:
                    hand_results[pid] = evaluate_5(hand)

        key_fn = deuce_to_seven_sort_key if self.EVALUATION_MODE == "deuce_to_seven" else None
        return resolve_showdown(list(self._betting_states.values()), hand_results, order, key=key_fn)
