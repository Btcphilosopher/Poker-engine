"""Seven Card Stud, Stud Hi-Lo (Stud/8), and Razz."""

from __future__ import annotations

from poker_engine.variants.stud_game import StudGame


class SevenCardStud(StudGame):
    """Standard 7-Card Stud: high hand only, lowest up-card brings in on 3rd street."""


class StudHiLo(StudGame):
    """
    Seven Card Stud Hi-Lo (Stud/8-or-better): each contested pot splits
    between the best high hand and the best qualifying low hand (8-or-better,
    Ace-to-5). Bring-in and action order follow the same "lowest/best up-card"
    convention as standard Stud — Stud Hi-Lo is NOT lowball for that purpose,
    only for half the pot at showdown.
    """

    EVALUATION_MODE = "hi_lo"
    LOW_QUALIFIER = 8


class Razz(StudGame):
    """
    Razz: pure lowball Stud, no qualifier — the best (lowest) Ace-to-5 hand
    always wins, even a bad one if nobody has better. Unlike standard Stud,
    the HIGHEST up-card brings it in on 3rd street, and the WORST-looking
    exposed hand acts first from 4th street onward (LOWBALL=True flips both).
    """

    EVALUATION_MODE = "low"
    LOW_QUALIFIER = None
    LOWBALL = True
