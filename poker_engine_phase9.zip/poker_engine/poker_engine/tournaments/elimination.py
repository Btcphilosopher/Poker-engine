"""
Finishing position computation.

A tournament director records eliminations in the order they happen
(first player out first). When two or more players bust in the very same
hand, ordering between them is the director's call — the standard
convention ("count-back": whoever had more chips at the start of that
hand finishes higher) requires cross-hand chip-count context this module
doesn't have, so callers are responsible for appending simultaneous
eliminations to `elimination_order` in the position they should finish,
worst-to-best.
"""

from __future__ import annotations

from typing import Dict, Sequence


def compute_finishing_positions(elimination_order: Sequence[str], winner_id: str) -> Dict[str, int]:
    """
    Given `elimination_order` (first player eliminated first) and the
    tournament winner, return {player_id: finishing_position}, where 1 is
    the winner and higher numbers finished earlier (busted out sooner).
    """
    total = len(elimination_order) + 1
    positions: Dict[str, int] = {winner_id: 1}
    for i, player_id in enumerate(elimination_order):
        positions[player_id] = total - i
    return positions
