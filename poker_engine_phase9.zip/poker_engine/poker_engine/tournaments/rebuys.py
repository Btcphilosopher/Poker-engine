"""
Rebuy and add-on tracking.

Rebuys let a busted (or, in some structures, any short-stacked) player buy
back in during a defined window (typically the first several blind
levels). Add-ons are a one-time extra chip purchase, usually offered to
everyone at the end of the rebuy period regardless of stack size.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Optional, Set

from poker_engine.players.player import Player


class RebuyError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class RebuyPolicy:
    rebuy_chips: int
    rebuy_cost: int
    max_rebuys: Optional[int] = None  # None = unlimited during the window
    rebuy_level_cutoff: int = 0  # rebuys allowed only while TournamentClock.level_index <= this (0-indexed)
    addon_chips: int = 0
    addon_cost: int = 0
    addon_available: bool = False

    def __post_init__(self) -> None:
        if self.rebuy_chips <= 0:
            raise RebuyError("rebuy_chips must be positive")
        if self.rebuy_cost < 0:
            raise RebuyError("rebuy_cost cannot be negative")
        if self.max_rebuys is not None and self.max_rebuys < 1:
            raise RebuyError("max_rebuys must be at least 1 if given")
        if self.rebuy_level_cutoff < 0:
            raise RebuyError("rebuy_level_cutoff cannot be negative")
        if self.addon_available and self.addon_chips <= 0:
            raise RebuyError("addon_chips must be positive when addon_available is True")


class RebuyTracker:
    """Tracks rebuy/add-on usage per player against a RebuyPolicy."""

    def __init__(self, policy: RebuyPolicy) -> None:
        self.policy = policy
        self._rebuy_counts: Dict[str, int] = defaultdict(int)
        self._addon_used: Set[str] = set()

    def rebuys_taken(self, player_id: str) -> int:
        return self._rebuy_counts.get(player_id, 0)

    def can_rebuy(self, player_id: str, current_level_index: int) -> bool:
        if current_level_index > self.policy.rebuy_level_cutoff:
            return False
        if self.policy.max_rebuys is not None and self._rebuy_counts[player_id] >= self.policy.max_rebuys:
            return False
        return True

    def rebuy(self, player: Player, current_level_index: int) -> None:
        if not self.can_rebuy(player.player_id, current_level_index):
            raise RebuyError(f"{player.player_id} is not eligible for a rebuy right now")
        player.rebuy(self.policy.rebuy_chips)
        self._rebuy_counts[player.player_id] += 1

    def can_addon(self, player_id: str) -> bool:
        return self.policy.addon_available and player_id not in self._addon_used

    def addon(self, player: Player) -> None:
        if not self.can_addon(player.player_id):
            raise RebuyError(f"{player.player_id} is not eligible for an add-on")
        player.rebuy(self.policy.addon_chips)
        self._addon_used.add(player.player_id)
