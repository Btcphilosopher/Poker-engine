"""
Bounty tracking for Knockout and Progressive Knockout tournaments.

Standard KO: eliminating a player collects their entire bounty in cash,
immediately. Progressive KO (PKO): only part of the collected bounty is
paid out as cash right away — the rest is added to the ELIMINATOR's own
bounty, so bounties grow as players accumulate knockouts (a player who's
knocked out several others can be worth significantly more than their
starting bounty by the time someone eliminates THEM).
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Sequence


class BountyError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class BountyConfig:
    bounty_amount: int  # starting bounty on every player's head
    progressive: bool = False
    progressive_split: float = 0.5  # fraction of a collected bounty added to the eliminator's own bounty (PKO only)

    def __post_init__(self) -> None:
        if self.bounty_amount <= 0:
            raise BountyError("bounty_amount must be positive")
        if self.progressive and not (0.0 <= self.progressive_split <= 1.0):
            raise BountyError("progressive_split must be between 0.0 and 1.0")


class BountyTracker:
    """Tracks each player's current bounty value and cash collected from knockouts."""

    def __init__(self, config: BountyConfig, player_ids: Sequence[str]) -> None:
        self.config = config
        self._bounties: Dict[str, int] = {pid: config.bounty_amount for pid in player_ids}
        self._cash_won: Dict[str, int] = defaultdict(int)

    def bounty_of(self, player_id: str) -> int:
        return self._bounties.get(player_id, 0)

    def record_knockout(self, eliminator_id: str, eliminated_id: str) -> int:
        """
        Award `eliminator_id` for knocking out `eliminated_id`. Returns the
        CASH amount awarded immediately (for PKO, this is only the
        non-progressive portion; the rest grows the eliminator's own
        bounty rather than being paid in cash right away).
        """
        if eliminated_id not in self._bounties:
            raise BountyError(f"{eliminated_id} has no bounty on record (already eliminated or never registered)")
        collected = self._bounties.pop(eliminated_id)

        if not self.config.progressive:
            self._cash_won[eliminator_id] += collected
            return collected

        added_to_bounty = int(collected * self.config.progressive_split)
        cash_now = collected - added_to_bounty
        self._bounties[eliminator_id] = self._bounties.get(eliminator_id, 0) + added_to_bounty
        self._cash_won[eliminator_id] += cash_now
        return cash_now

    def total_bounty_cash_won(self, player_id: str) -> int:
        return self._cash_won.get(player_id, 0)

    def all_bounty_cash_won(self) -> Dict[str, int]:
        return dict(self._cash_won)
