"""
Tournament prize payouts.

Real-world payout structures vary a lot by room and field size in ways too
specific to hard-code faithfully. This module provides a well-documented,
configurable APPROXIMATION (a geometric-decay curve, most-to-least) rather
than claiming to replicate any specific room's exact table — callers who
need a precise structure can pass explicit percentages to
`calculate_payouts` instead of using `standard_payout_percentages`.
"""

from __future__ import annotations

from typing import List, Sequence


class PayoutError(Exception):
    pass


def standard_paid_places(num_entrants: int) -> int:
    """
    A reasonable default for how many places get paid. Real rooms differ;
    this reflects a common rule of thumb (roughly the top 10-15% of a
    large field, with small fields commonly paying 1-3 places) rather than
    a precise or universal rule.
    """
    if num_entrants < 1:
        raise PayoutError("num_entrants must be at least 1")
    if num_entrants <= 6:
        return 1
    if num_entrants <= 45:
        return 3
    return max(3, round(num_entrants * 0.12))


def standard_payout_percentages(num_paid_places: int, *, top_heavy_ratio: float = 1.5) -> List[float]:
    """
    Payout percentages for `num_paid_places`, most-to-least, summing to
    1.0. Uses a geometric-decay curve: each place pays `top_heavy_ratio`
    times as much as the place directly below it. Higher `top_heavy_ratio`
    = more winner-take-most; 1.0 would be a flat/equal split.
    """
    if num_paid_places < 1:
        raise PayoutError("num_paid_places must be at least 1")
    if top_heavy_ratio <= 1:
        raise PayoutError("top_heavy_ratio must be greater than 1")
    weights = [top_heavy_ratio ** (num_paid_places - 1 - i) for i in range(num_paid_places)]
    total = sum(weights)
    return [w / total for w in weights]


def calculate_payouts(prize_pool: int, percentages: Sequence[float]) -> List[int]:
    """
    Split `prize_pool` (an integer amount — chips, cents, whatever unit the
    caller uses) across `len(percentages)` places, most-to-least. Rounds
    down to whole units per place and gives any rounding remainder to 1st
    place — the standard convention (nobody wants a payout structure that
    can't add up to the actual pool).
    """
    if not percentages:
        raise PayoutError("percentages must not be empty")
    if prize_pool < 0:
        raise PayoutError("prize_pool cannot be negative")
    total_pct = sum(percentages)
    if abs(total_pct - 1.0) > 1e-6:
        raise PayoutError(f"percentages must sum to 1.0, got {total_pct}")

    payouts = [int(prize_pool * p) for p in percentages]
    remainder = prize_pool - sum(payouts)
    if payouts:
        payouts[0] += remainder
    return payouts


def satellite_payouts(prize_pool: int, num_seats: int) -> List[int]:
    """
    Satellites award identical prizes (seats) to everyone who finishes in
    the money — a flat split, not a top-heavy curve. Any remainder from
    integer division is distributed one unit at a time starting from 1st
    place (consistent with `calculate_payouts`'s convention).
    """
    if num_seats < 1:
        raise PayoutError("num_seats must be at least 1")
    if prize_pool < 0:
        raise PayoutError("prize_pool cannot be negative")
    base = prize_pool // num_seats
    remainder = prize_pool % num_seats
    payouts = [base] * num_seats
    for i in range(remainder):
        payouts[i] += 1
    return payouts
