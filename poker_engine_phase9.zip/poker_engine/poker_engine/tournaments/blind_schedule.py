"""
Blind schedule and tournament clock.

A schedule is a fixed sequence of levels (each with its own blinds/antes
and a planned duration) plus optional breaks between them. The clock
tracks which level is currently active. This engine does not run a real
wall-clock timer — advancing the clock is an explicit action
(`advance_level()`), the same way every other multi-step process in this
engine (betting rounds, streets, hands) is explicitly driven by the
caller rather than by an internal timer. A real deployment would call
`advance_level()` from its own scheduler when a level's planned duration
elapses; `duration_minutes` is carried here purely for display/planning
(shown on a clock UI, used to compute "when is the next break"), not
enforced by this class.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Union

from poker_engine.betting.structures import BlindLevel, StudStakes


class BlindScheduleError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class BlindScheduleLevel:
    """
    One level of a tournament's blind schedule.

    `stakes` is either a `BlindLevel` (flop/draw games) or `StudStakes`
    (Stud games) — whichever the tournament's variant needs; `is_break`
    levels carry no meaningful stakes (playing pauses) and `stakes` is
    only there so every level has a uniform shape.
    """

    level_number: int
    stakes: Union[BlindLevel, StudStakes]
    duration_minutes: int
    is_break: bool = False

    def __post_init__(self) -> None:
        if self.level_number < 1:
            raise BlindScheduleError("level_number must be >= 1")
        if self.duration_minutes <= 0:
            raise BlindScheduleError("duration_minutes must be positive")


class BlindSchedule:
    """An ordered sequence of BlindScheduleLevels. Blinds never decrease level-over-level by convention (not enforced)."""

    def __init__(self, levels: Sequence[BlindScheduleLevel]) -> None:
        if not levels:
            raise BlindScheduleError("levels must not be empty")
        self.levels: List[BlindScheduleLevel] = list(levels)

    def level(self, index: int) -> BlindScheduleLevel:
        """
        The level at `index` (0-based). Once the schedule runs out of
        defined levels, the LAST level repeats indefinitely — standard
        tournament-clock behaviour for a schedule that doesn't explicitly
        define enough levels to cover very long final tables.
        """
        if index < 0:
            raise BlindScheduleError("index cannot be negative")
        clamped = min(index, len(self.levels) - 1)
        return self.levels[clamped]

    @property
    def total_levels(self) -> int:
        return len(self.levels)

    @staticmethod
    def standard_flop_schedule(
        starting_small_blind: int,
        num_levels: int,
        *,
        duration_minutes: int = 15,
        level_multiplier: float = 1.5,
        break_every: Optional[int] = None,
        break_duration_minutes: int = 5,
    ) -> "BlindSchedule":
        """
        A reasonable default schedule for a flop/draw-game tournament:
        blinds roughly double-ish (`level_multiplier`) each level, big
        blind always exactly 2x small blind. Real rooms hand-tune their
        schedules considerably; this is a sane starting point, not a
        claim of industry-standard precision.
        """
        if num_levels < 1:
            raise BlindScheduleError("num_levels must be at least 1")
        levels: List[BlindScheduleLevel] = []
        sb = float(starting_small_blind)
        for i in range(1, num_levels + 1):
            small = max(1, round(sb))
            big = small * 2
            levels.append(
                BlindScheduleLevel(
                    level_number=len(levels) + 1,
                    stakes=BlindLevel(small_blind=small, big_blind=big),
                    duration_minutes=duration_minutes,
                )
            )
            if break_every is not None and i % break_every == 0 and i != num_levels:
                levels.append(
                    BlindScheduleLevel(
                        level_number=len(levels) + 1,
                        stakes=BlindLevel(small_blind=small, big_blind=big),
                        duration_minutes=break_duration_minutes,
                        is_break=True,
                    )
                )
            sb *= level_multiplier
        return BlindSchedule(levels)


class TournamentClock:
    """Tracks which BlindScheduleLevel is currently active."""

    def __init__(self, schedule: BlindSchedule) -> None:
        self.schedule = schedule
        self._level_index = 0

    @property
    def level_index(self) -> int:
        return self._level_index

    @property
    def current_level(self) -> BlindScheduleLevel:
        return self.schedule.level(self._level_index)

    @property
    def is_on_break(self) -> bool:
        return self.current_level.is_break

    def advance_level(self) -> BlindScheduleLevel:
        """Move to the next level (stays on the last one once the schedule is exhausted)."""
        if self._level_index < self.schedule.total_levels - 1:
            self._level_index += 1
        return self.current_level
