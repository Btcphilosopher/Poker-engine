"""
Tournament — the top-level orchestrator above the Table/Player/Game layer.

Explicitly does NOT play hands itself. A Tournament tracks tournament-wide
state (registration, blind level, which tables exist and who's seated
where, elimination order, bounties, rebuys) across possibly many tables
and possibly many hours; the caller still drives each individual hand
through whatever Game class the tournament's variant uses (TexasHoldem, a
MixedGameRotation, etc.) exactly as shown in every earlier phase's tests —
this class is the layer that decides WHEN and WHERE those hands happen,
not what happens inside one.

Covers: Freezeout (the default — no rebuys), Rebuy (via RebuyPolicy),
Knockout / Progressive Knockout (via BountyConfig), Satellite (via
is_satellite + num_seats), Sit & Go (just a Tournament with a small
enough field that start() is called once registration fills it — no
separate machinery needed), and Multi-table tournaments (table
balancing/breaking via poker_engine.tables.balancing, called explicitly
via rebalance_tables()).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional

from poker_engine.tables.balancing import apply_seat_move, balance_tables, find_table_to_break, plan_table_break
from poker_engine.tables.table import Table
from poker_engine.tournaments.blind_schedule import BlindSchedule, TournamentClock
from poker_engine.tournaments.bounties import BountyConfig, BountyTracker
from poker_engine.tournaments.elimination import compute_finishing_positions
from poker_engine.tournaments.payouts import (
    calculate_payouts,
    satellite_payouts,
    standard_paid_places,
    standard_payout_percentages,
)
from poker_engine.tournaments.rebuys import RebuyPolicy, RebuyTracker


class TournamentError(Exception):
    pass


@dataclass
class TournamentConfig:
    buy_in: int
    starting_stack: int
    blind_schedule: BlindSchedule
    max_players_per_table: int = 9
    rebuy_policy: Optional[RebuyPolicy] = None
    bounty_config: Optional[BountyConfig] = None
    payout_percentages: Optional[List[float]] = None  # if None, computed from standard_paid_places/standard_payout_percentages
    is_satellite: bool = False
    num_seats: Optional[int] = None  # required if is_satellite

    def __post_init__(self) -> None:
        if self.buy_in < 0:
            raise TournamentError("buy_in cannot be negative")
        if self.starting_stack <= 0:
            raise TournamentError("starting_stack must be positive")
        if self.max_players_per_table < 2:
            raise TournamentError("max_players_per_table must be at least 2")
        if self.is_satellite and (self.num_seats is None or self.num_seats < 1):
            raise TournamentError("is_satellite requires num_seats >= 1")
        if self.payout_percentages is not None and abs(sum(self.payout_percentages) - 1.0) > 1e-6:
            raise TournamentError("payout_percentages must sum to 1.0")


class Tournament:
    def __init__(self, config: TournamentConfig) -> None:
        self.config = config
        self.clock = TournamentClock(config.blind_schedule)
        self.tables: List[Table] = []
        self.eliminations: List[str] = []  # first-eliminated first

        self.rebuy_tracker: Optional[RebuyTracker] = (
            RebuyTracker(config.rebuy_policy) if config.rebuy_policy is not None else None
        )
        self.bounty_tracker: Optional[BountyTracker] = None  # built in start(), once entrants are known

        self._registered: Dict[str, str] = {}  # player_id -> display_name
        self._prize_pool_contributions = 0  # actual dollars in: buy-ins + rebuy_cost + addon_cost, NOT a simple entry count
        self._entry_count = 0  # number of starting entries (for standard_paid_places sizing only)
        self._started = False

    # -- registration ----------------------------------------------------------

    @property
    def registered_player_ids(self) -> List[str]:
        return list(self._registered.keys())

    @property
    def is_started(self) -> bool:
        return self._started

    def register(self, player_id: str, display_name: str) -> None:
        if self._started:
            raise TournamentError("Cannot register after the tournament has started")
        if player_id in self._registered:
            raise TournamentError(f"{player_id} is already registered")
        self._registered[player_id] = display_name
        self._entry_count += 1
        self._prize_pool_contributions += self.config.buy_in

    def unregister(self, player_id: str) -> None:
        if self._started:
            raise TournamentError("Cannot unregister after the tournament has started")
        if player_id not in self._registered:
            raise TournamentError(f"{player_id} is not registered")
        del self._registered[player_id]
        self._entry_count -= 1
        self._prize_pool_contributions -= self.config.buy_in

    # -- lifecycle ----------------------------------------------------------

    def start(self) -> None:
        if self._started:
            raise TournamentError("Tournament has already started")
        if len(self._registered) < 2:
            raise TournamentError("Need at least 2 registered players to start")

        self._started = True
        player_ids = list(self._registered.keys())
        num_tables = math.ceil(len(player_ids) / self.config.max_players_per_table)
        self.tables = [
            Table(table_id=f"table-{i}", max_seats=self.config.max_players_per_table) for i in range(num_tables)
        ]
        for i, player_id in enumerate(player_ids):
            table = self.tables[i % num_tables]
            table.sit_down(player_id, self._registered[player_id], self.config.starting_stack)

        if self.config.bounty_config is not None:
            self.bounty_tracker = BountyTracker(self.config.bounty_config, player_ids)

    @property
    def remaining_player_ids(self) -> List[str]:
        return [p.player_id for t in self.tables for p in t.occupied_seats()]

    @property
    def total_entrants(self) -> int:
        return self._entry_count

    @property
    def is_finished(self) -> bool:
        if not self._started:
            return False
        remaining = len(self.remaining_player_ids)
        if self.config.is_satellite:
            assert self.config.num_seats is not None
            return remaining <= self.config.num_seats
        return remaining <= 1

    @property
    def is_final_table(self) -> bool:
        return len([t for t in self.tables if t.occupied_count() > 0]) <= 1

    # -- elimination / rebuy / bounty ----------------------------------------------------------

    def busted_player_ids(self, table: Table) -> List[str]:
        """Players seated at `table` with 0 chips (candidates for rebuy or elimination)."""
        return [p.player_id for p in table.occupied_seats() if p.stack == 0]

    def rebuy(self, table: Table, player_id: str) -> None:
        if self.rebuy_tracker is None:
            raise TournamentError("This tournament does not offer rebuys")
        player = table.find_player(player_id)
        if player is None:
            raise TournamentError(f"{player_id} is not seated at this table")
        self.rebuy_tracker.rebuy(player, self.clock.level_index)
        self._entry_count += 1
        self._prize_pool_contributions += self.rebuy_tracker.policy.rebuy_cost

    def addon(self, table: Table, player_id: str) -> None:
        if self.rebuy_tracker is None:
            raise TournamentError("This tournament does not offer add-ons")
        player = table.find_player(player_id)
        if player is None:
            raise TournamentError(f"{player_id} is not seated at this table")
        self.rebuy_tracker.addon(player)
        self._prize_pool_contributions += self.rebuy_tracker.policy.addon_cost

    def eliminate(self, table: Table, player_id: str, *, eliminator_id: Optional[str] = None) -> int:
        """
        Remove a busted player from the tournament. Returns their
        finishing position (higher number = eliminated earlier; not final
        until the tournament ends, since it depends on total_entrants at
        elimination time — recompute at the end via
        `compute_finishing_positions` if entries can still grow, e.g.
        rebuys still open).
        """
        if table.find_player(player_id) is None:
            raise TournamentError(f"{player_id} is not seated at this table")
        if self.bounty_tracker is not None:
            if eliminator_id is None:
                raise TournamentError("eliminator_id is required for bounty tournaments")
            self.bounty_tracker.record_knockout(eliminator_id, player_id)
        table.stand_up(player_id)
        self.eliminations.append(player_id)
        return self.total_entrants - len(self.eliminations) + 1

    # -- table balancing ----------------------------------------------------------

    def rebalance_tables(self) -> int:
        """
        Break any table that should be broken, then balance what's left,
        applying every move immediately. Returns the number of seat moves
        applied. Intended to be called between hands, never mid-hand.
        """
        moves_applied = 0

        to_break = find_table_to_break(self.tables)
        while to_break is not None:
            others = [t for t in self.tables if t.table_id != to_break.table_id]
            for move in plan_table_break(to_break, others):
                apply_seat_move(move, {t.table_id: t for t in self.tables})
                moves_applied += 1
            self.tables = [t for t in self.tables if t.table_id != to_break.table_id]
            to_break = find_table_to_break(self.tables)

        for move in balance_tables(self.tables):
            apply_seat_move(move, {t.table_id: t for t in self.tables})
            moves_applied += 1

        return moves_applied

    # -- prizes ----------------------------------------------------------

    @property
    def prize_pool(self) -> int:
        return self._prize_pool_contributions

    def finalize(self) -> Dict[str, int]:
        """
        Compute final prize payouts once the tournament is over. Includes
        bounty cash won separately, on top of the base prize-pool payout,
        for KO/PKO tournaments.

        Satellites are handled differently: since `is_finished` triggers
        once exactly `num_seats` players remain (the standard convention —
        everyone left has already "made it," and every seat is worth the
        same), there's no single winner to rank finishing positions from.
        Every remaining player gets an equal share; nobody outside that
        group is paid, regardless of how far they got.
        """
        if not self.is_finished:
            raise TournamentError("Tournament is not finished yet")

        if self.config.is_satellite:
            assert self.config.num_seats is not None
            survivors = self.remaining_player_ids
            payout_list = satellite_payouts(self.prize_pool, len(survivors))
            payouts = dict(zip(survivors, payout_list))
        else:
            winner_id = self.remaining_player_ids[0]
            positions = compute_finishing_positions(self.eliminations, winner_id)

            if self.config.payout_percentages is not None:
                percentages = self.config.payout_percentages
            else:
                num_paid = standard_paid_places(self.total_entrants)
                percentages = standard_payout_percentages(num_paid)
            payout_list = calculate_payouts(self.prize_pool, percentages)

            payouts = {}
            for player_id, position in positions.items():
                if position <= len(payout_list):
                    payouts[player_id] = payout_list[position - 1]

        if self.bounty_tracker is not None:
            for player_id, cash in self.bounty_tracker.all_bounty_cash_won().items():
                if cash:
                    payouts[player_id] = payouts.get(player_id, 0) + cash

        return payouts
