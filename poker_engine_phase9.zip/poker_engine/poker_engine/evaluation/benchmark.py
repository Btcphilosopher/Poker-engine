"""
Quick throughput benchmark for the hand evaluator.

Run with: python3 -m poker_engine.evaluation.benchmark

This is a sanity-check script, not a test. It reports where the current
combinations()-based implementation stands so future optimisation passes
(lookup tables) have a concrete before/after number.
"""

from __future__ import annotations

import random
import time

from poker_engine.cards import Card, Rank, Suit
from poker_engine.evaluation import evaluate_5, evaluate_best_of

ALL_CARDS = [Card(r, s) for r in Rank for s in Suit]


def _bench_evaluate_5(iterations: int = 200_000) -> float:
    rng = random.Random(1)
    hands = [rng.sample(ALL_CARDS, 5) for _ in range(iterations)]
    start = time.perf_counter()
    for hand in hands:
        evaluate_5(hand)
    elapsed = time.perf_counter() - start
    return iterations / elapsed


def _bench_evaluate_best_of_7(iterations: int = 20_000) -> float:
    rng = random.Random(2)
    hands = [rng.sample(ALL_CARDS, 7) for _ in range(iterations)]
    start = time.perf_counter()
    for hand in hands:
        evaluate_best_of(hand)
    elapsed = time.perf_counter() - start
    return iterations / elapsed


if __name__ == "__main__":
    rate_5 = _bench_evaluate_5()
    print(f"evaluate_5:            {rate_5:,.0f} hands/sec")

    rate_7 = _bench_evaluate_best_of_7()
    print(f"evaluate_best_of (7c): {rate_7:,.0f} hands/sec")

    print(
        "\nNote: evaluate_best_of currently brute-forces all C(7,5)=21 combinations "
        "per call. A perfect-hash lookup table (Cactus-Kev style) is the planned "
        "hardening pass to reach the spec's 'millions of evaluations per second' "
        "target for 7-card evaluation specifically; evaluate_5 is already close "
        "to that order of magnitude since it does no combinatorial search."
    )
