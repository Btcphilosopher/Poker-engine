"""
2-7 (Deuce-to-Seven) lowball hand evaluation — deferred from Phase 1,
built now that 2-7 Triple Draw gives it a concrete consumer.

Ace plays HIGH ONLY (never low) — unlike standard evaluate_5, which
recognizes A-2-3-4-5 as a "wheel" straight (5-high), a 2-7 evaluation must
NOT recognize that as a straight, since Ace can never help make a low
straight here. The best possible 2-7 hand is 7-5-4-3-2.

Hands are ranked by inverting standard high-hand comparison: whichever
hand would rank LOWEST under standard poker rules (weakest category,
lowest cards within a category) wins. A straight, flush, or pair all count
AGAINST a hand — the same reasoning as standard poker, just upside down —
so this module reuses `evaluate_5`'s category detection directly
(`allow_wheel=False`) rather than duplicating it, and provides a
comparison key that flips the direction.
"""

from __future__ import annotations

from itertools import combinations
from typing import Sequence, Tuple

from poker_engine.cards.card import Card
from poker_engine.evaluation.evaluator import evaluate_5
from poker_engine.evaluation.hand_category import HandResult


def evaluate_5_deuce_to_seven(cards: Sequence[Card]) -> HandResult:
    """
    Evaluate exactly 5 cards for 2-7 lowball. Returns a standard
    HandResult (same category/tiebreaker computation as evaluate_5),
    except A-2-3-4-5 is never treated as a straight. Compare results with
    `deuce_to_seven_sort_key`, NOT the HandResult's own `<`/`>` — those
    still reflect standard (high-hand) ordering.
    """
    return evaluate_5(cards, allow_wheel=False)


def deuce_to_seven_sort_key(result: HandResult) -> Tuple[int, Tuple[int, ...]]:
    """Comparison key for 2-7 lowball: the weakest standard hand ranking wins."""
    return (-int(result.category), tuple(-t for t in result.tiebreakers))


def best_deuce_to_seven_of(cards: Sequence[Card]) -> HandResult:
    """Best possible 5-card hand from >=5 cards, ranked by 2-7 lowball rules."""
    cards = list(cards)
    if len(cards) < 5:
        raise ValueError(f"best_deuce_to_seven_of requires at least 5 cards, got {len(cards)}")
    return max(
        (evaluate_5(combo, allow_wheel=False) for combo in combinations(cards, 5)),
        key=deuce_to_seven_sort_key,
    )
