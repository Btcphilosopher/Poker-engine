"""Hand category ranking and result value objects."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Sequence, Tuple

from poker_engine.cards.card import Card


class HandCategory(IntEnum):
    """
    Ordered so that a plain integer comparison gives the correct hand ranking.
    Royal Flush is not a distinct tier — it's the top instance of Straight Flush —
    but is called out here for display/API convenience (see HandResult.hand_name).
    """

    HIGH_CARD = 1
    PAIR = 2
    TWO_PAIR = 3
    THREE_OF_A_KIND = 4
    STRAIGHT = 5
    FLUSH = 6
    FULL_HOUSE = 7
    FOUR_OF_A_KIND = 8
    STRAIGHT_FLUSH = 9

    @property
    def display_name(self) -> str:
        return {
            HandCategory.HIGH_CARD: "High Card",
            HandCategory.PAIR: "Pair",
            HandCategory.TWO_PAIR: "Two Pair",
            HandCategory.THREE_OF_A_KIND: "Three of a Kind",
            HandCategory.STRAIGHT: "Straight",
            HandCategory.FLUSH: "Flush",
            HandCategory.FULL_HOUSE: "Full House",
            HandCategory.FOUR_OF_A_KIND: "Four of a Kind",
            HandCategory.STRAIGHT_FLUSH: "Straight Flush",
        }[self]


@dataclass(frozen=True, slots=True)
class HandResult:
    """
    The result of evaluating a single 5-card hand.

    `tiebreakers` is a tuple of rank values, most-significant first, such that
    comparing two HandResults of the *same* category via `(category, tiebreakers)`
    always produces the correct official ranking (including kicker comparisons).
    """

    category: HandCategory
    tiebreakers: Tuple[int, ...]
    cards: Tuple[Card, ...]

    @property
    def sort_key(self) -> Tuple[int, Tuple[int, ...]]:
        return (int(self.category), self.tiebreakers)

    @property
    def hand_name(self) -> str:
        if self.category is HandCategory.STRAIGHT_FLUSH and self.tiebreakers[0] == 14:
            return "Royal Flush"
        return self.category.display_name

    def __lt__(self, other: "HandResult") -> bool:
        return self.sort_key < other.sort_key

    def __le__(self, other: "HandResult") -> bool:
        return self.sort_key <= other.sort_key

    def __gt__(self, other: "HandResult") -> bool:
        return self.sort_key > other.sort_key

    def __ge__(self, other: "HandResult") -> bool:
        return self.sort_key >= other.sort_key

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, HandResult):
            return NotImplemented
        return self.sort_key == other.sort_key

    def __str__(self) -> str:
        cards_str = " ".join(str(c) for c in self.cards)
        return f"{self.hand_name} [{cards_str}]"


@dataclass(frozen=True, slots=True)
class LowHandResult:
    """
    Result of an Ace-to-5 lowball evaluation (used by Razz, 2-7 Triple Draw
    variants using A-5 low, and the low side of Hi-Lo split games).

    `values` are the actual ace-low ranks (Ace=1..King=13) sorted descending,
    for display/export purposes (e.g. "7-5-4-3-2").

    `rank_key` is a separate, shape-prefixed comparison key: hand "shape"
    (no pair / pair / two pair / trips / full house / quads) dominates first,
    exactly as in a standard high-hand evaluator, and only then do the actual
    ranks break ties. Comparisons must go through `rank_key`, not `values`,
    because a lower top card does NOT mean a better low hand once pairs are
    involved (e.g. 7-5-4-3-2 beats 6-6-4-3-2 despite 6 < 7).
    """

    values: Tuple[int, ...]
    rank_key: Tuple[int, ...]
    cards: Tuple[Card, ...]
    qualifies_for_low: bool

    def __lt__(self, other: "LowHandResult") -> bool:
        # Lower rank_key = better low hand.
        return self.rank_key < other.rank_key

    def __le__(self, other: "LowHandResult") -> bool:
        return self.rank_key <= other.rank_key

    def __gt__(self, other: "LowHandResult") -> bool:
        return self.rank_key > other.rank_key

    def __ge__(self, other: "LowHandResult") -> bool:
        return self.rank_key >= other.rank_key

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LowHandResult):
            return NotImplemented
        return self.rank_key == other.rank_key

    def __str__(self) -> str:
        cards_str = " ".join(str(c) for c in self.cards)
        ranks_str = "-".join(str(v) for v in self.values)
        return f"Low {ranks_str} [{cards_str}]"
