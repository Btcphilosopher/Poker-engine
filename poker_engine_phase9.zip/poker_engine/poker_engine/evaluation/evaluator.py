"""
Hand evaluation engine.

Implemented in this phase:
    - evaluate_5           5-card high-hand evaluation (all 9 categories, full tie-breaking)
    - evaluate_best_of     best 5-card hand out of N cards (e.g. 7-card hold'em/stud)
    - evaluate_omaha       Omaha-restricted evaluation (exactly 2 hole + 3 board)
    - evaluate_low_5       Ace-to-5 lowball evaluation of exactly 5 cards
    - evaluate_low_best_of best qualifying Ace-to-5 low out of N cards
    - evaluate_omaha_low   Omaha Hi-Lo low side (2 hole + 3 board, qualifier-gated)

Deliberately deferred to the variant-specific phase:
    - Badugi evaluation (suit-uniqueness based; structurally different from
      rank-counting evaluators and belongs with the Draw-games implementation).
    - 2-7 (Deuce-to-Seven) lowball, where straights/flushes count *against*
      the hand and Ace plays high only — will be added alongside Triple Draw.

Performance note: evaluate_5 is pure counting/sorting on 5 integers and is
already fast (low microseconds). evaluate_best_of / evaluate_omaha currently
brute-force via itertools.combinations, which is correct and simple but not
yet the "millions of evaluations per second" target from the spec. A
Cactus-Kev-style perfect-hash lookup table is planned as a hardening pass
once the full rule engine (which depends on this API) is in place — swapping
the implementation later will not change this module's public signatures.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
from typing import Iterable, Optional, Sequence, Tuple

from poker_engine.cards.card import Card
from poker_engine.evaluation.hand_category import HandCategory, HandResult, LowHandResult

_WHEEL = frozenset({14, 5, 4, 3, 2})


def _straight_high(unique_desc: Sequence[int], *, allow_wheel: bool = True) -> Optional[int]:
    """Given distinct ranks sorted descending, return the straight's high card, or None."""
    if len(unique_desc) != 5:
        return None
    if unique_desc[0] - unique_desc[4] == 4:
        return unique_desc[0]
    if allow_wheel and set(unique_desc) == _WHEEL:
        return 5  # wheel: A-2-3-4-5 plays as a 5-high straight
    return None


def evaluate_5(cards: Sequence[Card], *, allow_wheel: bool = True) -> HandResult:
    """
    Evaluate exactly 5 cards and return their HandResult.

    `allow_wheel` controls whether A-2-3-4-5 is recognized as a straight
    (True, the default, correct for every standard-ranking game). Pass
    False for 2-7 lowball, where Ace plays high only and never completes a
    low straight — see poker_engine.evaluation.deuce_to_seven, which is
    the only caller that should ever need this.
    """
    cards = list(cards)
    if len(cards) != 5:
        raise ValueError(f"evaluate_5 requires exactly 5 cards, got {len(cards)}")
    if len(set(cards)) != 5:
        raise ValueError("Duplicate card supplied to evaluate_5")

    ranks_desc = sorted((c.rank.value for c in cards), reverse=True)
    is_flush = len({c.suit for c in cards}) == 1
    unique_desc = sorted(set(ranks_desc), reverse=True)
    straight_high = _straight_high(unique_desc, allow_wheel=allow_wheel)

    counts = Counter(ranks_desc)
    # Group by (count desc, rank desc) so the "most significant" group comes first.
    count_items = sorted(counts.items(), key=lambda kv: (-kv[1], -kv[0]))
    pattern = tuple(c for _, c in count_items)
    ordered_cards = tuple(sorted(cards, key=lambda c: c.rank.value, reverse=True))

    if is_flush and straight_high is not None:
        return HandResult(HandCategory.STRAIGHT_FLUSH, (straight_high,), ordered_cards)
    if pattern == (4, 1):
        quad_rank, kicker = count_items[0][0], count_items[1][0]
        return HandResult(HandCategory.FOUR_OF_A_KIND, (quad_rank, kicker), ordered_cards)
    if pattern == (3, 2):
        trips_rank, pair_rank = count_items[0][0], count_items[1][0]
        return HandResult(HandCategory.FULL_HOUSE, (trips_rank, pair_rank), ordered_cards)
    if is_flush:
        return HandResult(HandCategory.FLUSH, tuple(ranks_desc), ordered_cards)
    if straight_high is not None:
        return HandResult(HandCategory.STRAIGHT, (straight_high,), ordered_cards)
    if pattern == (3, 1, 1):
        trips_rank = count_items[0][0]
        kickers = sorted((r for r, c in count_items[1:]), reverse=True)
        return HandResult(HandCategory.THREE_OF_A_KIND, (trips_rank, *kickers), ordered_cards)
    if pattern == (2, 2, 1):
        high_pair, low_pair = count_items[0][0], count_items[1][0]
        kicker = count_items[2][0]
        return HandResult(HandCategory.TWO_PAIR, (high_pair, low_pair, kicker), ordered_cards)
    if pattern == (2, 1, 1, 1):
        pair_rank = count_items[0][0]
        kickers = sorted((r for r, c in count_items[1:]), reverse=True)
        return HandResult(HandCategory.PAIR, (pair_rank, *kickers), ordered_cards)
    return HandResult(HandCategory.HIGH_CARD, tuple(ranks_desc), ordered_cards)


def evaluate_best_of(cards: Sequence[Card]) -> HandResult:
    """Return the best possible 5-card HandResult from >=5 candidate cards."""
    cards = list(cards)
    if len(cards) < 5:
        raise ValueError(f"evaluate_best_of requires at least 5 cards, got {len(cards)}")
    return max(evaluate_5(combo) for combo in combinations(cards, 5))


def evaluate_omaha(hole: Sequence[Card], board: Sequence[Card]) -> HandResult:
    """
    Omaha-restricted evaluation: the best hand using exactly 2 hole cards
    and exactly 3 board cards (never more, never fewer, of either).
    """
    hole, board = list(hole), list(board)
    if len(hole) < 2:
        raise ValueError("Omaha evaluation requires at least 2 hole cards")
    if len(board) < 3:
        raise ValueError("Omaha evaluation requires at least 3 board cards")

    best: Optional[HandResult] = None
    for h2 in combinations(hole, 2):
        for b3 in combinations(board, 3):
            result = evaluate_5(list(h2) + list(b3))
            if best is None or result > best:
                best = result
    assert best is not None
    return best


# ---------------------------------------------------------------------------
# Ace-to-5 lowball ("California" low, used by Razz and Hi-Lo split games)
# ---------------------------------------------------------------------------

_LOW_SHAPE_ORDER = {
    (1, 1, 1, 1, 1): 0,
    (2, 1, 1, 1): 1,
    (2, 2, 1): 2,
    (3, 1, 1): 3,
    (3, 2): 4,
    (4, 1): 5,
}


def _low_sort_key(values: Sequence[int]) -> Tuple[int, ...]:
    """
    Build a tuple such that comparing two of these with plain `<` reproduces
    official Ace-to-5 low hand ranking (lower tuple = better low hand).

    Structure (no pair / pair / two pair / ...) dominates first, exactly as
    in a standard high-hand evaluator; straights and flushes are irrelevant
    for low and are never considered. Within a matching structure, lower
    ranks are better.
    """
    counts = Counter(values)
    shape_pattern = tuple(sorted(counts.values(), reverse=True))
    shape_rank = _LOW_SHAPE_ORDER.get(shape_pattern, 9)

    if shape_pattern == (1, 1, 1, 1, 1):
        tail = tuple(sorted(values, reverse=True))
    elif shape_pattern == (2, 1, 1, 1):
        pair = next(r for r, c in counts.items() if c == 2)
        kickers = sorted(r for r, c in counts.items() if c == 1)
        tail = (pair, *kickers)
    elif shape_pattern == (2, 2, 1):
        pairs = sorted(r for r, c in counts.items() if c == 2)
        kicker = next(r for r, c in counts.items() if c == 1)
        tail = (*pairs, kicker)
    elif shape_pattern == (3, 1, 1):
        trips = next(r for r, c in counts.items() if c == 3)
        kickers = sorted(r for r, c in counts.items() if c == 1)
        tail = (trips, *kickers)
    elif shape_pattern == (3, 2):
        trips = next(r for r, c in counts.items() if c == 3)
        pair = next(r for r, c in counts.items() if c == 2)
        tail = (trips, pair)
    elif shape_pattern == (4, 1):
        quad = next(r for r, c in counts.items() if c == 4)
        kicker = next(r for r, c in counts.items() if c == 1)
        tail = (quad, kicker)
    else:
        tail = tuple(sorted(values))
    return (shape_rank, *tail)


def evaluate_low_5(cards: Sequence[Card], *, qualifier: Optional[int] = 8) -> LowHandResult:
    """
    Evaluate exactly 5 cards for Ace-to-5 low. `qualifier` is the standard
    Hi-Lo "8-or-better" rule (all five cards must rank 8 or below, ace-low,
    with no pair); pass qualifier=None (Razz) to disable qualification.
    """
    cards = list(cards)
    if len(cards) != 5:
        raise ValueError(f"evaluate_low_5 requires exactly 5 cards, got {len(cards)}")
    if len(set(cards)) != 5:
        raise ValueError("Duplicate card supplied to evaluate_low_5")

    values = [c.rank.low_ace_value() for c in cards]
    key = _low_sort_key(values)
    qualifies = key[0] == 0 and (qualifier is None or max(values) <= qualifier)
    display_values = tuple(sorted(values, reverse=True))
    ordered_cards = tuple(
        sorted(cards, key=lambda c: c.rank.low_ace_value(), reverse=True)
    )
    return LowHandResult(
        values=display_values, rank_key=key, cards=ordered_cards, qualifies_for_low=qualifies
    )


def evaluate_low_best_of(
    cards: Sequence[Card], *, qualifier: Optional[int] = 8
) -> Optional[LowHandResult]:
    """
    Best qualifying Ace-to-5 low hand from >=5 candidate cards, or None if no
    5-card subset qualifies (only relevant when `qualifier` is not None).
    """
    cards = list(cards)
    if len(cards) < 5:
        raise ValueError(f"evaluate_low_best_of requires at least 5 cards, got {len(cards)}")

    candidates = [evaluate_low_5(combo, qualifier=qualifier) for combo in combinations(cards, 5)]
    qualifying = [c for c in candidates if c.qualifies_for_low]
    if qualifier is not None and not qualifying:
        return None
    pool = qualifying if qualifying else candidates
    return min(pool, key=lambda r: r.rank_key)


def evaluate_omaha_low(
    hole: Sequence[Card], board: Sequence[Card], *, qualifier: Optional[int] = 8
) -> Optional[LowHandResult]:
    """Omaha Hi-Lo low side: best qualifying low using exactly 2 hole + 3 board cards."""
    hole, board = list(hole), list(board)
    if len(hole) < 2:
        raise ValueError("Omaha low evaluation requires at least 2 hole cards")
    if len(board) < 3:
        raise ValueError("Omaha low evaluation requires at least 3 board cards")

    best: Optional[LowHandResult] = None
    for h2 in combinations(hole, 2):
        for b3 in combinations(board, 3):
            result = evaluate_low_5(list(h2) + list(b3), qualifier=qualifier)
            if not result.qualifies_for_low:
                continue
            if best is None or result.rank_key < best.rank_key:
                best = result
    return best
