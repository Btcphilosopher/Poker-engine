"""
Badugi hand evaluation — deferred since Phase 1, built now that Badugi
(Phase 7) gives it a concrete consumer.

A "badugi" is a 4-card lowball hand where all four cards have DIFFERENT
ranks AND different suits — no pairing of rank, no pairing of suit. Ace
plays LOW ONLY (like Ace-to-5 lowball); the best possible badugi is
A-2-3-4 of four different suits.

If a player's actual 4 cards don't already satisfy this (some rank or
suit repeats), the hand is read as the BEST-QUALIFYING SUBSET: drop as
few cards as necessary to eliminate every rank/suit clash, and among
subsets of the same (maximal) size, the lowest-ranked one. More cards
always beats fewer (any 4-card badugi beats any 3-card badugi, regardless
of rank), and within the same card count, lower ranks win — the same
"shape dominates, then value" principle as Ace-to-5 lowball (Phase 1).
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Sequence, Tuple

from poker_engine.cards.card import Card


class BadugiError(Exception):
    pass


def _is_badugi(cards: Sequence[Card]) -> bool:
    ranks = [c.rank.low_ace_value() for c in cards]
    suits = [c.suit for c in cards]
    return len(set(ranks)) == len(cards) and len(set(suits)) == len(cards)


@dataclass(frozen=True, slots=True)
class BadugiResult:
    count: int  # 1-4: how many cards form the qualifying badugi
    cards: Tuple[Card, ...]  # the specific cards forming it (a subset of the 4 hole cards)

    @property
    def sort_key(self) -> Tuple[int, Tuple[int, ...]]:
        """
        Higher key = better hand, for consistency with HandResult/
        LowHandResult and direct compatibility with
        poker_engine.dealer.showdown.resolve_showdown's default key
        (`lambda hr: hr.sort_key`) — no custom key function needed to use
        BadugiResult with resolve_showdown.
        """
        values_desc = tuple(sorted((c.rank.low_ace_value() for c in self.cards), reverse=True))
        return (self.count, tuple(-v for v in values_desc))

    def __lt__(self, other: "BadugiResult") -> bool:
        return self.sort_key < other.sort_key

    def __le__(self, other: "BadugiResult") -> bool:
        return self.sort_key <= other.sort_key

    def __gt__(self, other: "BadugiResult") -> bool:
        return self.sort_key > other.sort_key

    def __ge__(self, other: "BadugiResult") -> bool:
        return self.sort_key >= other.sort_key

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BadugiResult):
            return NotImplemented
        return self.sort_key == other.sort_key

    def __str__(self) -> str:
        label = {4: "Badugi", 3: "3-card Badugi", 2: "2-card Badugi", 1: "1-card Badugi"}[self.count]
        cards_str = " ".join(str(c) for c in self.cards)
        return f"{label} [{cards_str}]"


def evaluate_badugi(cards: Sequence[Card]) -> BadugiResult:
    """Evaluate exactly 4 cards, returning the best qualifying badugi subset."""
    cards = list(cards)
    if len(cards) != 4:
        raise BadugiError(f"evaluate_badugi requires exactly 4 cards, got {len(cards)}")
    if len(set(cards)) != 4:
        raise BadugiError("Duplicate card supplied to evaluate_badugi")

    for size in range(4, 0, -1):
        candidates = [combo for combo in combinations(cards, size) if _is_badugi(combo)]
        if candidates:
            best = min(
                candidates,
                key=lambda combo: tuple(sorted((c.rank.low_ace_value() for c in combo), reverse=True)),
            )
            return BadugiResult(count=size, cards=tuple(best))
    raise AssertionError("unreachable: a single card is always a valid 1-card badugi")
