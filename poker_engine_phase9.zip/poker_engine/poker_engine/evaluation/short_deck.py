"""
Short Deck (6+) Hold'em hand ranking.

With 2-5 removed from the deck, flushes are harder to make than full
houses (the opposite of a standard 52-card deck), so most Short Deck
rulesets rank flush above full house. Everything else — category
detection, straights, tie-breaking within a category — is identical to
standard evaluation; only the relative order of two specific categories
changes.

Rather than duplicate the evaluator, this module reuses `evaluate_5`
(category detection doesn't care about deck size or ranking order) and
provides an alternate SORT KEY that swaps FLUSH and FULL_HOUSE for
comparison purposes, plus `evaluate_best_of_short_deck`, which is NOT just
"evaluate_best_of with a different comparator" — the combinatorial search
itself needs to search by the short-deck key rather than the standard one
and re-sort afterward.

Worth knowing: with exactly 7 cards (2 hole + 5 board, as in a real Short
Deck Hold'em hand), a full house and a flush can never BOTH be achievable
at once — a 2-rank full house and a 5-suit flush can share at most 2
cards, so having both options needs at least 8 total cards. That means the
flush/full-house ranking swap never changes which 5 cards a single
player's best hand is made of; it only ever matters when comparing BETWEEN
two different players, one holding a flush and the other a full house —
which is exactly the case it exists for.

Scope note: this module does NOT implement an alternate low/wheel-style
straight (some Short Deck rulesets treat A-6-7-8-9 as a valid straight,
analogous to the standard wheel). That's a genuinely disputed rule across
different rooms/tournaments, so rather than guess, this engine currently
uses the same straight detection as standard poker — meaning the lowest
possible straight in Short Deck is naturally 6-7-8-9-10, since 2-5 don't
exist in the deck to begin with. A configurable ace-low straight is a
reasonable future addition if a specific ruleset requires it.
"""

from __future__ import annotations

from itertools import combinations
from typing import Sequence, Tuple

from poker_engine.cards.card import Card
from poker_engine.evaluation.evaluator import evaluate_5
from poker_engine.evaluation.hand_category import HandCategory, HandResult

SHORT_DECK_CATEGORY_RANK = {
    HandCategory.HIGH_CARD: 1,
    HandCategory.PAIR: 2,
    HandCategory.TWO_PAIR: 3,
    HandCategory.THREE_OF_A_KIND: 4,
    HandCategory.STRAIGHT: 5,
    HandCategory.FULL_HOUSE: 6,  # swapped with FLUSH relative to standard ranking
    HandCategory.FLUSH: 7,  # swapped with FULL_HOUSE relative to standard ranking
    HandCategory.FOUR_OF_A_KIND: 8,
    HandCategory.STRAIGHT_FLUSH: 9,
}


def short_deck_sort_key(result: HandResult) -> Tuple[int, Tuple[int, ...]]:
    """Comparison key reflecting Short Deck ranking (flush beats full house)."""
    return (SHORT_DECK_CATEGORY_RANK[result.category], result.tiebreakers)


def evaluate_best_of_short_deck(cards: Sequence[Card]) -> HandResult:
    """Best possible 5-card HandResult from >=5 cards, ranked by Short Deck rules."""
    cards = list(cards)
    if len(cards) < 5:
        raise ValueError(f"evaluate_best_of_short_deck requires at least 5 cards, got {len(cards)}")
    return max((evaluate_5(combo) for combo in combinations(cards, 5)), key=short_deck_sort_key)
