"""
Determining action order in Stud games from exposed (up) cards.

This is NOT a poker hand evaluation — with only 2-4 cards showing (4th
through 6th/7th street), straights and flushes aren't "made" yet, so stud
convention only counts pairs/trips among the up cards, then compares the
rest as kickers. Used purely to decide who acts first each street from 4th
onward; the actual hand at showdown is evaluated normally with the full 7
cards via evaluate_best_of / evaluate_low_best_of.

(3rd street's forced action — the bring-in — is a full poker-hand
determination on a single card, already covered by
`poker_engine.betting.blinds.determine_bring_in`.)
"""

from __future__ import annotations

from collections import Counter
from typing import Dict, List, Sequence, Tuple

from poker_engine.cards.card import Card

_SUIT_PRIORITY = {"c": 0, "d": 1, "h": 2, "s": 3}


class ExposedHandError(Exception):
    pass


def exposed_hand_key(cards: Sequence[Card]) -> Tuple[Tuple[int, ...], Tuple[int, ...], int]:
    """
    Comparable key for a partial hand of up-cards. Higher key = better
    exposed hand. Pairs/trips outrank no-pair, then rank-value kickers,
    then (only as a final tiebreak between otherwise-identical-looking
    hands, which can only happen with different actual cards) the suit of
    the highest card, using the standard c<d<h<s priority.
    """
    cards = list(cards)
    if not cards:
        raise ExposedHandError("cards must not be empty")

    counts = Counter(c.rank.value for c in cards)
    count_items = sorted(counts.items(), key=lambda kv: (-kv[1], -kv[0]))
    pattern = tuple(c for _, c in count_items)
    ordered_ranks = tuple(r for r, _ in count_items)
    best_card = max(cards, key=lambda c: (c.rank.value, _SUIT_PRIORITY[c.suit.code]))
    return (pattern, ordered_ranks, _SUIT_PRIORITY[best_card.suit.code])


def best_exposed_player(up_cards: Dict[str, List[Card]], *, low_hand: bool = False) -> str:
    """
    The player_id who acts first based on exposed cards.

    low_hand=False (standard Stud / Stud Hi-Lo): the BEST-looking exposed
    hand acts first.
    low_hand=True (Razz): the WORST-looking exposed hand acts first — the
    player who looks best for a LOW hand, i.e. minimizes exposed_hand_key.
    """
    if not up_cards:
        raise ExposedHandError("up_cards must not be empty")
    chooser = min if low_hand else max
    return chooser(up_cards, key=lambda pid: exposed_hand_key(up_cards[pid]))
