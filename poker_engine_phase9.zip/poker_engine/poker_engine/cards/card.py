"""
Core card primitives: Suit, Rank, and the immutable Card value object.

Design notes
------------
- Rank values are the integers used throughout the evaluation engine
  (2..14, where 14 = Ace). This lets hand evaluation work directly on
  ``card.rank.value`` without any translation layer.
- Card is a frozen dataclass: hashable, comparable, and safe to share
  across threads (relevant later for multi-threaded Monte Carlo sims).
- Suit carries both a single-letter code (for compact serialisation /
  hand-history export) and a unicode symbol (for display).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from functools import total_ordering


class Suit(IntEnum):
    CLUBS = 0
    DIAMONDS = 1
    HEARTS = 2
    SPADES = 3

    @property
    def code(self) -> str:
        return ("c", "d", "h", "s")[self.value]

    @property
    def symbol(self) -> str:
        return ("♣", "♦", "♥", "♠")[self.value]

    @classmethod
    def from_code(cls, code: str) -> "Suit":
        mapping = {"c": cls.CLUBS, "d": cls.DIAMONDS, "h": cls.HEARTS, "s": cls.SPADES}
        try:
            return mapping[code.lower()]
        except KeyError as exc:
            raise ValueError(f"Unknown suit code: {code!r}") from exc


class Rank(IntEnum):
    TWO = 2
    THREE = 3
    FOUR = 4
    FIVE = 5
    SIX = 6
    SEVEN = 7
    EIGHT = 8
    NINE = 9
    TEN = 10
    JACK = 11
    QUEEN = 12
    KING = 13
    ACE = 14

    @property
    def code(self) -> str:
        return {
            2: "2", 3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "T",
            11: "J", 12: "Q", 13: "K", 14: "A",
        }[self.value]

    @classmethod
    def from_code(cls, code: str) -> "Rank":
        mapping = {
            "2": cls.TWO, "3": cls.THREE, "4": cls.FOUR, "5": cls.FIVE, "6": cls.SIX,
            "7": cls.SEVEN, "8": cls.EIGHT, "9": cls.NINE, "T": cls.TEN, "10": cls.TEN,
            "J": cls.JACK, "Q": cls.QUEEN, "K": cls.KING, "A": cls.ACE,
        }
        try:
            return mapping[code.upper()]
        except KeyError as exc:
            raise ValueError(f"Unknown rank code: {code!r}") from exc

    def low_ace_value(self) -> int:
        """Value of this rank when Ace plays low (Ace-to-5 lowball, wheel straights)."""
        return 1 if self is Rank.ACE else self.value


@total_ordering
@dataclass(frozen=True, slots=True)
class Card:
    rank: Rank
    suit: Suit

    def __str__(self) -> str:
        return f"{self.rank.code}{self.suit.code}"

    def __repr__(self) -> str:
        return f"Card({self.rank.name}, {self.suit.name})"

    def pretty(self) -> str:
        return f"{self.rank.code}{self.suit.symbol}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Card):
            return NotImplemented
        return self.rank == other.rank and self.suit == other.suit

    def __lt__(self, other: "Card") -> bool:
        if not isinstance(other, Card):
            return NotImplemented
        return (self.rank, self.suit) < (other.rank, other.suit)

    def __hash__(self) -> int:
        return hash((self.rank, self.suit))

    @classmethod
    def from_str(cls, text: str) -> "Card":
        """Parse a two-character card code, e.g. 'Ah', 'Td', '9c'."""
        text = text.strip()
        if len(text) < 2:
            raise ValueError(f"Invalid card string: {text!r}")
        rank_part, suit_part = text[:-1], text[-1]
        return cls(rank=Rank.from_code(rank_part), suit=Suit.from_code(suit_part))
