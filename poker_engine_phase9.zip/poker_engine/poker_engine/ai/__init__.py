"""
ai — not yet implemented.

Phase 10 — pluggable AI player framework (rule-based styles, Monte Carlo AI, CFR/NN interfaces).

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
