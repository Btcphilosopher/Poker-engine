"""
Showdown resolution.

Ties together Phase 1 (hand evaluation), Phase 2 (pot computation and
distribution), and this phase's dealing/table machinery into "given these
players' final hands, who wins what."

`resolve_showdown` resolves each pot to a SINGLE winning group (the best
hand among that pot's eligible players by some comparison key, split evenly
among ties) — used by Hold'em, Omaha, Short Deck, Stud, and Draw games.

`resolve_showdown_hi_lo` splits each pot in half between the best high hand
and the best QUALIFYING low hand (scooped entirely by high if no low
qualifies) — used by Omaha Hi-Lo, Stud Hi-Lo, and Razz-adjacent split games.
Added in Phase 5 once Omaha Hi-Lo gave it a concrete shape to build against,
per the plan noted in Phase 3/4.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, replace
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from poker_engine.betting.actions import ActionType
from poker_engine.betting.player_state import PlayerBettingState
from poker_engine.betting.pot import Pot, compute_pots, distribute_pot
from poker_engine.betting.round import BettingRound
from poker_engine.evaluation.hand_category import HandResult, LowHandResult


class ShowdownError(Exception):
    pass


def last_aggressor_of(round_: BettingRound) -> Optional[str]:
    """The last player to make a COMPLETE or incomplete bet/raise on this street, if any."""
    for action in reversed(round_.history):
        if action.action_type in (ActionType.BET, ActionType.RAISE):
            return action.player_id
    return None


def determine_reveal_order(action_order_final_street: Sequence[str], last_aggressor: Optional[str]) -> List[str]:
    """
    Who shows their hand first at showdown, and in what order.

    If someone bet or raised on the final street, they show first (they
    "have the goods" or are bluffing — either way, they show), then it
    proceeds around the table from there. If everyone checked the final
    street, the first player to act shows first, in normal action order.
    """
    order = list(action_order_final_street)
    if last_aggressor is None or last_aggressor not in order:
        return order
    idx = order.index(last_aggressor)
    return order[idx:] + order[:idx]


@dataclass(frozen=True, slots=True)
class PotOutcome:
    pot: Pot
    winners: Tuple[str, ...]
    payouts: Dict[str, int]


@dataclass(frozen=True, slots=True)
class HandOutcome:
    pot_outcomes: Tuple[PotOutcome, ...]
    total_payouts: Dict[str, int]

    @property
    def total_awarded(self) -> int:
        return sum(self.total_payouts.values())


def resolve_showdown(
    players: Sequence[PlayerBettingState],
    hand_results: Dict[str, HandResult],
    order_from_button: Sequence[str],
    *,
    key: Optional[Callable[[HandResult], object]] = None,
) -> HandOutcome:
    """
    Build main/side pots from `players`' contributions, determine the
    winner(s) of each from `hand_results`, and split-distribute each pot.

    `hand_results` only needs entries for players who actually reach
    showdown with more than one live contender — an uncontested pot (a
    single eligible player, everyone else folded) is awarded to that player
    directly without requiring their hand to be evaluated at all, matching
    how a real dealer never asks a player to show when nobody else is left
    to contest the pot.

    `key`, if given, overrides how two HandResults compare — the default is
    HandResult's own natural ordering (standard hand rankings). Short Deck
    Hold'em is the reason this exists: it ranks flush above full house, so
    it passes `poker_engine.evaluation.short_deck.short_deck_sort_key`
    instead of trusting the standard ordering.
    """
    key_fn: Callable[[HandResult], object] = key or (lambda hr: hr.sort_key)
    pots = compute_pots(players)
    pot_outcomes: List[PotOutcome] = []
    total_payouts: Dict[str, int] = defaultdict(int)

    for pot in pots:
        if not pot.eligible_player_ids:
            pot_outcomes.append(PotOutcome(pot=pot, winners=(), payouts={}))
            continue

        if len(pot.eligible_player_ids) == 1:
            winners: Tuple[str, ...] = pot.eligible_player_ids
        else:
            missing = [pid for pid in pot.eligible_player_ids if pid not in hand_results]
            if missing:
                raise ShowdownError(f"Missing hand_results for contested pot eligible players: {missing}")
            best_key = max(key_fn(hand_results[pid]) for pid in pot.eligible_player_ids)
            winners = tuple(pid for pid in pot.eligible_player_ids if key_fn(hand_results[pid]) == best_key)

        payouts = distribute_pot(pot, list(winners), order_from_button)
        pot_outcomes.append(PotOutcome(pot=pot, winners=winners, payouts=payouts))
        for pid, amount in payouts.items():
            total_payouts[pid] += amount

    return HandOutcome(pot_outcomes=tuple(pot_outcomes), total_payouts=dict(total_payouts))


def resolve_showdown_hi_lo(
    players: Sequence[PlayerBettingState],
    high_hand_results: Dict[str, HandResult],
    low_hand_results: Dict[str, Optional[LowHandResult]],
    order_from_button: Sequence[str],
) -> HandOutcome:
    """
    Hi-Lo split-pot resolution (Omaha Hi-Lo, Stud Hi-Lo, Razz-style splits).

    Each contested pot is split in half: one half to the best high hand,
    one half to the best QUALIFYING low hand. If nobody among a pot's
    eligible players has a qualifying low (`low_hand_results[pid]` is None
    or `.qualifies_for_low` is False), the high hand scoops the entire pot
    — the standard rule. Standard convention for an odd chip when a pot
    doesn't split evenly in two: the extra chip goes to the high half.

    `low_hand_results` should have an entry for every player in
    `high_hand_results` (use None for "did not qualify" rather than
    omitting the key) — this mirrors how Omaha Hi-Lo hands are actually
    evaluated: every live hand gets checked for a qualifying low, most just
    don't have one.
    """
    pots = compute_pots(players)
    pot_outcomes: List[PotOutcome] = []
    total_payouts: Dict[str, int] = defaultdict(int)

    for pot in pots:
        if not pot.eligible_player_ids:
            pot_outcomes.append(PotOutcome(pot=pot, winners=(), payouts={}))
            continue

        if len(pot.eligible_player_ids) == 1:
            winners = pot.eligible_player_ids
            payouts = distribute_pot(pot, list(winners), order_from_button)
            pot_outcomes.append(PotOutcome(pot=pot, winners=winners, payouts=payouts))
            for pid, amount in payouts.items():
                total_payouts[pid] += amount
            continue

        missing = [pid for pid in pot.eligible_player_ids if pid not in high_hand_results]
        if missing:
            raise ShowdownError(f"Missing high_hand_results for contested pot eligible players: {missing}")

        best_high = max(high_hand_results[pid] for pid in pot.eligible_player_ids)
        high_winners = [pid for pid in pot.eligible_player_ids if high_hand_results[pid] == best_high]

        qualifying_low_ids = [
            pid
            for pid in pot.eligible_player_ids
            if low_hand_results.get(pid) is not None and low_hand_results[pid].qualifies_for_low
        ]

        if not qualifying_low_ids:
            payouts = distribute_pot(pot, high_winners, order_from_button)
            winners = tuple(high_winners)
        else:
            best_low_key = min(low_hand_results[pid].rank_key for pid in qualifying_low_ids)
            low_winners = [pid for pid in qualifying_low_ids if low_hand_results[pid].rank_key == best_low_key]

            high_half_amount = (pot.amount + 1) // 2  # odd chip goes to the high half
            low_half_amount = pot.amount - high_half_amount
            high_payouts = distribute_pot(replace(pot, amount=high_half_amount), high_winners, order_from_button)
            low_payouts = distribute_pot(replace(pot, amount=low_half_amount), low_winners, order_from_button)

            payouts = defaultdict(int)
            for pid, amount in high_payouts.items():
                payouts[pid] += amount
            for pid, amount in low_payouts.items():
                payouts[pid] += amount
            payouts = dict(payouts)
            winners = tuple(sorted(set(high_winners) | set(low_winners)))

        pot_outcomes.append(PotOutcome(pot=pot, winners=winners, payouts=payouts))
        for pid, amount in payouts.items():
            total_payouts[pid] += amount

    return HandOutcome(pot_outcomes=tuple(pot_outcomes), total_payouts=dict(total_payouts))
