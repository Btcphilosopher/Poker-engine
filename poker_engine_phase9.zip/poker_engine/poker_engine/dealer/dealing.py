"""
Dealer — dealing mechanics.

These are deliberately low-level, variant-agnostic building blocks. Which
streets get dealt, how many hole cards, whether a street is up or down —
that's variant logic (Phase 4-6). This module just knows how to move cards
from a Deck to players correctly, the way a real dealer's hands would.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence

from poker_engine.betting.round import BettingRound
from poker_engine.cards.card import Card
from poker_engine.deck.deck import Deck


class DealingError(Exception):
    pass


def deal_hole_cards(deck: Deck, player_order: Sequence[str], num_cards: int) -> Dict[str, List[Card]]:
    """
    Deal `num_cards` to each player in round-robin order (one card to each
    player, repeated), matching how a real dealer deals — not all of one
    player's cards before moving to the next.
    """
    if not player_order:
        raise DealingError("player_order must not be empty")
    if num_cards < 0:
        raise ValueError("num_cards cannot be negative")

    hands: Dict[str, List[Card]] = {pid: [] for pid in player_order}
    for _ in range(num_cards):
        for pid in player_order:
            hands[pid].append(deck.deal_one())
    return hands


@dataclass(frozen=True, slots=True)
class CommunityDeal:
    burned: List[Card]
    cards: List[Card]


def deal_community_cards(deck: Deck, count: int, *, burn: bool = True) -> CommunityDeal:
    """Deal `count` community cards (flop=3, turn/river=1), burning one card first by default."""
    if count <= 0:
        raise ValueError("count must be positive")
    burned = deck.burn(1) if burn else []
    cards = deck.deal(count)
    return CommunityDeal(burned=burned, cards=cards)


@dataclass(frozen=True, slots=True)
class StudStreetDeal:
    burned: List[Card]
    cards: Dict[str, Card]
    face_up: bool


def deal_stud_street(
    deck: Deck, player_order: Sequence[str], *, face_up: bool, burn: bool = True
) -> StudStreetDeal:
    """Deal one card to each player (up or down), in round-robin order, optionally burning first."""
    if not player_order:
        raise DealingError("player_order must not be empty")
    burned = deck.burn(1) if burn else []
    cards = {pid: deck.deal_one() for pid in player_order}
    return StudStreetDeal(burned=burned, cards=cards, face_up=face_up)


def draw_replacement_cards(deck: Deck, num_discarded: int) -> List[Card]:
    """
    Deal replacement cards for a draw round. Callers are responsible for
    tracking/discarding the player's original cards themselves — this just
    hands out the replacements from the deck.
    """
    if num_discarded < 0:
        raise ValueError("num_discarded cannot be negative")
    return deck.deal(num_discarded)


def advance_to_next_street(round_: BettingRound) -> int:
    """
    Capture the completed street's total pot and reset every player's
    `street_contributed` for the next street, as one atomic operation.

    This exists to prevent a specific footgun: `BettingRound.total_pot()`
    is a LIVE computation over each player's `street_contributed`, not a
    snapshot. Calling `player.start_new_street()` on everyone (which any
    dealer loop must do between streets) BEFORE reading `total_pot()`
    silently zeroes out what you were about to carry forward — the pot
    just vanishes with no error. Always call this instead of doing the two
    steps by hand.
    """
    carried_pot = round_.total_pot()
    for player in round_.players:
        player.start_new_street()
    return carried_pot
