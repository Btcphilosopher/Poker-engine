"""
Multi-table balancing.

Standard tournament-software behaviour: keep every table's active player
count within one of every other table's, and "break" (dissolve) a table
once its players could all be redistributed onto the remaining tables
without exceeding anyone's seat count — the classic "we're down to 3
tables, let's consolidate to 2" moment.

These functions are pure planners: they compute what moves *should* happen
but don't mutate any Table themselves. The caller applies each SeatMove via
`Table.stand_up` / `Table.sit_down` (and should do so with the actual chip
stack carried over, not a fresh buy-in).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

from poker_engine.tables.table import Table


class BalancingError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class SeatMove:
    player_id: str
    from_table_id: str
    to_table_id: str


def balance_tables(tables: Sequence[Table]) -> List[SeatMove]:
    """
    Compute the moves needed so no two tables' active player counts differ
    by more than one. Always moves from the fullest table to the emptiest
    table with room, one player at a time, until balanced.
    """
    if len(tables) < 2:
        return []

    by_id: Dict[str, Table] = {}
    for t in tables:
        if t.table_id in by_id:
            raise BalancingError(f"Duplicate table_id: {t.table_id}")
        by_id[t.table_id] = t

    counts = {tid: len(t.active_player_ids()) for tid, t in by_id.items()}
    # Which of each table's active players remain candidates to move,
    # tracked separately from Table's own state (we never mutate it here).
    remaining_movable = {tid: list(t.active_player_ids()) for tid, t in by_id.items()}

    moves: List[SeatMove] = []
    while True:
        fullest_id = max(counts, key=lambda tid: counts[tid])
        emptiest_id = min(counts, key=lambda tid: counts[tid])
        if counts[fullest_id] - counts[emptiest_id] <= 1:
            break
        if fullest_id == emptiest_id:
            break
        if counts[emptiest_id] >= by_id[emptiest_id].max_seats:
            raise BalancingError(
                f"Cannot balance: table {emptiest_id} is full but still has fewer players"
            )
        if not remaining_movable[fullest_id]:
            raise BalancingError(f"Table {fullest_id} has no movable players left")

        player_id = remaining_movable[fullest_id].pop()
        moves.append(SeatMove(player_id=player_id, from_table_id=fullest_id, to_table_id=emptiest_id))
        counts[fullest_id] -= 1
        counts[emptiest_id] += 1

    return moves


def find_table_to_break(tables: Sequence[Table]) -> Optional[Table]:
    """
    If every player currently at the smallest table could be reseated onto
    the OTHER tables without exceeding any of their max_seats, return that
    smallest table (the standard "break the short table" candidate).
    Otherwise return None.
    """
    if len(tables) < 2:
        return None

    smallest = min(tables, key=lambda t: len(t.active_player_ids()))
    others = [t for t in tables if t.table_id != smallest.table_id]

    displaced = len(smallest.active_player_ids())
    capacity_elsewhere = sum(t.max_seats - len(t.active_player_ids()) for t in others)

    if displaced <= capacity_elsewhere:
        return smallest
    return None


def plan_table_break(broken: Table, others: Sequence[Table]) -> List[SeatMove]:
    """
    Distribute every active player from `broken` across `others` as evenly
    as possible, respecting each destination's max_seats. Does not move
    anyone off of `others` — only ever fills their empty seats.
    """
    if not others:
        raise BalancingError("Need at least one other table to break into")

    by_id: Dict[str, Table] = {t.table_id: t for t in others}
    counts = {tid: len(t.active_player_ids()) for tid, t in by_id.items()}
    capacities = {tid: t.max_seats for tid, t in by_id.items()}

    moves: List[SeatMove] = []
    for player_id in broken.active_player_ids():
        candidates = [tid for tid in counts if counts[tid] < capacities[tid]]
        if not candidates:
            raise BalancingError("Not enough seats across the other tables to break this table")
        destination = min(candidates, key=lambda tid: counts[tid])
        moves.append(SeatMove(player_id=player_id, from_table_id=broken.table_id, to_table_id=destination))
        counts[destination] += 1

    return moves


def apply_seat_move(move: SeatMove, tables_by_id: Dict[str, Table]) -> None:
    """
    Convenience helper: actually perform one SeatMove against real Table
    objects, carrying the player's current chip stack across (a table move
    is not a new buy-in).
    """
    source = tables_by_id[move.from_table_id]
    destination = tables_by_id[move.to_table_id]
    player = source.stand_up(move.player_id)
    destination.sit_down(player.player_id, player.display_name, player.stack)
