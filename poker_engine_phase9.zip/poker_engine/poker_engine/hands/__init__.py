"""
hands — not yet implemented, and possibly not needed as originally scoped.

Originally planned (Phase 1's scaffold) to hold "per-hand orchestration
objects tying deck+evaluation+betting together for a single hand" — but by
Phase 5, that turned out to live naturally in poker_engine.variants instead
(FlopGame and its subclasses ARE the per-hand orchestration objects). This
module may end up housing something narrower for Stud/Draw-specific needs
in Phase 6, or may be retired entirely if variants/ continues to cover it.
Left scaffolded rather than deleted until Phase 6 clarifies which way it
goes.
"""
