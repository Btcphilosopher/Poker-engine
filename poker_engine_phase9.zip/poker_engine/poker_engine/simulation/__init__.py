"""
simulation — not yet implemented.

Phase 10 — Monte Carlo equity calculator, range vs range, multi-threaded execution.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
