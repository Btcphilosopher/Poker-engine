"""
Deck management.

Supports:
  - Standard 52-card deck
  - Short deck ("6+" hold'em) — ranks 6..A, 36 cards
  - Multi-deck support (deck_count) for future variants that need it
  - Three shuffle strategies:
      * secure   — os.urandom-backed CSPRNG (secrets), for real-money play
      * seeded   — deterministic, reproducible given a seed (testing / replay)
      * standard — fast, non-cryptographic (Monte Carlo simulation loops)
  - Fast reset (rebuild + reshuffle without reallocating card objects)
"""

from __future__ import annotations

import random
import secrets
from typing import List, Optional

from poker_engine.cards.card import Card, Rank, Suit


class DeckExhaustedError(Exception):
    """Raised when a deal or burn is requested but the deck has no cards left."""


class Deck:
    """A physical deck of cards: draw pile + discard/burn pile."""

    SHORT_DECK_MIN_RANK = Rank.SIX

    def __init__(self, *, short_deck: bool = False, deck_count: int = 1) -> None:
        if deck_count < 1:
            raise ValueError("deck_count must be >= 1")
        self.short_deck = short_deck
        self.deck_count = deck_count
        self._master: List[Card] = self._build_master()
        self._draw_pile: List[Card] = list(self._master)
        self._burned: List[Card] = []
        self._dealt: List[Card] = []

    def _build_master(self) -> List[Card]:
        ranks = [r for r in Rank if (not self.short_deck or r >= self.SHORT_DECK_MIN_RANK)]
        one_deck = [Card(rank=r, suit=s) for r in ranks for s in Suit]
        return one_deck * self.deck_count

    # -- shuffling -----------------------------------------------------

    def shuffle(self, *, seed: Optional[int] = None, secure: bool = False) -> None:
        """
        Shuffle the current draw pile in place.

        - secure=True uses a CSPRNG (secrets) Fisher-Yates shuffle; ignores `seed`.
        - seed is not None => deterministic shuffle via random.Random(seed).
        - otherwise => fast, non-deterministic shuffle via random.shuffle.
        """
        if secure:
            self._secure_shuffle(self._draw_pile)
            return
        rng = random.Random(seed) if seed is not None else random.Random()
        rng.shuffle(self._draw_pile)

    @staticmethod
    def _secure_shuffle(cards: List[Card]) -> None:
        """Cryptographically secure Fisher-Yates shuffle using secrets.randbelow."""
        for i in range(len(cards) - 1, 0, -1):
            j = secrets.randbelow(i + 1)
            cards[i], cards[j] = cards[j], cards[i]

    # -- dealing ---------------------------------------------------------

    def deal(self, n: int = 1) -> List[Card]:
        if n < 0:
            raise ValueError("n must be >= 0")
        if n > len(self._draw_pile):
            raise DeckExhaustedError(
                f"Cannot deal {n} card(s); only {len(self._draw_pile)} remain."
            )
        dealt = self._draw_pile[:n]
        del self._draw_pile[:n]
        self._dealt.extend(dealt)
        return dealt

    def deal_one(self) -> Card:
        return self.deal(1)[0]

    def burn(self, n: int = 1) -> List[Card]:
        if n > len(self._draw_pile):
            raise DeckExhaustedError(
                f"Cannot burn {n} card(s); only {len(self._draw_pile)} remain."
            )
        burned = self._draw_pile[:n]
        del self._draw_pile[:n]
        self._burned.extend(burned)
        return burned

    # -- lifecycle ---------------------------------------------------------

    def replenish(self, cards: List[Card], *, seed: Optional[int] = None, secure: bool = False) -> None:
        """
        Return previously-dealt cards to the draw pile and reshuffle them
        in. Used when a game needs more cards than currently remain — e.g.
        multi-round Draw poker with several players discarding heavily
        across multiple draws can genuinely exhaust a 52-card deck. The
        standard house rule is to shuffle earlier discards back in rather
        than ending the hand early; callers are responsible for only ever
        passing cards that are safe to reuse (e.g. discards from a
        COMPLETED prior round, never the round currently being dealt).
        """
        self._draw_pile.extend(cards)
        self.shuffle(seed=seed, secure=secure)

    def reset(self) -> None:
        """Return every card (drawn, burned) to the draw pile, unshuffled."""
        self._draw_pile = list(self._master)
        self._burned.clear()
        self._dealt.clear()

    def cards_remaining(self) -> int:
        return len(self._draw_pile)

    def __len__(self) -> int:
        return len(self._draw_pile)

    @property
    def total_cards(self) -> int:
        return len(self._master)

    @property
    def burned_cards(self) -> List[Card]:
        return list(self._burned)

    @property
    def dealt_cards(self) -> List[Card]:
        return list(self._dealt)

    def peek_draw_pile(self) -> List[Card]:
        """For tests/debugging only — inspect remaining order without mutating."""
        return list(self._draw_pile)
