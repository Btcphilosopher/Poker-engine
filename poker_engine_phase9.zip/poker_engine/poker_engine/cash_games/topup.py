"""
Auto top-up.

A cash-game convenience: if a player's stack falls to or below a
threshold between hands, automatically bring it back up to a target level
rather than requiring them to notice and manually top up. This engine has
no wallet/bankroll system (chip amounts are abstract throughout, the same
way tournament buy-ins are — see Tournament's docs), so this only ever
adds chips directly via `Table.top_up`; where those chips "come from" in
a real-money deployment is a payments-layer concern outside this engine's
scope.
"""

from __future__ import annotations

from dataclasses import dataclass

from poker_engine.tables.table import Table, TableError


class AutoTopUpError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class AutoTopUpPolicy:
    threshold: int  # top up when stack falls to or below this
    target: int  # top up TO this amount (still capped by the table's max_buyin, via Table.top_up)

    def __post_init__(self) -> None:
        if self.threshold < 0:
            raise AutoTopUpError("threshold cannot be negative")
        if self.target <= self.threshold:
            raise AutoTopUpError("target must be greater than threshold")


def apply_auto_topup(table: Table, policy: AutoTopUpPolicy, player_id: str) -> int:
    """
    Top up `player_id` to `policy.target` if their stack is at or below
    `policy.threshold`. Returns the amount actually added (0 if no top-up
    was needed, or if the table's max_buyin left no room to add anything).
    Intended to be called between hands, like `Table.settle_hand()`.
    """
    player = table.find_player(player_id)
    if player is None:
        raise TableError(f"{player_id} is not seated at this table")
    if player.stack > policy.threshold:
        return 0
    needed = policy.target - player.stack
    if needed <= 0:
        return 0
    return table.top_up(player_id, needed)
