"""
Seat reservations.

Holds a seat for a player who's registered/reserved but hasn't sat down
yet, preventing others from taking it until the reservation is fulfilled
or expires. Expiry is expressed in HAND COUNTS, not wall-clock time — this
engine has no internal timer anywhere (see TournamentClock's identical
choice in Phase 8); a real deployment ties expiry to its own scheduler or
to the hand counter it's already tracking.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

from poker_engine.players.player import Player
from poker_engine.tables.table import Table


class SeatReservationError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class SeatReservation:
    player_id: str
    display_name: str
    seat_index: int
    expires_at_hand: int


class SeatReservationManager:
    def __init__(self) -> None:
        self._reservations: Dict[int, SeatReservation] = {}  # seat_index -> reservation

    def reserve(
        self,
        table: Table,
        player_id: str,
        display_name: str,
        seat_index: int,
        *,
        expires_after_hands: int,
        current_hand_count: int,
    ) -> SeatReservation:
        if not (0 <= seat_index < table.max_seats):
            raise SeatReservationError(f"Seat index {seat_index} out of range")
        if table.seats[seat_index] is not None:
            raise SeatReservationError(f"Seat {seat_index} is already occupied")
        if seat_index in self._reservations:
            raise SeatReservationError(f"Seat {seat_index} is already reserved")
        if expires_after_hands < 1:
            raise SeatReservationError("expires_after_hands must be at least 1")

        reservation = SeatReservation(
            player_id=player_id,
            display_name=display_name,
            seat_index=seat_index,
            expires_at_hand=current_hand_count + expires_after_hands,
        )
        self._reservations[seat_index] = reservation
        return reservation

    def is_reserved(self, seat_index: int) -> bool:
        return seat_index in self._reservations

    def reservation_at(self, seat_index: int) -> Optional[SeatReservation]:
        return self._reservations.get(seat_index)

    def available_seats(self, table: Table) -> List[int]:
        """Empty seat indices that are NOT held by a reservation."""
        return [i for i in table.empty_seat_indices() if i not in self._reservations]

    def fulfil(self, table: Table, seat_index: int, buyin: int) -> Player:
        """Seat the reserved player (they showed up), consuming the reservation."""
        reservation = self._reservations.get(seat_index)
        if reservation is None:
            raise SeatReservationError(f"No reservation at seat {seat_index}")
        player = table.sit_down(reservation.player_id, reservation.display_name, buyin, seat_index=seat_index)
        del self._reservations[seat_index]
        return player

    def cancel(self, seat_index: int) -> None:
        if seat_index not in self._reservations:
            raise SeatReservationError(f"No reservation at seat {seat_index}")
        del self._reservations[seat_index]

    def expire_stale(self, current_hand_count: int) -> List[SeatReservation]:
        """Remove and return every reservation whose expiry has passed."""
        expired = [r for r in self._reservations.values() if current_hand_count >= r.expires_at_hand]
        for r in expired:
            del self._reservations[r.seat_index]
        return expired
