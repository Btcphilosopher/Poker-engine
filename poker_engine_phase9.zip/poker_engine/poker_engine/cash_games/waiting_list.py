"""FIFO waiting list for a full cash-game table."""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple


class WaitingListError(Exception):
    pass


class WaitingList:
    """
    Tracks players waiting for a seat, in join order, along with the
    buy-in each one intends to bring — so when a seat opens up, they're
    seated with their own requested amount, not an arbitrary default.
    """

    def __init__(self) -> None:
        self._queue: List[str] = []
        self._entries: Dict[str, Tuple[str, int]] = {}  # player_id -> (display_name, buyin)

    def add(self, player_id: str, display_name: str, buyin: int) -> int:
        """Add to the list; returns the player's 1-indexed position."""
        if player_id in self._entries:
            raise WaitingListError(f"{player_id} is already on the waiting list")
        if buyin <= 0:
            raise WaitingListError("buyin must be positive")
        self._queue.append(player_id)
        self._entries[player_id] = (display_name, buyin)
        return len(self._queue)

    def remove(self, player_id: str) -> None:
        if player_id not in self._entries:
            raise WaitingListError(f"{player_id} is not on the waiting list")
        self._queue.remove(player_id)
        del self._entries[player_id]

    def position(self, player_id: str) -> int:
        """1-indexed position on the list."""
        if player_id not in self._entries:
            raise WaitingListError(f"{player_id} is not on the waiting list")
        return self._queue.index(player_id) + 1

    def peek_next(self) -> Optional[Tuple[str, str, int]]:
        """(player_id, display_name, buyin) of whoever's next, without removing them."""
        if not self._queue:
            return None
        pid = self._queue[0]
        name, buyin = self._entries[pid]
        return pid, name, buyin

    def pop_next(self) -> Optional[Tuple[str, str, int]]:
        """Remove and return whoever's next — call once they're actually seated."""
        if not self._queue:
            return None
        pid = self._queue.pop(0)
        name, buyin = self._entries.pop(pid)
        return pid, name, buyin

    def __len__(self) -> int:
        return len(self._queue)

    @property
    def is_empty(self) -> bool:
        return not self._queue

    @property
    def player_ids(self) -> List[str]:
        return list(self._queue)
