"""
CashGame — the top-level orchestrator for an ongoing ring game at one
table, playing the role Tournament (Phase 8) plays for tournaments.

Explicitly does NOT play hands itself, for the same reason Tournament
doesn't: the caller drives each hand through whatever Game class the
table's variant uses (TexasHoldem, a MixedGameRotation, etc.). CashGame
tracks what's specific to a ring game rather than a tournament: players
can join and leave freely at any time (no elimination tracking — busting
out just means leaving, or topping back up), a waiting list for when the
table is full, optional seat reservations, and optional automatic
top-ups.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from poker_engine.cash_games.seat_reservation import SeatReservation, SeatReservationManager
from poker_engine.cash_games.topup import AutoTopUpPolicy, apply_auto_topup
from poker_engine.cash_games.waiting_list import WaitingList
from poker_engine.players.player import Player
from poker_engine.tables.table import Table


class CashGameError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class CashGameConfig:
    min_buyin: int
    max_buyin: int
    max_seats: int = 9
    seat_reservation_hands: int = 0  # 0 = reservations disabled by default
    auto_topup_policy: Optional[AutoTopUpPolicy] = None

    def __post_init__(self) -> None:
        if self.min_buyin <= 0:
            raise CashGameError("min_buyin must be positive")
        if self.max_buyin < self.min_buyin:
            raise CashGameError("max_buyin cannot be less than min_buyin")
        if self.max_seats < 2:
            raise CashGameError("max_seats must be at least 2")
        if self.seat_reservation_hands < 0:
            raise CashGameError("seat_reservation_hands cannot be negative")


class CashGame:
    def __init__(self, config: CashGameConfig, table_id: str = "cash-table") -> None:
        self.config = config
        self.table = Table(
            table_id=table_id, max_seats=config.max_seats, min_buyin=config.min_buyin, max_buyin=config.max_buyin
        )
        self.waiting_list = WaitingList()
        self.reservations = SeatReservationManager()
        self._hand_count = 0

    @property
    def hand_count(self) -> int:
        return self._hand_count

    # -- joining / leaving ----------------------------------------------------------

    def join(self, player_id: str, display_name: str, buyin: int) -> Optional[Player]:
        """
        Seat the player immediately if a seat is free (and not reserved
        for someone else); otherwise add them to the waiting list and
        return None.
        """
        available = self.reservations.available_seats(self.table)
        if not available:
            self.waiting_list.add(player_id, display_name, buyin)
            return None
        return self.table.sit_down(player_id, display_name, buyin, seat_index=available[0])

    def leave(self, player_id: str) -> Player:
        """Stand a player up and immediately try to seat whoever's next on the waiting list."""
        player = self.table.stand_up(player_id)
        self._seat_next_waiting_player()
        return player

    def _seat_next_waiting_player(self) -> Optional[Player]:
        available = self.reservations.available_seats(self.table)
        if not available or self.waiting_list.is_empty:
            return None
        entry = self.waiting_list.pop_next()
        assert entry is not None
        player_id, display_name, buyin = entry
        return self.table.sit_down(player_id, display_name, buyin, seat_index=available[0])

    # -- seat reservations ----------------------------------------------------------

    def reserve_seat(self, player_id: str, display_name: str, *, seat_index: Optional[int] = None) -> SeatReservation:
        if self.config.seat_reservation_hands <= 0:
            raise CashGameError("This cash game does not offer seat reservations")
        available = self.reservations.available_seats(self.table)
        if seat_index is None:
            if not available:
                raise CashGameError("No seats available to reserve")
            seat_index = available[0]
        return self.reservations.reserve(
            self.table,
            player_id,
            display_name,
            seat_index,
            expires_after_hands=self.config.seat_reservation_hands,
            current_hand_count=self._hand_count,
        )

    def fulfil_reservation(self, seat_index: int, buyin: int) -> Player:
        return self.reservations.fulfil(self.table, seat_index, buyin)

    # -- buy-ins / top-ups ----------------------------------------------------------

    def rebuy(self, player_id: str, amount: int) -> int:
        """Add more chips to an already-seated player — a voluntary cash-game re-buy."""
        return self.table.top_up(player_id, amount)

    def apply_auto_topups(self) -> None:
        """Apply the configured auto top-up policy (if any) to every seated player. Call between hands."""
        if self.config.auto_topup_policy is None:
            return
        for player in self.table.occupied_seats():
            apply_auto_topup(self.table, self.config.auto_topup_policy, player.player_id)

    # -- lifecycle ----------------------------------------------------------

    def between_hands(self) -> None:
        """
        Call once after settling a hand, before starting the next one:
        advances the hand counter, expires stale seat reservations, and
        applies any configured auto top-ups.
        """
        self._hand_count += 1
        self.reservations.expire_stale(self._hand_count)
        self.apply_auto_topups()
