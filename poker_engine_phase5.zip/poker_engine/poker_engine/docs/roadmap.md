# Roadmap

Status legend: ✅ done · 🔜 next · ⬜ not started

| Phase | Scope | Status |
|---|---|---|
| 1 | **Foundation** — cards, deck, hand evaluation (5-card, best-of-N, Omaha, Ace-to-5 low) | ✅ |
| 2 | **Betting engine** — blinds, antes, bring-in, pot manager with side pots, limit/pot-limit/no-limit raise rules, all-in handling | ✅ |
| 3 | **Dealer + table management** — shuffle/deal orchestration, street progression, pot distribution, table balancing | ✅ |
| 4 | **Texas Hold'em (NL / Limit / Pot-Limit) end-to-end** — first fully playable variant | ✅ |
| 5 | **Other flop games** — Omaha, Omaha Hi-Lo, Short Deck (6+), Pineapple, Crazy Pineapple, Irish | ✅ |
| 6 | Stud games (7-Stud, Stud Hi-Lo, Razz) + Draw games (5-Card Draw, 2-7 Triple Draw, Badugi) | 🔜 |
| 7 | Mixed games — HORSE rotation, general mixed-game framework | ⬜ |
| 8 | Tournament engine — SNG, freezeout, rebuy, KO/PKO, satellite, MTT, blind/break schedules, prize calculation, table balancing/merging | ⬜ |
| 9 | Cash games — ring games, buy-ins, seat reservations, waiting lists, auto top-up, table limits | ⬜ |
| 10 | AI framework (rule-based styles, Monte Carlo AI, CFR/NN interfaces) + Monte Carlo simulation engine (equity, range vs range, multi-threaded) | ⬜ |
| 11 | Statistics engine (VPIP/PFR/3-bet/aggression/BB-100/ROI/...) + hand history export + replay engine | ⬜ |
| 12 | Networking layer + REST API + WebSocket architecture | ⬜ |
| 13 | Hardening — full-suite coverage push, Docker, CI/CD, complete developer/API docs | ⬜ |

## Phase 1 deliverables

- `poker_engine/cards/` — `Card`, `Rank`, `Suit`
- `poker_engine/deck/` — `Deck` (standard/short/multi-deck, 3 shuffle modes)
- `poker_engine/evaluation/` — `evaluate_5`, `evaluate_best_of`,
  `evaluate_omaha`, `evaluate_low_5`, `evaluate_low_best_of`,
  `evaluate_omaha_low`, plus a throughput benchmark script
- 79 tests (unit + edge-case + property-based), 97% coverage
- Full package scaffold for every module named in the original spec, each
  stub documenting which phase will implement it

## Phase 2 deliverables

- `poker_engine/betting/structures.py` — `BettingStructure` (NL/PL/FL),
  `BlindLevel`
- `poker_engine/betting/actions.py` — `ActionType`, `Action` (hand-history
  log entry)
- `poker_engine/betting/player_state.py` — `PlayerBettingState`
- `poker_engine/betting/pot.py` — `compute_pots` (main + side pots via
  contribution layering), `distribute_pot` (split-pot chip division with
  the standard odd-chip-to-first-winner-left-of-button rule)
- `poker_engine/betting/round.py` — `BettingRound`, the core street state
  machine: turn order, legal-action computation, minimum-raise tracking,
  the "incomplete all-in raise doesn't reopen action" rule, pot-limit
  sizing, fixed-limit exact-size + raise-cap enforcement
- `poker_engine/betting/blinds.py` — blind/ante/bring-in/dead-blind
  posting, blind assignment (incl. heads-up), stud bring-in determination
- `poker_engine/betting/button.py` — dealer button rotation across seats
  (skipping empty seats)
- 105 new tests (unit, edge-case, property-based via Hypothesis, and a
  full multi-street integration test), bringing the suite to 184 tests /
  95%+ overall coverage

Real bugs caught and fixed during Phase 2's own test-writing (see
architecture.md for details): a short-stacked player could incorrectly be
offered "raise" for less than the current bet; a pot-limit sizing fallback
could balloon the legal max bet to a player's entire stack in a degenerate
zero-pot edge case.

## Phase 3 deliverables

- `poker_engine/players/player.py` — `Player` (persistent, across-hands
  state: name, seat, status, stack) and `PlayerStatus`, distinct from
  `PlayerBettingState` (ephemeral, per-hand)
- `poker_engine/tables/table.py` — `Table`: seating, buy-in range
  enforcement, dealer button rotation, and correct pre-flop/post-flop
  action-order derivation (including 3-handed and heads-up special cases)
- `poker_engine/tables/balancing.py` — `balance_tables` (keep multi-table
  player counts within one of each other), `find_table_to_break` /
  `plan_table_break` (standard tournament table consolidation)
- `poker_engine/dealer/dealing.py` — `deal_hole_cards` (round-robin),
  `deal_community_cards` (flop/turn/river with burns), `deal_stud_street`,
  `draw_replacement_cards`, and `advance_to_next_street` (see the footgun
  it prevents, below)
- `poker_engine/dealer/showdown.py` — `resolve_showdown` (pots → winners →
  payouts, single-ranking games), `determine_reveal_order`,
  `last_aggressor_of`
- 80 new tests (unit, edge-case, property-based, and a full end-to-end
  hand played through the real public API from seating to settlement),
  bringing the suite to 264 tests / 96% overall coverage

A real bug was caught while building Phase 3's own integration test: a
scratch script called `player.start_new_street()` (resetting
`street_contributed`) *before* reading `BettingRound.total_pot()` to carry
forward as the next street's pot — silently zeroing the carried pot with
no error, because `total_pot()` is a live computation over mutable state,
not a snapshot. Fixed at the API level with `advance_to_next_street()`,
which captures the pot and resets state as one atomic operation, so this
mistake isn't available to make. See architecture.md for the full story.

## Phase 4 deliverables

- `poker_engine/variants/base_game.py` — `BaseGame` (ABC every variant
  implements: `start_hand`, `legal_actions`, `apply_action`,
  `current_player`, `is_hand_complete`, `outcome`), `Street` enum for
  flop-based games
- `poker_engine/variants/texas_holdem.py` — `TexasHoldem`, one class
  parametrized by `BettingStructure` covering all three required variants
  (NL / Limit / Pot-Limit Hold'em). Fully self-contained state machine:
  blinds/antes → deal → four betting rounds with automatic street
  progression → automatic "run it out" when everyone's all-in →
  automatic uncontested-pot detection when folds leave one player →
  showdown → settlement
- 25 unit/edge-case tests plus property-based tests driving 300+
  fully-randomized complete games (every structure, 2-6 players, uneven
  stacks, heads-up) through the real public API, all verified to
  terminate and conserve chips exactly
- 292 tests total, 96% overall coverage

Phase 4 is where the "only one live player left -> end the hand
immediately" rule that Phase 3 explicitly deferred (see
`BettingRound.is_betting_complete()`'s docstring) finally gets
implemented, in `TexasHoldem._advance_if_needed()` — it's checked before
every other street-advancement logic, exactly as promised.

## Phase 5 deliverables

- `poker_engine/variants/flop_game.py` — `FlopGame`, extracted from Phase
  4's `TexasHoldem` once there were enough concrete variants to generalize
  from correctly. Every flop-based variant is now mostly class-attribute
  configuration (`HOLE_CARDS_DEALT`, `HOLE_CARDS_FINAL`,
  `DISCARD_AFTER_STREET`, `SHORT_DECK`, `EVALUATION_MODE`) rather than
  reimplemented street-progression logic. Also adds a full discard-phase
  mechanic (`discard()`, `awaiting_discard`) for the Pineapple family,
  including correctly pausing mid-"run it out" when an all-in happens
  before a pending discard.
- `poker_engine/variants/texas_holdem.py` — refactored to a 2-line
  `FlopGame` subclass with zero behaviour change (verified: all 292
  pre-existing tests pass unchanged).
- `poker_engine/variants/omaha.py` — `Omaha` (4 hole cards, exactly-2+3
  evaluation) and `OmahaHiLo` (same, pot split between qualifying high
  and low via the new `resolve_showdown_hi_lo`).
- `poker_engine/variants/short_deck_holdem.py` — `ShortDeckHoldem` (36-card
  deck, flush beats full house).
- `poker_engine/variants/pineapple.py` — `Pineapple`, `CrazyPineapple`,
  `Irish` (3 or 4 hole cards, discard down to 2 at different points,
  standard Hold'em evaluation once discarded).
- `poker_engine/evaluation/short_deck.py` — `short_deck_sort_key`,
  `evaluate_best_of_short_deck` (swaps flush/full-house ranking; see
  architecture.md for why this can never matter for a single player's own
  best-hand selection with exactly 7 cards, only for comparing between
  players).
- `poker_engine/dealer/showdown.py` — `resolve_showdown` gained an
  optional `key` parameter (Short Deck's hook); `resolve_showdown_hi_lo`
  is new (Omaha Hi-Lo's pot-splitting, with the standard "odd chip to the
  high half" rule) — this is the Hi-Lo capability Phase 3 and 4 both
  deliberately deferred until there was a concrete consumer to design it
  against.
- 52 new tests (unit, edge-case, and property-based — ~440 randomized full
  games across all 7 flop-based variants, every structure, random discard
  choices), bringing the suite to 344 tests / 97% overall coverage

## Notes for the next session

- Phase 6 (Stud + Draw games) is next, and is a bigger architectural step
  than Phase 5 was: Stud has no button/blinds at all (bring-in from the
  lowest/highest up-card instead — already built in
  `poker_engine.betting.blinds.determine_bring_in`), fixed betting order
  determined by up-cards each street rather than a static rotation, and up
  to 5 betting rounds (3rd through 7th street) instead of 4. Draw games
  need the discard mechanic FlopGame just gained, but for a full-hand
  redraw rather than a one-time narrowing, and have no community cards at
  all. Both are different enough from FlopGame that they'll likely need
  their own base class (`StudGame`?) rather than forcing them into
  FlopGame's shape — the same "wait for 2-3 concrete examples before
  extracting the abstraction" discipline that produced FlopGame itself
  applies here too: build Stud and one Draw variant concretely first, see
  what's actually shared, then decide.
- Badugi and 2-7 Triple Draw's evaluators (deferred all the way back in
  Phase 1) are needed for Phase 6 and should be built then, now that
  there's a concrete variant driving their exact requirements.
- The short-deck ranking mechanism (`key` parameter on `resolve_showdown`)
  turned out to be a clean, minimally-invasive extension point — worth
  remembering as the pattern if Stud/Draw variants ever need their own
  alternate rankings (e.g. 2-7 lowball's "aces high, straights/flushes
  count against you" ordering, still deferred from Phase 1).
