# Poker Engine

A production-grade, multi-variant poker engine core, built in phases. This
repository currently contains **Phase 1: Foundation** — the card engine and
hand evaluator that every later phase (betting, variants, tournaments, AI,
simulation, API) will build on.

See [`docs/roadmap.md`](docs/roadmap.md) for the full 13-phase build plan and
current status, and [`docs/architecture.md`](docs/architecture.md) for design
notes on what's implemented so far.

## What's implemented (Phase 1)

- **Cards** (`poker_engine.cards`) — immutable `Card`, `Rank`, `Suit`, with
  string parsing/formatting (`Card.from_str("Ah")`, `str(card)`).
- **Deck** (`poker_engine.deck`) — standard 52-card and short (6+) 36-card
  decks, multi-deck support, three shuffle strategies (secure/CSPRNG, seeded/
  deterministic, standard), deal, burn, reset.
- **Evaluation** (`poker_engine.evaluation`) — full 5-card hand evaluation
  (all 9 categories, complete tie-breaking), best-of-N (7-card hold'em/stud),
  Omaha-restricted evaluation (exactly 2 hole + 3 board), and Ace-to-5 low
  evaluation (Razz / Hi-Lo split, with configurable qualifier).

79 tests, 97% coverage on implemented modules (unit, edge-case, and
property-based via Hypothesis). See `tests/`.

## Quickstart

```bash
pip install -e ".[dev]"
pytest
```

```python
from poker_engine.cards import Card
from poker_engine.deck import Deck
from poker_engine.evaluation import evaluate_5, evaluate_best_of, evaluate_omaha

# Deal a hand
deck = Deck()
deck.shuffle(seed=42)  # deterministic, for reproducible tests/replays
hand = deck.deal(5)

result = evaluate_5(hand)
print(result)  # e.g. "Pair [Kc Kd 9h 4s 2c]"

# 7-card (hold'em / stud): best 5 of 7
seven_cards = [Card.from_str(c) for c in "Ac Ad Kh Qd 9c Th 2s".split()]
print(evaluate_best_of(seven_cards))

# Omaha: exactly 2 hole + 3 board, never more or fewer of either
hole = [Card.from_str(c) for c in "Ac 9c 2h 3s".split()]
board = [Card.from_str(c) for c in "Kc Qc 4c 8d 2d".split()]
print(evaluate_omaha(hole, board))
```

## Benchmark

```bash
python3 -m poker_engine.evaluation.benchmark
```

Current throughput (single-threaded, no lookup-table optimisation yet):
~100K hands/sec for `evaluate_5`, ~5K hands/sec for `evaluate_best_of` on
7 cards (brute-force over the 21 five-card combinations). A perfect-hash
lookup table is planned as a hardening pass — see the roadmap.

## Project layout

```
poker_engine/
    cards/        implemented — Card, Rank, Suit
    deck/         implemented — Deck
    evaluation/   implemented — evaluators + benchmark
    betting/      scaffolded — Phase 2
    players/      scaffolded — Phase 2-3
    dealer/       scaffolded — Phase 3
    tables/       scaffolded — Phase 3, 9
    hands/        scaffolded — Phase 4-6
    variants/     scaffolded — Phase 4-6
    tournaments/  scaffolded — Phase 8
    ai/           scaffolded — Phase 10
    simulation/   scaffolded — Phase 10
    statistics/   scaffolded — Phase 11
    network/      scaffolded — Phase 12
    api/          scaffolded — Phase 12
tests/
```

Every scaffolded module has a docstring in its `__init__.py` naming which
phase will fill it in.
