# Roadmap

Status legend: ✅ done · 🔜 next · ⬜ not started

| Phase | Scope | Status |
|---|---|---|
| 1 | **Foundation** — cards, deck, hand evaluation (5-card, best-of-N, Omaha, Ace-to-5 low) | ✅ |
| 2 | Betting engine — blinds, antes, bring-in, pot manager with side pots, limit/pot-limit/no-limit raise rules, all-in handling | 🔜 |
| 3 | Dealer + table management — shuffle/deal orchestration, street progression, pot distribution, table balancing | ⬜ |
| 4 | Texas Hold'em (NL / Limit / Pot-Limit) end-to-end — first fully playable variant | ⬜ |
| 5 | Other flop games — Omaha, Omaha Hi-Lo, Short Deck (6+), Pineapple, Crazy Pineapple, Irish | ⬜ |
| 6 | Stud games (7-Stud, Stud Hi-Lo, Razz) + Draw games (5-Card Draw, 2-7 Triple Draw, Badugi) | ⬜ |
| 7 | Mixed games — HORSE rotation, general mixed-game framework | ⬜ |
| 8 | Tournament engine — SNG, freezeout, rebuy, KO/PKO, satellite, MTT, blind/break schedules, prize calculation, table balancing/merging | ⬜ |
| 9 | Cash games — ring games, buy-ins, seat reservations, waiting lists, auto top-up, table limits | ⬜ |
| 10 | AI framework (rule-based styles, Monte Carlo AI, CFR/NN interfaces) + Monte Carlo simulation engine (equity, range vs range, multi-threaded) | ⬜ |
| 11 | Statistics engine (VPIP/PFR/3-bet/aggression/BB-100/ROI/...) + hand history export + replay engine | ⬜ |
| 12 | Networking layer + REST API + WebSocket architecture | ⬜ |
| 13 | Hardening — full-suite coverage push, Docker, CI/CD, complete developer/API docs | ⬜ |

## Phase 1 deliverables (this pass)

- `poker_engine/cards/` — `Card`, `Rank`, `Suit`
- `poker_engine/deck/` — `Deck` (standard/short/multi-deck, 3 shuffle modes)
- `poker_engine/evaluation/` — `evaluate_5`, `evaluate_best_of`,
  `evaluate_omaha`, `evaluate_low_5`, `evaluate_low_best_of`,
  `evaluate_omaha_low`, plus a throughput benchmark script
- 79 tests (unit + edge-case + property-based), 97% coverage
- Full package scaffold for every module named in the original spec, each
  stub documenting which phase will implement it

## Notes for the next session

- Phase 2 (betting) is the natural next step: it only depends on Phase 1's
  `Card`/`Deck`, not on any variant rules, and every later phase needs it.
- The 7-card evaluator's lookup-table optimisation (see architecture.md) is
  intentionally deferred rather than done now, so it can be benchmarked
  against real gameplay load once Phase 4 exists, instead of against a
  synthetic microbenchmark.
