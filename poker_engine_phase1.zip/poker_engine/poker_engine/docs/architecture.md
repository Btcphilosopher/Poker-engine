# Architecture — Phase 1 (Foundation)

## Design principles carried through from here on

- **Immutability where it's free.** `Card` is a frozen, slotted dataclass —
  hashable, safe to share across threads, cheap to compare. This matters
  later for the multi-threaded Monte Carlo engine (Phase 10), which will
  pass cards between worker threads without locking.
- **Rank values ARE poker values.** `Rank.ACE.value == 14`. Evaluation code
  never needs a translation table between "what the enum says" and "what the
  hand ranking needs" — that's a common source of off-by-one bugs in poker
  engines and it's designed out from the start.
- **Comparison keys, not comparison functions.** Both `HandResult` and
  `LowHandResult` reduce to a plain tuple (`sort_key` / `rank_key`) such that
  Python's built-in tuple comparison produces the correct poker ranking.
  This means `max()`, `sorted()`, `min()` and the `<`/`>` operators all just
  work, including across combinatorial search (`evaluate_best_of`).
- **Display values and comparison keys are kept separate.** `LowHandResult`
  had a real bug caught during Phase 1 testing: the internal comparison key
  for Ace-to-5 low hands (which must be shape-prefixed — see below) is *not*
  the same as the actual card ranks you'd want to show a user. The dataclass
  now carries both `values` (display) and `rank_key` (comparison) explicitly
  rather than overloading one field for both purposes.

## Hand evaluation algorithm

`evaluate_5` classifies a 5-card hand by:
1. Sorting ranks descending and counting duplicates (`Counter`).
2. Checking flush (all one suit) and straight (5 consecutive distinct ranks,
   with the wheel A-2-3-4-5 as a special case where the Ace plays low).
3. Mapping the rank-count "pattern" (e.g. `(4,1)`, `(3,2)`, `(2,2,1)`) plus
   the flush/straight flags to one of the 9 `HandCategory` values.
4. Building an ordered tiebreaker tuple specific to that category (e.g. for
   two pair: `(high_pair, low_pair, kicker)`), so any two hands of the same
   category compare correctly including full kicker resolution.

`evaluate_best_of` (7-card hold'em/stud) and `evaluate_omaha` (Omaha's
"exactly 2 hole + 3 board" restriction) are built on top of `evaluate_5` via
`itertools.combinations` — correct by construction, since they're just
"evaluate every legal 5-card hand and take the best." This is the right
starting point for correctness; see the roadmap for the planned lookup-table
optimisation once the full rule engine depends on this API and a stable
before/after benchmark is meaningful.

## Ace-to-5 low evaluation

This is the one place in Phase 1 where the "obvious" implementation is
actually wrong, and it's worth documenting why.

A tempting shortcut for low-hand comparison is: sort each hand's ace-low
values descending, then compare the two tuples lexicographically (lower
tuple wins). This is correct for *unpaired* hands, but breaks the moment a
pair is involved:

```
7-5-4-3-2 (no pair)  vs  6-6-4-3-2 (pair of sixes)
```

Naive lexicographic comparison checks the highest card first (7 vs 6) and
would call the paired 6-6-4-3-2 hand better — which is wrong. In real
Ace-to-5 low (used by Razz, and for resolving the low side of Hi-Lo split
pots when a qualifier is disabled), **hand shape dominates first**, exactly
like a standard high hand: five-distinct-ranks beats one-pair beats two-pair
beats trips beats full house beats quads, *regardless* of what the actual
ranks are. Only within the same shape do lower ranks win.

`_low_sort_key` builds a `(shape_rank, *ordered_ranks)` tuple that encodes
this correctly, and `LowHandResult.rank_key` is what all comparisons go
through. `LowHandResult.values` is a separate, plain-English field (actual
ace-low ranks, sorted descending) kept purely for display and hand-history
export.

## What's deliberately not here yet

- **Badugi evaluation** — structurally different (suit-uniqueness based
  rather than rank-counting) and belongs with the Draw-games phase where
  it'll be built alongside the game rules that actually use it.
- **2-7 (Deuce-to-Seven) lowball** — straights/flushes count *against* the
  hand and Ace plays high-only, the opposite of Ace-to-5. Deferred to the
  Triple Draw implementation.
- **Lookup-table hand evaluation** — the current combinatorial approach is
  correct and already fast enough for turn-based gameplay (~100K hands/sec
  for `evaluate_5`); a perfect-hash table is planned once the full rule
  engine exists and Monte Carlo simulation volume actually demands it.
