"""
betting — not yet implemented.

Phase 2 — blinds/antes/bring-in, pot manager with side-pot splitting, limit/pot-limit/no-limit raise rules, all-in handling.

This module is scaffolded now so the package layout matches the full
architecture from the start; it will be filled in during its listed phase.
"""
