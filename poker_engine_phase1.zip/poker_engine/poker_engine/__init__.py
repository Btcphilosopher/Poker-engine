"""
poker_engine — a production-grade, multi-variant poker engine.

Phase 1 (Foundation) is implemented: cards, deck, and hand evaluation.
See docs/roadmap.md for the full build plan and current status.
"""

from poker_engine.cards import Card, Rank, Suit
from poker_engine.deck import Deck, DeckExhaustedError
from poker_engine.evaluation import (
    HandCategory,
    HandResult,
    LowHandResult,
    evaluate_5,
    evaluate_best_of,
    evaluate_omaha,
    evaluate_low_5,
    evaluate_low_best_of,
    evaluate_omaha_low,
)

__version__ = "0.1.0"

__all__ = [
    "Card",
    "Rank",
    "Suit",
    "Deck",
    "DeckExhaustedError",
    "HandCategory",
    "HandResult",
    "LowHandResult",
    "evaluate_5",
    "evaluate_best_of",
    "evaluate_omaha",
    "evaluate_low_5",
    "evaluate_low_best_of",
    "evaluate_omaha_low",
]
