# Poker Engine

A production-grade, multi-variant poker engine core, built in phases. This
repository currently contains **Phases 1-10**: Foundation, Betting Engine,
Dealer + Table Management, Texas Hold'em, Other Flop Games, Stud + Draw
Games, Badugi + Mixed Games, the Tournament Engine, Cash Games, and the AI
Framework + Monte Carlo Simulation Engine — **thirteen fully playable
variants**, a mixed-game rotation framework, full tournament orchestration,
ongoing ring-game sessions, eight pluggable AI archetypes (including
CFR-ready and neural-network-ready extension points), and a Monte Carlo
equity calculator with multi-threaded execution.

See [`docs/roadmap.md`](docs/roadmap.md) for the full 13-phase build plan and
current status, and [`docs/architecture.md`](docs/architecture.md) for design
notes — including real bugs caught and fixed during each phase's own
test-writing, documented in detail because they're instructive.

## What's implemented

**Phase 1 — Foundation**
- **Cards** (`poker_engine.cards`) — immutable `Card`, `Rank`, `Suit`, with
  string parsing/formatting (`Card.from_str("Ah")`, `str(card)`).
- **Deck** (`poker_engine.deck`) — standard 52-card and short (6+) 36-card
  decks, multi-deck support, three shuffle strategies (secure/CSPRNG, seeded/
  deterministic, standard), deal, burn, reset.
- **Evaluation** (`poker_engine.evaluation`) — full 5-card hand evaluation
  (all 9 categories, complete tie-breaking), best-of-N (7-card hold'em/stud),
  Omaha-restricted evaluation (exactly 2 hole + 3 board), and Ace-to-5 low
  evaluation (Razz / Hi-Lo split, with configurable qualifier).

**Phase 2 — Betting Engine**
- **`BettingRound`** (`poker_engine.betting`) — the core street state
  machine: turn order, legal-action computation, correct minimum-raise
  tracking (including the "incomplete all-in raise doesn't reopen the
  action" rule), pot-limit sizing, fixed-limit exact sizing + raise cap,
  all-in handling.
- **Pots** — `compute_pots` builds main + side pots from contributions
  (handles any number of simultaneous all-ins at different stack depths);
  `distribute_pot` splits a pot evenly with the standard odd-chip rule.
- **Forced bets** — blinds, antes, bring-in, dead blinds, blind assignment
  (including heads-up), stud bring-in determination (low or high card).
- **Button** — dealer button rotation across seats, skipping empty ones.

**Phase 3 — Dealer + Table Management**
- **`Player`** (`poker_engine.players`) — persistent, across-hands player
  state (name, seat, status, stack), separate from the ephemeral
  per-hand `PlayerBettingState`.
- **`Table`** (`poker_engine.tables`) — seating, buy-in range enforcement,
  dealer button rotation, and correct pre-flop/post-flop action-order
  derivation for any table size, including heads-up and 3-handed.
- **Table balancing** — `balance_tables` keeps multi-table player counts
  within one of each other; `find_table_to_break`/`plan_table_break`
  handle standard tournament table consolidation.
- **Dealing** (`poker_engine.dealer`) — round-robin hole cards, community
  cards with burns, stud streets, draw replacements.
- **Showdown** — `resolve_showdown` ties pot computation to hand evaluation
  to determine winners and payouts; `determine_reveal_order` and
  `last_aggressor_of` for showdown procedure.

**Phase 4 — Texas Hold'em (first playable variant)**
- **`FlopGame`** (`poker_engine.variants`) — the shared street-progression
  state machine behind every community-card variant: deal → betting rounds
  with automatic street progression → automatic "run it out" when
  everyone's all-in → automatic uncontested-pot handling → showdown →
  settlement.
- **`TexasHoldem`** — No-Limit, Limit, and Pot-Limit, one class
  parametrized by `BettingStructure`.
- **`BaseGame`** — the ABC every variant implements.

**Phase 5 — Other Flop Games**
- **`Omaha`** / **`OmahaHiLo`** — 4 hole cards, exactly-2-hole+3-board
  evaluation; Hi-Lo splits each pot between qualifying high and low via the
  new `resolve_showdown_hi_lo`.
- **`ShortDeckHoldem`** — 36-card deck, flush ranks above full house
  (`poker_engine.evaluation.short_deck`).
- **`Pineapple`** / **`CrazyPineapple`** / **`Irish`** — extra hole cards
  dealt, discarded down to 2 mid-hand via `FlopGame`'s new `discard()`
  phase (correctly handles discarding even when everyone's already gone
  all-in and the board is being run out automatically).

All seven variants share the same `FlopGame` machinery — each one is
mostly a handful of class attributes rather than reimplemented logic;
`TexasHoldem` itself is now a 2-line subclass.

**Phase 6 — Stud + Draw Games**
- **`SevenCardStud`** / **`StudHiLo`** / **`Razz`** (`poker_engine.variants`)
  — antes + bring-in instead of blinds, action order recalculated fresh
  each street from exposed up-cards, 5 betting rounds (3rd-7th street).
  `StudHiLo` reuses `resolve_showdown_hi_lo` directly; `Razz` flips both
  bring-in and action-order direction via a single `LOWBALL` flag.
- **`FiveCardDraw`** / **`TripleDraw`** — discard-and-redraw rounds instead
  of community cards, reusing `FlopGame`'s blind/button machinery.
  `TripleDraw` uses 2-7 lowball ranking (`poker_engine.evaluation.
  deuce_to_seven`, deferred since Phase 1: Ace plays high only, straights
  and flushes count against the hand).
- **`Deck.replenish()`** — reshuffles previously-discarded cards back into
  the draw pile when a Draw game genuinely runs the 52-card deck dry
  (a real scenario with several players discarding heavily, not a
  contrived one — see architecture.md).

**Phase 7 — Badugi + Mixed Games**
- **`Badugi`** (`poker_engine.variants`) — 4 hole cards, 3 draw rounds,
  ranked by `poker_engine.evaluation.badugi` (deferred since Phase 1: best
  qualifying 4-card subset with no duplicate rank or suit, Ace low only).
  The fourth concrete `DrawGame` example, requiring zero changes to
  `DrawGame` itself beyond one new evaluation-mode branch.
- **`MixedGameRotation`** / **`RotationLeg`** / **`horse_rotation()`** — a
  general framework for cycling through variants across many hands at one
  table (the classic HORSE rotation built from it as a convenience
  factory). Each hand is still a fresh Game instance; the rotation just
  knows which class and stakes object go with each leg, and fixes a real
  fairness gap (see architecture.md) where Stud legs don't self-advance
  the table's dealer button.

**Phase 8 — Tournament Engine**
- **`Tournament`** (`poker_engine.tournaments`) — the top-level
  orchestrator above the Table/Player/Game layer: registration, seating
  across possibly-many tables, elimination tracking, table rebalancing
  (finally gives `poker_engine.tables.balancing`, built in Phase 3, a real
  caller), and prize payouts. One configuration-driven class covers every
  tournament type in the spec — Freezeout (default), Rebuy, Knockout/PKO,
  Satellite, Sit & Go, and Multi-table — rather than a class per type,
  since none of those turn out to differ algorithmically (see
  architecture.md).
- **`BlindSchedule`** / **`TournamentClock`** — explicit level progression
  (no internal timer, matching this engine's "caller drives every
  multi-step process" pattern throughout).
- **`payouts.py`** — configurable top-heavy payout curves and flat
  satellite splits.
- **`BountyConfig`** / **`BountyTracker`** — Knockout and Progressive
  Knockout, including compounding bounty growth across eliminations.
- **`RebuyPolicy`** / **`RebuyTracker`** — rebuys (with a level-index
  window) and add-ons.

**Phase 9 — Cash Games**
- **`CashGame`** (`poker_engine.cash_games`) — the ongoing-ring-game
  counterpart to `Tournament`: join/leave freely, no elimination
  tracking, an auto-seating **`WaitingList`** for when the table is full,
  optional **`SeatReservationManager`** (hand-count-based expiry, no
  wall-clock timer), and an optional **`AutoTopUpPolicy`** that brings a
  stack back up automatically between hands.
- **`Table.top_up()`** — new: adding chips to an already-seated player,
  capped by `max_buyin` without ever clawing back winnings above it.

**Phase 10 — AI Framework + Monte Carlo Simulation**
- **`poker_engine.simulation`** — `calculate_equity` (win/tie/lose
  probabilities via Monte Carlo simulation, specific hands or full
  `HandRange`s, multi-threaded via `concurrent.futures` with a swappable
  executor for genuine parallelism), `hand_strength_vs_random`,
  `pot_odds` / `expected_value_of_call` / `expected_value_of_bet`.
- **`poker_engine.ai`** — the pluggable `AIPlayer` interface
  (`choose_action(state) -> AIDecision`) and eight archetypes:
  `RandomPlayer`, `CallingStation`, `TightPassive`, `LoosePassive`,
  `TightAggressive`, `LooseAggressive` (fast heuristic-driven),
  `TournamentAI` / `CashGameAI` (stack-pressure-aware profiles), and
  `MonteCarloAI` (decides from real simulated equity). Plus two
  pluggable extension points built to prove "future reinforcement
  learning plugs in without rewriting the engine": **`PolicyTableAI`**
  (CFR-shaped — samples from an externally supplied probability
  distribution) and **`CallableModelAI`** (NN-shaped — wraps any
  `features -> scores` predict function).
- **`FlopGame.pot_size` / `StudGame.pot_size` / `DrawGame.pot_size`** —
  new: needed by the AI layer to see the pot, didn't exist before.

786 tests total, 98%+ coverage (unit, edge-case, property-based via
Hypothesis, and — the strongest signal of correctness — well over 1,000
fully-randomized complete games across all thirteen variants, randomized
full tournaments, randomized cash-game sessions, and randomized AI
archetype matchups across every variant family, all reconciling money
exactly). See `tests/`.

## Quickstart

```bash
pip install -e ".[dev]"
pytest
```

```python
from poker_engine.betting import ActionType, BettingStructure, BlindLevel
from poker_engine.deck import Deck
from poker_engine.tables import Table
from poker_engine.variants import TexasHoldem

# Seat players at a table
table = Table(table_id="main", max_seats=6)
table.sit_down("alice", "Alice", 1000, seat_index=0)
table.sit_down("bob", "Bob", 1000, seat_index=1)
table.sit_down("carol", "Carol", 1000, seat_index=2)

# Play one complete hand
deck = Deck()
deck.shuffle(seed=42)  # deterministic, for reproducible tests/replays
game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20), deck=deck)
game.start_hand()

while not game.is_hand_complete:
    pid = game.current_player
    legal = game.legal_actions(pid)
    action = ActionType.CHECK if legal.can_check else ActionType.CALL
    game.apply_action(pid, action)

print(game.outcome)   # pots, winners, payouts
game.settle()          # apply results back to each Player's persistent stack
```

See `tests/test_variants_texas_holdem.py` and
`tests/test_dealer_integration.py` for the same flow with real betting
(raises, all-ins, side pots) instead of check/call.

Every other variant uses the exact same API — just swap the class:

```python
from poker_engine.variants import Omaha, OmahaHiLo, ShortDeckHoldem, Pineapple

game = Omaha(table, BettingStructure.POT_LIMIT, BlindLevel(small_blind=10, big_blind=20))
game.start_hand()  # 4 hole cards dealt automatically; everything else identical

# Discard-based variants (Pineapple, CrazyPineapple, Irish) pause for a
# discard phase mid-hand:
game = Pineapple(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
game.start_hand()
# ... bet preflop as normal ...
while game.awaiting_discard:
    pid = game.current_player
    game.discard(pid, keep=game.hole_cards[pid][:2])  # choose which 2 of 3 to keep
# ... continue betting as normal ...
```

Stud games use antes + bring-in (`StudStakes`) instead of blinds, and have
no button:

```python
from poker_engine.betting.structures import StudStakes
from poker_engine.variants import SevenCardStud, Razz, StudHiLo

stakes = StudStakes(ante=1, bring_in=3, small_bet=10, big_bet=20)
game = SevenCardStud(table, BettingStructure.FIXED_LIMIT, stakes)
game.start_hand()  # 2 down + 1 up dealt; bring-in posted automatically
```

Draw games use blinds like Hold'em, but pause for a discard-and-redraw
round instead of dealing a board:

```python
from poker_engine.variants import FiveCardDraw, TripleDraw

game = FiveCardDraw(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
game.start_hand()
# ... bet as normal until game.awaiting_draw ...
while game.awaiting_draw:
    pid = game.current_player
    game.draw(pid, discard=game.hole_cards[pid][:2])  # discard 0-5 cards, replacements dealt automatically
```

Mixed-game rotations (like HORSE) cycle through variants across many
hands at one table:

```python
from poker_engine.variants import MixedGameRotation, horse_rotation

rotation = MixedGameRotation(table, horse_rotation(blind_level, stud_stakes, hands_per_leg=8))
game = rotation.start_next_hand()   # constructs the current leg's Game class
# ... play the hand to completion as usual ...
game.settle()
rotation.advance()                  # moves to the next hand, rotating legs as needed
```

A `Tournament` sits above all of this — registration, seating across
possibly-many tables, elimination, table rebalancing, and payouts — while
you still drive each hand through whatever Game class the tournament uses,
exactly as shown above:

```python
from poker_engine.tournaments import BlindSchedule, Tournament, TournamentConfig

schedule = BlindSchedule.standard_flop_schedule(starting_small_blind=10, num_levels=20, break_every=4)
config = TournamentConfig(buy_in=100, starting_stack=1500, blind_schedule=schedule, max_players_per_table=9)
t = Tournament(config)
for player_id in ["alice", "bob", "carol"]:
    t.register(player_id, player_id)
t.start()  # seats everyone into tables

while not t.is_finished:
    for table in list(t.tables):
        if table.occupied_count() < 2:
            continue
        game = TexasHoldem(table, BettingStructure.NO_LIMIT, t.clock.current_level.stakes)
        game.start_hand()
        # ... play the hand ...
        game.settle()
        for busted_id in t.busted_player_ids(table):
            t.eliminate(table, busted_id)
    t.rebalance_tables()   # breaks/merges tables as the field shrinks
    t.clock.advance_level()

payouts = t.finalize()  # {player_id: prize_amount}, sums to t.prize_pool exactly
```

A `CashGame` is the ring-game counterpart — no elimination, players join
and leave freely, with a waiting list and optional seat reservations for
when the table is full:

```python
from poker_engine.cash_games import AutoTopUpPolicy, CashGame, CashGameConfig

config = CashGameConfig(
    min_buyin=100, max_buyin=1000, max_seats=9,
    auto_topup_policy=AutoTopUpPolicy(threshold=100, target=1000),
)
cash_game = CashGame(config)
cash_game.join("alice", "Alice", 500)
cash_game.join("bob", "Bob", 500)
# ... table fills up; further joins queue on cash_game.waiting_list ...

game = TexasHoldem(cash_game.table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=1, big_blind=2))
game.start_hand()
# ... play the hand ...
game.settle()
cash_game.between_hands()  # expires stale reservations, applies auto top-ups

cash_game.leave("alice")  # frees the seat; next person on the waiting list is auto-seated
```

AI archetypes drive decisions through the same `legal_actions()` /
`apply_action()` contract a human UI would use — nothing below `AIPlayer`
needs to know or care who's deciding:

```python
from poker_engine.ai import build_game_state_view, TightAggressive, MonteCarloAI
from poker_engine.cards import Card, Rank, Suit

full_deck = [Card(r, s) for r in Rank for s in Suit]
ai_by_player = {"alice": TightAggressive(), "bob": MonteCarloAI(full_deck, num_simulations=500)}

game = TexasHoldem(table, BettingStructure.NO_LIMIT, BlindLevel(small_blind=10, big_blind=20))
game.start_hand()
while not game.is_hand_complete:
    pid = game.current_player
    state = build_game_state_view(game, pid)
    decision = ai_by_player[pid].choose_action(state)
    game.apply_action(pid, decision.action_type, decision.amount)
game.settle()
```

The Monte Carlo equity calculator can be used standalone too:

```python
from poker_engine.simulation import calculate_equity

aa = [Card.from_str("Ah"), Card.from_str("Ad")]
kk = [Card.from_str("Kh"), Card.from_str("Kd")]
remaining = [c for c in full_deck if c not in aa and c not in kk]
results = calculate_equity([aa, kk], [], remaining, num_simulations=20_000, num_workers=4)
print(results[0].equity)  # ~0.82
```

## Benchmark

```bash
python3 -m poker_engine.evaluation.benchmark
```

Current throughput (single-threaded, no lookup-table optimisation yet):
~100K hands/sec for `evaluate_5`, ~5K hands/sec for `evaluate_best_of` on
7 cards (brute-force over the 21 five-card combinations). A perfect-hash
lookup table is planned as a hardening pass — see the roadmap.

## Project layout

```
poker_engine/
    cards/        implemented — Card, Rank, Suit
    deck/         implemented — Deck
    evaluation/   implemented — evaluators + benchmark
    betting/      implemented — BettingRound, pots, blinds, button
    players/      implemented — Player, PlayerStatus
    tables/       implemented — Table, multi-table balancing
    dealer/       implemented — dealing mechanics, showdown resolution
    variants/     implemented — BaseGame, FlopGame, TexasHoldem, Omaha,
                                 OmahaHiLo, ShortDeckHoldem, Pineapple,
                                 CrazyPineapple, Irish, StudGame,
                                 SevenCardStud, StudHiLo, Razz, DrawGame,
                                 FiveCardDraw, TripleDraw, Badugi,
                                 MixedGameRotation, horse_rotation
    hands/        scaffolded — see hands/__init__.py; likely subsumed by variants/
    tournaments/  implemented — Tournament, BlindSchedule, payouts,
                                 bounties (KO/PKO), rebuys
    cash_games/   implemented — CashGame, WaitingList,
                                 SeatReservationManager, AutoTopUpPolicy
    ai/           implemented — AIPlayer, 8 archetypes, GameStateView,
                                 PolicyTableAI, CallableModelAI
    simulation/   implemented — calculate_equity, HandRange, EV/pot odds
    statistics/   scaffolded — Phase 11
    network/      scaffolded — Phase 12
    api/          scaffolded — Phase 12
tests/
```

Every scaffolded module has a docstring in its `__init__.py` naming which
phase will fill it in.
