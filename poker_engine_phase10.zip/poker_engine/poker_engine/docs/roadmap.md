# Roadmap

Status legend: ✅ done · 🔜 next · ⬜ not started

| Phase | Scope | Status |
|---|---|---|
| 1 | **Foundation** — cards, deck, hand evaluation (5-card, best-of-N, Omaha, Ace-to-5 low) | ✅ |
| 2 | **Betting engine** — blinds, antes, bring-in, pot manager with side pots, limit/pot-limit/no-limit raise rules, all-in handling | ✅ |
| 3 | **Dealer + table management** — shuffle/deal orchestration, street progression, pot distribution, table balancing | ✅ |
| 4 | **Texas Hold'em (NL / Limit / Pot-Limit) end-to-end** — first fully playable variant | ✅ |
| 5 | **Other flop games** — Omaha, Omaha Hi-Lo, Short Deck (6+), Pineapple, Crazy Pineapple, Irish | ✅ |
| 6 | **Stud games** (7-Stud, Stud Hi-Lo, Razz) **+ Draw games** (5-Card Draw, 2-7 Triple Draw) | ✅ |
| 7 | **Badugi + Mixed games** — HORSE rotation, general mixed-game framework | ✅ |
| 8 | **Tournament engine** — SNG, freezeout, rebuy, KO/PKO, satellite, MTT, blind/break schedules, prize calculation, table balancing/merging | ✅ |
| 9 | **Cash games** — ring games, buy-ins, seat reservations, waiting lists, auto top-up, table limits | ✅ |
| 10 | **AI framework** (rule-based styles, Monte Carlo AI, CFR/NN interfaces) **+ Monte Carlo simulation engine** (equity, range vs range, multi-threaded) | ✅ |
| 11 | Statistics engine (VPIP/PFR/3-bet/aggression/BB-100/ROI/...) + hand history export + replay engine | 🔜 |
| 12 | Networking layer + REST API + WebSocket architecture | ⬜ |
| 13 | Hardening — full-suite coverage push, Docker, CI/CD, complete developer/API docs | ⬜ |

## Phase 1 deliverables

- `poker_engine/cards/` — `Card`, `Rank`, `Suit`
- `poker_engine/deck/` — `Deck` (standard/short/multi-deck, 3 shuffle modes)
- `poker_engine/evaluation/` — `evaluate_5`, `evaluate_best_of`,
  `evaluate_omaha`, `evaluate_low_5`, `evaluate_low_best_of`,
  `evaluate_omaha_low`, plus a throughput benchmark script
- 79 tests (unit + edge-case + property-based), 97% coverage
- Full package scaffold for every module named in the original spec, each
  stub documenting which phase will implement it

## Phase 2 deliverables

- `poker_engine/betting/structures.py` — `BettingStructure` (NL/PL/FL),
  `BlindLevel`
- `poker_engine/betting/actions.py` — `ActionType`, `Action` (hand-history
  log entry)
- `poker_engine/betting/player_state.py` — `PlayerBettingState`
- `poker_engine/betting/pot.py` — `compute_pots` (main + side pots via
  contribution layering), `distribute_pot` (split-pot chip division with
  the standard odd-chip-to-first-winner-left-of-button rule)
- `poker_engine/betting/round.py` — `BettingRound`, the core street state
  machine: turn order, legal-action computation, minimum-raise tracking,
  the "incomplete all-in raise doesn't reopen action" rule, pot-limit
  sizing, fixed-limit exact-size + raise-cap enforcement
- `poker_engine/betting/blinds.py` — blind/ante/bring-in/dead-blind
  posting, blind assignment (incl. heads-up), stud bring-in determination
- `poker_engine/betting/button.py` — dealer button rotation across seats
  (skipping empty seats)
- 105 new tests (unit, edge-case, property-based via Hypothesis, and a
  full multi-street integration test), bringing the suite to 184 tests /
  95%+ overall coverage

Real bugs caught and fixed during Phase 2's own test-writing (see
architecture.md for details): a short-stacked player could incorrectly be
offered "raise" for less than the current bet; a pot-limit sizing fallback
could balloon the legal max bet to a player's entire stack in a degenerate
zero-pot edge case.

## Phase 3 deliverables

- `poker_engine/players/player.py` — `Player` (persistent, across-hands
  state: name, seat, status, stack) and `PlayerStatus`, distinct from
  `PlayerBettingState` (ephemeral, per-hand)
- `poker_engine/tables/table.py` — `Table`: seating, buy-in range
  enforcement, dealer button rotation, and correct pre-flop/post-flop
  action-order derivation (including 3-handed and heads-up special cases)
- `poker_engine/tables/balancing.py` — `balance_tables` (keep multi-table
  player counts within one of each other), `find_table_to_break` /
  `plan_table_break` (standard tournament table consolidation)
- `poker_engine/dealer/dealing.py` — `deal_hole_cards` (round-robin),
  `deal_community_cards` (flop/turn/river with burns), `deal_stud_street`,
  `draw_replacement_cards`, and `advance_to_next_street` (see the footgun
  it prevents, below)
- `poker_engine/dealer/showdown.py` — `resolve_showdown` (pots → winners →
  payouts, single-ranking games), `determine_reveal_order`,
  `last_aggressor_of`
- 80 new tests (unit, edge-case, property-based, and a full end-to-end
  hand played through the real public API from seating to settlement),
  bringing the suite to 264 tests / 96% overall coverage

A real bug was caught while building Phase 3's own integration test: a
scratch script called `player.start_new_street()` (resetting
`street_contributed`) *before* reading `BettingRound.total_pot()` to carry
forward as the next street's pot — silently zeroing the carried pot with
no error, because `total_pot()` is a live computation over mutable state,
not a snapshot. Fixed at the API level with `advance_to_next_street()`,
which captures the pot and resets state as one atomic operation, so this
mistake isn't available to make. See architecture.md for the full story.

## Phase 4 deliverables

- `poker_engine/variants/base_game.py` — `BaseGame` (ABC every variant
  implements: `start_hand`, `legal_actions`, `apply_action`,
  `current_player`, `is_hand_complete`, `outcome`), `Street` enum for
  flop-based games
- `poker_engine/variants/texas_holdem.py` — `TexasHoldem`, one class
  parametrized by `BettingStructure` covering all three required variants
  (NL / Limit / Pot-Limit Hold'em). Fully self-contained state machine:
  blinds/antes → deal → four betting rounds with automatic street
  progression → automatic "run it out" when everyone's all-in →
  automatic uncontested-pot detection when folds leave one player →
  showdown → settlement
- 25 unit/edge-case tests plus property-based tests driving 300+
  fully-randomized complete games (every structure, 2-6 players, uneven
  stacks, heads-up) through the real public API, all verified to
  terminate and conserve chips exactly
- 292 tests total, 96% overall coverage

Phase 4 is where the "only one live player left -> end the hand
immediately" rule that Phase 3 explicitly deferred (see
`BettingRound.is_betting_complete()`'s docstring) finally gets
implemented, in `TexasHoldem._advance_if_needed()` — it's checked before
every other street-advancement logic, exactly as promised.

## Phase 5 deliverables

- `poker_engine/variants/flop_game.py` — `FlopGame`, extracted from Phase
  4's `TexasHoldem` once there were enough concrete variants to generalize
  from correctly. Every flop-based variant is now mostly class-attribute
  configuration (`HOLE_CARDS_DEALT`, `HOLE_CARDS_FINAL`,
  `DISCARD_AFTER_STREET`, `SHORT_DECK`, `EVALUATION_MODE`) rather than
  reimplemented street-progression logic. Also adds a full discard-phase
  mechanic (`discard()`, `awaiting_discard`) for the Pineapple family,
  including correctly pausing mid-"run it out" when an all-in happens
  before a pending discard.
- `poker_engine/variants/texas_holdem.py` — refactored to a 2-line
  `FlopGame` subclass with zero behaviour change (verified: all 292
  pre-existing tests pass unchanged).
- `poker_engine/variants/omaha.py` — `Omaha` (4 hole cards, exactly-2+3
  evaluation) and `OmahaHiLo` (same, pot split between qualifying high
  and low via the new `resolve_showdown_hi_lo`).
- `poker_engine/variants/short_deck_holdem.py` — `ShortDeckHoldem` (36-card
  deck, flush beats full house).
- `poker_engine/variants/pineapple.py` — `Pineapple`, `CrazyPineapple`,
  `Irish` (3 or 4 hole cards, discard down to 2 at different points,
  standard Hold'em evaluation once discarded).
- `poker_engine/evaluation/short_deck.py` — `short_deck_sort_key`,
  `evaluate_best_of_short_deck` (swaps flush/full-house ranking; see
  architecture.md for why this can never matter for a single player's own
  best-hand selection with exactly 7 cards, only for comparing between
  players).
- `poker_engine/dealer/showdown.py` — `resolve_showdown` gained an
  optional `key` parameter (Short Deck's hook); `resolve_showdown_hi_lo`
  is new (Omaha Hi-Lo's pot-splitting, with the standard "odd chip to the
  high half" rule) — this is the Hi-Lo capability Phase 3 and 4 both
  deliberately deferred until there was a concrete consumer to design it
  against.
- 52 new tests (unit, edge-case, and property-based — ~440 randomized full
  games across all 7 flop-based variants, every structure, random discard
  choices), bringing the suite to 344 tests / 97% overall coverage

## Phase 6 deliverables

- `poker_engine/evaluation/deuce_to_seven.py` — 2-7 lowball evaluation,
  deferred since Phase 1. Reuses `evaluate_5` via a new `allow_wheel`
  parameter (default `True`, fully backward-compatible) rather than
  duplicating category-detection logic.
- `poker_engine/evaluation/exposed.py` — `best_exposed_player`,
  `exposed_hand_key`: determining Stud action order from partial up-cards,
  which is explicitly NOT a poker hand evaluation (no straights/flushes
  possible with 2-4 cards showing).
- `poker_engine/betting/structures.py` — `StudStakes` (ante/bring-in/
  small-bet/big-bet).
- `poker_engine/betting/round.py` — `BettingRound` gained an optional
  `min_bet_after_first_raise` parameter, built specifically for Stud's
  bring-in "completion" rule (a small forced bet that the next player can
  complete to a full bet, after which normal-sized raises resume) — see
  the bug story below.
- `poker_engine/variants/stud_game.py` — `StudGame`: antes + bring-in
  instead of blinds, action order recalculated fresh every street from
  exposed cards, 5 betting rounds (3rd-7th street).
- `poker_engine/variants/seven_card_stud.py` — `SevenCardStud`,
  `StudHiLo` (reuses `resolve_showdown_hi_lo` directly — no new pot logic
  needed), `Razz` (`LOWBALL=True` flips both bring-in and action-order
  direction).
- `poker_engine/variants/draw_game.py` — `DrawGame`: reuses FlopGame's
  blind/button machinery, but replaces community-card streets with
  discard-and-redraw rounds. Kept separate from `FlopGame` (different
  discard semantics: full redraw vs. one-time narrowing) and separate from
  `StudGame` (blinds vs. antes+bring-in) — three independent state
  machines under `BaseGame`, not a forced hierarchy.
- `poker_engine/variants/five_card_draw.py` — `FiveCardDraw`,
  `TripleDraw` (2-7 lowball, 3 draw rounds).
- `poker_engine/deck/deck.py` — `Deck.replenish()`, new: reshuffles
  previously-dealt cards back into the draw pile. Built to fix a real bug
  (below), not speculatively.
- 90 new tests (unit, edge-case, and property-based — ~600 additional
  randomized full games across all 5 new variants), bringing the suite to
  434 tests / 98% overall coverage

### Three real bugs caught during Phase 6

1. **Bring-in completion sizing.** Stud's bring-in "completion" (a player
   raising a small forced bet up to a full small-bet) doesn't fit standard
   raise math — completing to *exactly* small_bet is a smaller increment
   than the bring-in itself, but every raise *after* that must jump back
   to a full small-bet increment. Fixed via `min_bet_after_first_raise`.
   The first version of the fix only updated `BettingRound`'s internal
   bookkeeping (`last_raise_size`), which turned out to be necessary but
   not sufficient: `FIXED_LIMIT`'s `legal_actions()` computed its raise
   range directly from `self.min_bet`, completely bypassing that
   bookkeeping (fixed-limit raises are normally a constant size, so it
   never needed to consult it before). Caught by direct verification with
   exact expected numbers ($3 bring-in → completes to $10 → next raise to
   $20 → $30) before trusting the design, not by assuming the first fix
   was sufficient.
2. **Bring-in action order.** The first implementation put the bring-in
   poster FIRST in the next street's action order — but they already
   acted (via the forced bet); the player AFTER them should act first,
   with the bring-in poster acting LAST (mirroring how the big blind acts
   last pre-flop in flop games). Caught immediately by a test that simply
   tried to fold the first-to-act player and got "nothing to call,"
   because the engine had them facing their own bring-in.
3. **Deck exhaustion in Draw games.** Property testing found that several
   players discarding heavily across multiple rounds (or even within a
   single round, for 5-Card Draw specifically, which only gets one) can
   genuinely exhaust a 52-card deck — not a contrived case, a real
   consequence of "many players, aggressive discarding, one deck." Fixed
   with `Deck.replenish()`: reshuffle previously-discarded cards back into
   the draw pile rather than crashing the hand. The first version of this
   fix only reused discards from *completed* rounds (mirroring the live-
   casino convention of never reusing the current round's own discards, to
   avoid players seeing what was just mucked) — which fixed Triple Draw
   but couldn't help 5-Card Draw at all, since it only has one round and
   therefore no "completed" round to draw from. Simplified to reshuffle in
   *any* prior discard, including from earlier in the same round, once it
   was clear the live-casino protocol concern (players watching what gets
   mucked) doesn't apply to a headless rules engine — documented as a
   deliberate simplification, not an oversight.

## Phase 7 deliverables

- `poker_engine/evaluation/badugi.py` — Badugi evaluation, deferred since
  Phase 1: best-qualifying-subset search over a 4-card hand (no duplicate
  rank, no duplicate suit, Ace low only), with a `.sort_key` property
  deliberately shaped to match `HandResult`/`LowHandResult`'s convention
  — `resolve_showdown`'s *default* key function works on `BadugiResult`
  objects with no custom `key` override needed, purely because the
  attribute name and "higher = better" direction match.
- `poker_engine/variants/badugi.py` — `Badugi`, a `DrawGame` subclass
  (4 cards, 3 draw rounds, `EVALUATION_MODE="badugi"`) — the fourth
  concrete `DrawGame` example, and it required zero changes to `DrawGame`
  itself beyond the one new evaluation-mode branch, confirming the
  abstraction generalizes rather than just happening to fit three
  examples.
- `poker_engine/variants/mixed_games.py` — `RotationLeg`, `MixedGameRotation`
  (the general mixed-game framework), and `horse_rotation()` (the classic
  5-game HORSE cycle built from it). Each hand is still a fresh Game
  instance per the "one instance = one hand" pattern every variant
  already follows; the rotation just knows which class and stakes object
  go with each leg.
- 65 new tests (unit, edge-case, and property-based — including a
  12-hands-deep randomized rotation test that switches game types every
  hand while verifying chip conservation across the whole sequence),
  bringing the suite to 480 tests / 98% overall coverage

### The button-fairness bug in mixed rotations

`StudGame` deliberately never touches the table's dealer button (it's
irrelevant to Stud's own action order, which is recalculated from exposed
cards every street). That's correct in isolation, but surfaced a real gap
once hands from different variants share a table: `FlopGame`/`DrawGame`
subclasses already advance the button themselves in `start_hand()`, so
if `MixedGameRotation` did nothing extra, a player could sit on the button
through an entire run of Stud hands and *still* be on it when the rotation
returned to a blind-based game — several hands of unfair positioning
compressed into what should have been one button-move each. Fixed by
having `MixedGameRotation.start_next_hand()` advance the button itself,
but *only* when the upcoming leg is a `StudGame` subclass — advancing it
unconditionally would double-advance for every blind-based leg, which
already does it internally. Verified directly: button position must
differ before vs. after `start_next_hand()` even across two consecutive
Stud legs, where neither game class touches it on its own.

## Phase 8 deliverables

- `poker_engine/tournaments/blind_schedule.py` — `BlindSchedule`,
  `BlindScheduleLevel`, `TournamentClock` (explicit `advance_level()`,
  matching the "no internal timers, caller drives every multi-step
  process" pattern used everywhere else in this engine), plus a
  `standard_flop_schedule()` convenience builder.
- `poker_engine/tournaments/payouts.py` — `standard_paid_places`,
  `standard_payout_percentages` (a documented approximation, not a claim
  of matching any specific room's real table), `calculate_payouts`,
  `satellite_payouts` (flat split).
- `poker_engine/tournaments/bounties.py` — `BountyConfig`/`BountyTracker`
  for Knockout and Progressive Knockout, including compounding bounty
  growth across multiple eliminations.
- `poker_engine/tournaments/rebuys.py` — `RebuyPolicy`/`RebuyTracker` for
  rebuys (with a level-index cutoff window and optional max count) and
  add-ons.
- `poker_engine/tournaments/elimination.py` — `compute_finishing_positions`
  from a recorded elimination order.
- `poker_engine/tournaments/tournament.py` — `Tournament`, the top-level
  orchestrator: registration, seating across possibly-many tables,
  elimination, rebuy/bounty integration, table rebalancing (finally gives
  `poker_engine.tables.balancing`, built in Phase 3, a real caller), and
  `finalize()` payouts. Covers every tournament type from the spec as
  configuration on one class rather than separate classes: Freezeout is
  the default, Rebuy/KO/PKO/Satellite are opt-in config, SNG and MTT are
  just "how many players register before `start()`" and "how many tables
  that needs," not separate code paths.
- 124 new tests (unit, edge-case, property-based, and two full
  integration tests playing real hands via `TexasHoldem` across multiple
  tables down to a winner — one of them with real progressive-knockout
  bounty attribution), bringing the suite to 604 tests / 98% overall
  coverage.

### Three real bugs caught during Phase 8

1. **Prize pool used the wrong price for rebuys.** The first
   implementation computed `prize_pool = entry_count * buy_in` — correct
   only when every rebuy costs exactly the same as the original buy-in,
   which is a common but not universal convention (rebuy costs often
   differ from the initial buy-in in real tournaments). Fixed by tracking
   actual dollar contributions directly (`buy_in` on registration,
   `rebuy_cost`/`addon_cost` on rebuy/add-on) instead of deriving the pool
   from a simple count. Caught immediately by a smoke test using a
   deliberately different `rebuy_cost` from `buy_in` — a scenario the
   earlier, simpler tests hadn't exercised because they happened to use
   matching values.
2. **Satellites played down to a single winner** instead of stopping once
   exactly `num_seats` players remain — the standard real-world
   convention, since every seat is worth the same and there's no reason to
   keep playing once the field matches the number of prizes. Fixed by
   making `is_finished` satellite-aware and rewriting `finalize()` to
   handle a multi-survivor result (no single winner to rank finishing
   positions from; every remaining player splits the pool equally)
   instead of assuming exactly one winner always exists.
3. **The most significant bug of this phase**: property testing a
   long-running tournament (many hands, blinds growing every level)
   surfaced a genuine stuck-hand bug — late in a heads-up match, if the
   blinds have grown larger than BOTH remaining players' stacks, both
   players go all-in from posting forced blinds alone, before anyone ever
   gets a turn to act. `current_player` was `None` immediately after
   `start_hand()`, and since the "run it out when everyone's all-in" logic
   only ever runs from inside `apply_action()` (triggered *after* an
   action), nothing was left to ever trigger it — the hand simply never
   progressed. This wasn't found by any hand-picked test across four
   phases of variant-building, only by a property test that happened to
   run enough realistic hands, with growing blinds, for two short stacks
   to collide. Fixed identically in all three base game classes
   (`FlopGame`, `DrawGame`, `StudGame`): call the same advancement check
   once, unconditionally, at the end of `start_hand()`, immediately after
   the first betting round is constructed — safe in the normal case
   (nothing has happened yet, so the check is a no-op) and correct in the
   degenerate one (immediately runs the hand out to showdown). Every
   scenario this class of bug could hit — flop-game blinds, stud
   ante+bring-in, and (deterministically, not just via property search)
   dedicated regression tests were added for all three, not just the one
   the property test happened to find.

## Notes for the next session

- Phase 9 (Cash Games) is next: ring games, buy-in ranges (`Table`
  already enforces `min_buyin`/`max_buyin`, built in Phase 3 — this phase
  is more about the *policy* around it: waiting lists, seat reservations,
  auto top-up when a player's stack drops below some threshold), and
  table limits as an ongoing cash-game concept rather than a one-time
  tournament buy-in.
- The stuck-hand bug this phase found is worth remembering as a pattern,
  not just a fixed instance: "the advancement/completion check only runs
  after an action" is a natural way to write a turn-based state machine,
  and it's easy to forget that the FIRST decision point of a hand
  (whether anyone can act at all) needs the same check applied once
  before the first action, not only after every subsequent one. Any
  future phase that adds a new "hand start" path (Phase 9's cash-game
  auto-seating, perhaps) should check this explicitly rather than assume
  the existing games' coverage of it generalizes automatically.
- `Tournament` currently assumes a single poker variant per event.
  Wrapping a `MixedGameRotation` (Phase 7) as the thing a `Tournament`
  drives instead of a single `Game` class — for genuine HORSE
  tournaments, not just cash-game HORSE — is a natural, currently-unbuilt
  extension; nothing in this phase's design should conflict with it, but
  it hasn't been exercised together yet.

## Phase 9 deliverables

- `poker_engine/tables/table.py` — `Table.top_up()`, new: adding chips to
  an already-seated player (a cash-game re-buy, or an automatic top-up),
  capped by `max_buyin` without ever clawing back a stack that's grown
  past it from winnings.
- `poker_engine/cash_games/waiting_list.py` — `WaitingList`: FIFO queue
  that remembers each waiting player's own requested buy-in, so they're
  seated with the right amount whenever a seat opens, not a default.
- `poker_engine/cash_games/seat_reservation.py` — `SeatReservationManager`:
  holds a seat for a registered-but-not-yet-seated player, with
  hand-count-based expiry (no wall-clock timer, matching
  `TournamentClock`'s identical choice in Phase 8).
- `poker_engine/cash_games/topup.py` — `AutoTopUpPolicy` /
  `apply_auto_topup`: automatically bring a stack back up to a target
  level once it falls to or below a threshold, between hands.
- `poker_engine/cash_games/cash_game.py` — `CashGame`, the top-level
  orchestrator for an ongoing ring game, playing the role `Tournament`
  plays for tournaments: join/leave, the waiting list auto-seating
  whoever's next when a seat opens, seat reservations, rebuys, and
  `between_hands()` for the recurring bookkeeping (reservation expiry +
  auto top-ups). Deliberately kept as its own package (parallel to
  `tournaments/`) rather than folded into `tables/`, the same judgment
  call already made for `hands/` → `variants/` back in Phase 5: the
  original scaffold didn't have an exact slot for "cash game session
  orchestration" any more than it did for "per-hand orchestration
  objects," and forcing session-level logic into the same module as
  `Table`'s low-level seat mechanics would blur a distinction (data
  structure vs. orchestrator) this project has kept consistently
  everywhere else (`Table` vs. `Tournament`, `BettingRound` vs.
  `TexasHoldem`).
- 96 new tests (unit, edge-case, property-based, and three full
  integration tests playing real hands via `TexasHoldem` inside an
  ongoing session with realistic churn, seat-reservation expiry, and
  auto top-up), bringing the suite to 674 tests / 98% overall coverage.

### The top_up/rebuy reactivation bug

`Table.top_up()`'s first version added chips by setting `player.stack +=
amount` directly — correct arithmetic, but incomplete. `Player.
apply_hand_result()` (Phase 3) marks a player `ELIMINATED` the instant
their stack hits exactly 0, and `Player.rebuy()` (also Phase 3) already
knew to reactivate `ELIMINATED` back to `ACTIVE` when adding chips — but
`top_up()` didn't call `rebuy()`, it duplicated the "add chips" half of
what `rebuy()` does without the status-reactivation half. The result: a
player topped up after busting would sit at the table with a healthy
stack but a status still stuck on `ELIMINATED`, and since
`FlopGame.start_hand()` only ever looks at `is_active` players
(`status == ACTIVE and stack > 0`) when deciding who's dealt in, they'd be
silently skipped every hand thereafter — seated, funded, and invisible to
the game.

This wasn't caught by any of `top_up()`'s own unit tests, because none of
them constructed a player who'd actually been marked `ELIMINATED` first —
they all tested top-up arithmetic against players who were still `ACTIVE`
the whole time, which never exercises the reactivation path at all. It
took the `CashGame` integration test — real hands, real busts, real
top-ups, exactly the sequence that produces an `ELIMINATED` player with a
positive stack — to surface it. Fixed by having `top_up()` delegate to
`player.rebuy()` for the actual chip addition, rather than reimplementing
half of what `rebuy()` already did correctly. The general lesson (also
true of Phase 8's stuck-hand bug): a method that duplicates another
method's logic instead of calling it doesn't just risk drifting out of
sync once — it starts out already missing whatever the original method
did that the duplicate's author didn't think to re-derive.

## Phase 10 deliverables

- `poker_engine/simulation/ranges.py` — `HandRange`: a fixed hand or a
  full "any N cards" enumeration, the basis for range-vs-range equity.
- `poker_engine/simulation/equity.py` — `calculate_equity`: the Monte
  Carlo equity calculator, dealing out unknown board/hole cards many
  times and tallying win/tie shares. Multi-threaded via
  `concurrent.futures` (`num_workers` + a swappable `executor_factory`,
  default `ThreadPoolExecutor`); the worker function is a plain top-level
  function specifically so `ProcessPoolExecutor` also works, for genuine
  parallelism when the GIL matters. `hand_strength_vs_random` is the
  convenience wrapper the spec's "hand strength estimation" bullet maps
  to (a specific hand's equity against `HandRange.random`).
- `poker_engine/simulation/ev.py` — `pot_odds`, `expected_value_of_call`,
  `expected_value_of_bet`: the standard formulas, verified against exact
  known values (breakeven equity gives exactly 0 EV; a guaranteed-fold
  bluff wins exactly the pot).
- `Table.pot_size` → moved to `FlopGame.pot_size` / `StudGame.pot_size` /
  `DrawGame.pot_size` (new): reads live from the active `BettingRound`
  mid-hand, falls back to summing `total_contributed` once the round's
  gone (post-settle). Needed by the AI layer; didn't exist before this
  phase because nothing needed it yet.
- `poker_engine/ai/game_state.py` — `GameStateView` /
  `build_game_state_view`: the variant-agnostic snapshot every AI's
  `choose_action` receives, built by reading whichever attributes a given
  `BaseGame` subclass actually exposes rather than assuming one shape.
- `poker_engine/ai/hand_strength.py` — the FAST heuristic
  (`estimate_preflop_strength`, `estimate_made_hand_strength`), distinct
  from the Monte Carlo version in `simulation/equity.py`: the spec's
  simpler archetypes need microsecond decisions across thousands of
  hands, not a simulation per action.
- `poker_engine/ai/base_ai.py` — `AIPlayer` / `AIDecision`: the one-method
  interface (`choose_action(state) -> AIDecision`) every archetype in
  this phase, and any future one, implements.
- `poker_engine/ai/archetypes.py` — `RandomPlayer`, `CallingStation`,
  `TightPassive`, `LoosePassive`, `TightAggressive`, `LooseAggressive`:
  all driven by the heuristic hand-strength estimate, differing only in
  fold/raise thresholds and sizing. Behavioural differentiation verified
  directly (TightPassive folds at least as often as LoosePassive,
  LooseAggressive raises at least as often as TightAggressive, over many
  hands) — not just "these are different classes" but "these actually
  play differently."
- `poker_engine/ai/profiles.py` — `TournamentAI` (loosens thresholds as
  the stack-to-pot ratio shrinks, approximating push/fold pressure) and
  `CashGameAI` (fixed thresholds — no elimination clock, no reason to
  widen as a stack shrinks).
- `poker_engine/ai/monte_carlo_ai.py` — `MonteCarloAI`: decides from real
  simulated equity against a random range instead of the heuristic,
  falling back to the cheap preflop heuristic before the flop (simulating
  a board that hasn't been dealt yet buys nothing).
- `poker_engine/ai/pluggable.py` — `PolicyTableAI` (CFR-shaped: samples
  from an externally supplied `state -> {action: probability}` function)
  and `CallableModelAI` (NN-shaped: `state_to_features` + a
  `features -> {action: score}` predict function). Neither trains a real
  strategy — that's out of scope for a rules engine — both exist to prove
  the seam works: an external strategy, however it was produced, drives
  `choose_action` through nothing but the standard `AIPlayer` interface.
- 112 new tests (unit, edge-case, property-based, and integration tests
  playing real hands across multiple variants with mixed archetypes —
  including a six-archetype hand and a MonteCarloAI-vs-TournamentAI
  session spanning 8 sequential hands), bringing the suite to 786 tests /
  98% overall coverage.

### Three real issues caught by writing this phase's own tests

None of these were bugs in the sense of "wrong pot math" — they were
weaknesses in newly-built, inherently-approximate logic that the act of
writing tests against exposed, exactly as intended.

1. **The preflop heuristic ranked hands in a genuinely wrong order
   twice.** First pass: `AA` and `AKs` both capped at exactly `1.0`,
   losing a distinction basic enough that no poker player would accept
   it. Second pass, after rebalancing the first: a pair of deuces scored
   *below* unsuited `7-2` — the single worst-regarded starting hand in
   poker — because the pair bonus wasn't large enough to overcome two
   merely-mediocre unpaired ranks. Both were caught by writing the
   direct, obvious test ("does AA beat AKs", "does any pair beat weak
   unpaired cards") rather than only testing that the function returns
   *a* number in `[0, 1]`. The fix both times was recalibrating constants
   the docstring already called "deliberately simple" — worth doing
   anyway, since even an approximate heuristic should get the
   uncontroversial cases right.
2. **`TournamentAI`'s first draft mutated shared state to adjust
   thresholds.** It wrapped a `TightAggressive` instance and temporarily
   overwrote its `FOLD_THRESHOLD`/`RAISE_THRESHOLD` class attributes
   inside a `try/finally`, restoring them after each decision. This
   would have worked correctly for the single-sequential-turn model this
   engine uses — nothing was actually broken — but it's a real design
   smell: mutating an object another part of the code might also be
   holding a reference to, for a purely local, temporary adjustment. Caught
   by re-reading the diff before writing tests against it, not by a
   failing test; rewritten to parameterize the thresholds directly
   instead of wrapping-and-mutating another `AIPlayer` instance.
3. **A property test's own loop-guard checked the wrong condition.**
   `table.occupied_count() < 2` (seated players) instead of
   `len(table.active_player_ids()) < 2` (players actually able to play) —
   a player who'd busted to 0 chips stayed seated, so the guard let the
   loop try to start a new hand with only one ACTIVE player, and
   `start_hand()` correctly rejected it. This was a bug in the *test*, not
   the engine (`start_hand()`'s own validation was exactly right) — but
   it's the same category of mistake Phase 8 and Phase 9 both found in
   production code: checking a broader, easier-to-reach-for condition
   than the one that's actually load-bearing.

## Notes for the next session

- Phase 11 (Statistics + Hand History + Replay) is next. The AI framework
  gives it something to generate statistics FROM: running many archetype
  matchups (already proven to terminate and conserve chips reliably via
  this phase's property tests) is a natural way to produce realistic hand
  volume for VPIP/PFR/aggression-factor/BB-100 calculations to validate
  against, rather than needing hand-written fixture hands for everything.
- `GameStateView` and `AIDecision` are close to, but not quite, a hand
  history record — a `GameStateView` at each decision point plus the
  `AIDecision` taken is most of what a replay engine needs per action,
  missing only a timestamp/sequence-number and the eventual hand outcome.
  Worth checking whether Phase 11's hand-history format can be built
  as a thin wrapper around data these two classes already carry, rather
  than a parallel representation invented from scratch.
- The equity calculator's real throughput (~2,000 simulations/second,
  bottlenecked by `evaluate_best_of`'s repeated `evaluate_5` calls over
  C(7,5) combinations) is the same bottleneck this project has deferred
  since Phase 1's benchmark script first measured it. Every phase since
  has had a reason not to prioritize the lookup-table optimisation
  because nothing was calling the evaluator enough times in a tight loop
  to make it urgent; Phase 10's Monte Carlo simulation is the first
  caller for which it plausibly IS urgent (the spec's own "millions of
  simulations" framing). If Phase 11's statistics engine or any later
  phase needs genuinely large-scale simulation throughput, this is the
  natural point to finally revisit it, now that there's a caller whose
  performance actually depends on it — rather than continuing to defer
  the optimisation to yet another future phase with the same reasoning.
